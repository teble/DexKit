# Android optimization-level size comparison

Use the current retained Small14 combination with UNCACHED_DESCRIPTORS and
RAW_DESCRIPTOR_LOOKUP. The source matches the previously validated engine;
no production source or default configuration changes are required.

1. Preserve the existing Oz AAR and configuration. Record source identity,
   NDK/CMake/Gradle identity, and the comparison driver. The Gradle init script
   changes only C/C++ Release optimization from Oz to O3, O2, Os, or Oz.
   Keep full LTO, section garbage collection, symbol stripping, C++ runtime,
   minSdk, sixteen experimental switches, and 16 KiB maximum page size fixed.
2. Run :dexkit-android:assembleRelease for all four levels and all four ABIs.
   Archive each AAR immediately. Finish with Oz to restore the existing output.
3. Inspect actual AAR ELF members, compile/link commands, exports, dependencies,
   load alignment, and unchanged non-native AAR contents. Compare installed
   library bytes, compressed bytes, section sizes and complete AAR size.
4. Save a table and reproducible evidence. Keep generated AAR/SO files outside
   git and provide their absolute paths. Runtime performance is excluded from
   this round at the user's request; do not infer speed or process memory from
   code size. ADB initially listed no devices.
