"""Compare actual packaged Android ELF files, keeping runtime claims separate."""
import hashlib
import json
import re
import shlex
import subprocess
import zipfile
from pathlib import Path

ROOT = Path('/Users/teble/project/android/DexKit-qaux-benchmark')
OUT = Path(__file__).resolve().parent
BIN = Path('/Users/teble/Library/Android/sdk/ndk/26.1.10909125/toolchains/llvm/prebuilt/darwin-x86_64/bin')
LEVELS = ['O3', 'O2', 'Os', 'Oz']
ABIS = ['arm64-v8a', 'armeabi-v7a', 'x86', 'x86_64']
MACHINES = {'arm64-v8a': 'AArch64', 'armeabi-v7a': 'ARM', 'x86': 'Intel 80386',
            'x86_64': 'Advanced Micro Devices X86-64'}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')


def normalized(command):
    tokens = shlex.split(command)
    positions = [i for i, token in enumerate(tokens) if re.fullmatch('-O[0123sgz]', token)]
    assert positions
    tokens[positions[-1]] = '-O<LEVEL>'
    return [re.sub(r'(/(?:\.cxx|intermediates/cxx)/Release/)[^/]+', r'\1<CONFIG>', t) for t in tokens]


complete = json.loads((OUT / 'complete.json').read_text())
assert complete['levels'] == 4 and complete['android_libraries'] == 16 and complete['source_unchanged']
plan = json.loads((OUT / 'frozen-build-plan.json').read_text())
for path, expected in plan['files'].items():
    assert sha(path) == expected, 'Frozen input changed: ' + path

results = []
aar_results = []
non_native_reference = None
compiled_reference = {}
linked_reference = {}
exports_reference = {}
needed_reference = {}
baseline_native = {}
with zipfile.ZipFile(OUT / 'baseline/dexkit-android-release.aar') as archive:
    for abi in ABIS:
        baseline_native[abi] = digest(archive.read('jni/' + abi + '/libdexkit.so'))

for level in LEVELS:
    target = OUT / 'artifacts' / level
    build = json.loads((target / 'build-result.json').read_text())
    aar = Path(build['aar'])
    assert sha(aar) == build['aar_sha256']
    with zipfile.ZipFile(aar) as archive:
        assert archive.testzip() is None
        non_native = {n: digest(archive.read(n)) for n in archive.namelist() if not n.startswith('jni/')}
        if non_native_reference is None:
            non_native_reference = non_native
        assert non_native == non_native_reference, 'Non-native AAR payload differs: ' + level
        packaged_bytes = 0
        raw_bytes = 0
        for abi in ABIS:
            member = 'jni/' + abi + '/libdexkit.so'
            info = archive.getinfo(member)
            library = target / member
            assert sha(library) == digest(archive.read(member))
            assert library.stat().st_size == info.file_size
            packaged_bytes += info.compress_size
            raw_bytes += info.file_size
            evidence = target / 'configuration' / abi
            sections_raw = subprocess.check_output([str(BIN / 'llvm-size'), '--format=sysv', str(library)], text=True)
            elf_raw = subprocess.check_output([str(BIN / 'llvm-readelf'), '-h', '-l', '-S', '-d', '-W', str(library)], text=True)
            symbols_raw = subprocess.check_output([str(BIN / 'llvm-nm'), '--dynamic', '--defined-only', '--extern-only',
                                                   '--format=posix', str(library)], text=True)
            (evidence / 'sections.txt').write_text(sections_raw)
            (evidence / 'elf.txt').write_text(elf_raw)
            (evidence / 'exports.txt').write_text(symbols_raw)
            sections = {}
            for line in sections_raw.splitlines():
                match = re.fullmatch(r'(\.[^\s]+)\s+(\d+)\s+(\d+)\s*', line)
                if match:
                    sections[match[1]] = int(match[2])
            assert sections.get('.text', 0) > 0
            assert not any(name.startswith('.debug') or name == '.symtab' for name in sections)
            assert not re.search(r'\s\.symtab\s', elf_raw) and not re.search(r'\s\.debug\w*\s', elf_raw)
            machine = re.search(r'^\s*Machine:\s+(.+)$', elf_raw, re.M)[1].strip()
            assert machine == MACHINES[abi], (abi, machine)
            assert 'DYN (Shared object file)' in elf_raw
            loads = []
            for line in elf_raw.splitlines():
                parts = line.split()
                if parts and parts[0] == 'LOAD':
                    row = dict(offset=int(parts[1], 16), vaddr=int(parts[2], 16),
                               file_bytes=int(parts[4], 16), memory_bytes=int(parts[5], 16),
                               flags=' '.join(parts[6:-1]), alignment=int(parts[-1], 16))
                    assert row['alignment'] == 16384
                    assert row['offset'] % row['alignment'] == row['vaddr'] % row['alignment']
                    loads.append(row)
            assert loads
            exports = sorted(' '.join(line.split()[:2]) for line in symbols_raw.splitlines() if line.strip())
            assert sum(name.startswith('Java_') for name in exports) == 34
            needed = sorted(re.findall(r'\(NEEDED\).*?\[([^\]]+)\]', elf_raw))
            assert needed
            assert re.search(r'\(SONAME\).*?\[libdexkit\.so\]', elf_raw)
            exports_reference.setdefault(abi, exports)
            needed_reference.setdefault(abi, needed)
            assert exports == exports_reference[abi], (level, abi, 'exports')
            assert needed == needed_reference[abi], (level, abi, 'dependencies')
            compiled = json.loads((evidence / 'compile_commands.json').read_text())
            normalized_compiled = {row['file']: normalized(row['command']) for row in compiled}
            compiled_reference.setdefault(abi, normalized_compiled)
            assert normalized_compiled == compiled_reference[abi], (level, abi, 'compile options other than optimization')
            links = [line for line in (evidence / 'ninja-commands.txt').read_text().splitlines()
                     if ' -shared ' in line and 'libdexkit.so' in line]
            assert len(links) == 1
            normalized_link = normalized(links[0])
            linked_reference.setdefault(abi, normalized_link)
            assert normalized_link == linked_reference[abi], (level, abi, 'link options other than optimization')
            results.append(dict(level=level, abi=abi, path=str(library), sha256=sha(library),
                                file_bytes=info.file_size, aar_compressed_bytes=info.compress_size,
                                zip_compression_type=info.compress_type, sections=sections,
                                section_total_bytes=sum(sections.values()), machine=machine, loads=loads,
                                exported_symbols=exports, needed_libraries=needed,
                                baseline_Oz_identical=(sha(library) == baseline_native[abi]) if level == 'Oz' else None))
    aar_results.append(dict(level=level, path=str(aar), bytes=aar.stat().st_size, sha256=sha(aar),
                            native_uncompressed_bytes=raw_bytes, native_compressed_bytes=packaged_bytes,
                            non_native_payload_sha256=non_native))

by_key = {(r['abi'], r['level']): r for r in results}
for row in results:
    row['change_from_Oz_percent'] = (row['file_bytes'] / by_key[(row['abi'], 'Oz')]['file_bytes'] - 1) * 100
    row['change_from_O3_percent'] = (row['file_bytes'] / by_key[(row['abi'], 'O3')]['file_bytes'] - 1) * 100
summary = dict(source_commit=plan['source_commit'], native_engine_commit=plan['native_engine_commit'],
               frozen_plan_sha256=sha(OUT / 'frozen-build-plan.json'), libraries=results, aars=aar_results,
               verification=dict(source_unchanged=True, effective_optimization_levels_checked=True,
                                 compile_and_link_flags_match_except_optimization=True,
                                 non_native_AAR_contents_identical=True, exported_API_and_dependencies_match=True,
                                 all_ELF_libraries_stripped=True, all_LOAD_alignment_16KiB=True,
                                 original_Oz_native_reproduced=all(by_key[(abi, 'Oz')]['baseline_Oz_identical'] for abi in ABIS),
                                 original_Oz_AAR_reproduced=complete['original_Oz_aar_reproduced'],
                                 Android_runtime_tested=False))
save(OUT / 'summary.json', summary)

def kib(value):
    return '%.2f' % (value / 1024)


lines = ['# Android optimization-level size comparison', '',
         'This compares the current retained optimization combination plus uncached',
         'member descriptors at four compiler optimization levels. The packaged Android',
         'Release configuration was already `-Oz`. Only the effective C/C++ Release',
         'optimization flag changes; full LTO remains enabled at all four levels.', '',
         '## Packaged shared-library sizes', '',
         'Sizes below are the stripped `jni/<abi>/libdexkit.so` members extracted from',
         'the actual Gradle AARs. KiB means 1024 bytes. File size is not runtime RSS/PSS.', '',
         '| ABI | O3 KiB | O2 KiB | Os KiB | Oz KiB | Oz versus O3 |',
         '| --- | ---: | ---: | ---: | ---: | ---: |']
for abi in ABIS:
    cells = [kib(by_key[(abi, level)]['file_bytes']) for level in LEVELS]
    lines.append('| ' + abi + ' | ' + ' | '.join(cells) + ' | %+.2f%% |' % by_key[(abi, 'Oz')]['change_from_O3_percent'])
lines += ['', 'Exact standalone SO file bytes:', '',
          '| ABI | O3 bytes | O2 bytes | Os bytes | Oz bytes |',
          '| --- | ---: | ---: | ---: | ---: |']
for abi in ABIS:
    lines.append('| ' + abi + ' | ' + ' | '.join(str(by_key[(abi, level)]['file_bytes']) for level in LEVELS) + ' |')
lines += ['', 'Each SO relative to the existing Oz configuration:', '',
          '| ABI | O3 versus Oz | O2 versus Oz | Os versus Oz |',
          '| --- | ---: | ---: | ---: |']
for abi in ABIS:
    lines.append('| ' + abi + ' | ' + ' | '.join('%+.2f%%' % by_key[(abi, level)]['change_from_Oz_percent']
                  for level in ['O3', 'O2', 'Os']) + ' |')
lines += ['', '## Selected ELF sections', '',
          'These are section byte sizes, not a measurement of resident process memory.',
          'The full section list and load segments are retained in the evidence.', '',
          '| ABI | Level | .text KiB | .rodata KiB | .data + .data.rel.ro KiB | .bss KiB | Unwind tables KiB |',
          '| --- | --- | ---: | ---: | ---: | ---: | ---: |']
for abi in ABIS:
    for level in LEVELS:
        s = by_key[(abi, level)]['sections']
        unwind = sum(s.get(k, 0) for k in ['.eh_frame', '.eh_frame_hdr', '.ARM.exidx', '.ARM.extab'])
        lines.append('| %s | %s | %s | %s | %s | %s | %s |' % (abi, level, kib(s['.text']), kib(s.get('.rodata', 0)),
                     kib(s.get('.data', 0) + s.get('.data.rel.ro', 0)), kib(s.get('.bss', 0)), kib(unwind)))
lines += ['', '## Fixed inputs and checks', '',
          '- Native engine: `' + plan['native_engine_commit'] + '`; source snapshot: `' + plan['source_commit'] + '`.',
          '- NDK `26.1.10909125`, minSdk 21, full LTO, section garbage collection,',
          '  stripped symbols, the same C++ runtime, and 16 KiB load alignment.',
          '- All sixteen retained experimental switches match the prior validated',
          '  uncached build. Diagnostics and internal metrics remain disabled.',
          '- All 16 libraries were built by `:dexkit-android:assembleRelease`.',
          '  Every realized compile and link command was checked. After normalizing',
          '  generated build-directory names, they differ only in the selected final',
          '  optimization flag. Earlier NDK default `-O3` arguments are overridden',
          '  by the final selected argument; checking the effective final flag avoids',
          '  mistaking the earlier default for the active optimization level.',
          '- All libraries are stripped ELF shared objects of the expected machine',
          '  type, export the same 34 JNI entry points, retain the same dependencies',
          '  per ABI, and preserve 16 KiB PT_LOAD alignment.',
          '- Non-native AAR members are byte-identical across the four variants.',
          '- Native Oz matches the previously saved baseline: `' + str(summary['verification']['original_Oz_native_reproduced']).lower() + '`.',
          '- Complete Oz AAR matches the previously saved baseline: `' + str(complete['original_Oz_aar_reproduced']).lower() + '`.',
          '- The normal Gradle output is left at Oz; production defaults are unchanged.',
          '- At the user\'s request, this round measures size only. No Android runtime',
          '  timing or runtime correctness test was performed for these compiler',
          '  variants. The results do not establish which level executes fastest.', '',
          '## Artifacts and reproduction', '']
for row in aar_results:
    lines += ['- `' + row['level'] + '`: [' + Path(row['path']).name + '](' + row['path'] + ')',
              '  SHA256 `' + row['sha256'] + '`.']
lines += ['', 'Extracted SOs are alongside each AAR under `jni/<abi>/libdexkit.so`.',
          'The [evidence directory](evidence/android-optimization-levels/v1/) records',
          'the frozen source plan, exact Gradle commands, init script, CMake caches,',
          'compile/link commands, ELF inspection output, hashes and size summaries.',
          'Compiled AAR/SO files are local artifacts and are excluded from git.', '']
assert all(ord(c) < 128 for c in '\n'.join(lines))
report = ROOT / 'tools/qaux-benchmark/ANDROID-OPTIMIZATION-LEVELS.md'
report.write_text('\n'.join(lines))
print(report)
for abi in ABIS:
    print(abi, {level: kib(by_key[(abi, level)]['file_bytes']) for level in LEVELS})
for row in aar_results:
    print('AAR', row['level'], row['bytes'], '%.3f MiB' % (row['bytes'] / 2**20))
print(json.dumps(summary['verification'], indent=2))
