"""Archive the Android build/size evidence, excluding local compiled artifacts."""
import hashlib
import json
import shutil
import tarfile
from pathlib import Path

ROOT = Path('/Users/teble/project/android/DexKit-qaux-benchmark')
OUT = Path(__file__).resolve().parent
DEST = ROOT / 'tools/qaux-benchmark/evidence/android-optimization-levels/v1'
REPORT = ROOT / 'tools/qaux-benchmark/ANDROID-OPTIMIZATION-LEVELS.md'


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


assert not DEST.exists(), 'Do not overwrite an archived comparison'
summary = json.loads((OUT / 'summary.json').read_text())
assert len(summary['libraries']) == 16 and len(summary['aars']) == 4
assert summary['verification']['compile_and_link_flags_match_except_optimization']
for row in summary['libraries'] + summary['aars']:
    assert sha(row['path']) == row['sha256']
files = {'ANDROID-OPTIMIZATION-LEVELS.md': REPORT}
for path in OUT.rglob('*'):
    if path.is_file() and path.suffix in ['.py', '.gradle', '.md', '.json', '.txt', '.log', '.ninja']:
        files['run/' + path.relative_to(OUT).as_posix()] = path
assert not any(p.suffix in ['.aar', '.so', '.jar', '.class', '.o', '.a'] for p in files.values())
members = {name: dict(sha256=sha(path), size=path.stat().st_size) for name, path in sorted(files.items())}
DEST.mkdir(parents=True)
archive = DEST / 'raw-evidence.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for name, path in sorted(files.items()):
        tar.add(path, arcname=name, recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    assert set(tar.getnames()) == set(members)
    for item in tar.getmembers():
        with tar.extractfile(item) as stream:
            data = stream.read()
        assert hashlib.sha256(data).hexdigest() == members[item.name]['sha256']
        assert len(data) == members[item.name]['size']
metadata = dict(archive=archive.name, archive_sha256=sha(archive),
                archive_bytes=archive.stat().st_size, member_count=len(members),
                every_member_read_back_and_verified=True)
save(DEST / 'manifest.json', dict(metadata, members=members))
save(DEST / 'integrity.json', metadata)
for name in ['summary.json', 'frozen-build-plan.json', 'complete.json']:
    shutil.copyfile(OUT / name, DEST / name)
save(DEST / 'source-identity.json', dict(source_commit=summary['source_commit'],
                                       native_engine_commit=summary['native_engine_commit'],
                                       frozen_plan_sha256=sha(OUT / 'frozen-build-plan.json'),
                                       report_sha256=sha(REPORT)))
print(json.dumps(metadata, indent=2))
