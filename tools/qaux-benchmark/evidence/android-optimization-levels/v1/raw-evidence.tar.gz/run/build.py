"""Build real Android AARs while changing only the Release optimization flag."""
import datetime
import hashlib
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path

ROOT = Path('/Users/teble/project/android/DexKit-qaux-benchmark')
OUT = Path(__file__).resolve().parent
OLD = OUT.parent / 'uncached-descriptors-v1/validation/gradle'
SDK = Path('/Users/teble/Library/Android/sdk')
NDK = SDK / 'ndk/26.1.10909125'
JDK = Path('/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home')
ABIS = ['arm64-v8a', 'armeabi-v7a', 'x86', 'x86_64']
LEVELS = ['O3', 'O2', 'Os', 'Oz']
AAR = ROOT / 'dexkit-android/build/outputs/aar/dexkit-android-release.aar'


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def save(path, obj):
    path.write_text(json.dumps(obj, indent=2) + '\n')


def cache_options(path):
    values = {}
    for line in path.read_text().splitlines():
        if line and not line.startswith(('#', '//')) and ':' in line and '=' in line:
            key, value = line.split('=', 1)
            values[key.split(':')[0]] = value
    return values


def assert_frozen(plan):
    for path, expected in plan['files'].items():
        assert sha(path) == expected, 'Frozen source changed: ' + path


old = json.loads((OLD / 'validation.json').read_text())
props = [item for item in old['command'] if item.startswith('-Pexperiment')]
env = os.environ.copy()
env.update(JAVA_HOME=str(JDK), ANDROID_HOME=str(SDK), ANDROID_SDK_ROOT=str(SDK),
           CMAKE_BUILD_PARALLEL_LEVEL='3')
plan_path = OUT / 'frozen-build-plan.json'

if not plan_path.exists():
    assert not subprocess.check_output(['git', '-C', ROOT, 'status', '--porcelain'], text=True).strip()
    previous_aar = OLD / 'dexkit-android-release.aar'
    assert sha(previous_aar) == old['aar_sha256']
    if AAR.exists():
        assert sha(AAR) == old['aar_sha256']
    baseline = OUT / 'baseline'
    baseline.mkdir()
    shutil.copyfile(previous_aar, baseline / AAR.name)
    shutil.copyfile(OLD / 'validation.json', baseline / 'validation.json')
    for abi in ABIS:
        shutil.copyfile(OLD / (abi + '-CMakeCache.txt'), baseline / (abi + '-CMakeCache.txt'))
    tracked = subprocess.check_output(['git', '-C', ROOT, 'ls-files', '--',
                 'Core', 'schema', 'dexkit/src/main', 'dexkit-android', 'build.gradle',
                 'settings.gradle', 'gradle.properties', 'gradle/wrapper'], text=True).splitlines()
    paths = [ROOT / p for p in tracked if (ROOT / p).is_file()]
    paths += [Path(__file__), OUT / 'optimization.gradle', OUT / 'PLAN.md',
              NDK / 'source.properties', NDK / 'toolchains/llvm/prebuilt/darwin-x86_64/bin/clang++']
    plan = dict(source_commit=subprocess.check_output(['git', '-C', ROOT, 'rev-parse', 'HEAD'], text=True).strip(),
                frozen_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                native_engine_commit='2be1a63f1ac9de56f6e5cd53123322388e598006',
                levels=LEVELS, abis=ABIS, existing_aar_sha256=old['aar_sha256'],
                original_output_present=AAR.exists(), baseline_aar_source=str(previous_aar),
                compiler=subprocess.check_output([str(NDK / 'toolchains/llvm/prebuilt/darwin-x86_64/bin/clang++'), '--version'], text=True),
                gradle_properties=props, files={str(p): sha(p) for p in sorted(set(paths))})
    assert not subprocess.check_output(['git', '-C', ROOT, 'diff', plan['native_engine_commit'], 'HEAD',
                                        '--', 'Core', 'dexkit/src/main', 'dexkit-android', 'schema'], text=True)
    save(plan_path, plan)
else:
    plan = json.loads(plan_path.read_text())
assert_frozen(plan)

completed_path = OUT / 'completed.json'
completed = json.loads(completed_path.read_text()) if completed_path.exists() else []
for level in LEVELS:
    if any(row['level'] == level for row in completed):
        continue
    target = OUT / 'artifacts' / level
    target.mkdir(parents=True, exist_ok=False)
    command = ['bash', './gradlew', ':dexkit-android:assembleRelease', '--max-workers=2',
               '--console=plain', '-I', str(OUT / 'optimization.gradle'),
               '-PbenchmarkAndroidOptimization=' + level, *props]
    save(target / 'command.json', dict(command=command, environment={key: env[key] for key in
                                     ['JAVA_HOME', 'ANDROID_HOME', 'ANDROID_SDK_ROOT', 'CMAKE_BUILD_PARALLEL_LEVEL']}))
    print('START ' + level, flush=True)
    started = time.monotonic()
    with (target / 'build.log').open('w') as log:
        result = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
    if result.returncode:
        save(target / 'failure.json', dict(exit_code=result.returncode))
        print((target / 'build.log').read_text()[-9000:], flush=True)
        raise SystemExit(result.returncode)
    assert_frozen(plan)
    output = target / ('dexkit-android-' + level + '-release.aar')
    shutil.copyfile(AAR, output)
    with zipfile.ZipFile(output) as archive:
        libs = [name for name in archive.namelist() if name.startswith('jni/') and name.endswith('/libdexkit.so')]
        assert sorted(name.split('/')[1] for name in libs) == ABIS
        for name in libs:
            dest = target / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(archive.read(name))
    caches = []
    for abi in ABIS:
        candidates = []
        for path in (ROOT / 'dexkit-android/.cxx/Release').glob('*/' + abi + '/CMakeCache.txt'):
            options = cache_options(path)
            if (options.get('CMAKE_CXX_FLAGS_RELEASE') == '-' + level + ' -DNDEBUG'
                    and options.get('DEXKIT_EXPERIMENT_UNCACHED_DESCRIPTORS') == 'ON'
                    and options.get('DEXKIT_EXPERIMENT_COMPACT_CALLERS') == 'ON'):
                candidates.append(path)
        assert candidates, (level, abi)
        source = max(candidates, key=lambda p: p.stat().st_mtime)
        cache = cache_options(source)
        baseline = cache_options(OUT / 'baseline' / (abi + '-CMakeCache.txt'))
        keys = [k for k in baseline if k.startswith('DEXKIT_')]
        assert all(cache.get(k) == baseline[k] for k in keys), (level, abi, 'experiment configuration')
        assert cache['CMAKE_C_FLAGS_RELEASE'] == '-' + level + ' -DNDEBUG'
        evidence = target / 'configuration' / abi
        evidence.mkdir(parents=True)
        for name in ['CMakeCache.txt', 'compile_commands.json', 'metadata_generation_command.txt', 'build.ninja']:
            shutil.copyfile(source.parent / name, evidence / name)
        compiled = json.loads((evidence / 'compile_commands.json').read_text())
        for item in compiled:
            tokens = shlex.split(item['command'])
            opts = [token for token in tokens if re.fullmatch(r'-O[0123sgz]', token)]
            assert opts and opts[-1] == '-' + level, (level, abi, item['file'], opts)
            for flag in ['-flto=full', '-fno-exceptions', '-fno-rtti', '-Wl,--strip-all', '-Wl,-z,max-page-size=16384']:
                assert flag in tokens, (level, abi, flag)
        ninja = cache['CMAKE_MAKE_PROGRAM']
        commands = subprocess.check_output([ninja, '-C', str(source.parent), '-t', 'commands', 'dexkit'], text=True)
        (evidence / 'ninja-commands.txt').write_text(commands)
        links = [line for line in commands.splitlines() if ' -shared ' in line and 'libdexkit.so' in line]
        assert len(links) == 1, (level, abi, 'link command')
        opts = re.findall(r'(?<!\S)-O[0123sgz](?!\S)', links[0])
        assert opts and opts[-1] == '-' + level
        for flag in ['-flto=full', '-Wl,--gc-sections', '-Wl,--strip-all', '-Wl,-z,max-page-size=16384']:
            assert flag in links[0]
        caches.append(dict(abi=abi, source=str(source), cache_sha256=sha(source),
                           translation_units=len(compiled), optimization_flags=opts))
    record = dict(level=level, aar=str(output), aar_sha256=sha(output), aar_bytes=output.stat().st_size,
                  build_wall_seconds=time.monotonic() - started, configurations=caches)
    save(target / 'build-result.json', record)
    completed.append(record)
    save(completed_path, completed)
    print('DONE ' + level + ' AAR=' + str(output.stat().st_size) + ' bytes; effective compile/link flags verified for four ABIs', flush=True)

assert_frozen(plan)
assert len(completed) == 4
save(OUT / 'complete.json', dict(levels=4, android_libraries=16, source_unchanged=True,
                                final_output_level='Oz', aar_sha256=sha(AAR),
                                original_Oz_aar_reproduced=sha(AAR) == old['aar_sha256']))
print('COMPLETE: 16 Android libraries / four AARs; source unchanged', flush=True)
