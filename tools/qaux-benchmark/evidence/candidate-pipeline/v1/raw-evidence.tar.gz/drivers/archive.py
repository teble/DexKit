import hashlib,json,shutil,subprocess,tarfile
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark');BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55');E=BASE/'candidate-pipeline-v1';OLD=BASE/'string-admission-v1'
REV='82d6afb49d9faa5e49ee899ae948675d490ac99a';out=ROOT/'tools/qaux-benchmark/evidence/candidate-pipeline/v1'
out.mkdir(parents=True,exist_ok=True);assert not any(out.iterdir())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
summary=json.loads((E/'formal-v2/summary.json').read_text());assert summary['sweeps']==52 and summary['samples']==624
for name in ['summary.json','validation-summary.json','diagnostics-summary.json','source-identity.json','measurement-integrity.json','adapter-target-correction.json']:
 shutil.copyfile(E/'formal-v2'/name,out/name)
files={}
def add(path,name):
 assert path.is_file() and not path.is_symlink() and name not in files,(path,name)
 files[name]=path
for path in sorted((E/'formal-v2').rglob('*')):
 if path.is_file() and path.suffix not in ['.class','.aar','.jar','.dylib','.so','.a','.o'] and path.name!='checks':add(path,str(path.relative_to(E)))
for artifact in sorted((E/'artifacts-v2').iterdir()):
 m=json.loads((artifact/'artifact.json').read_text());assert m['native_sha256']==sha(artifact/'libdexkit.dylib')
 for name in ['artifact.json','CMakeCache.txt','source.patch','build.log']:
  if (artifact/name).is_file():add(artifact/name,str((artifact/name).relative_to(E)))
# The first failed Android attempt and its actual source revision remain visible.
add(E/'formal/gradle-v1/build.log','historical-9227210/gradle-v1-build.log')
for path in sorted((E/'artifacts').glob('*/artifact.json')):add(path,'historical-9227210/'+str(path.relative_to(E)))
for name in ['build-normal-queue.json','build-extra-queue.json','validation-normal-queue.json','validation-extra-queue.json']:
 add(E/'formal'/name,'historical-9227210/formal/'+name)
for path in sorted(E.glob('*.py')):add(path,'drivers/'+path.name)
add(E/'review-draft.md','review-scope.md')
for path in sorted((E/'fixtures').rglob('*')):
 if path.is_file():add(path,'fixtures/'+str(path.relative_to(E/'fixtures')))
shared={'admission-final':OLD/'fixtures/admission-final','multidex':OLD/'fixtures/multidex','cross-range':OLD/'fixtures/cross-range','reordered':OLD/'fixtures/reordered',
 'strings-correctness-v1':BASE/'next-round/fixtures/strings-correctness-v1','strings-correctness-wide-v1':BASE/'next-round/fixtures/strings-correctness-wide-v1',
 'old-nested-broad':BASE/'string-inverse-v2/fixtures/broad','old-integration':BASE/'string-inverse-v2/fixtures/integration','budget':BASE/'string-inverse-v1/fixtures/budget'}
for name,directory in shared.items():
 for path in sorted(directory.iterdir()):
  if path.is_file():add(path,'shared-fixtures/'+name+'/'+path.name)
for name in ['artifact.json','CMakeCache.txt','source.patch','build.log']:
 add(OLD/'artifacts/small'/name,'old-small-engine/'+name)
for name in ['run-metadata.json','report.json','run.log','gc.log']:
 add(OLD/'formal/verify-small'/name,'old-small-verification/'+name)
names=['build_native.py','run.py','sweep.py','workload_sweep.py','QueryReplay.java','force_tests.gradle',
 'make_symbol_fixture.py','make_string_fixture.py','make_relation_fixture.py','make_batch_fixture.py','make_string_inverse_fixture.py',
 'string_queries.h','string_checks.cpp','string_workload.cpp','batch_queries.h','batch_checks.cpp','batch_workload.cpp',
 'validate_string_checks.py','validate_batch_checks.py','inverted_string_checks.cpp','inverted_string_budget_checks.cpp','string_inverse_integration_checks.cpp',
 'make_string_admission_fixture.py','string_admission_queries.h','string_admission_workload.cpp','string_admission_checks.cpp','validate_string_admission.py',
 'make_string_admission_cross_fixture.py','string_admission_cross_dex_checks.cpp',
 'candidate_runtime_checks.cpp','candidate_noexceptions_checks.cpp','candidate_pipeline_checks.cpp','candidate_integration_checks.cpp','candidate_workload.cpp','make_candidate_fixture.py','make_candidate_skew_fixture.py']
for name in names:
 path=E/'archived-sources'/name;path.parent.mkdir(parents=True,exist_ok=True)
 path.write_bytes(subprocess.check_output(['git','-C',str(ROOT),'show',REV+':tools/qaux-benchmark/'+name]))
 if name!='workload_sweep.py':assert path.read_bytes()==(ROOT/'tools/qaux-benchmark'/name).read_bytes(),name
 add(path,'frozen-source/'+name)
add(ROOT/'tools/qaux-benchmark/workload_sweep.py','final-input-guard/workload_sweep.py')
add(ROOT/'tools/qaux-benchmark/baseline/expected.json','frozen-qq-expected.json')
for name in ['CANDIDATE-PIPELINE-EXECUTION.md','CANDIDATE-PIPELINE-REVIEW.md','CANDIDATE-PIPELINE-RESULTS.md']:
 add(ROOT/'tools/qaux-benchmark'/name,'report/'+name)
archive=out/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name,path in sorted(files.items()):tar.add(path,arcname=name,recursive=False)
manifest=dict(version='v1',engine_commit=REV,accepted_sweeps=52,accepted_samples=624,excluded_sweeps=22,excluded_samples=264,
 archive_sha256=sha(archive),files={name:sha(path) for name,path in sorted(files.items())},
 scope='All accepted paired observations and deployment-target exclusions; seven final native builds plus frozen Small; final correctness, real-scheduler failure, sanitizer, JVM/four-ABI and QQ verification; historical Android no-exceptions failure; synthetic fixtures and exact reproduction sources. Proprietary QQ APK and compiled native/JVM/AAR binaries are excluded. The final Python guard only adds validation outside timed child execution.')
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive,'r:gz') as tar:
 assert set(tar.getnames())==set(files)
 for member in tar:
  assert member.isfile()
  assert hashlib.sha256(tar.extractfile(member).read()).hexdigest()==manifest['files'][member.name]
print(json.dumps(dict(files=len(files),bytes=archive.stat().st_size,sha256=manifest['archive_sha256'])),flush=True)
