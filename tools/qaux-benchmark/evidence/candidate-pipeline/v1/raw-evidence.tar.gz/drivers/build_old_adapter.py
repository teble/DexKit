import hashlib,json,shlex,shutil,subprocess
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
E=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/candidate-pipeline-v1')
old=E.parent/'string-admission-v1/artifacts/small'
out=E/'artifacts-v2/old-small';out.mkdir(parents=True)
manifest=json.loads((old/'artifact.json').read_text());opts=manifest['cmake_options']
exe=out/'build/Core/dexkit_candidate_workload';exe.parent.mkdir(parents=True)
cmd=[opts['CMAKE_CXX_COMPILER'],'-std=c++20','-pthread','-arch','arm64','-isysroot',subprocess.check_output(['xcrun','--show-sdk-path'],text=True).strip()]+shlex.split(opts['CMAKE_CXX_FLAGS_RELEASE'])
for k,v in opts.items():
 if k.startswith(('DEXKIT_EXPERIMENT_','DEXKIT_BENCHMARK_','DEXKIT_ENABLE_')):cmd+=['-D'+k+'='+{'ON':'1','OFF':'0'}.get(v,v)]
for directory in ['dexkit/include','third_party/slicer/export','third_party/thread_helper','third_party/aho_corasick_trie','third_party/parallel_hashmap','third_party/flatbuffers/include']:cmd+=['-I',str(ROOT/'Core'/directory)]
source=ROOT/'tools/qaux-benchmark/candidate_workload.cpp';archive=old/'build/Core/libdexkit_static.a';cmd+=[str(source),str(archive),'-lz','-o',str(exe)]
with (out/'build.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for f in ['libdexkit.dylib','build/Core/dexkit_string_workload','build/Core/dexkit_batch_workload']:shutil.copy2(old/f,out/f)
manifest['adapter']={'command':cmd,'archive_sha256':sha(archive),'native_artifact':str(old),'executable_sha256':sha(exe),'headers_use_only_unchanged_public_DexKit_API':True,
 'sources':{p:sha(ROOT/'tools/qaux-benchmark'/p) for p in ['candidate_workload.cpp','string_admission_queries.h','string_workload.cpp','string_queries.h']}}
(out/'artifact.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('BUILT old-small adapter',flush=True)
