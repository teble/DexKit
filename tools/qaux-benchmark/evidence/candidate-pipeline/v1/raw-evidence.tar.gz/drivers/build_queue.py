import concurrent.futures
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Users/teble/project/android/DexKit-qaux-benchmark')
DATA = Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/candidate-pipeline-v1')
JDK = '/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home'
NINE = ['LAZY_DIRECTORIES', 'COMPACT_STRINGS', 'NEGATIVE_STRINGS', 'STRUCTURAL_DESCRIPTORS',
        'DESCRIPTOR_FAST_HITS', 'RAW_INTERFACES', 'FIELD_IDENTITY_SPLIT', 'COMPACT_INVOKES', 'SINGLE_RELATION']
phase = sys.argv[1]
assert phase in ('normal', 'extra')
variants = [('control', 0, False, False, False), ('combined', 1, False, False, False),
            ('slices', 2, False, False, False)] if phase == 'normal' else [
            ('combined-trace', 1, True, False, False), ('slices-trace', 2, True, False, False),
            ('slices-sanitized', 2, True, True, False), ('slices-standalone', 2, True, False, True)]

def run(spec):
    name, mode, trace, sanitize, standalone = spec
    command = ['python3', 'tools/qaux-benchmark/build_native.py', '--source-root', str(ROOT),
               '--output', str(DATA/'artifacts'/name), '--java-home', JDK, '--jobs', '3']
    definitions = ['DEXKIT_BENCHMARK_STRING_WORKLOAD=ON', 'DEXKIT_BENCHMARK_BATCH_WORKLOAD=ON',
                   'DEXKIT_EXPERIMENT_INVERTED_STRINGS=ON', 'DEXKIT_EXPERIMENT_INVERTED_STRING_RANGES=ON']
    if not standalone:
        definitions += ['DEXKIT_EXPERIMENT_'+name+'=ON' for name in NINE]
    if mode:
        definitions += ['DEXKIT_EXPERIMENT_CANDIDATE_PIPELINE=ON']
    if mode == 2:
        definitions += ['DEXKIT_EXPERIMENT_CANDIDATE_SLICES=ON']
    if trace or sanitize or standalone:
        definitions += ['DEXKIT_BENCHMARK_DIAGNOSTICS=ON']
    if sanitize:
        flags = '-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer'
        definitions += ['CMAKE_C_FLAGS_RELEASE='+flags, 'CMAKE_CXX_FLAGS_RELEASE='+flags,
                        'CMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined',
                        'CMAKE_SHARED_LINKER_FLAGS=-fsanitize=address,undefined']
    for define in definitions:
        command += ['--define', define]
    print('START '+name, flush=True)
    with (DATA/'formal'/(name+'-build-launcher.log')).open('w') as log:
        subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=True)
    print('DONE '+name, flush=True)
    return {'name': name, 'command': command}

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    records = list(pool.map(run, variants))
(DATA/'formal'/('build-'+phase+'-queue.json')).write_text(json.dumps(records, indent=2)+'\n')
