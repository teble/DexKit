import hashlib,json,re,shlex,subprocess
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark');E=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/candidate-pipeline-v1');BASE=E.parent;OLD=BASE/'string-admission-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sdk=subprocess.check_output(['xcrun','--show-sdk-path'],text=True).strip()
for kind in ['budget','cross-range']:
 records=[]
 labels=['control','combined-trace','slices-trace','slices-sanitized'] if kind=='budget' else ['combined-trace','slices-trace','slices-sanitized','slices-standalone']
 expected=(OLD/'formal'/(kind+'-control')/'stdout.bin').read_bytes()
 for label in labels:
  a=E/'artifacts-v2'/label; out=E/'formal-v2'/(kind+'-'+label);out.mkdir()
  opts=json.loads((a/'artifact.json').read_text())['cmake_options']
  source=ROOT/'tools/qaux-benchmark'/('inverted_string_budget_checks.cpp' if kind=='budget' else 'string_admission_cross_dex_checks.cpp')
  fixture=BASE/'string-inverse-v1/fixtures/budget/strings.apk' if kind=='budget' else OLD/'fixtures/cross-range/strings.apk'
  archive=a/'build/Core/libdexkit_static.a';exe=out/'checks'
  cmd=[opts['CMAKE_CXX_COMPILER'],'-std=c++20','-pthread','-arch','arm64','-isysroot',sdk]+shlex.split(opts['CMAKE_CXX_FLAGS_RELEASE'])
  for k,v in opts.items():
   if k.startswith(('DEXKIT_EXPERIMENT_','DEXKIT_BENCHMARK_','DEXKIT_ENABLE_')):cmd+=['-D'+k+'='+{'ON':'1','OFF':'0'}.get(v,v)]
  for d in ['dexkit/include','third_party/slicer/export','third_party/thread_helper','third_party/aho_corasick_trie','third_party/parallel_hashmap','third_party/flatbuffers/include']:cmd+=['-I',str(ROOT/'Core'/d)]
  cmd+=[str(source),str(archive),'-lz','-o',str(exe)]
  print('START '+kind+' '+label,flush=True)
  with (out/'build.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
  with (out/'stdout.bin').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:subprocess.run([str(exe),str(fixture)],stdout=stdout,stderr=stderr,check=True,timeout=180)
  assert (out/'stdout.bin').read_bytes()==expected,(kind,label)
  if kind=='budget':
   log=(out/'stderr.log').read_text()
   for phase in [0,1]:
    section=log.split('BUDGET_BEGIN phase='+str(phase)+'\n')[1].split('BUDGET_END phase='+str(phase)+'\n')[0]
    assert 'BENCH_STRING_INVERSE' not in section
   assert len(re.findall(r'^BENCH_STRING_INVERSE_INDEX ',log,re.M))==(0 if label=='control' else 3)
  records.append(dict(label=label,source_sha256=sha(source),archive_sha256=sha(archive),executable_sha256=sha(exe),fixture_sha256=sha(fixture),ordered_bytes_sha256=sha(out/'stdout.bin'),compile=cmd,passed=True))
  print('DONE '+kind+' '+label,flush=True)
 (E/'formal-v2'/(kind+'-checks.json')).write_text(json.dumps(records,indent=2)+'\n')
records=[]
for kind in ['string','batch']:
 expected=(OLD/'formal'/('reordered-'+kind+'-small')/'stdout.bin').read_bytes()
 fixture=OLD/'fixtures/reordered/strings.apk'
 for label in ['control','combined','slices','slices-sanitized']:
  out=E/'formal-v2'/('reordered-'+kind+'-'+label);out.mkdir()
  exe=E/'artifacts-v2'/label/('build/Core/dexkit_'+kind+'_checks')
  print('START reordered '+kind+' '+label,flush=True)
  with (out/'stdout.bin').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:subprocess.run([str(exe),'--dump',str(fixture)],stdout=stdout,stderr=stderr,check=True,timeout=180)
  assert (out/'stdout.bin').read_bytes()==expected
  if kind=='string':
   rows=[json.loads(line) for line in re.findall(r'^STRING_RESULTS (.+)$',(out/'stderr.log').read_text(),re.M)]
   ids=[row[1] for r in rows if r['classes'] and r['variant']==1 for row in r['results'] if row[0]==0]
   assert ids==sorted(ids,reverse=True) and ids!=sorted(ids)
  records.append(dict(kind=kind,label=label,executable_sha256=sha(exe),fixture_sha256=sha(fixture),ordered_bytes_sha256=sha(out/'stdout.bin'),passed=True))
  print('DONE reordered '+kind+' '+label,flush=True)
(E/'formal-v2/reordered-checks.json').write_text(json.dumps(records,indent=2)+'\n')
