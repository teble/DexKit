import json,sys
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark');E=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/candidate-pipeline-v1')
sys.path.insert(0,str(ROOT/'tools/qaux-benchmark'))
from sweep import summarize
summaries={};stages={};total=0
for phase in ['main','confirm']:
 queue=json.loads((E/'formal-v2'/('measurement-'+phase+'-queue.json')).read_text());assert len(queue)==(36 if phase=='main' else 16)
 for item in queue:
  path=E/'formal-v2'/item['name'];result=json.loads((path/'summary.json').read_text());rows=json.loads((path/'samples.json').read_text())
  labels=item['labels'];assert len(rows)==12 and result['pairs']==6
  assert {(r['pair'],r['label']) for r in rows}=={(p,label) for p in range(6) for label in labels}
  summaries[item['name']]=dict(family=item['name'].split('-')[0],labels=labels,metrics=result['metrics']);total+=len(rows)
  if item['kind']!='qq':continue
  detail=[]
  for row in rows:
   report=json.loads((path/('pair-%02d-%s'%(row['pair'],row['label']))/'report.json').read_text())
   measured={'pair':row['pair'],'label':row['label'],'position':row['position']}
   for batch in [True,False]:
    for first in [True,False]:
     selected=[s for s in report['stages'] if (s['stage']=='batch_strings')==batch and (s['pass']==0)==first]
     if not selected:continue
     name=('batch' if batch else 'chains')+('_first_ms' if first else '_warm_per_pass_ms')
     if batch:assert all(s['group_count']==149 for s in selected)
     measured[name]=sum(s['api_ns'] for s in selected)/1e6/(1 if first else report['passes']-1)
   for stage in report['stages']:
    tag=stage['feature']+'__'+stage['stage']+('_first_ms' if stage['pass']==0 else '_warm_per_pass_ms')
    measured[tag]=measured.get(tag,0)+stage['api_ns']/1e6/(1 if stage['pass']==0 else report['passes']-1)
   detail.append(measured)
  stages[item['name']]={'rows':detail,'metrics':summarize(detail,labels,6,result['seed']+411,[k for k in detail[0] if k.endswith('_ms')])}
assert len(summaries)==52 and total==624
output=dict(sweeps=52,samples=total,comparisons=summaries,qq_stages=stages)
(E/'formal-v2/summary.json').write_text(json.dumps(output,indent=2)+'\n')
for name,record in summaries.items():
 if '-confirm-' not in name:continue
 print(name)
 for key in ['lifecycle_ms','positive_ms','negative_ms','peak_footprint_bytes']:
  if key in record['metrics']:
   v=record['metrics'][key];print(key,round(v['median_change_percent'],2),[round(x,2) for x in v['bootstrap95_percent']],{k:round(s['median'],4) for k,s in v['variants'].items()})
for name,record in stages.items():
 if '-confirm-' not in name:continue
 for key in ['batch_warm_per_pass_ms','chains_warm_per_pass_ms','AutoReceiveOriginalPhoto_cache_miss__nt_on_init_view_warm_per_pass_ms']:
  if key in record['metrics']:
   v=record['metrics'][key];print(name,key,round(v['median_change_percent'],2),[round(x,2) for x in v['bootstrap95_percent']],{k:round(s['median'],4) for k,s in v['variants'].items()})
