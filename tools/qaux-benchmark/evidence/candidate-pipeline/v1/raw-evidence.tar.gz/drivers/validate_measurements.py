import hashlib,importlib.util,json,re,subprocess,sys
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark');E=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/candidate-pipeline-v1');F=E/'formal-v2'
sys.path.insert(0,str(ROOT/'tools/qaux-benchmark'))
from workload_sweep import deployment_targets
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checked={};records=[];samples=0
for phase in ['main','confirm']:
 items=json.loads((F/('measurement-'+phase+'-queue.json')).read_text());assert len(items)==(36 if phase=='main' else 16)
 for item in items:
  path=F/item['name'];summary=json.loads((path/'summary.json').read_text());rows=json.loads((path/'samples.json').read_text())
  assert len(rows)==12 and len({(r['pair'],r['label']) for r in rows})==12 and summary['pairs']==6
  if item['kind']=='native':
   for variant in summary['variants']:
    exe=Path(variant['executable']);assert sha(exe)==variant['executable_sha256']
    assert variant['artifact']['engine_commit']=='82d6afb49d9faa5e49ee899ae948675d490ac99a'
    if str(exe) not in checked:checked[str(exe)]=dict(sha256=sha(exe),deployment_targets=deployment_targets(exe,variant['artifact']))
    assert checked[str(exe)]['deployment_targets']==['11.0']
   if item['name'].startswith('combined-'):assert '/artifacts-v2/control/' in summary['variants'][0]['executable']
   for key in ['CMAKE_CXX_COMPILER','CMAKE_CXX_FLAGS_RELEASE','CMAKE_OSX_ARCHITECTURES','CMAKE_OSX_SYSROOT','CMAKE_OSX_DEPLOYMENT_TARGET']:
    assert summary['variants'][0]['artifact']['cmake_options'][key]==summary['variants'][1]['artifact']['cmake_options'][key]
   identities={(r['report']['mode'],r['report']['repeats'],r['report']['checksum'],r['report']['returned']) for r in rows};assert len(identities)==1
  else:
   for row in rows:
    meta=json.loads((path/('pair-%02d-%s'%(row['pair'],row['label']))/'run-metadata.json').read_text())
    assert meta['exit_code']==0 and meta['baseline_counts_and_flow_equal'] and meta.get('repeat_results_equal') is not False
    assert not meta.get('report_error') and meta['native_sha256']==row['native_sha256']
  samples+=len(rows);records.append(dict(name=item['name'],kind=item['kind'],samples=12,summary_sha256=sha(path/'summary.json'),samples_sha256=sha(path/'samples.json')))
assert len(records)==52 and samples==624
correction=json.loads((F/'adapter-target-correction.json').read_text());assert correction['excluded_sweeps']==22 and correction['excluded_samples']==264
X=F/'excluded-unmatched-adapter';bad=[]
for record in correction['records']:
 summary=json.loads((X/record['name']/'summary.json').read_text());old=summary['variants'][0]
 assert '/old-small/' in old['executable'];assert len(json.loads((X/record['name']/'samples.json').read_text()))==12
 bad.append(dict(name=record['name'],summary_sha256=sha(X/record['name']/'summary.json'),samples_sha256=sha(X/record['name']/'samples.json')))
result=dict(sweeps=52,accepted_samples=samples,excluded_sweeps=22,excluded_samples=264,executables=checked,records=records,excluded_records=bad,
 measurement_driver_sha256=sha(ROOT/'tools/qaux-benchmark/workload_sweep.py'),notes='Final guard adds only pre-run validation outside measured child processes. Unaffected earlier CMake runs were independently checked against it. Small control has the same native library hash as frozen old Small.')
(F/'measurement-integrity.json').write_text(json.dumps(result,indent=2)+'\n')
identity=json.loads((F/'source-identity.json').read_text());identity['old_adapter_native_timings_excluded']=True;identity['accepted_native_workloads']=checked
(F/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
validation=json.loads((F/'validation-summary.json').read_text());validation['measurement_integrity']=dict(sweeps=52,accepted_samples=624,excluded_samples=264,correction='adapter-target-correction.json')
(F/'validation-summary.json').write_text(json.dumps(validation,indent=2)+'\n')
print('Validated all 624 accepted observations, all 264 exclusions, executable identities and matching compiler targets.')
