import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE = Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
DATA = BASE/'candidate-pipeline-v1'
OLD = BASE/'string-admission-v1'
phase = sys.argv[1]
assert phase in ('normal', 'extra')
labels = ['control', 'combined', 'slices'] if phase == 'normal' else [
    'combined-trace', 'slices-trace', 'slices-sanitized', 'slices-standalone']
queue = DATA/'formal-v2'/('validation-'+phase+'-queue.json')
records = json.loads(queue.read_text()) if queue.exists() else []

def run(name, command, binary=False):
    if any(row['name'] == name for row in records):
        return
    command = list(map(str, command))
    print('START '+name, flush=True)
    with (DATA/'formal-v2'/(name+'.log')).open('w') as err:
        if binary:
            with (DATA/'formal-v2'/(name+'.bin')).open('wb') as out:
                subprocess.run(command, cwd=ROOT, stdout=out, stderr=err, check=True)
        else:
            subprocess.run(command, cwd=ROOT, stdout=err, stderr=subprocess.STDOUT, check=True)
    records.append({'name': name, 'command': command, 'binary': binary})
    queue.write_text(json.dumps(records, indent=2)+'\n')
    print('DONE '+name, flush=True)

for label in labels:
    exe = DATA/'artifacts-v2'/label/'build/Core'
    for check in ['candidate_runtime', 'candidate_noexceptions', 'candidate_pipeline', 'inverted_string']:
        run(check+'-'+label, [exe/('dexkit_'+check+'_checks')])
    if phase == 'extra':
        run('candidate-integration-'+label, [exe/'dexkit_candidate_integration_checks',
            DATA/'fixtures/cross-slice/strings.apk'], True)
        for fixture in ['admission-final', 'multidex']:
            run('routes-'+label+'-'+fixture, [exe/'dexkit_string_admission_checks', OLD/'fixtures'/fixture/'strings.apk'])
        run('inverse-integration-'+label, [exe/'dexkit_string_inverse_integration_checks',
            BASE/'string-inverse-v2/fixtures/integration/strings.apk'], True)

for fixture in ['admission-final', 'multidex']:
    command = ['python3', 'tools/qaux-benchmark/validate_string_admission.py', '--fixture', OLD/'fixtures'/fixture,
               '--output', DATA/'formal-v2'/('admission-'+fixture+'-'+phase), '--variant', 'old-small',
               OLD/'artifacts/small/build/Core/dexkit_string_admission_workload']
    for label in labels:
        command += ['--variant', label, DATA/'artifacts-v2'/label/'build/Core/dexkit_string_admission_workload']
    run('admission-'+fixture+'-'+phase, command)

for fixture in ['strings-correctness-v1', 'strings-correctness-wide-v1']:
    for kind in ['string', 'batch']:
        name = kind+'-'+fixture+'-'+phase
        command = ['python3', 'tools/qaux-benchmark/validate_'+kind+'_checks.py',
                   '--fixture', BASE/'next-round/fixtures'/fixture, '--output', DATA/'formal-v2'/name,
                   '--variant', 'old-small', OLD/'artifacts/small']
        for label in labels:
            command += ['--variant', label, DATA/'artifacts-v2'/label]
        run(name, command)

if phase == 'extra':
    for prefix in ['candidate-integration-', 'inverse-integration-']:
        payloads = [(DATA/'formal-v2'/(prefix+label+'.bin')).read_bytes() for label in labels]
        assert all(payload == payloads[0] for payload in payloads)
