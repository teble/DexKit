import collections,hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark');E=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/candidate-pipeline-v1');OLD=E.parent/'string-admission-v1'
REV=subprocess.check_output(['git','-C',str(ROOT),'rev-parse','82d6afb'],text=True).strip()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
nine=['LAZY_DIRECTORIES','COMPACT_STRINGS','NEGATIVE_STRINGS','STRUCTURAL_DESCRIPTORS','DESCRIPTOR_FAST_HITS','RAW_INTERFACES','FIELD_IDENTITY_SPLIT','COMPACT_INVOKES','SINGLE_RELATION']
artifacts=[]
for label in ['control','combined','slices','combined-trace','slices-trace','slices-sanitized','slices-standalone']:
 a=E/'artifacts-v2'/label;m=json.loads((a/'artifact.json').read_text());assert m['engine_commit']==REV and m['native_sha256']==sha(a/'libdexkit.dylib')
 expected=([] if label=='slices-standalone' else nine[:])+['INVERTED_STRINGS','INVERTED_STRING_RANGES']
 if label!='control':expected+=['CANDIDATE_PIPELINE']
 if label.startswith('slices'):expected+=['CANDIDATE_SLICES']
 enabled=sorted(k.removeprefix('DEXKIT_EXPERIMENT_') for k,v in m['cmake_options'].items() if k.startswith('DEXKIT_EXPERIMENT_') and v=='ON')
 assert enabled==sorted(expected),(label,enabled)
 for name,value in m['source_trees'].items():assert value==subprocess.check_output(['git','-C',str(ROOT),'rev-parse',REV+':'+name],text=True).strip()
 assert (a/'source.patch').read_text()=='\n' and not m['untracked_source_sha256']
 artifacts.append(dict(label=label,native_sha256=m['native_sha256'],engine_commit=REV,source_trees=m['source_trees'],enabled=enabled,diagnostics=m['diagnostics']))
assert not subprocess.check_output(['git','-C',str(ROOT),'diff',REV,'--','Core','dexkit/src/main/cpp','schema'])
old=json.loads((E/'artifacts-v2/old-small/artifact.json').read_text())
identities=dict(engine_commit=REV,artifacts=artifacts,old_small=old,control_byte_identical_to_old_small=artifacts[0]['native_sha256']==old['native_sha256'])
(E/'formal-v2/source-identity.json').write_text(json.dumps(identities,indent=2)+'\n')
checks=[]
for fixture in ['strings-correctness-v1','strings-correctness-wide-v1']:
 for kind in ['string','batch']:
  records=[]
  for phase in ['normal','extra']:records+=json.loads((E/'formal-v2'/(kind+'-'+fixture+'-'+phase)/'validation.json').read_text())['records']
  assert all(r['passed'] for r in records) and len({r['ordered_results_sha256'] for r in records})==1
  checks.append(dict(kind=kind,fixture=fixture,variants=len({r['native_sha256'] for r in records}),queries_per_variant=records[0]['queries'],ordered_sha256=records[0]['ordered_results_sha256']))
for fixture in ['admission-final','multidex']:
 records=[]
 for phase in ['normal','extra']:records+=json.loads((E/'formal-v2'/('admission-'+fixture+'-'+phase)/'validation.json').read_text())
 assert all(r['passed'] for r in records) and len({r['ordered_bytes_sha256'] for r in records})==1
 checks.append(dict(kind='admission',fixture=fixture,variants=len({r['executable_sha256'] for r in records}),queries_per_state=58,states=3,ordered_sha256=records[0]['ordered_bytes_sha256']))
gradle=json.loads((E/'formal-v2/gradle-v2/validation.json').read_text());assert gradle['total_tests']==71
assert all(int(t.get('skipped',0))==0 and int(t['failures'])==0 and int(t['errors'])==0 for t in gradle['tests'])
for abi in gradle['abis']+['desktop']:
 text=(E/'formal-v2/gradle-v2'/(abi+'-CMakeCache.txt')).read_text();enabled=sorted(re.findall(r'^DEXKIT_EXPERIMENT_(\w+):BOOL=ON$',text,re.M))
 assert enabled==sorted(nine+['INVERTED_STRINGS','INVERTED_STRING_RANGES','CANDIDATE_PIPELINE','CANDIDATE_SLICES']),(abi,enabled)
extra={}
for name in ['budget-checks','reordered-checks','cross-range-checks']:
 rows=json.loads((E/'formal-v2'/(name+'.json')).read_text());assert rows and all(r['passed'] for r in rows);extra[name]=rows
for phase,count in [('normal',18),('extra',38)]:
 rows=json.loads((E/'formal-v2'/('validation-'+phase+'-queue.json')).read_text());assert len(rows)==count,(phase,len(rows))
public=[]
for label in ['combined-trace','slices-trace','slices-sanitized','slices-standalone']:
 path=E/'formal-v2'/('candidate-integration-'+label)
 log=path.with_suffix('.log').read_text();r=json.loads(re.findall(r'^CHECK_CANDIDATE_INTEGRATION (.+)$',log,re.M)[0]);assert r['passed'] and r['public_cases']==8 and r['injected']==32
 public.append(dict(label=label,**r,ordered_bytes_sha256=sha(path.with_suffix('.bin'))))
assert len({p['ordered_bytes_sha256'] for p in public})==1
verified=[]
for label in ['control','combined','slices','slices-trace']:
 m=json.loads((E/'formal-v2'/('verify-'+label)/'run-metadata.json').read_text());assert m['exit_code']==0 and m['baseline_results_equal'] and m['passes']==11
 verified.append(dict(label=label,native_sha256=m['native_sha256'],passes=11,passed=True))
validation=dict(engine_commit=REV,oracles=checks,gradle=gradle,extra=extra,candidate_integration=public,qq=verified,
 runtime='Seven configurations pass capture lifetime, controlled submit failure, independent budgets, bitmap boundaries, no-exceptions compilation/execution and preparation/validation failure with externally owned real QueryScheduler. Does not promise recovery from arbitrary scheduler-internal allocation failure.',
 historical_failure='The first Android build at 9227210 failed because Android disables C++ exceptions. 82d6afb preserves that mode and passed all four ABIs. Earlier native results are historical, not the final build evidence.')
(E/'formal-v2/validation-summary.json').write_text(json.dumps(validation,indent=2)+'\n')
parse=lambda text:dict((k,int(v)) for k,v in re.findall(r'(\w+)=(\d+)',text))
def traces(path):
 lines=path.read_text().splitlines()
 return {tag:[parse(line) for line in lines if line.startswith(tag+' ')] for tag in ['BENCH_CANDIDATE_SOURCE','BENCH_CANDIDATE_PIPELINE','BENCH_STRING_INVERSE_INDEX','BENCH_STRING_INVERSE_QUERY']}
qq=traces(E/'formal-v2/verify-slices-trace/run.log')
index=qq['BENCH_STRING_INVERSE_INDEX'];runs=qq['BENCH_CANDIDATE_PIPELINE'];sources=qq['BENCH_CANDIDATE_SOURCE']
assert len(index)==41 and sum(r['bytes'] for r in index)==5609448
assert all(r['remaining_reserved']==0 and r['peak_reserved']<=64*1024*1024 for r in runs)
native={}
for path in sorted((E/'formal-v2/native-traces').glob('*.log')):
 d=traces(path);jobs=d['BENCH_CANDIDATE_PIPELINE']
 assert all(r['remaining_reserved']==0 and r['peak_reserved']<=64*1024*1024 for r in jobs)
 native[path.stem]=d
 if path.name.endswith('cross-method-multiple-w4.log'):
  assert jobs[0]['prepare']==1 and jobs[0]['validate']==(5 if path.name.startswith('slices') else 0)
 if path.name.endswith('cross-class-multiple-w4.log'):
  assert jobs[0]['prepare']==1 and jobs[0]['validate']==(3 if path.name.startswith('slices') else 0)
 if path.name.endswith('skew-method-multiple-w4.log'):
  assert jobs[0]['prepare']==16 and jobs[0]['validate']==(10 if path.name.startswith('slices') else 0)
 if 'w1' in path.name:assert all(j['validate']==0 for j in jobs)
 if 'method-equal-one-w4-warm' in path.name or 'class-one-w4-warm' in path.name:assert all(j['validate']==0 for j in jobs)
 if 'nested-method-nested' in path.name:assert not jobs
summary=dict(qq=dict(queries=len(runs),dex_sources=len(sources),prepare=sum(r['prepare'] for r in runs),validate=sum(r['validate'] for r in runs),inline=sum(r['inline'] for r in runs),fallback=sum(r['fallback'] for r in runs),peak_reserved=max(r['peak_reserved'] for r in runs),retained_index_bytes=sum(r['bytes'] for r in index),route_reasons={str(k):v for k,v in collections.Counter((r['route'],r['reason']) for r in sources).items()}),qq_raw=qq,native=native,
 budget_scope='Explicitly listed controlled arrays only; excludes persistent indexes, matcher/trie caches, temporary associative containers and trie-hit buffers, result metadata, allocator overhead and whole-process memory.')
(E/'formal-v2/diagnostics-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('Validated final native identities, all oracles, JVM/four ABI, real scheduler failure checks and route diagnostics.')
print(json.dumps(summary['qq']))
print('Control byte-identical to old Small:',identities['control_byte_identical_to_old_small'])
