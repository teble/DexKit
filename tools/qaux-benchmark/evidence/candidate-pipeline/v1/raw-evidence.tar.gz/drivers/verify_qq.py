#!/usr/bin/env python3
import json
from pathlib import Path
import subprocess
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
DATA=BASE/'candidate-pipeline-v1'
JDK='/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home'
records=[]
def run(name, command):
 command=list(map(str,command)); print('START '+name,flush=True)
 with (DATA/'formal-v2'/(name+'-launcher.log')).open('w') as output:
  subprocess.run(command,cwd=ROOT,stdout=output,stderr=subprocess.STDOUT,check=True)
 records.append({'name':name,'command':command})
 (DATA/'formal-v2'/'qq-verification-queue.json').write_text(json.dumps(records,indent=2)+'\n')
 print('DONE '+name,flush=True)
for label in ['control','combined','slices','slices-trace']:
 name='verify-'+label
 command=['python3','tools/qaux-benchmark/run.py','--dexkit-root',ROOT,'--corpus',BASE/'qaux-extracted','--apk',BASE/'qq-9.3.55.apk',
  '--java-home',JDK,'--memory-probe',BASE/'artifacts/probe-v2/libqauxbench_probe.dylib','--output',DATA/'formal-v2'/name,
  '--native-library',(DATA/'artifacts-v2'/label)/'libdexkit.dylib','--passes','11','--threads','4','--profile','all','--mode','verify']
 run(name,command)
