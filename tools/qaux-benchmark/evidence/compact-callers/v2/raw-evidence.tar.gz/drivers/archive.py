"""Package the finite caller evidence, excluding proprietary/compiled inputs."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT = Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE = Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
E = BASE / 'compact-callers-v2'
DEST = ROOT / 'tools/qaux-benchmark/evidence/compact-callers/v2'
DEST.mkdir(parents=True, exist_ok=True)
assert all(path.name in ['raw-evidence.tar.gz', 'integrity.json', 'source-identity.json',
                        'summary.json', 'validation-summary.json', 'manifest.json']
           for path in DEST.iterdir()), 'Unexpected evidence destination content.'
files = {}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def add(path, name):
    assert path.is_file(), path
    assert name not in files, name
    files[name] = path


def tree(path, prefix):
    for file in sorted(path.rglob('*')):
        if not file.is_file():
            continue
        relative = file.relative_to(path)
        if any(part in ['classes', '__pycache__'] for part in relative.parts):
            continue
        if file.suffix in ['.class', '.jar', '.aar', '.so', '.dylib', '.o', '.a', '.pyc']:
            continue
        add(file, prefix + '/' + str(relative))


for name in ['measurements', 'validation', 'fixtures']:
    tree(E / name, name)
for file in sorted(E.glob('*.py')):
    add(file, 'drivers/' + file.name)
add(E / 'summary.json', 'summary.json')
for directory in sorted((E / 'artifacts').iterdir()):
    for file in sorted(directory.iterdir()):
        if file.is_file() and file.suffix in ['.json', '.txt', '.log', '.patch']:
            add(file, 'artifacts/' + directory.name + '/' + file.name)

for relative in ['followup/fixtures/relations', 'followup/fixtures/invoke-tiny',
                 'followup/fixtures/invoke-mixed', 'followup/fixtures/invoke-giant',
                 'next-round/fixtures/strings-correctness-v1',
                 'next-round/fixtures/strings-correctness-wide-v1',
                 'candidate-pipeline-v1/fixtures/cross-slice',
                 'string-inverse-v2/fixtures/integration']:
    tree(BASE / relative, 'inputs/' + relative)
add(BASE / 'string-admission-v1/artifacts/small/artifact.json', 'inputs/old-small-artifact.json')
for size in ['tiny', 'mixed', 'giant']:
    name = 'invoke-' + size + '-29-case-oracle.bin.gz'
    add(ROOT / 'tools/qaux-benchmark/evidence/followup/single' / name, 'inputs/frozen-oracles/' + name)
for file in sorted((ROOT / 'tools/qaux-benchmark').iterdir()):
    if file.is_file() and (file.suffix in ['.py', '.cpp', '.h', '.java', '.gradle', '.json']
                           or file.name.startswith('COMPACT-CALLERS-')):
        add(file, 'source/tools/' + file.name)
tree(ROOT / 'tools/qaux-benchmark/licenses', 'source/tools/licenses')

summary = json.loads((E / 'summary.json').read_text())
engine = summary['engine_commit']
baseline = '6fc9595137773c20d8fc98c44f37c16146bb48f4'
changed = subprocess.check_output(['git', '-C', str(ROOT), 'diff', '--name-only', baseline, engine], text=True).splitlines()
native_files = [path for path in changed if path.startswith('Core/') or path in
                ['dexkit/build.gradle', 'dexkit-android/build.gradle']]
for relative in native_files:
    add(ROOT / relative, 'source/engine/' + relative)
patch = subprocess.check_output(['git', '-C', str(ROOT), 'diff', baseline, engine,
                                 '--', 'Core', 'dexkit/build.gradle', 'dexkit-android/build.gradle'], text=True)
(E / 'engine.patch').write_text(patch)
add(E / 'engine.patch', 'source/engine.patch')
identity = dict(engine_commit=engine, baseline_commit=baseline,
                source_trees=json.loads((E / 'artifacts/compact/artifact.json').read_text())['source_trees'],
                normal_native_sha256={label: json.loads((E / 'artifacts' / label / 'artifact.json').read_text())['native_sha256']
                                      for label in ['control', 'compact']},
                frozen_plan_sha256=summary['frozen_plan_sha256'],
                note='The timed native code and workload are fixed at the engine commit. '
                     'Later fixture/report scripts are included verbatim. Reproduction needs the '
                     'repository at that commit, separately obtained QQ APK/corpus and equivalent '
                     'JDK, compiler and Android SDK/NDK inputs.')
(DEST / 'source-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
integrity = {name: dict(bytes=path.stat().st_size, sha256=sha(path)) for name, path in sorted(files.items())}
archive = DEST / 'raw-evidence.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=6) as tar:
    for name, path in sorted(files.items()):
        tar.add(path, arcname=name, recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(integrity)
    for member in tar:
        raw = tar.extractfile(member).read()
        expected = integrity[member.name]
        assert len(raw) == expected['bytes']
        assert hashlib.sha256(raw).hexdigest() == expected['sha256'], member.name
(DEST / 'integrity.json').write_text(json.dumps(integrity, indent=2) + '\n')
for path in [E / 'summary.json', E / 'validation/validation-summary.json']:
    shutil.copyfile(path, DEST / path.name)
manifest = dict(archive=archive.name, archive_bytes=archive.stat().st_size,
                archive_sha256=sha(archive), files=len(files), verified_readback=True,
                engine_commit=engine, accepted_sweeps=34, accepted_fresh_processes=408,
                excluded_measurements=0, omitted=['QQ APK/corpus', 'compiled native/JVM/Android artifacts'],
                integrity_sha256=sha(DEST / 'integrity.json'))
(DEST / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest, indent=2))
