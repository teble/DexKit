import concurrent.futures
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Users/teble/project/android/DexKit-qaux-benchmark')
E = Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/compact-callers-v2')
JDK = '/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home'
SMALL = ['LAZY_DIRECTORIES', 'COMPACT_STRINGS', 'NEGATIVE_STRINGS', 'STRUCTURAL_DESCRIPTORS',
         'DESCRIPTOR_FAST_HITS', 'RAW_INTERFACES', 'FIELD_IDENTITY_SPLIT', 'COMPACT_INVOKES',
         'SINGLE_RELATION', 'INVERTED_STRINGS', 'INVERTED_STRING_RANGES',
         'SKIP_EMPTY_CANDIDATES', 'MOVE_FIND_RESULTS']
phase = sys.argv[1]
plans = {
    'dev': [('control-dev', False, True, True, False), ('compact-dev', True, True, True, False)],
    'normal': [('control', False, False, True, False), ('compact', True, False, True, False)],
    'trace': [('control-trace', False, True, True, False), ('compact-trace', True, True, True, False)],
    'isolated': [('isolated-control', False, True, False, False), ('isolated-compact', True, True, False, False)],
    'sanitize': [('compact-sanitized', True, True, True, True)],
}
(E/'validation').mkdir(exist_ok=True)


def run(spec):
    name, compact, trace, small, sanitize = spec
    path = E / ('development' if phase == 'dev' else 'artifacts') / name
    command = ['python3', 'tools/qaux-benchmark/build_native.py', '--source-root', str(ROOT),
               '--output', str(path), '--java-home', JDK, '--jobs', '3']
    definitions = ['DEXKIT_BENCHMARK_RELATION_WORKLOAD=ON', 'DEXKIT_BENCHMARK_STRING_WORKLOAD=ON',
                   'DEXKIT_BENCHMARK_BATCH_WORKLOAD=ON',
                   'DEXKIT_EXPERIMENT_COMPACT_CALLERS=' + ('ON' if compact else 'OFF')]
    if small:
        definitions += ['DEXKIT_EXPERIMENT_' + flag + '=ON' for flag in SMALL]
    if trace:
        definitions += ['DEXKIT_BENCHMARK_DIAGNOSTICS=ON', 'DEXKIT_BENCHMARK_RELATION_CHECKS=ON']
    if sanitize:
        flags = '-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer'
        definitions += ['CMAKE_C_FLAGS_RELEASE=' + flags, 'CMAKE_CXX_FLAGS_RELEASE=' + flags,
                        'CMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined',
                        'CMAKE_SHARED_LINKER_FLAGS=-fsanitize=address,undefined',
                        'DEXKIT_EXPERIMENT_CANDIDATE_PIPELINE=ON', 'DEXKIT_EXPERIMENT_CANDIDATE_SLICES=ON']
    for definition in definitions:
        command += ['--define', definition]
    print('START ' + name, flush=True)
    with (E/'validation'/(name+'-build-launcher.log')).open('w') as log:
        subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=True)
    print('DONE ' + name, flush=True)
    return {'name': name, 'command': command}


with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    result = list(pool.map(run, plans[phase]))
(E/'validation'/('build-'+phase+'.json')).write_text(json.dumps(result, indent=2)+'\n')
