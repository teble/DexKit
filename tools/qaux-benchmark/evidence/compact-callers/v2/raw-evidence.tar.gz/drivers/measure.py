"""Frozen finite caller comparisons; both phases run serially."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE = Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
E = BASE / 'compact-callers-v2'
OUT = E / 'measurements'
JDK = Path('/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home')
LABELS = ['control', 'compact']
FIXTURES = {name: BASE / 'followup/fixtures' / ('invoke-' + name) / 'invocations.apk'
            for name in ['tiny', 'mixed', 'giant']}
FIXTURES.update({name: E / 'fixtures' / name / 'invocations.apk'
                 for name in ['mostly-empty', 'one-source']})
CASES = [
    ('tiny', 'caller-match-cold-w1'),
    ('tiny', 'caller-output-late-w4'),
    ('mixed', 'caller-match-cold-w4'),
    ('mixed', 'caller-match-late-w4'),
    ('mixed', 'caller-multiple-late-w4'),
    ('mixed', 'caller-output-full-w4'),
    ('giant', 'caller-early-cold-w4'),
    ('giant', 'caller-match-cold-w4'),
    ('giant', 'caller-multiple-late-w1'),
    ('giant', 'caller-output-cold-w4'),
    ('mostly-empty', 'caller-match-cold-w1'),
    ('mostly-empty', 'caller-match-late-w4'),
    ('one-source', 'caller-match-cold-w1'),
    ('one-source', 'caller-match-cold-w4'),
]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def make_plan():
    plan = []
    for phase, seed in [('main', 2026091620), ('confirm', 2026091720)]:
        for fixture, mode in CASES:
            seed += 1
            plan.append(dict(name=phase + '-' + fixture + '-' + mode,
                             phase=phase, kind='native', labels=LABELS, pairs=6,
                             seed=seed, fixture=str(FIXTURES[fixture]),
                             fixture_name=fixture, mode=mode, repeats=16))
        for passes, threads in [(1, 4), (11, 4), (1, 1)]:
            seed += 1
            plan.append(dict(name=phase + '-qq-p%d-w%d' % (passes, threads),
                             phase=phase, kind='qq', labels=LABELS, pairs=6,
                             seed=seed, passes=passes, threads=threads, profile='all'))
    assert len(plan) == 34
    return plan


def command(item):
    if item['kind'] == 'native':
        cmd = [sys.executable, ROOT / 'tools/qaux-benchmark/workload_sweep.py',
               '--fixture', item['fixture'], '--output', OUT / item['name'],
               '--mode', item['mode'], '--repeats', str(item['repeats']),
               '--pairs', str(item['pairs']), '--seed', str(item['seed'])]
        for label in LABELS:
            cmd += ['--variant', label, E / 'artifacts' / label]
    else:
        cmd = [sys.executable, ROOT / 'tools/qaux-benchmark/sweep.py',
               '--dexkit-root', ROOT, '--corpus', BASE / 'qaux-extracted',
               '--apk', BASE / 'qq-9.3.55.apk', '--java-home', JDK,
               '--memory-probe', BASE / 'artifacts/probe-v2/libqauxbench_probe.dylib',
               '--output', OUT / item['name'], '--pairs', str(item['pairs']),
               '--passes', str(item['passes']), '--threads', str(item['threads']),
               '--profile', item['profile'], '--seed', str(item['seed'])]
        for label in LABELS:
            cmd += ['--variant', label, E / 'artifacts' / label / 'libdexkit.dylib',
                    E / 'validation' / ('verify-%s-w%d' % (label, item['threads']))]
    return list(map(str, cmd))


action = sys.argv[1]
assert action in ['freeze', 'run']
OUT.mkdir(exist_ok=True)
frozen_path = OUT / 'frozen-plan.json'
plan = make_plan()
if action == 'freeze':
    assert not frozen_path.exists(), 'The plan has already been frozen.'
    paths = list(FIXTURES.values()) + [Path(__file__)]
    paths += [ROOT / 'tools/qaux-benchmark' / name for name in
              ['workload_sweep.py', 'sweep.py', 'run.py', 'QueryReplay.java']]
    for label in LABELS:
        paths += [E / 'artifacts' / label / name for name in
                  ['artifact.json', 'libdexkit.dylib', 'build/Core/dexkit_invocation_workload']]
        for workers in [1, 4]:
            meta_path = E / 'validation' / ('verify-%s-w%d' % (label, workers)) / 'run-metadata.json'
            meta = json.loads(meta_path.read_text())
            assert meta['exit_code'] == 0 and meta['baseline_results_equal'] is True
            paths += [meta_path] + list(map(Path, meta['jars_sha256']))
    frozen = dict(frozen_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  engine_commit=subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip(),
                  policy='Two phases, 6 balanced AB/BA pairs each. 408 fresh process samples. '
                         'Keep every successful sample, including outliers. No native/Gradle build or '
                         'functional validation during timing. The QQ adapter compiles serially before '
                         'each fresh JVM outside its measured lifecycle. OS caches are not flushed.',
                  files={str(path): sha(path) for path in sorted(set(paths))},
                  sweeps=[dict(item, command=command(item)) for item in plan])
    frozen_path.write_text(json.dumps(frozen, indent=2) + '\n')
    print('FROZEN', sha(frozen_path), 'sweeps=34 fresh_processes=408', flush=True)
    sys.exit(0)

frozen = json.loads(frozen_path.read_text())
assert frozen['sweeps'] == [dict(item, command=command(item)) for item in plan]
for path, expected in frozen['files'].items():
    assert sha(path) == expected, 'Frozen input changed: ' + path
queue = OUT / 'completed.json'
completed = json.loads(queue.read_text()) if queue.exists() else []
for item in frozen['sweeps']:
    name = item['name']
    if any(row['name'] == name for row in completed):
        assert (OUT / name / 'summary.json').is_file()
        continue
    print('START ' + name, flush=True)
    with (OUT / (name + '-launcher.log')).open('w') as log:
        subprocess.run(item['command'], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=True)
    summary = json.loads((OUT / name / 'summary.json').read_text())
    value = summary['metrics']['lifecycle_ms']
    completed.append(dict(item, summary_sha256=sha(OUT / name / 'summary.json')))
    queue.write_text(json.dumps(completed, indent=2) + '\n')
    print('DONE %s lifecycle=%+.2f%% %s (%d/34)' %
          (name, value['median_change_percent'], value['bootstrap95_percent'], len(completed)), flush=True)
for path, expected in frozen['files'].items():
    assert sha(path) == expected, 'Frozen input changed after measurement: ' + path
print('COMPLETE 34 sweeps / 408 fresh process samples', flush=True)
