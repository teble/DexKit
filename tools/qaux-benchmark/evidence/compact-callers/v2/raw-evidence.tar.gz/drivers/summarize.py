"""Reconcile the frozen caller experiment and its already completed evidence."""
import hashlib
import json
from pathlib import Path
import random
import subprocess
import zipfile

ROOT = Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE = Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
E = BASE / 'compact-callers-v2'
M = E / 'measurements'
V = E / 'validation'


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tagged(path, tag):
    return [json.loads(line[len(tag) + 1:]) for line in path.read_text().splitlines()
            if line.startswith(tag + ' ')]


frozen = read(M / 'frozen-plan.json')
completed = read(M / 'completed.json')
assert len(completed) == len(frozen['sweeps']) == 34
assert [row['name'] for row in completed] == [row['name'] for row in frozen['sweeps']]
for path, expected in frozen['files'].items():
    assert sha(Path(path)) == expected, path

sweeps = []
for item in completed:
    directory = M / item['name']
    assert sha(directory / 'summary.json') == item['summary_sha256']
    summary = read(directory / 'summary.json')
    samples = read(directory / 'samples.json')
    assert len(samples) == 12
    order = [pair % 2 for pair in range(6)]
    random.Random(item['seed']).shuffle(order)
    assert summary['reversed_order'] == order
    for pair in range(6):
        rows = sorted([row for row in samples if row['pair'] == pair], key=lambda row: row['position'])
        assert [row['label'] for row in rows] == (['compact', 'control'] if order[pair] else ['control', 'compact'])
        if item['kind'] == 'qq':
            for row in rows:
                metadata = read(directory / ('pair-%02d-%s' % (pair, row['label'])) / 'run-metadata.json')
                assert metadata['exit_code'] == 0 and metadata['baseline_counts_and_flow_equal'] is True
                assert metadata['repeat_results_equal'] is (True if item['passes'] > 1 else None)
                assert metadata['native_sha256'] == read(E / 'artifacts' / row['label'] / 'artifact.json')['native_sha256']
                assert metadata['passes'] == item['passes'] and metadata['threads'] == item['threads']
    sweeps.append(dict(item, summary=summary))

capacity = {}
for label in ['control', 'compact']:
    log = V / ('verify-' + label + '-trace-w4') / 'run.log'
    rows = tagged(log, 'BENCH_CALLER_ROWS')
    stages = tagged(log, 'BENCH_CALLER_BUILD')
    census = next(row for row in tagged(log, 'BENCH_CENSUS')
                  if row.get('phase') == 'pre_close' and row.get('category') == 'callers')
    final = next(row for row in stages if row['phase'] == 'released')
    assert final['count_cursor_capacity_bytes'] == final['pending_capacity_bytes'] == 0
    assert sum(row['edges'] for row in rows) == final['final_edges']
    capacity[label] = dict(stages=stages, census=census, ordered_rows=rows,
                           final_bytes=final['directory_bytes'] + final['payload_capacity_bytes'])
assert capacity['control']['ordered_rows'] == capacity['compact']['ordered_rows']
assert len(capacity['compact']['ordered_rows']) == 41
capacity['retained_saved_bytes'] = capacity['control']['final_bytes'] - capacity['compact']['final_bytes']
capacity['retained_change_percent'] = (capacity['compact']['final_bytes'] / capacity['control']['final_bytes'] - 1) * 100
capacity['ordered_rows_equal'] = True
capacity['note'] = ('Capacity totals count final row directories and edge allocations, excluding their per-DEX '
                    'owner objects and allocator metadata. Build-stage snapshots are not an allocator/process '
                    'peak. All count/cursor and pending-import capacity is released before publication.')
with zipfile.ZipFile(BASE / 'qq-9.3.55.apk') as apk:
    dexes = [info for info in apk.infolist() if info.filename.endswith('.dex')]
    capacity['raw_dex_bytes'] = sum(info.file_size for info in dexes)
    capacity['raw_dex_count'] = len(dexes)

native = {}
for phase in ['normal', 'trace', 'sanitize']:
    rows = read(V / ('checks-' + phase + '.json'))
    for row in rows:
        output = V / (row['name'] + ('.bin' if row['binary'] else '.log'))
        assert sha(output) == row['output_sha256'], output
    native[phase] = len(rows)
assert sum(native.values()) == 66
independent = []
for path in sorted(V.glob('independent-*.log')):
    if path.name.endswith('-stderr.log'):
        continue
    row = read(path)
    assert row['independent_rows_equal'] is True and row['zero_bindings_checked'] == 2
    independent.append(dict(name=path.stem, **row))
contracts = [sha(path) for path in V.glob('contracts-*.bin')]
assert len(contracts) == 5 and len(set(contracts)) == 1
extra = read(V / 'extra/summary.json')
assert len(extra) == 12
for row in extra:
    assert sha(V / 'extra' / (row['name'] + '.bin')) == row['sha256']
for fixture in ['mostly-empty', 'one-source']:
    for kind in ['caller', 'invocation']:
        assert len({row['sha256'] for row in extra if row['name'].startswith(fixture + '-' + kind + '-')}) == 1
qq = []
for item in read(V / 'qq-verification.json'):
    meta = read(V / item['name'] / 'run-metadata.json')
    assert item['passed'] is True and meta['exit_code'] == 0 and meta['baseline_results_equal'] is True
    qq.append(dict(name=item['name'], passes=meta['passes'], threads=meta['threads'],
                   native_sha256=meta['native_sha256'], baseline_results_equal=True))
gradle = read(V / 'gradle/validation.json')
assert gradle['total_tests'] == 71 and gradle['skipped'] == 0 and len(gradle['abis']) == 4
assert all(int(row['failures']) == int(row['errors']) == int(row['skipped']) == 0 for row in gradle['tests'])
query_oracles = {}
for path in sorted(V.glob('*strings-correctness*/validation.json')):
    records = read(path)['records']
    assert all(row['passed'] is True for row in records)
    assert len({row['ordered_results_sha256'] for row in records}) == 1
    query_oracles[path.parent.name] = dict(queries=records[0]['queries'], variants=[row['label'] for row in records])
validation = dict(engine_commit=frozen['engine_commit'], native_commands=native,
                  native_total=66, additional_native_commands=12, independent_caller=independent,
                  complete_caller_dump_equal=True, contract_dump_sha256=contracts[0],
                  qq=qq, qq_ordered_raw_rows_equal=True, extra=extra,
                  string_batch_oracles=query_oracles, gradle=gradle,
                  limitation='ASan/UBSan ran on the host. Android validates four ABI builds; no Android device timing or sanitizer run.')
(V / 'validation-summary.json').write_text(json.dumps(validation, indent=2) + '\n')
result = dict(engine_commit=frozen['engine_commit'], frozen_plan_sha256=sha(M / 'frozen-plan.json'),
              accepted_sweeps=34, accepted_fresh_processes=408, excluded_measurements=0,
              frozen_inputs_unchanged=True, host=dict(
                  cpu=subprocess.check_output(['sysctl', '-n', 'machdep.cpu.brand_string'], text=True).strip(),
                  os=subprocess.check_output(['sw_vers'], text=True).strip()),
              caller_capacity=capacity, validation=validation, sweeps=sweeps)
(E / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(accepted_sweeps=34, fresh_processes=408, validation_native=78,
                     qq_verified=len(qq), jvm_tests=71, abis=gradle['abis'],
                     retained_saved_mib=capacity['retained_saved_bytes'] / 1048576,
                     retained_change_percent=capacity['retained_change_percent']), indent=2))
