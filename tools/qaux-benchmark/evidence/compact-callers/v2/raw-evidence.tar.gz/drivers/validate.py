import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE = Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
E = BASE/'compact-callers-v2'
phase = sys.argv[1]
groups = {'normal': ['control', 'compact'],
          'trace': ['control-trace', 'compact-trace', 'isolated-control', 'isolated-compact'],
          'sanitize': ['compact-sanitized']}
labels = groups[phase]
queue = E/'validation'/('checks-'+phase+'.json')
records = json.loads(queue.read_text()) if queue.exists() else []


def run(name, command, binary=False):
    if any(item['name'] == name for item in records):
        return
    command = list(map(str, command))
    print('START '+name, flush=True)
    path = E/'validation'/(name+('.bin' if binary else '.log'))
    with (E/'validation'/(name+'-stderr.log')).open('w') as err, path.open('wb') as out:
        process = subprocess.run(command, cwd=E/'validation', stdout=out, stderr=err, timeout=240)
    if process.returncode:
        raise RuntimeError(name+': '+(E/'validation'/(name+'-stderr.log')).read_text()[-4000:])
    records.append(dict(name=name, command=command, binary=binary,
                        output_sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    queue.write_text(json.dumps(records, indent=2)+'\n')
    print('DONE '+name, flush=True)


for label in labels:
    exe = E/'artifacts'/label/'build/Core'
    if label in ['compact', 'compact-sanitized']:
        run('index-'+label, [exe/'dexkit_caller_index_checks'])
    if not label.startswith('isolated'):
        for name in ['candidate_runtime', 'candidate_noexceptions', 'candidate_pipeline', 'inverted_string']:
            run(name+'-'+label, [exe/('dexkit_'+name+'_checks')])
    if phase != 'normal':
        run('contracts-'+label, [exe/'dexkit_caller_checks', '--dump', E/'fixtures/contracts/callers.apk'], True)
        run('independent-'+label, ['python3', ROOT/'tools/qaux-benchmark/validate_caller_fixture.py',
            '--manifest', E/'fixtures/contracts/manifest.json', '--dump', E/'validation'/('contracts-'+label+'.bin'), '--log', E/'validation'/('contracts-'+label+'-stderr.log')])
        run('relations-'+label, [exe/'dexkit_relation_checks', '--dump', BASE/'followup/fixtures/relations/relations.apk'], True)
        for size in ['tiny', 'mixed', 'giant']:
            name = 'invoke-'+size+'-'+label
            run(name, [exe/'dexkit_invocation_checks', '--dump', BASE/('followup/fixtures/invoke-'+size+'/invocations.apk')], True)
            oracle = ROOT/('tools/qaux-benchmark/evidence/followup/single/invoke-'+size+'-29-case-oracle.bin.gz')
            assert (E/'validation'/(name+'.bin')).read_bytes() == gzip.decompress(oracle.read_bytes()), name
        if not label.startswith('isolated'):
            for name, fixture in [('candidate', BASE/'candidate-pipeline-v1/fixtures/cross-slice/strings.apk'),
                                  ('string_inverse', BASE/'string-inverse-v2/fixtures/integration/strings.apk')]:
                run(name+'-integration-'+label, [exe/('dexkit_'+name+'_integration_checks'), fixture], True)

if phase in ['normal', 'sanitize']:
    for size in ['strings-correctness-v1', 'strings-correctness-wide-v1']:
        for kind in ['string', 'batch']:
            name = kind+'-'+size+'-'+phase
            command = ['python3', ROOT/('tools/qaux-benchmark/validate_'+kind+'_checks.py'),
                       '--fixture', BASE/'next-round/fixtures'/size, '--output', E/'validation'/name,
                       '--variant', 'old-small', BASE/'string-admission-v1/artifacts/small']
            for label in labels:
                command += ['--variant', label, E/'artifacts'/label]
            run(name, command)

if phase != 'normal':
    reference = (E/'validation/contracts-control-trace.bin').read_bytes()
    for label in labels:
        assert (E/'validation'/('contracts-'+label+'.bin')).read_bytes() == reference
    if phase == 'sanitize':
        for name in ['candidate', 'string_inverse']:
            assert (E/'validation'/(name+'-integration-compact-sanitized.bin')).read_bytes() == (E/'validation'/(name+'-integration-control-trace.bin')).read_bytes()
print('COMPLETE '+phase+' '+str(len(records))+' commands', flush=True)
