import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/teble/project/android/DexKit-qaux-benchmark')
E = Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/compact-callers-v2')
out = E/'validation/extra'
out.mkdir(exist_ok=True)
records = []
for fixture in ['mostly-empty', 'one-source']:
    for check in ['caller', 'invocation']:
        expected = None
        for label in ['control-trace', 'compact-trace', 'compact-sanitized']:
            name = fixture+'-'+check+'-'+label
            command = [E/'artifacts'/label/('build/Core/dexkit_'+check+'_checks'), '--dump', E/'fixtures'/fixture/'invocations.apk']
            command = list(map(str, command))
            print('START '+name, flush=True)
            with (out/(name+'.bin')).open('wb') as stdout, (out/(name+'.log')).open('w') as stderr:
                process = subprocess.run(command, stdout=stdout, stderr=stderr, timeout=240)
            if process.returncode:
                raise RuntimeError(name+': '+(out/(name+'.log')).read_text()[-2500:])
            digest = hashlib.sha256((out/(name+'.bin')).read_bytes()).hexdigest()
            if expected is None:
                expected = digest
            assert digest == expected, name
            records.append(dict(name=name, command=command, sha256=digest))
            (out/'summary.json').write_text(json.dumps(records, indent=2)+'\n')
            print('DONE '+name, flush=True)
