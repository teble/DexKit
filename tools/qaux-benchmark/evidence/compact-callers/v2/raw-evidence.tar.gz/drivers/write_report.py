"""Write the caller result tables directly from the reconciled paired evidence."""
import json
from pathlib import Path

ROOT = Path('/Users/teble/project/android/DexKit-qaux-benchmark')
E = Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/compact-callers-v2')
D = json.loads((E / 'summary.json').read_text())
lines = []


def add(text=''):
    lines.append(text)


def value(row, metric):
    return row['summary']['metrics'].get(metric)


def change(row, metric):
    item = value(row, metric)
    if item is None:
        return 'n/a'
    lo, hi = item['bootstrap95_percent']
    return '%+.2f%% [%+.2f, %+.2f]' % (item['median_change_percent'], lo, hi)


def absolute(row, metric):
    item = value(row, metric)
    if item is None:
        return 'n/a'
    divisor = 1048576 if metric.endswith('bytes') else 1
    return '%.3f -> %.3f' % tuple(item['variants'][label]['median'] / divisor
                                for label in ['control', 'compact'])


def table(headers, rows):
    add('| ' + ' | '.join(headers) + ' |')
    add('| ' + ' | '.join(['---'] * len(headers)) + ' |')
    for row in rows:
        add('| ' + ' | '.join(map(str, row)) + ' |')
    add()


add('''# Compact caller results

The counted, exact-allocation caller index is a useful memory and cold-lifecycle
optimization on this QQ workload. Across two independent runs, four-worker QQ
create-to-close time improves by 13.88-16.02% for one pass and 4.90-5.07% for
11 passes. One-worker, one-pass time improves by 10.68-11.98%. Caller directory
and edge capacity falls from 160.035 MiB to 103.275 MiB, saving 56.760 MiB
(35.47%). Measured QQ physical footprint peaks fall by about 54-68 MiB.

Keep COMPACT_CALLERS as a default-OFF experiment. The results support retaining
it as a candidate addition to the Small profile, with explicit tradeoffs:
repeated QQ queries are statistically unresolved, several exhaustive caller
traversals are around 1-2% slower, and tiny late construction adds about 0.06 ms.
No public API/schema changes or default enablement are part of this increment.

## Fixed comparison and method

Engine: `e3ec3622ff9bc3b3613f934356bbd1cf6b4408c5`. Both binaries use the same
source and compiler settings and differ only in COMPACT_CALLERS. Control is the
13-option Small profile after the ordinary-find extraction: LAZY_DIRECTORIES,
COMPACT_STRINGS, NEGATIVE_STRINGS, STRUCTURAL_DESCRIPTORS,
DESCRIPTOR_FAST_HITS, RAW_INTERFACES, FIELD_IDENTITY_SPLIT, COMPACT_INVOKES,
SINGLE_RELATION, INVERTED_STRINGS, INVERTED_STRING_RANGES,
SKIP_EMPTY_CANDIDATES and MOVE_FIND_RESULTS. CANDIDATE_PIPELINE and
CANDIDATE_SLICES are OFF. Compact adds only COMPACT_CALLERS.

Host: Apple M1, macOS 26.5.1. Native builds use Apple Clang 21, arm64,
`-O3 -DNDEBUG`, C++20 and a macOS 11.0 deployment target. Metrics and diagnostics
are compiled out for timing. QQ uses JBR 17.0.6, a fixed 256 MiB JVM heap and
AlwaysPreTouch. Artifact, adapter, fixture, JAR, JDK and probe hashes are recorded.

The exact 17-case list was frozen before timing and repeated in an independent
confirmation: 34 sweeps, six balanced randomized AB/BA pairs per sweep, 408
fresh processes. All successful samples are retained, including outliers; none
were excluded or replaced. Builds and functional checks did not overlap timing.
The QQ launcher compiles its adapter serially before each JVM, outside the
measured create-to-close interval. OS file caches were not flushed. This is a
host measurement, with Android build coverage rather than Android device timing.

Every arrow below is control median -> compact median. Percentages are medians
of paired relative changes, which can differ from ratios of the two medians.
Brackets are exploratory 95% paired-median bootstrap intervals (4,000 draws,
six pairs); they do not establish a universal regression bound. Negative is
better for time and memory. Complete samples and every staged metric are in the
evidence archive.

## QQ time

Lifecycle is the observed bridge create-to-close interval, including query
output handling and close. It excludes JVM startup and adapter compilation.
Each `all` pass follows the frozen QAuxiliary query flow on QQ 9.3.55.
''')
qq = [row for row in D['sweeps'] if row['kind'] == 'qq']
table(['Run', 'Lifecycle ms', 'Paired change [95% interval]'],
      [[row['name'], absolute(row, 'lifecycle_ms'), change(row, 'lifecycle_ms')] for row in qq])
add('''The first pass improves in every QQ sweep. Close improves by about 41-46%,
consistent with replacing roughly 1.32 million retained caller buffers with
82 directory/payload allocations. This is an interpretation of the allocation
change, not an isolated causal measurement. The ten repeated passes are neutral
within their intervals. Create does not have a consistent gain; the confirmation
11-pass case records +5.93% [0.98, 12.99] there even while lifecycle improves.
''')
table(['Run', 'Create change', 'First API pass change', 'Passes 1-10 API change', 'Close change'],
      [[row['name'], change(row, 'create_ms'), change(row, 'pass0_api_ms'),
        change(row, 'repeated_api_ms'), change(row, 'close_ms')] for row in qq])
add('## QQ physical memory\n')
table(['Run', 'Peak footprint MiB', 'Footprint change', 'Max RSS MiB', 'RSS change'],
      [[row['name'], absolute(row, 'peak_footprint_bytes'), change(row, 'peak_footprint_bytes'),
        absolute(row, 'max_rss_bytes'), change(row, 'max_rss_bytes')] for row in qq])
add('''Physical footprint improves in all six sweeps. RSS is less consistent:
the main four-worker single-pass estimate is +0.67% with an interval crossing
zero. Neither RSS nor physical footprint is caller-exclusive heap usage; both
also include mapped DEX data, other caches, JVM state, allocator behavior and
harness allocations. Reported in-window peak metrics are retained in JSON too.

## Exact caller capacity and build storage

QQ contains 41 DEX files with 392.742 MiB of raw uncompressed DEX. The caller
table covers 2,600,031 method IDs and 10,936,362 ordered edges. There are
1,315,612 nonempty final rows. All 41 per-DEX ordered caller hashes, row counts,
edge counts and largest-row counts agree between diagnostic control and compact.
The largest final row has 534,428 entries.
''')
capacity = D['caller_capacity']
c0 = capacity['control']['census']
c1 = capacity['compact']['census']
table(['Retained category', 'Control MiB', 'Compact MiB', 'Saved MiB'], [
    [label, '%.3f' % (before / 1048576), '%.3f' % (after / 1048576), '%.3f' % ((before - after) / 1048576)]
    for label, before, after in [
        ('Row directory', c0['index_bytes'], c1['index_bytes']),
        ('Edge capacity', c0['payload_capacity_bytes'], c1['payload_capacity_bytes']),
        ('Total', capacity['control']['final_bytes'], capacity['compact']['final_bytes'])]])
add('''The final compact edge capacity is exactly 10,936,362 eight-byte entries;
the old retained capacity is 13,175,981 entries. The compact directory has one
size_t offset per method plus one sentinel per DEX. Totals exclude the small
per-DEX owner objects and allocator metadata. Retained buffer counts are
1,315,653 -> 82 (41 row directories plus 41 nonempty edge arrays).
''')
stages = []
for label in ['control', 'compact']:
    for row in capacity[label]['stages']:
        values = [row[key] / 1048576 for key in ['directory_bytes', 'payload_capacity_bytes',
                  'count_cursor_capacity_bytes', 'pending_capacity_bytes']]
        stages.append([label + ' / ' + row['phase'], *['%.3f' % v for v in values],
                       '%.3f' % sum(values)])
table(['Snapshot', 'Directory MiB', 'Edges MiB', 'Count/cursor MiB', 'Pending imports MiB', 'Tracked total MiB'], stages)
add('''The 19.837 MiB count array becomes the write cursor array and is then freed.
Pending imports also drop to zero capacity before publication. Their temporary
capacity grows from 6.633 MiB to 13.266 MiB because each pending record retains a
size_t source length; this is included above. At the allocated snapshot compact
has 33.102 MiB of temporary count/import capacity. `counted` final_edges=0 means
the final layout has not been allocated yet; it does not mean there were no calls.

These are capacity snapshots, not measured allocator peaks. In particular, old
aggregation can temporarily overlap allocations as rows grow, and allocator
rounding is outside these totals. Physical peaks must be assessed from the
ordinary-build measurements, rather than inferred from this table.

## Bounded native workloads

Tiny, mixed and giant use the existing 26-, 98,306- and 262,146-edge fixtures.
Mostly-empty uses nine DEX files, eight sources with 5,000 methods each, and
60,008 edges concentrated into shared targets while most reverse rows stay
empty. One-source has three DEX files and 131,074 edges, with one method making
131,072 calls. Each fresh process performs 16 API repetitions after preparation.

Cold preparation includes instruction extraction, forward invocation storage,
identity resolution and caller completion. Late first builds forward invocations,
then times caller completion separately. Full builds all caches. These nested
preparation intervals already belong to setup/lifecycle and must not be summed
again. API columns for these staged modes are warm even when the preparation
mode is named cold. Lifecycle also includes queries, output serialization,
destruction and the memory probes.
''')
for phase in ['main', 'confirm']:
    native = [row for row in D['sweeps'] if row['kind'] == 'native' and row['phase'] == phase]
    add('### ' + phase.capitalize() + ' construction and lifecycle\n')
    table(['Fixture / mode', 'Preparation ms', 'Preparation change', 'Lifecycle ms', 'Lifecycle change'],
          [[row['fixture_name'] + ' / ' + row['mode'], absolute(row, 'caller_build_ms'),
            change(row, 'caller_build_ms'), absolute(row, 'lifecycle_ms'), change(row, 'lifecycle_ms')]
           for row in native])
add('''The giant early-hit lifecycle improves by 16.26% in main and 7.12% in
confirmation, although the latter interval crosses zero. Mixed late multiple
matching improves in both phases, and giant one-worker late multiple matching
has estimates near -4.6%. Output-heavy lifecycle changes remain unresolved.

Regressions are retained explicitly. Tiny late preparation goes from about
0.09 ms to 0.15-0.16 ms, with lifecycle +29.02% in main and +8.22% in confirmation
(absolute medians 0.460 -> 0.553 ms and 0.440 -> 0.507 ms). Exhaustive matching
on mixed/giant and mostly-empty rows is usually around 1-2% slower end to end.
One-source confirmation is +1.12% with one worker and +0.85% with four workers;
the main intervals crossed zero. Mostly-empty late construction changes sign:
-5.36% [-24.48, 24.55] in main, +14.32% [7.06, 23.58] in confirmation.

The mostly-empty late confirmation retains a large outlier: lifecycle median
change is +1.77%, but its bootstrap interval extends to +69.16%. This workload
cannot support a tight worst-case regression claim. No sample was removed to
narrow that interval.

### Warm APIs and memory

Warm allocator snapshots are after index preparation and before timed queries.
Closed snapshots are after bridge destruction while the small query/metadata
inputs still exist; their later destruction is inside lifecycle. JSON retains
both closed footprint and closed malloc values. The malloc column below is
whole-process allocator in-use bytes, not an isolated caller heap.
''')
for phase in ['main', 'confirm']:
    native = [row for row in D['sweeps'] if row['kind'] == 'native' and row['phase'] == phase]
    add('#### ' + phase.capitalize() + '\n')
    table(['Fixture / mode', 'Repeated API ms (15)', 'API change', 'Warm malloc MiB', 'Peak footprint MiB', 'Peak change'],
          [[row['fixture_name'] + ' / ' + row['mode'], absolute(row, 'repeated_api_ms'),
            change(row, 'repeated_api_ms'), absolute(row, 'warm_malloc_in_use_bytes'),
            absolute(row, 'peak_footprint_bytes'), change(row, 'peak_footprint_bytes')] for row in native])
add('''Warm malloc in-use capacity does not improve on every fixture: the dense
mixed/giant/one-source cases have small increases of about 13-16 KiB, while the
mostly-empty case drops by 0.625 MiB. Dense exact rows already offer little
payload slack to remove, and allocator rounding/owner overhead still matters.
Physical peaks improve for many long-row match cases; full output and tiny
cases do not show a universal peak reduction.

## Implementation and validation

Cold extraction counts while decoding existing invoke instructions. Late
construction counts the existing forward rows. Final caller storage consists
of an M+1 prefix directory and an exact uninitialized array of trivial 8-byte
entries. Existing cross-DEX identity binding is preserved; local contributions
precede source-DEX/work-list contributions, duplicates remain duplicated, and
transferred reference rows remain empty. Preassigned disjoint segments permit
parallel source filling without changing result order. The existing warmup
barrier publishes callers only after workers join and temporary capacity is freed.

Published rows are immutable spans and remain stable through later RW/full
warmup. The Hungarian matcher can borrow their immutable storage. The measured
increment therefore includes counted construction, exact allocation, removal of
the old late empty instruction walk and span borrowing. Total percentages do
not isolate any one of those mechanisms. cross_info and field storage are unchanged.

Debug and DIAGNOSTICS builds validate segment endpoints and replay final fill
lengths. Normal release omits that validation-only replay; size overflow and
whole-array write checks stay active. This follows the concrete finding in the
[source review](COMPACT-CALLERS-REVIEW.md). Pro inspected b28699b, not the final
e3ec362 correction, and did not run tests or benchmarks.

- 66 native validation commands pass: 13 normal, 36 diagnostic/isolated,
  and 17 sanitizer commands. Coverage includes component arithmetic and
  no-exceptions checks, inverse/candidate integration, existing relation checks,
  and the frozen complete 29-query tiny/mixed/giant invocation results.
- The authored five-DEX caller oracle covers 33 methods and 31 edges, including
  duplicate definitions/instructions, unresolved-before-resolvable references,
  reverse ClassDef order, empty DEX rows and two successful zero-count bindings.
  All five control/compact/isolated/sanitized dumps agree byte for byte. Its
  raw rows are independently validated; the full FlatBuffer tail is compared
  between implementations rather than independently decoded by Python.
- One/four workers, cold/late/full initialization, concurrent full warmup and
  a caller query queued behind an active guard validate publication, released
  capacity and stable row addresses through later RW/full initialization.
- 12 further caller/invocation commands on mostly-empty and one-source fixtures
  pass with identical complete dumps for control, compact and ASan/UBSan.
- Normal and sanitizer string/batch checks match their independent 90/36-query
  oracles on small and wide fixtures, alongside the prior Small control.
- Six QQ verification runs pass the frozen complete results and flow. The
  subsequent 72 measured JVMs retain equal result counts and flow; verification
  and timing use the same native/input/JDK/JAR/adapter/probe identities.
- `:dexkit:cmakeBuild`, `:dexkit:jar`, all 71 JVM tests (zero failures/errors/
  skips), and `:dexkit-android:assembleRelease` pass with Small plus callers.
  Android builds cover arm64-v8a, armeabi-v7a, x86 and x86_64. Host ASan/UBSan
  and 32-bit Android compilation do not substitute for Android device execution.

## Evidence and reproduction

[Structured summary](evidence/compact-callers/v2/summary.json),
[validation summary](evidence/compact-callers/v2/validation-summary.json),
[raw evidence](evidence/compact-callers/v2/raw-evidence.tar.gz),
[archive manifest](evidence/compact-callers/v2/manifest.json), and
[per-file integrity](evidence/compact-callers/v2/integrity.json) contain the
accepted plans, commands, samples, reports, logs, fixture generators, bounded
fixtures, source snapshots and artifact identities. QQ APK and compiled
native/JVM/Android outputs are omitted. Obtain the same QQ corpus separately.

The archive's `drivers/build.py`, `validate.py`, `verify_qq.py`, `validate_extra.py`,
`gradle.py` and `measure.py` describe the exact run. Paths are machine-specific
and must be adjusted in a new reproduction. Keep compiler/SDK/JDK versions,
normal diagnostics-OFF settings and input hashes equivalent. Re-run full ordered
verification before accepting newly compiled binaries for timing. `measure.py`
freezes the finite plan before its first measurement.

The native implementation is fixed at e3ec362. Subsequent fixture/report commits
do not change the timed engine. The CMake option is
`DEXKIT_EXPERIMENT_COMPACT_CALLERS`; Gradle uses
`-PexperimentCompactCallers=ON`, alongside the explicitly listed Small options.
''')
report = '\n'.join(lines).rstrip() + '\n'
assert report.isascii()
(ROOT / 'tools/qaux-benchmark/COMPACT-CALLERS-RESULTS.md').write_text(report)
print('Wrote COMPACT-CALLERS-RESULTS.md:', len(report), 'bytes')
