// DexKit - An high-performance runtime parsing library for dex
// implemented in C++.
// Copyright (C) 2022-2023 LuckyPray
// https://github.com/LuckyPray/DexKit
//
// This program is free software: you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation, either
// version 3 of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see
// <https://www.gnu.org/licenses/>.
// <https://github.com/LuckyPray/DexKit/blob/master/LICENSE>.

#include "dex_item.h"

#include "utils/byte_code_util.h"
#include "utils/opcode_util.h"
#include "utils/dex_descriptor_util.h"

#if DEXKIT_BENCHMARK_DIAGNOSTICS
#include <cstdio>
#endif

namespace dexkit {

inline void PushEncodeNumber(dex::InstructionFormat op_format, uint8_t op, const uint16_t *ptr, std::vector<EncodeNumber> *using_numbers);

DexItem::DexItem(uint32_t id, std::shared_ptr<MemMap> mmap, uint32_t header_off, DexKit *dexkit) :
        _image(std::move(mmap)),
        dexkit(dexkit),
        // NOTE: the size passed here is just (mapped_length - header_off).
        // It is NOT the actual logical DEX size. Reader::ValidateHeader()
        // will parse the header and correct the size using header->file_size/
        // container_size. Do not rely on this initial size for bounds checks.
        reader(_image->data() + header_off, _image->len() - header_off),
        dex_id(id) {
    InitBaseCache();
}

void DexItem::InitBaseCache() {
    strings.resize(reader.StringIds().size());
    auto strings_it = strings.begin();
    for (auto &str: reader.StringIds()) {
        auto *str_ptr = reader.dataPtr<dex::u1>(str.string_data_off);
        ReadULeb128(&str_ptr);
        *strings_it++ = reinterpret_cast<const char *>(str_ptr);
    }
    if (!strings.empty() && strings[0].empty()) {
        empty_string_id = 0;
    }

    type_names.resize(reader.TypeIds().size());
    type_name_array_count.resize(reader.TypeIds().size());
    auto type_names_it = type_names.begin();
    int idx = 0;
    for (auto &type_id: reader.TypeIds()) {
        *type_names_it = strings[type_id.descriptor_idx];
        auto array_count = type_names_it->find_first_not_of('[');
        DEXKIT_CHECK(array_count != std::string::npos);
        type_name_array_count[idx] = array_count;
        type_ids_map[*type_names_it++] = idx++;
    }

    uint32_t element_type_idx = dex::kNoIndex;
    auto element_type_class_desc = "Ljava/lang/annotation/ElementType;";
    auto annotation_target_class_desc = "Ljava/lang/annotation/Target;";
    if (type_ids_map.contains(element_type_class_desc)) {
        element_type_idx = type_ids_map[element_type_class_desc];
    }
    if (type_ids_map.contains(annotation_target_class_desc)) {
        annotation_target_class_id = type_ids_map[annotation_target_class_desc];
    }

    uint32_t retention_policy_type_idx = dex::kNoIndex;
    auto retention_policy_class_desc = "Ljava/lang/annotation/RetentionPolicy;";
    auto annotation_retention_class_desc = "Ljava/lang/annotation/Retention;";
    if (type_ids_map.contains(retention_policy_class_desc)) {
        retention_policy_type_idx = type_ids_map[retention_policy_class_desc];
    }
    if (type_ids_map.contains(annotation_retention_class_desc)) {
        annotation_retention_class_id = type_ids_map[annotation_retention_class_desc];
    }

    proto_type_list.resize(reader.ProtoIds().size());
    auto proto_it = proto_type_list.begin();
    for (auto &proto: reader.ProtoIds()) {
        if (proto.parameters_off != 0) {
            auto *type_list_ptr = reader.dataPtr<dex::TypeList>(proto.parameters_off);
            *proto_it = type_list_ptr;
        }
        ++proto_it;
    }

    class_field_ids.resize(reader.TypeIds().size());
    pending_cross_ref_field_ids.resize(reader.TypeIds().size());
    int field_idx = 0;
    for (auto &field: reader.FieldIds()) {
        if (field.class_idx == element_type_idx) {
            auto name = strings[field.name_idx];
            if (name == "TYPE") {
                target_element_map[field_idx] = schema::TargetElementType::Type;
            } else if (name == "FIELD") {
                target_element_map[field_idx] = schema::TargetElementType::Field;
            } else if (name == "METHOD") {
                target_element_map[field_idx] = schema::TargetElementType::Method;
            } else if (name == "PARAMETER") {
                target_element_map[field_idx] = schema::TargetElementType::Parameter;
            } else if (name == "CONSTRUCTOR") {
                target_element_map[field_idx] = schema::TargetElementType::Constructor;
            } else if (name == "LOCAL_VARIABLE") {
                target_element_map[field_idx] = schema::TargetElementType::LocalVariable;
            } else if (name == "ANNOTATION_TYPE") {
                target_element_map[field_idx] = schema::TargetElementType::AnnotationType;
            } else if (name == "PACKAGE") {
                target_element_map[field_idx] = schema::TargetElementType::Package;
            } else if (name == "TYPE_PARAMETER") {
                target_element_map[field_idx] = schema::TargetElementType::TypeParameter;
            } else if (name == "TYPE_USE") {
                target_element_map[field_idx] = schema::TargetElementType::TypeUse;
            }
        } else if (field.class_idx == retention_policy_type_idx) {
            auto name = strings[field.name_idx];
            if (name == "SOURCE") {
                retention_map[field_idx] = schema::RetentionPolicyType::Source;
            } else if (name == "CLASS") {
                retention_map[field_idx] = schema::RetentionPolicyType::Class;
            } else if (name == "RUNTIME") {
                retention_map[field_idx] = schema::RetentionPolicyType::Runtime;
            }
        }
        class_field_ids[field.class_idx].emplace_back(field_idx);
        ++field_idx;
    }

    type_def_flag.resize(reader.TypeIds().size());
    type_def_idx.resize(reader.TypeIds().size());
#if !DEXKIT_EXPERIMENT_RAW_SOURCE_FILES
    class_source_files.resize(reader.TypeIds().size());
#endif
    class_access_flags.resize(reader.TypeIds().size());
#if !DEXKIT_EXPERIMENT_RAW_INTERFACES
    class_interface_ids.resize(reader.TypeIds().size());
#endif
    class_method_ids.resize(reader.TypeIds().size());
    pending_cross_ref_method_ids.resize(reader.TypeIds().size());
    const auto method_count = reader.MethodIds().size();
    const auto field_count = reader.FieldIds().size();
#if DEXKIT_EXPERIMENT_PAGED_DESCRIPTORS || DEXKIT_EXPERIMENT_POINTER_DESCRIPTORS
    method_descriptors.Initialize(method_count);
#else
    method_descriptors.resize(method_count);
#endif
    method_access_flags.resize(method_count);
    method_codes.resize(method_count);
#if !DEXKIT_EXPERIMENT_LAZY_DIRECTORIES
    lazy_method_opcode_slots = std::make_unique<LazyMethodOpCodesSlot[]>(method_count);
    lazy_method_using_string_slots = std::make_unique<LazyMethodUsingStringsSlot[]>(method_count);
    lazy_using_numbers_slots = std::make_unique<LazyUsingNumbersSlot[]>(method_count);
#endif
#if DEXKIT_EXPERIMENT_PAGED_DESCRIPTORS || DEXKIT_EXPERIMENT_POINTER_DESCRIPTORS
    field_descriptors.Initialize(field_count);
#else
    field_descriptors.resize(field_count);
#endif
#if DEXKIT_EXPERIMENT_STRUCTURAL_DESCRIPTORS && !DEXKIT_EXPERIMENT_PAGED_DESCRIPTORS && !DEXKIT_EXPERIMENT_POINTER_DESCRIPTORS
    method_descriptor_ready = std::make_unique<std::atomic<uint8_t>[]>(method_count);
    field_descriptor_ready = std::make_unique<std::atomic<uint8_t>[]>(field_count);
#endif
    field_access_flags.resize(field_count);

    method_cross_info.resize(method_count);
    field_cross_info.resize(field_count);

    auto class_def_idx = 0;
    for (auto &class_def: reader.ClassDefs()) {
        auto def_idx = class_def_idx++;
#if !DEXKIT_EXPERIMENT_RAW_SOURCE_FILES
        if (class_def.source_file_idx != dex::kNoIndex) {
            class_source_files[class_def.class_idx] = strings[class_def.source_file_idx];
        }
#endif
        type_def_flag[class_def.class_idx] = true;
        type_def_idx[class_def.class_idx] = def_idx;
        class_access_flags[class_def.class_idx] = class_def.access_flags;

#if !DEXKIT_EXPERIMENT_RAW_INTERFACES
        if (class_def.interfaces_off) {
            auto interface_type_list = this->reader.dataPtr<dex::TypeList>(class_def.interfaces_off);
            if (interface_type_list != nullptr) {
                auto &interfaces = this->class_interface_ids[class_def.class_idx];
                interfaces.reserve(interface_type_list->size);
                for (auto i = 0; i < interface_type_list->size; ++i) {
                    interfaces.emplace_back(interface_type_list->list[i].type_idx);
                }
            }
        }
#endif

        if (class_def.class_data_off == 0) {
            continue;
        }

        const auto *class_data = reader.dataPtr<dex::u1>(class_def.class_data_off);
        uint32_t static_fields_size = ReadULeb128(&class_data);
        uint32_t instance_fields_count = ReadULeb128(&class_data);
        uint32_t direct_methods_count = ReadULeb128(&class_data);
        uint32_t virtual_methods_count = ReadULeb128(&class_data);

        auto &methods = class_method_ids[class_def.class_idx];

        for (uint32_t i = 0, class_field_idx = 0; i < static_fields_size; ++i) {
            class_field_idx += ReadULeb128(&class_data);
            field_access_flags[class_field_idx] = ReadULeb128(&class_data);
        }

        for (uint32_t i = 0, class_field_idx = 0; i < instance_fields_count; ++i) {
            class_field_idx += ReadULeb128(&class_data);
            field_access_flags[class_field_idx] = ReadULeb128(&class_data);
        }

        for (uint32_t i = 0, class_method_idx = 0; i < direct_methods_count; ++i) {
            class_method_idx += ReadULeb128(&class_data);
            method_access_flags[class_method_idx] = ReadULeb128(&class_data);
            uint32_t code_off = ReadULeb128(&class_data);
            if (code_off) {
                method_codes[class_method_idx] = reader.dataPtr<const dex::Code>(code_off);
            }
            methods.emplace_back(class_method_idx);
        }
        for (uint32_t i = 0, class_method_idx = 0; i < virtual_methods_count; ++i) {
            class_method_idx += ReadULeb128(&class_data);
            method_access_flags[class_method_idx] = ReadULeb128(&class_data);
            uint32_t code_off = ReadULeb128(&class_data);
            if (code_off) {
                method_codes[class_method_idx] = reader.dataPtr<const dex::Code>(code_off);
            }
            methods.emplace_back(class_method_idx);
        }
        std::sort(methods.begin(), methods.end());
    }
    for (uint32_t type_idx = 0; type_idx < type_def_flag.size(); ++type_idx) {
        if (!type_def_flag[type_idx]) {
            std::swap(pending_cross_ref_field_ids[type_idx], class_field_ids[type_idx]);
        }
    }

    auto method_idx = 0;
    for (auto &method_def: reader.MethodIds()) {
        if (!type_def_flag[method_def.class_idx]) {
            pending_cross_ref_method_ids[method_def.class_idx].emplace_back(method_idx);
        }
        ++method_idx;
    }
    {
        static std::mutex put_declare_class_mutex;
        std::lock_guard<std::mutex> lock(put_declare_class_mutex);
        for (auto &class_def: reader.ClassDefs()) {
            dexkit->PutDeclaredClass(type_names[class_def.class_idx], dex_id, class_def.class_idx);
        }
    }
}

bool DexItem::NeedInitCache(uint32_t need_flag) const {
    return (dex_flag.load(std::memory_order_acquire) & need_flag) != need_flag;
}

uint32_t DexItem::BeginInitCache(uint32_t init_flags) {
    std::unique_lock lock(init_cache_state_mutex);
    while (true) {
        auto ready_flags = dex_flag.load(std::memory_order_acquire);
        auto missing_flags = init_flags & ~ready_flags;
        if (missing_flags == 0) {
            return 0;
        }
        if (init_cache_inflight_flags == 0) {
            init_cache_inflight_flags = missing_flags;
            return missing_flags;
        }
        init_cache_state_cv.wait(lock, [this] {
            return init_cache_inflight_flags == 0;
        });
    }
}

void DexItem::FinishInitCache(uint32_t init_flags) {
    {
        std::lock_guard lock(init_cache_state_mutex);
        dex_flag.fetch_or(init_flags, std::memory_order_release);
        init_cache_inflight_flags &= ~init_flags;
    }
    init_cache_state_cv.notify_all();
}

void DexItem::WaitInitCache(uint32_t init_flags) const {
    std::unique_lock lock(init_cache_state_mutex);
    init_cache_state_cv.wait(lock, [this, init_flags] {
        auto ready_flags = dex_flag.load(std::memory_order_acquire);
        return (ready_flags & init_flags) == init_flags;
    });
}

void DexItem::InitCache(uint32_t init_flags) {
#if DEXKIT_BENCHMARK_DIAGNOSTICS
    benchmark_warmup_calls[0].fetch_add(1, std::memory_order_relaxed);
#endif
    bool need_foreach_method = false;
    bool need_op_seq = (init_flags & kOpSequence) != 0;
    bool need_method_using_string = (init_flags & kUsingString) != 0;
    bool need_method_using_field = (init_flags & kMethodUsingField) != 0;
    bool need_method_invoking = (init_flags & kMethodInvoking) != 0;
    bool need_method_caller = (init_flags & kCallerMethod) != 0;
    bool need_field_rw_method = (init_flags & kRwFieldMethod) != 0;
    bool need_class_annotation = (init_flags & kClassAnnotation) != 0;
    bool need_field_annotation = (init_flags & kFieldAnnotation) != 0;
    bool need_method_annotation = (init_flags & kMethodAnnotation) != 0;
    bool need_param_annotation = (init_flags & kParamAnnotation) != 0;
    bool need_annotation = need_class_annotation || need_field_annotation || need_method_annotation || need_param_annotation;
    // only used for full cache
    bool need_method_using_number = (init_flags & kUsingNumber) != 0;

    if (need_op_seq) {
        method_opcode_seq.resize(reader.MethodIds().size(), std::nullopt);
        need_foreach_method = true;
    }
    if (need_method_invoking) {
        method_invoking_ids.resize(reader.MethodIds().size());
        need_foreach_method = true;
    }
    if (need_method_caller) {
#if DEXKIT_EXPERIMENT_COMPACT_CALLERS
        method_caller_ids.BeginCounts(reader.MethodIds().size());
#else
        method_caller_ids.resize(reader.MethodIds().size());
        need_foreach_method = true;
#endif
    }
    if (need_method_using_string) {
        method_using_string_ids.resize(reader.MethodIds().size());
        need_foreach_method = true;
    }
    if (need_method_using_field) {
        method_using_field_ids.resize(reader.MethodIds().size());
        need_foreach_method = true;
    }
    if (need_field_rw_method) {
        field_get_method_ids.resize(reader.FieldIds().size());
        field_put_method_ids.resize(reader.FieldIds().size());
        need_foreach_method = true;
    }
    if (need_method_using_number) {
        method_using_numbers.resize(reader.MethodIds().size());
        need_foreach_method = true;
    }

#if DEXKIT_EXPERIMENT_SKIP_RW_WALK || DEXKIT_BENCHMARK_DIAGNOSTICS
    const bool rw_only = need_field_rw_method && !(need_op_seq || need_method_using_string
            || need_method_using_field || need_method_invoking || need_method_using_number);
#endif
#if DEXKIT_EXPERIMENT_SKIP_RW_WALK
    // Reverse rows consume published forward rows below. A co-requested caller
    // relation also consumes its forward rows when no instruction output is missing.
    if (rw_only) need_foreach_method = false;
#endif
#if DEXKIT_BENCHMARK_DIAGNOSTICS
    uint64_t walked_methods = 0;
    uint64_t walked_instructions = 0;
#endif
    if (need_foreach_method) {
        for (auto &class_def: reader.ClassDefs()) {
            for (auto method_id: class_method_ids[class_def.class_idx]) {
                auto code = method_codes[method_id];
                if (code == nullptr) {
                    continue;
                }
#if DEXKIT_BENCHMARK_DIAGNOSTICS
                ++walked_methods;
#endif

                std::optional<std::vector<uint8_t>> *op_seq_ptr = nullptr;
                std::vector<uint32_t> *method_using_string_ptr = nullptr;
                std::vector<std::pair<uint32_t, bool>> *method_using_field_ptr = nullptr;
                std::vector<uint32_t> *method_invoking_ptr = nullptr;
                std::vector<EncodeNumber> *method_using_number_ptr = nullptr;

                if (need_op_seq) {
                    op_seq_ptr = &method_opcode_seq[method_id];
                    *op_seq_ptr = std::vector<uint8_t>();
                }
                if (need_method_using_string) {
#if DEXKIT_EXPERIMENT_COMPACT_STRINGS
                    method_using_string_ptr = method_using_string_ids.BeginMethod(method_id);
#else
                    method_using_string_ptr = &method_using_string_ids[method_id];
#endif
                }
                if (need_method_using_field) {
#if DEXKIT_EXPERIMENT_COMPACT_FIELDS
                    method_using_field_ptr = method_using_field_ids.BeginMethod(method_id);
#else
                    method_using_field_ptr = &method_using_field_ids[method_id];
#endif
                }
                if (need_method_invoking) {
#if DEXKIT_EXPERIMENT_COMPACT_INVOKES
                    method_invoking_ptr = method_invoking_ids.BeginMethod(method_id);
#else
                    method_invoking_ptr = &method_invoking_ids[method_id];
#endif
                }
                if (need_method_using_number) {
                    method_using_number_ptr = &method_using_numbers[method_id];
                }

                auto p = code->insns;
                auto end_p = p + code->insns_size;
                while (p < end_p) {
#if DEXKIT_BENCHMARK_DIAGNOSTICS
                    ++walked_instructions;
#endif
                    auto op = (uint8_t) *p;
                    if (need_op_seq) {
                        op_seq_ptr->value().emplace_back(op);
                    }
                    auto ptr = p;
                    auto width = GetBytecodeWidth(ptr++);
                    auto op_format = ins_formats[op];

                    if (need_method_using_string) {
                        if (op == 0x1a) { // const-string
                            auto index = ReadShort(ptr);
                            method_using_string_ptr->emplace_back(index);
#if DEXKIT_EXPERIMENT_COMPACT_STRINGS && DEXKIT_BENCHMARK_DIAGNOSTICS
                            method_using_string_ids.ObserveAppend();
#endif
                        } else if (op == 0x1b) { // const-string-jumbo
                            auto index = ReadInt(ptr);
                            method_using_string_ptr->emplace_back(index);
#if DEXKIT_EXPERIMENT_COMPACT_STRINGS && DEXKIT_BENCHMARK_DIAGNOSTICS
                            method_using_string_ids.ObserveAppend();
#endif
                        }
                    }

                    if (need_method_using_field) {
                        if (op >= 0x52 && op <= 0x6d) {
                            // iget, iget-wide, iget-object, iget-boolean, iget-byte, iget-char, iget-short
                            // sget, sget-wide, sget-object, sget-boolean, sget-byte, sget-char, sget-short
                            auto is_getter = ((op >= 0x52 && op <= 0x58) || (op >= 0x60 && op <= 0x66));
                            // iput, iput-wide, iput-object, iput-boolean, iput-byte, iput-char, iput-short
                            // sput, sput-wide, sput-object, sput-boolean, sput-byte, sput-char, sput-short
                            auto is_setter = ((op >= 0x59 && op <= 0x5f) || (op >= 0x67 && op <= 0x6d));
                            auto index = ReadShort(ptr);
                            method_using_field_ptr->emplace_back(index, is_getter);
#if DEXKIT_EXPERIMENT_COMPACT_FIELDS && DEXKIT_BENCHMARK_DIAGNOSTICS
                            method_using_field_ids.ObserveAppend();
#endif
                        }
                    }

                    if (need_method_invoking) {
                        if ((op >= 0x6e && op <= 0x72) // invoke-kind
                            || (op >= 0x74 && op <= 0x78)) { // invoke-kind/range
                            auto index = ReadShort(ptr);
                            method_invoking_ptr->emplace_back(index);
#if DEXKIT_EXPERIMENT_COMPACT_CALLERS
                            if (need_method_caller) method_caller_ids.Count(index);
#endif
#if DEXKIT_EXPERIMENT_COMPACT_INVOKES && DEXKIT_BENCHMARK_DIAGNOSTICS
                            method_invoking_ids.ObserveAppend();
#endif
                        }
                    }

                    if (need_method_using_number) {
                        PushEncodeNumber(op_format, op, ptr, method_using_number_ptr);
                    }

                    p += width;
                }
#if DEXKIT_EXPERIMENT_COMPACT_FIELDS
                if (need_method_using_field) method_using_field_ids.EndMethod(method_id);
#endif
#if DEXKIT_EXPERIMENT_COMPACT_INVOKES
                if (need_method_invoking) method_invoking_ids.EndMethod(method_id);
#endif
#if DEXKIT_EXPERIMENT_COMPACT_STRINGS
                if (need_method_using_string) method_using_string_ids.EndMethod(method_id);
#endif
            }
        }
    }

#if DEXKIT_BENCHMARK_DIAGNOSTICS
    if (need_field_rw_method || need_method_caller) {
        std::fprintf(stderr, "BENCH_INSTRUCTION_WALK {\"dex\":%u,\"flags\":%u,\"rw_only\":%s,\"walk\":%s,\"methods\":%llu,\"instructions\":%llu}\n",
                     dex_id, init_flags, rw_only ? "true" : "false", need_foreach_method ? "true" : "false",
                     static_cast<unsigned long long>(walked_methods), static_cast<unsigned long long>(walked_instructions));
    }
#endif
    if (need_method_caller) {
#if DEXKIT_EXPERIMENT_COMPACT_CALLERS
        // Joint cold extraction counted at the invoke instruction above. Late
        // caller construction only reads the already published forward rows.
        if (!need_method_invoking) {
            for (const auto &class_def : reader.ClassDefs())
                for (auto method_id : class_method_ids[class_def.class_idx])
                    for (auto invoke_id : method_invoking_ids[method_id])
                        method_caller_ids.Count(invoke_id);
        }
#if DEXKIT_BENCHMARK_DIAGNOSTICS
        std::fprintf(stderr, "BENCH_CALLER_COUNT {\"dex\":%u,\"source\":\"%s\"}\n",
                     dex_id, need_method_invoking ? "instruction" : "forward");
#endif
#else
        for (auto &class_def: reader.ClassDefs()) {
            for (auto method_id: class_method_ids[class_def.class_idx]) {
                for (auto invoke_id: method_invoking_ids[method_id]) {
                    method_caller_ids[invoke_id].emplace_back(dex_id, method_id);
                }
            }
        }
#endif
    }

    if (need_field_rw_method) {
        for (auto &class_def: reader.ClassDefs()) {
            for (auto method_id: class_method_ids[class_def.class_idx]) {
                for (auto &field_using: method_using_field_ids[method_id]) {
                    auto field_id = field_using.first;
                    auto is_getter = field_using.second;
                    if (is_getter) {
                        field_get_method_ids[field_id].emplace_back(dex_id, method_id);
                    } else {
                        field_put_method_ids[field_id].emplace_back(dex_id, method_id);
                    }
                }
            }
        }
    }

    if (need_annotation) {
        if (need_class_annotation) {
            class_annotations.resize(reader.TypeIds().size());
        }
        if (need_field_annotation) {
            field_annotations.resize(reader.FieldIds().size());
        }
        if (need_method_annotation) {
            method_annotations.resize(reader.MethodIds().size());
        }
        if (need_param_annotation) {
            method_parameter_annotations.resize(reader.MethodIds().size());
        }

        for (auto &class_def: reader.ClassDefs()) {
            if (class_def.annotations_off == 0) {
                continue;
            }
            auto dex_annotations = reader.dataPtr<dex::AnnotationsDirectoryItem>(class_def.annotations_off);
            if (need_class_annotation) {
                class_annotations[class_def.class_idx] = reader.ExtractAnnotationSet(dex_annotations->class_annotations_off);
            }
            auto *ptr = reinterpret_cast<const dex::u1 *>(dex_annotations + 1);
            if (need_field_annotation) {
                for (dex::u4 i = 0; i < dex_annotations->fields_size; ++i) {
                    auto dex_field_annotation = reinterpret_cast<const dex::FieldAnnotationsItem *>(ptr);
                    field_annotations[dex_field_annotation->field_idx] = reader.ExtractAnnotationSet(dex_field_annotation->annotations_off);
                    ptr += sizeof(dex::FieldAnnotationsItem);
                }
            } else {
                ptr += dex_annotations->fields_size * sizeof(dex::FieldAnnotationsItem);
            }
            if (need_method_annotation) {
                for (dex::u4 i = 0; i < dex_annotations->methods_size; ++i) {
                    auto dex_method_annotation = reinterpret_cast<const dex::MethodAnnotationsItem *>(ptr);
                    method_annotations[dex_method_annotation->method_idx] = reader.ExtractAnnotationSet(dex_method_annotation->annotations_off);
                    ptr += sizeof(dex::MethodAnnotationsItem);
                }
            } else {
                ptr += dex_annotations->methods_size * sizeof(dex::MethodAnnotationsItem);
            }
            if (need_param_annotation) {
                for (dex::u4 i = 0; i < dex_annotations->parameters_size; ++i) {
                    auto dex_parameter_annotation = reinterpret_cast<const dex::ParameterAnnotationsItem *>(ptr);
                    auto dex_annotation_set_ref_list = reader.dataPtr<dex::AnnotationSetRefList>(dex_parameter_annotation->annotations_off);
                    for (dex::u4 j = 0; j < dex_annotation_set_ref_list->size; ++j) {
                        auto dex_annotation_set_ref_item = dex_annotation_set_ref_list->list[j];
                        method_parameter_annotations[dex_parameter_annotation->method_idx].emplace_back(reader.ExtractAnnotationSet(dex_annotation_set_ref_item.annotations_off));
                    }
                    ptr += sizeof(dex::ParameterAnnotationsItem);
                }
            }
        }
    }
}

bool DexItem::NeedPutCrossRef(uint32_t need_cross_flag) const {
    DEXKIT_CHECK((need_cross_flag & ~kCrossRefIdentityFlags) == 0);
    return (dex_cross_flag.load(std::memory_order_acquire) & need_cross_flag) != need_cross_flag;
}

uint32_t DexItem::BeginPutCrossRef(uint32_t put_cross_flag) {
    DEXKIT_CHECK((put_cross_flag & ~kCrossRefIdentityFlags) == 0);
    std::unique_lock lock(cross_ref_state_mutex);
    while (true) {
        auto ready_flags = dex_cross_flag.load(std::memory_order_acquire);
        auto missing_flags = put_cross_flag & ~ready_flags;
        if (missing_flags == 0) {
            return 0;
        }
        if (cross_ref_inflight_flags == 0) {
            cross_ref_inflight_flags = missing_flags;
            return missing_flags;
        }
        cross_ref_state_cv.wait(lock, [this] {
            return cross_ref_inflight_flags == 0;
        });
    }
}

void DexItem::FinishPutCrossRef(uint32_t put_cross_flag) {
    {
        std::lock_guard lock(cross_ref_state_mutex);
        dex_cross_flag.fetch_or(put_cross_flag, std::memory_order_release);
        cross_ref_inflight_flags &= ~put_cross_flag;
    }
    cross_ref_state_cv.notify_all();
}

void DexItem::WaitPutCrossRef(uint32_t put_cross_flag) const {
    std::unique_lock lock(cross_ref_state_mutex);
    cross_ref_state_cv.wait(lock, [this, put_cross_flag] {
        auto ready_flags = dex_cross_flag.load(std::memory_order_acquire);
        return (ready_flags & put_cross_flag) == put_cross_flag;
    });
}

void DexItem::PutCrossRef(uint32_t put_cross_flag) {
#if DEXKIT_BENCHMARK_DIAGNOSTICS
    benchmark_warmup_calls[1].fetch_add(1, std::memory_order_relaxed);
    DescriptorUseScope descriptor_scope(DescriptorUse::CrossReference);
#endif
    DEXKIT_CHECK((put_cross_flag & ~kCrossRefIdentityFlags) == 0);
    bool need_caller_cross = (put_cross_flag & kCallerMethod) != 0;
    bool need_rw_field_cross = (put_cross_flag & kFieldIdentity) != 0;
#if DEXKIT_EXPERIMENT_FIELD_IDENTITY_SPLIT
    // InitDexCache has already published all requested local caches. Preserve
    // the original payload filter when reverse rows exist in this same warmup.
    const bool keep_empty_field_bindings = (dex_flag.load(std::memory_order_acquire) & kRwFieldMethod) == 0;
#else
    constexpr bool keep_empty_field_bindings = false;
#endif

    for (int type_idx = 0; type_idx < type_names.size(); ++type_idx) {
        if (!this->type_def_flag[type_idx] && type_names[type_idx][0] != '[') {
            auto declared_pair = dexkit->GetClassDeclaredPair(type_names[type_idx]);
            auto origin_dex = declared_pair.first;
            auto origin_type_idx = declared_pair.second;

            // no declared in any dex
            if (origin_dex == nullptr) {
                continue;
            }
            auto &mutex = origin_dex->GetTypeDefMutex(origin_type_idx);
            std::lock_guard lock(mutex);

            if (need_caller_cross) {
                const auto &method_ids = this->pending_cross_ref_method_ids[type_idx];

                auto &origin_method_ids = origin_dex->class_method_ids[origin_type_idx];
                for (int ori_i = 0, cur_i = 0; ori_i < origin_method_ids.size() && cur_i < method_ids.size(); ++ori_i) {
                    auto origin_method_idx = origin_method_ids[ori_i];
                    auto curr_method_idx = method_ids[cur_i];
#if DEXKIT_BENCHMARK_DIAGNOSTICS
                    descriptor_diagnostics.method_comparisons.fetch_add(1, std::memory_order_relaxed);
#endif
#if DEXKIT_EXPERIMENT_STRUCTURAL_DESCRIPTORS
                    if (!HasSameMethodIdentity(curr_method_idx, *origin_dex, origin_method_idx)) {
#else
                    auto origin_method_descriptor = origin_dex->GetMethodDescriptor(origin_method_idx);
                    auto curr_method_descriptor = this->GetMethodDescriptor(curr_method_idx);
                    if (curr_method_descriptor != origin_method_descriptor) {
#endif
                        continue;
                    }
                    method_cross_info[curr_method_idx] = {origin_dex->dex_id, origin_method_idx};
#if DEXKIT_EXPERIMENT_COMPACT_CALLERS
                    const auto source_count = method_caller_ids.LocalCount(curr_method_idx);
                    if (source_count != 0) {
#else
                    if (!method_caller_ids[curr_method_idx].empty()) {
#endif
                        pending_aggregate_method_work_items.emplace_back(PendingAggregateMethodWorkItem{
                                .source_method_idx = curr_method_idx,
                                .target_dex_id = static_cast<uint16_t>(origin_dex->dex_id),
                                .target_method_idx = origin_method_idx,
#if DEXKIT_EXPERIMENT_COMPACT_CALLERS
                                .source_count = source_count,
#endif
                        });
                    }
                    ++cur_i;
                }
            }

            if (need_rw_field_cross) {
                const auto &field_ids = this->pending_cross_ref_field_ids[type_idx];

                auto &origin_field_ids = origin_dex->class_field_ids[origin_type_idx];
                for (int ori_i = 0, cur_i = 0; ori_i < origin_field_ids.size() && cur_i < field_ids.size(); ++ori_i) {
                    auto origin_field_idx = origin_field_ids[ori_i];
                    auto curr_field_idx = field_ids[cur_i];
#if DEXKIT_BENCHMARK_DIAGNOSTICS
                    descriptor_diagnostics.field_comparisons.fetch_add(1, std::memory_order_relaxed);
#endif
#if DEXKIT_EXPERIMENT_STRUCTURAL_DESCRIPTORS
                    if (!HasSameFieldIdentity(curr_field_idx, *origin_dex, origin_field_idx)) {
#else
                    auto origin_field_descriptor = origin_dex->GetFieldDescriptor(origin_field_idx);
                    auto curr_field_descriptor = this->GetFieldDescriptor(curr_field_idx);
                    if (origin_field_descriptor != curr_field_descriptor) {
#endif
                        continue;
                    }
                    field_cross_info[curr_field_idx] = {origin_dex->dex_id, origin_field_idx};
                    if (keep_empty_field_bindings || !field_get_method_ids[curr_field_idx].empty()
                            || !field_put_method_ids[curr_field_idx].empty()) {
                        pending_aggregate_field_work_items.emplace_back(PendingAggregateFieldWorkItem{
                                .source_field_idx = curr_field_idx,
                                .target_dex_id = static_cast<uint16_t>(origin_dex->dex_id),
                                .target_field_idx = origin_field_idx
                        });
                    }
                    ++cur_i;
                }
            }
        }
    }

    if (need_caller_cross) {
        pending_cross_ref_method_ids.clear();
        pending_cross_ref_method_ids.shrink_to_fit();
    }
    if (need_rw_field_cross) {
        pending_cross_ref_field_ids.clear();
        pending_cross_ref_field_ids.shrink_to_fit();
    }
}

std::mutex &DexItem::GetTypeDefMutex(uint32_t type_idx) {
    return (*type_def_mutexes)[type_idx % type_def_mutexes->size()];
}

// NOLINTNEXTLINE
ClassBean DexItem::GetClassBean(uint32_t type_idx) {
    if (!this->type_def_flag[type_idx]) {
        auto pair = dexkit->GetClassDeclaredPair(this->type_names[type_idx]);
        if (pair.first) {
            return pair.first->GetClassBean(pair.second);
        }
    }
    ClassBean bean;
    bean.id = type_idx;
    bean.dex_id = this->dex_id;
    bean.dex_descriptor = this->type_names[type_idx];
    if (this->type_def_flag[type_idx]) {
        auto &class_def = this->reader.ClassDefs()[this->type_def_idx[type_idx]];
#if DEXKIT_EXPERIMENT_RAW_SOURCE_FILES
        bean.source_file = GetSourceFileByIndex(class_def.source_file_idx);
#else
        bean.source_file = this->class_source_files[type_idx];
#endif
        bean.access_flags = class_def.access_flags;
        bean.super_class_id = class_def.superclass_idx;
#if DEXKIT_EXPERIMENT_RAW_INTERFACES
        const auto interfaces = GetInterfaceTypeIds(type_idx);
        bean.interface_ids.resize(interfaces.size());
        for (size_t i = 0; i < interfaces.size(); ++i) bean.interface_ids[i] = interfaces[i];
#else
        bean.interface_ids = this->class_interface_ids[type_idx];
#endif
        bean.field_ids = this->class_field_ids[type_idx];
        bean.method_ids = this->class_method_ids[type_idx];
    }
    return bean;
}

#if DEXKIT_EXPERIMENT_RAW_INTERFACES
RawTypeIds DexItem::GetInterfaceTypeIds(uint32_t type_idx) const {
    if (!type_def_flag[type_idx]) return {};
    const auto &definition = reader.ClassDefs()[type_def_idx[type_idx]];
    return RawTypeIds(definition.interfaces_off
            ? reader.dataPtr<dex::TypeList>(definition.interfaces_off) : nullptr);
}
#endif

// NOLINTNEXTLINE
MethodBean DexItem::GetMethodBean(uint32_t method_idx) {
    auto &method_def = this->reader.MethodIds()[method_idx];
    if (!this->type_def_flag[method_def.class_idx]) {
        auto cross_info = this->method_cross_info[method_idx];
        if (cross_info.has_value()) {
            return this->dexkit->GetDexItem(cross_info->first)->GetMethodBean(cross_info->second);
        }
    }
    auto &proto_def = this->reader.ProtoIds()[method_def.proto_idx];
    auto &type_list = this->proto_type_list[method_def.proto_idx];
    MethodBean bean;
    bean.id = method_idx;
    bean.dex_id = this->dex_id;
    bean.class_id = method_def.class_idx;
    bean.access_flags = this->method_access_flags[method_idx];
    bean.dex_descriptor = this->GetMethodDescriptor(method_idx);
    bean.return_type = proto_def.return_type_idx;
    std::vector<uint32_t> parameter_type_ids;
    auto len = type_list ? type_list->size : 0;
    parameter_type_ids.reserve(len);
    for (int i = 0; i < len; ++i) {
        parameter_type_ids.emplace_back(type_list->list[i].type_idx);
    }
    bean.parameter_types = parameter_type_ids;
    return bean;
}

// NOLINTNEXTLINE
FieldBean DexItem::GetFieldBean(uint32_t field_idx) {
    auto &field_def = this->reader.FieldIds()[field_idx];
    if (!this->type_def_flag[field_def.class_idx]) {
        auto cross_info = this->field_cross_info[field_idx];
        if (cross_info.has_value()) {
            return this->dexkit->GetDexItem(cross_info->first)->GetFieldBean(cross_info->second);
        }
    }
    FieldBean bean;
    bean.id = field_idx;
    bean.dex_id = this->dex_id;
    bean.class_id = field_def.class_idx;
    bean.access_flags = this->field_access_flags[field_idx];
    bean.dex_descriptor = this->GetFieldDescriptor(field_idx);
    bean.type_id = field_def.type_idx;
    return bean;
}

std::optional<MethodBean> DexItem::GetMethodBean(uint32_t type_idx, std::string_view method_descriptor) {
#if DEXKIT_BENCHMARK_DIAGNOSTICS
    DescriptorUseScope descriptor_scope(DescriptorUse::Lookup);
#endif
#if DEXKIT_EXPERIMENT_RAW_DESCRIPTOR_LOOKUP
    const auto descriptor = internal::ParseMethodDescriptorView(method_descriptor);
    if (!descriptor || descriptor->declaring_type != type_names[type_idx]) return std::nullopt;
#endif
    auto &methods = this->class_method_ids[type_idx];
    for (auto method_idx: methods) {
#if DEXKIT_BENCHMARK_DIAGNOSTICS
        descriptor_diagnostics.method_comparisons.fetch_add(1, std::memory_order_relaxed);
#endif
#if DEXKIT_EXPERIMENT_RAW_DESCRIPTOR_LOOKUP
        if (MatchesDescriptor(method_idx, *descriptor)) {
#else
        if (this->GetMethodDescriptor(method_idx) == method_descriptor) {
#endif
            return this->GetMethodBean(method_idx);
        }
    }
    return std::nullopt;
}

std::optional<FieldBean> DexItem::GetFieldBean(uint32_t type_idx, std::string_view method_descriptor) {
#if DEXKIT_BENCHMARK_DIAGNOSTICS
    DescriptorUseScope descriptor_scope(DescriptorUse::Lookup);
#endif
#if DEXKIT_EXPERIMENT_RAW_DESCRIPTOR_LOOKUP
    const auto descriptor = internal::ParseFieldDescriptorView(method_descriptor);
    if (!descriptor || descriptor->declaring_type != type_names[type_idx]) return std::nullopt;
#endif
    auto &fields = this->class_field_ids[type_idx];
    for (auto field_idx: fields) {
#if DEXKIT_BENCHMARK_DIAGNOSTICS
        descriptor_diagnostics.field_comparisons.fetch_add(1, std::memory_order_relaxed);
#endif
#if DEXKIT_EXPERIMENT_RAW_DESCRIPTOR_LOOKUP
        if (MatchesDescriptor(field_idx, *descriptor)) {
#else
        if (this->GetFieldDescriptor(field_idx) == method_descriptor) {
#endif
            return this->GetFieldBean(field_idx);
        }
    }
    return std::nullopt;
}

#if DEXKIT_EXPERIMENT_STRUCTURAL_DESCRIPTORS
bool DexItem::HasSameMethodIdentity(uint32_t method_idx, const DexItem &other, uint32_t other_idx) const {
    const auto &left = reader.MethodIds()[method_idx];
    const auto &right = other.reader.MethodIds()[other_idx];
    if (strings[left.name_idx] != other.strings[right.name_idx]
        || type_names[left.class_idx] != other.type_names[right.class_idx]) return false;
    const auto *left_types = proto_type_list[left.proto_idx];
    const auto *right_types = other.proto_type_list[right.proto_idx];
    const auto count = left_types ? left_types->size : 0;
    if (count != (right_types ? right_types->size : 0)) return false;
    const auto &left_proto = reader.ProtoIds()[left.proto_idx];
    const auto &right_proto = other.reader.ProtoIds()[right.proto_idx];
    if (type_names[left_proto.return_type_idx] != other.type_names[right_proto.return_type_idx]) return false;
    for (uint32_t i = 0; i < count; ++i) {
        if (type_names[left_types->list[i].type_idx] != other.type_names[right_types->list[i].type_idx]) return false;
    }
    return true;
}

bool DexItem::HasSameFieldIdentity(uint32_t field_idx, const DexItem &other, uint32_t other_idx) const {
    const auto &left = reader.FieldIds()[field_idx];
    const auto &right = other.reader.FieldIds()[other_idx];
    return strings[left.name_idx] == other.strings[right.name_idx]
        && type_names[left.class_idx] == other.type_names[right.class_idx]
        && type_names[left.type_idx] == other.type_names[right.type_idx];
}

bool DexItem::MatchesDescriptor(uint32_t method_idx, const internal::MethodDescriptorView &descriptor) const {
    const auto &method = reader.MethodIds()[method_idx];
    if (strings[method.name_idx] != descriptor.name
        || type_names[method.class_idx] != descriptor.declaring_type) return false;
    const auto *types = proto_type_list[method.proto_idx];
    const auto count = types ? types->size : 0;
    if (count != descriptor.parameter_count) return false;
    const auto &proto = reader.ProtoIds()[method.proto_idx];
    if (type_names[proto.return_type_idx] != descriptor.return_type) return false;
    auto remaining = descriptor.parameters;
    for (uint32_t i = 0; i < count; ++i) {
        const auto type = type_names[types->list[i].type_idx];
        if (!remaining.starts_with(type)) return false;
        remaining.remove_prefix(type.size());
    }
    return remaining.empty();
}

bool DexItem::MatchesDescriptor(uint32_t field_idx, const internal::FieldDescriptorView &descriptor) const {
    const auto &field = reader.FieldIds()[field_idx];
    return strings[field.name_idx] == descriptor.name
        && type_names[field.class_idx] == descriptor.declaring_type
        && type_names[field.type_idx] == descriptor.type;
}
#endif

// NOLINTNEXTLINE
AnnotationBean DexItem::GetAnnotationBean(ir::Annotation *annotation) {
    AnnotationBean bean;
    bean.dex_id = this->dex_id;
    bean.type_id = annotation->type->orig_index;
    bean.type_descriptor = type_names[annotation->type->orig_index];
    bean.visibility = ((int8_t) annotation->visibility == -1)
            ? schema::AnnotationVisibilityType::None
            : (schema::AnnotationVisibilityType) annotation->visibility;
    for (auto &element : annotation->elements) {
        bean.elements.emplace_back(GetAnnotationElementBean(element));
    }
    return bean;
}

// NOLINTNEXTLINE
AnnotationEncodeValueBean DexItem::GetAnnotationEncodeValueBean(ir::EncodedValue *encoded_value) {
    AnnotationEncodeValueBean bean;
    switch (encoded_value->type) {
        case 0x00: bean.type = schema::AnnotationEncodeValueType::ByteValue; break;
        case 0x02: bean.type = schema::AnnotationEncodeValueType::ShortValue; break;
        case 0x03: bean.type = schema::AnnotationEncodeValueType::CharValue; break;
        case 0x04: bean.type = schema::AnnotationEncodeValueType::IntValue; break;
        case 0x06: bean.type = schema::AnnotationEncodeValueType::LongValue; break;
        case 0x10: bean.type = schema::AnnotationEncodeValueType::FloatValue; break;
        case 0x11: bean.type = schema::AnnotationEncodeValueType::DoubleValue; break;
        case 0x17: bean.type = schema::AnnotationEncodeValueType::StringValue; break;
        case 0x18: bean.type = schema::AnnotationEncodeValueType::TypeValue; break;
        case 0x1a: bean.type = schema::AnnotationEncodeValueType::MethodValue; break;
        case 0x1b: bean.type = schema::AnnotationEncodeValueType::EnumValue; break;
        case 0x1c: bean.type = schema::AnnotationEncodeValueType::ArrayValue; break;
        case 0x1d: bean.type = schema::AnnotationEncodeValueType::AnnotationValue; break;
        case 0x1e: bean.type = schema::AnnotationEncodeValueType::NullValue; break;
        case 0x1f: bean.type = schema::AnnotationEncodeValueType::BoolValue; break;
        default: break;
    }
    switch (encoded_value->type) {
        case 0x00: bean.value = encoded_value->u.byte_value; break;
        case 0x02: bean.value = encoded_value->u.short_value; break;
        case 0x03: bean.value = encoded_value->u.char_value; break;
        case 0x04: bean.value = encoded_value->u.int_value; break;
        case 0x06: bean.value = encoded_value->u.long_value; break;
        case 0x10: bean.value = encoded_value->u.float_value; break;
        case 0x11: bean.value = encoded_value->u.double_value; break;
        case 0x17: bean.value = encoded_value->u.string_value->c_str(); break;
        case 0x18: bean.value = std::make_unique<ClassBean>(GetClassBean(encoded_value->u.type_value->orig_index)); break;
        case 0x1a: bean.value = std::make_unique<MethodBean>(GetMethodBean(encoded_value->u.method_value->orig_index)); break;
        case 0x1b: bean.value = std::make_unique<FieldBean>(GetFieldBean(encoded_value->u.enum_value->orig_index)); break;
        case 0x1c: bean.value = std::make_unique<AnnotationEncodeArrayBean>(GetAnnotationEncodeArrayBean(encoded_value->u.array_value)); break;
        case 0x1d: bean.value = std::make_unique<AnnotationBean>(GetAnnotationBean(encoded_value->u.annotation_value)); break;
        case 0x1e: bean.value = 0; break;
        case 0x1f: bean.value = encoded_value->u.bool_value; break;
        default: break;
    }
    return bean;
}

// NOLINTNEXTLINE
AnnotationElementBean DexItem::GetAnnotationElementBean(ir::AnnotationElement *annotation_element) {
    AnnotationElementBean bean;
    bean.name = annotation_element->name->c_str();
    bean.value = GetAnnotationEncodeValueBean(annotation_element->value);
    return bean;
}

// NOLINTNEXTLINE
AnnotationEncodeArrayBean DexItem::GetAnnotationEncodeArrayBean(ir::EncodedArray *encoded_array) {
    AnnotationEncodeArrayBean array;
    for (auto value: encoded_array->values) {
        array.values.emplace_back(GetAnnotationEncodeValueBean(value));
    }
    return array;
}

std::vector<AnnotationBean>
DexItem::GetClassAnnotationBeans(uint32_t class_idx) {
    if ((dex_flag.load(std::memory_order_acquire) & kClassAnnotation) == 0) {
        auto class_def = reader.ClassDefs()[type_def_idx[class_idx]];
        auto annotationsDirectory = reader.ExtractAnnotations(class_def.annotations_off);
        if (!annotationsDirectory) return {};
        auto annotationSet = annotationsDirectory->class_annotation
                             ? annotationsDirectory->class_annotation->annotations
                             : std::vector<ir::Annotation *>();
        std::vector<AnnotationBean> beans;
        for (auto annotation: annotationSet) {
            AnnotationBean bean = GetAnnotationBean(annotation);
            beans.emplace_back(std::move(bean));
        }
        return beans;
    }
    std::vector<AnnotationBean> beans;
    auto annotationSet = this->class_annotations[class_idx];
    if (annotationSet) {
        for (auto annotation: annotationSet->annotations) {
            AnnotationBean bean = GetAnnotationBean(annotation);
            beans.emplace_back(std::move(bean));
        }
    }
    return beans;
}

std::vector<AnnotationBean>
DexItem::GetMethodAnnotationBeans(uint32_t method_idx) {
    if ((dex_flag.load(std::memory_order_acquire) & kMethodAnnotation) == 0) {
        auto method_def = reader.MethodIds()[method_idx];
        auto class_def = reader.ClassDefs()[type_def_idx[method_def.class_idx]];
        auto annotationsDirectory = reader.ExtractAnnotations(class_def.annotations_off);
        if (!annotationsDirectory) return {};
        for (auto ann_ptr: annotationsDirectory->method_annotations) {
            auto method_decl = ann_ptr->method_decl;
            if (method_decl->orig_index != method_idx) {
                continue;
            }
            auto annotationSet = ann_ptr->annotations
                                 ? ann_ptr->annotations->annotations
                                 : std::vector<ir::Annotation *>();
            std::vector<AnnotationBean> beans;
            for (auto annotation: annotationSet) {
                AnnotationBean bean = GetAnnotationBean(annotation);
                beans.emplace_back(std::move(bean));
            }
            return beans;
        }
        return {};
    }
    auto annotationSet = this->method_annotations[method_idx];
    if (annotationSet == nullptr) {
        return {};
    }
    std::vector<AnnotationBean> beans;
    for (auto annotation: annotationSet->annotations) {
        AnnotationBean bean = GetAnnotationBean(annotation);
        beans.emplace_back(std::move(bean));
    }
    return beans;
}

std::vector<AnnotationBean>
DexItem::GetFieldAnnotationBeans(uint32_t field_idx) {
    if ((dex_flag.load(std::memory_order_acquire) & kFieldAnnotation) == 0) {
        auto field_def = reader.FieldIds()[field_idx];
        auto class_def = reader.ClassDefs()[type_def_idx[field_def.class_idx]];
        auto annotationsDirectory = reader.ExtractAnnotations(class_def.annotations_off);
        if (!annotationsDirectory) return {};
        for (auto ann_ptr: annotationsDirectory->field_annotations) {
            auto field_decl = ann_ptr->field_decl;
            if (field_decl->orig_index != field_idx) {
                continue;
            }
            auto annotationSet = ann_ptr->annotations
                                 ? ann_ptr->annotations->annotations
                                 : std::vector<ir::Annotation *>();
            std::vector<AnnotationBean> beans;
            for (auto annotation: annotationSet) {
                AnnotationBean bean = GetAnnotationBean(annotation);
                beans.emplace_back(std::move(bean));
            }
            return beans;
        }
        return {};
    }
    auto annotationSet = this->field_annotations[field_idx];
    if (annotationSet == nullptr) {
        return {};
    }
    std::vector<AnnotationBean> beans;
    for (auto annotation: annotationSet->annotations) {
        AnnotationBean bean = GetAnnotationBean(annotation);
        beans.emplace_back(std::move(bean));
    }
    return beans;
}

std::vector<std::vector<AnnotationBean>>
DexItem::GetParameterAnnotationBeans(uint32_t method_idx) {
    if ((dex_flag.load(std::memory_order_acquire) & kParamAnnotation) == 0) {
        auto method_def = reader.MethodIds()[method_idx];
        auto class_def = reader.ClassDefs()[type_def_idx[method_def.class_idx]];
        auto annotationsDirectory = reader.ExtractAnnotations(class_def.annotations_off);
        if (!annotationsDirectory) return {};
        std::vector<std::vector<AnnotationBean>> beans;
        for (auto params_ann_ptr: annotationsDirectory->param_annotations) {
            auto method_decl = params_ann_ptr->method_decl;
            if (method_decl->orig_index != method_idx) {
                continue;
            }
            if (params_ann_ptr->annotations == nullptr) {
                return {};
            }
            for (auto ann_ptr : params_ann_ptr->annotations->annotations) {
                auto annotationSet = ann_ptr
                                     ? ann_ptr->annotations
                                     : std::vector<ir::Annotation *>();

                std::vector<AnnotationBean> annotationBeans;
                for (auto annotation: annotationSet) {
                    AnnotationBean bean = GetAnnotationBean(annotation);
                    annotationBeans.emplace_back(std::move(bean));
                }
                beans.emplace_back(std::move(annotationBeans));
            }
            return beans;
        }
        return {};
    }
    std::vector<std::vector<AnnotationBean>> beans;
    auto param_annotations = this->method_parameter_annotations[method_idx];
    if (param_annotations.empty()) {
        return {};
    }
    for (auto annotationSet: param_annotations) {
        std::vector<AnnotationBean> annotationBeans;
        if (annotationSet) {
            for (auto annotation: annotationSet->annotations) {
                AnnotationBean bean = GetAnnotationBean(annotation);
                annotationBeans.emplace_back(std::move(bean));
            }
        }
        beans.emplace_back(std::move(annotationBeans));
    }
    return beans;
}

std::optional<std::vector<std::optional<std::string_view>>>
DexItem::GetParameterNames(uint32_t method_idx) {
    auto code = method_codes[method_idx];
    if (code == nullptr || code->debug_info_off == 0) {
        return {};
    }
    auto *ptr = reader.dataPtr<dex::u1>(code->debug_info_off);
    ReadULeb128(&ptr); // line_start
    auto parameter_count = ReadULeb128(&ptr);
    std::vector<std::optional<std::string_view>> names;
    names.reserve(parameter_count);
    for (auto i = 0; i < parameter_count; ++i) {
        auto name_idx = ReadULeb128(&ptr) - 1;
        if (name_idx == dex::kNoIndex) {
            names.emplace_back(std::nullopt);
        } else {
            names.emplace_back(strings[name_idx]);
        }
    }
    return names;
}

std::vector<uint8_t>
DexItem::GetMethodOpCodes(uint32_t method_idx) {
    // OpCodes stay as a per-method lazy exception: cold metadata reads should not force
    // bridge-level kOpSequence warm-up for the whole DexKit instance.
    if ((dex_flag.load(std::memory_order_acquire) & kOpSequence) != 0) {
        const auto &op_seq = method_opcode_seq[method_idx];
        return op_seq.has_value() ? op_seq.value() : std::vector<uint8_t>();
    }
    return GetLazyMethodOpCodes(method_idx);
}

std::vector<MethodBean> DexItem::GetCallMethods(uint32_t method_idx) {
    DEXKIT_CHECK(!method_caller_ids.empty());
    const auto &method_caller = this->method_caller_ids[method_idx];
    std::vector<MethodBean> beans;
    beans.reserve(method_caller.size());
    for (auto &[ori_dex_id, caller_id]: method_caller) {
        if (ori_dex_id == this->dex_id) {
            beans.emplace_back(GetMethodBean(caller_id));
        } else {
            auto dex = dexkit->GetDexItem(ori_dex_id);
            beans.emplace_back(dex->GetMethodBean(caller_id));
        }
    }
    return beans;
}

std::vector<MethodBean> DexItem::GetInvokeMethods(uint32_t method_idx) {
    DEXKIT_CHECK(!method_invoking_ids.empty());
    const auto &method_invoking = this->method_invoking_ids[method_idx];
    std::vector<MethodBean> beans;
    beans.reserve(method_invoking.size());
    for (auto invoking_id: method_invoking) {
        beans.emplace_back(GetMethodBean(invoking_id));
    }
    return beans;
}

std::vector<std::string_view> DexItem::GetUsingStrings(uint32_t method_idx) {
    // Using-strings follows the same rule as opcodes: per-method lazy fallback is allowed
    // for metadata getters, while matcher/query hot paths rely on the outer ready barrier.
    std::vector<std::string_view> using_strings;
    std::span<const uint32_t> method_using_strings;
    if ((dex_flag.load(std::memory_order_acquire) & kUsingString) != 0) {
        method_using_strings = method_using_string_ids[method_idx];
    } else {
        method_using_strings = GetLazyMethodUsingStringIds(method_idx);
    }
    using_strings.reserve(method_using_strings.size());
    for (auto string_id: method_using_strings) {
        using_strings.emplace_back(this->strings[string_id]);
    }
    return using_strings;
}

std::vector<UsingFieldBean> DexItem::GetUsingFields(uint32_t method_idx) {
    // Cross-ref accessors intentionally have no fallback: callers must enter through the
    // DexKit barrier so these final shared indexes are already published.
    DEXKIT_CHECK(!method_using_field_ids.empty());
    const auto &method_using_fields = this->method_using_field_ids[method_idx];
    std::vector<UsingFieldBean> using_fields;
    using_fields.reserve(method_using_fields.size());
    for (auto [method_id, is_getting]: method_using_fields) {
        UsingFieldBean bean;
        bean.field = GetFieldBean(method_id);
        bean.is_getting = is_getting;
        using_fields.emplace_back(bean);
    }
    return using_fields;
}

std::vector<MethodBean> DexItem::FieldGetMethods(uint32_t field_idx) {
#if DEXKIT_BENCHMARK_DIAGNOSTICS
    benchmark_field_reverse_reads[2].fetch_add(1, std::memory_order_relaxed);
#endif
    DEXKIT_CHECK(!field_get_method_ids.empty());
    const auto &method_ids = this->field_get_method_ids[field_idx];
    std::vector<MethodBean> beans;
    beans.reserve(method_ids.size());
    for (auto &[ori_dex_id, method_id]: method_ids) {
        if (ori_dex_id == this->dex_id) {
            beans.emplace_back(GetMethodBean(method_id));
        } else {
            auto dex = dexkit->GetDexItem(ori_dex_id);
            beans.emplace_back(dex->GetMethodBean(method_id));
        }
    }
    return beans;
}

std::vector<MethodBean> DexItem::FieldPutMethods(uint32_t field_idx) {
#if DEXKIT_BENCHMARK_DIAGNOSTICS
    benchmark_field_reverse_reads[3].fetch_add(1, std::memory_order_relaxed);
#endif
    DEXKIT_CHECK(!field_put_method_ids.empty());
    const auto &method_ids = this->field_put_method_ids[field_idx];
    std::vector<MethodBean> beans;
    beans.reserve(method_ids.size());
    for (auto &[ori_dex_id, method_id]: method_ids) {
        if (ori_dex_id == this->dex_id) {
            beans.emplace_back(GetMethodBean(method_id));
        } else {
            auto dex = dexkit->GetDexItem(ori_dex_id);
            beans.emplace_back(dex->GetMethodBean(method_id));
        }
    }
    return beans;
}

std::string_view DexItem::GetMethodDescriptor(uint32_t method_idx) {
#if DEXKIT_EXPERIMENT_DESCRIPTOR_FAST_HITS
#if DEXKIT_EXPERIMENT_PAGED_DESCRIPTORS || DEXKIT_EXPERIMENT_POINTER_DESCRIPTORS
    if (auto cached = method_descriptors.TryGet(method_idx)) return *cached;
#else
    if (method_descriptor_ready[method_idx].load(std::memory_order_acquire)) {
        // The ready publication guarantees an engaged immutable optional.
        return *method_descriptors[method_idx];
    }
#endif
    return GetMethodDescriptorCold(method_idx);
}

std::string_view DexItem::GetMethodDescriptorCold(uint32_t method_idx) {
#endif
#if DEXKIT_EXPERIMENT_PAGED_DESCRIPTORS
    return method_descriptors.GetOrCreate(method_idx,
        [this, method_idx](auto &&emit) { VisitMethodDescriptorParts(method_idx, emit); },
        [this](size_t bytes) {
#if DEXKIT_BENCHMARK_DIAGNOSTICS
            descriptor_diagnostics.Built(true, bytes);
#endif
        });
#else
#if DEXKIT_EXPERIMENT_POINTER_DESCRIPTORS
    if (auto cached = method_descriptors.TryGet(method_idx)) return *cached;
    std::lock_guard descriptor_lock(descriptor_mutexes[method_idx % descriptor_mutexes.size()]);
    if (auto cached = method_descriptors.TryGet(method_idx)) return *cached;
#else
#if DEXKIT_EXPERIMENT_STRUCTURAL_DESCRIPTORS
    if (method_descriptor_ready[method_idx].load(std::memory_order_acquire)) {
        return method_descriptors[method_idx].value();
    }
    std::lock_guard descriptor_lock(descriptor_mutexes[method_idx % descriptor_mutexes.size()]);
#endif
    auto &method_desc = this->method_descriptors[method_idx];
    if (method_desc != std::nullopt) {
        return method_desc.value();
    }
#endif
    auto &method_def = this->reader.MethodIds()[method_idx];
    auto &proto_def = this->reader.ProtoIds()[method_def.proto_idx];
    auto &type_list = this->proto_type_list[method_def.proto_idx];
    auto type_defs = this->reader.TypeIds();

    std::string descriptor(this->type_names[method_def.class_idx]);
    descriptor += "->";
    descriptor += this->strings[method_def.name_idx];
    descriptor += "(";
    auto len = type_list ? type_list->size : 0;
    for (int i = 0; i < len; ++i) {
        descriptor += strings[type_defs[type_list->list[i].type_idx].descriptor_idx];
    }
    descriptor += ')';
    descriptor += strings[type_defs[proto_def.return_type_idx].descriptor_idx];

#if DEXKIT_EXPERIMENT_POINTER_DESCRIPTORS
    // Copy, as the dense optional path does, to preserve string capacity policy.
    auto owned = std::make_unique<std::string>(descriptor);
#else
    method_desc = descriptor;
#endif
#if DEXKIT_BENCHMARK_DIAGNOSTICS
    descriptor_diagnostics.Built(true, descriptor.size());
#endif
#if DEXKIT_EXPERIMENT_POINTER_DESCRIPTORS
    return method_descriptors.Publish(method_idx, std::move(owned));
#else
#if DEXKIT_EXPERIMENT_STRUCTURAL_DESCRIPTORS
    method_descriptor_ready[method_idx].store(1, std::memory_order_release);
#endif
    return method_desc.value();
#endif
#endif
}

std::string_view DexItem::GetFieldDescriptor(uint32_t field_idx) {
#if DEXKIT_EXPERIMENT_DESCRIPTOR_FAST_HITS
#if DEXKIT_EXPERIMENT_PAGED_DESCRIPTORS || DEXKIT_EXPERIMENT_POINTER_DESCRIPTORS
    if (auto cached = field_descriptors.TryGet(field_idx)) return *cached;
#else
    if (field_descriptor_ready[field_idx].load(std::memory_order_acquire)) {
        return *field_descriptors[field_idx];
    }
#endif
    return GetFieldDescriptorCold(field_idx);
}

std::string_view DexItem::GetFieldDescriptorCold(uint32_t field_idx) {
#endif
#if DEXKIT_EXPERIMENT_PAGED_DESCRIPTORS
    return field_descriptors.GetOrCreate(field_idx,
        [this, field_idx](auto &&emit) { VisitFieldDescriptorParts(field_idx, emit); },
        [this](size_t bytes) {
#if DEXKIT_BENCHMARK_DIAGNOSTICS
            descriptor_diagnostics.Built(false, bytes);
#endif
        });
#else
#if DEXKIT_EXPERIMENT_POINTER_DESCRIPTORS
    if (auto cached = field_descriptors.TryGet(field_idx)) return *cached;
    std::lock_guard descriptor_lock(descriptor_mutexes[field_idx % descriptor_mutexes.size()]);
    if (auto cached = field_descriptors.TryGet(field_idx)) return *cached;
#else
#if DEXKIT_EXPERIMENT_STRUCTURAL_DESCRIPTORS
    if (field_descriptor_ready[field_idx].load(std::memory_order_acquire)) {
        return field_descriptors[field_idx].value();
    }
    std::lock_guard descriptor_lock(descriptor_mutexes[field_idx % descriptor_mutexes.size()]);
#endif
    auto &field_desc = this->field_descriptors[field_idx];
    if (field_desc != std::nullopt) {
        return field_desc.value();
    }
#endif
    auto &field_id = this->reader.FieldIds()[field_idx];
    auto &type_id = this->reader.TypeIds()[field_id.type_idx];

    std::string descriptor(this->type_names[field_id.class_idx]);
    descriptor += "->";
    descriptor += this->strings[field_id.name_idx];
    descriptor += ":";
    descriptor += this->strings[type_id.descriptor_idx];

#if DEXKIT_EXPERIMENT_POINTER_DESCRIPTORS
    // Copy, as the dense optional path does, to preserve string capacity policy.
    auto owned = std::make_unique<std::string>(descriptor);
#else
    field_desc = descriptor;
#endif
#if DEXKIT_BENCHMARK_DIAGNOSTICS
    descriptor_diagnostics.Built(false, descriptor.size());
#endif
#if DEXKIT_EXPERIMENT_POINTER_DESCRIPTORS
    return field_descriptors.Publish(field_idx, std::move(owned));
#else
#if DEXKIT_EXPERIMENT_STRUCTURAL_DESCRIPTORS
    field_descriptor_ready[field_idx].store(1, std::memory_order_release);
#endif
    return field_desc.value();
#endif
#endif
}

std::vector<uint8_t> DexItem::GetOpSeqFromCode(uint32_t method_idx) {
    auto code = method_codes[method_idx];
    if (code == nullptr) {
        return {};
    }
    std::vector<uint8_t> op_seq;
    auto p = code->insns;
    auto end_p = p + code->insns_size;
    while (p < end_p) {
        op_seq.emplace_back((uint8_t) *p);
        p += GetBytecodeWidth(p);
    }
    return std::move(op_seq);
}

std::vector<uint32_t> DexItem::GetUsingStringsFromCode(uint32_t method_idx) {
    auto code = method_codes[method_idx];
    if (code == nullptr) {
        return {};
    }
    std::vector<uint32_t> using_strings;
    auto p = code->insns;
    auto end_p = p + code->insns_size;
    while (p < end_p) {
        auto op = (uint8_t) *p;
        auto ptr = p;
        auto width = GetBytecodeWidth(ptr++);
        if (op == 0x1a) { // const-string
            auto index = ReadShort(ptr);
            using_strings.emplace_back(index);
        } else if (op == 0x1b) { // const-string-jumbo
            auto index = ReadInt(ptr);
            using_strings.emplace_back(index);
        }
        p += width;
    }
    return std::move(using_strings);
}

const std::vector<uint8_t> &DexItem::GetLazyMethodOpCodes(uint32_t method_idx) {
#if DEXKIT_EXPERIMENT_LAZY_DIRECTORIES
    std::call_once(lazy_opcode_directory_once, [this] {
        lazy_method_opcode_slots = std::make_unique<LazyMethodOpCodesSlot[]>(reader.MethodIds().size());
    });
#endif
    auto &slot = lazy_method_opcode_slots[method_idx];
    auto state = slot.state.load(std::memory_order_acquire);
    if (state == static_cast<uint8_t>(LazyMethodFeatureState::Ready)) {
        return *slot.data;
    }

    uint8_t expected = static_cast<uint8_t>(LazyMethodFeatureState::Empty);
    if (slot.state.compare_exchange_strong(expected,
                                           static_cast<uint8_t>(LazyMethodFeatureState::Building),
                                           std::memory_order_acq_rel,
                                           std::memory_order_acquire)) {
        auto built_data = std::make_unique<const std::vector<uint8_t>>(GetOpSeqFromCode(method_idx));
        auto stripe = method_idx % lazy_method_wait_mutexes->size();
        {
            std::lock_guard lock((*lazy_method_wait_mutexes)[stripe]);
            slot.data = std::move(built_data);
            slot.state.store(static_cast<uint8_t>(LazyMethodFeatureState::Ready), std::memory_order_release);
        }
        (*lazy_method_wait_cvs)[stripe].notify_all();
        return *slot.data;
    }

    auto stripe = method_idx % lazy_method_wait_mutexes->size();
    std::unique_lock lock((*lazy_method_wait_mutexes)[stripe]);
    (*lazy_method_wait_cvs)[stripe].wait(lock, [&slot] {
        return slot.state.load(std::memory_order_acquire) == static_cast<uint8_t>(LazyMethodFeatureState::Ready);
    });
    return *slot.data;
}

const std::vector<uint32_t> &DexItem::GetLazyMethodUsingStringIds(uint32_t method_idx) {
#if DEXKIT_EXPERIMENT_LAZY_DIRECTORIES
    std::call_once(lazy_string_directory_once, [this] {
        lazy_method_using_string_slots = std::make_unique<LazyMethodUsingStringsSlot[]>(reader.MethodIds().size());
    });
#endif
    auto &slot = lazy_method_using_string_slots[method_idx];
    auto state = slot.state.load(std::memory_order_acquire);
    if (state == static_cast<uint8_t>(LazyMethodFeatureState::Ready)) {
        return *slot.data;
    }

    uint8_t expected = static_cast<uint8_t>(LazyMethodFeatureState::Empty);
    if (slot.state.compare_exchange_strong(expected,
                                           static_cast<uint8_t>(LazyMethodFeatureState::Building),
                                           std::memory_order_acq_rel,
                                           std::memory_order_acquire)) {
        auto built_data = std::make_unique<const std::vector<uint32_t>>(GetUsingStringsFromCode(method_idx));
        auto stripe = method_idx % lazy_method_wait_mutexes->size();
        {
            std::lock_guard lock((*lazy_method_wait_mutexes)[stripe]);
            slot.data = std::move(built_data);
            slot.state.store(static_cast<uint8_t>(LazyMethodFeatureState::Ready), std::memory_order_release);
        }
        (*lazy_method_wait_cvs)[stripe].notify_all();
        return *slot.data;
    }

    auto stripe = method_idx % lazy_method_wait_mutexes->size();
    std::unique_lock lock((*lazy_method_wait_mutexes)[stripe]);
    (*lazy_method_wait_cvs)[stripe].wait(lock, [&slot] {
        return slot.state.load(std::memory_order_acquire) == static_cast<uint8_t>(LazyMethodFeatureState::Ready);
    });
    return *slot.data;
}

std::vector<uint32_t> DexItem::GetInvokeMethodsFromCode(uint32_t method_idx) {
    auto code = method_codes[method_idx];
    if (code == nullptr) {
        return {};
    }
    std::vector<uint32_t> invoke_methods;
    auto p = code->insns;
    auto end_p = p + code->insns_size;
    while (p < end_p) {
        auto op = (uint8_t) *p;
        auto ptr = p;
        auto width = GetBytecodeWidth(ptr++);
        auto op_format = ins_formats[op];
        if (op_format == dex::k35c // invoke-kind
            || op_format == dex::k3rc) { // invoke-kind/range
            auto index = ReadShort(ptr);
            invoke_methods.emplace_back(index);
        }
        p += width;
    }
    return std::move(invoke_methods);
}

void PushEncodeNumber(dex::InstructionFormat op_format, uint8_t op, const uint16_t *ptr, std::vector<EncodeNumber> *using_numbers) {
    switch (op_format) {
        // using number
        case dex::k11n: { // const/4
            uint8_t value = *(ptr - 1) >> 12;
            if (value & 0x8) {
                value |= 0xf0;
            }
            using_numbers->emplace_back(EncodeNumber{.type = BYTE, .value = {.L8 = (int8_t) value}});
            break;
        }
        case dex::k21s: { // const/16, const-wide/16
            uint16_t value = *ptr;
            if (value & 0x8000) {
                value |= 0xffff0000;
            }
            using_numbers->emplace_back(EncodeNumber{.type = SHORT, .value = {.L16 = (int16_t) value}});
            break;
        }
        case dex::k21h: { // const/high16, const-wide/high16
            if (op == 0x15) {
                using_numbers->emplace_back(EncodeNumber{.type = FLOAT, .value = {.L32 = {.int_value = (int32_t) (*ptr << 16)}}});
            } else { // 0x19
                using_numbers->emplace_back(EncodeNumber{.type = DOUBLE, .value = {.L64 = {.long_value = (int64_t) (((uint64_t) *ptr) << 48)}}});
            }
            break;
        }
        case dex::k31i: { // const, const-wide/32
            if (op == 0x14) {
                using_numbers->emplace_back(EncodeNumber{.type = FLOAT, .value = {.L32 = {.int_value = (int32_t) ReadInt(ptr)}}});
            } else { // 0x17
                using_numbers->emplace_back(EncodeNumber{.type = INT, .value = {.L32 = {.int_value = (int32_t) ReadInt(ptr)}}});
            }
            break;
        }
        case dex::k51l: // const-wide
            using_numbers->emplace_back(EncodeNumber{.type = LONG, .value = {.L64 = {.long_value = (int64_t) ReadLong(ptr)}}});
            break;
        case dex::k22s: // binop/lit16
            using_numbers->emplace_back(EncodeNumber{.type = SHORT, .value = {.L16 = (int16_t) *ptr}});
            break;
        case dex::k22b: // binop/lit8
            using_numbers->emplace_back(EncodeNumber{.type = BYTE, .value = {.L8 = (int8_t) (*ptr >> 8)}});
            break;
        default:
            break;
    }
}

std::vector<EncodeNumber> DexItem::ParseUsingNumbersFromCode(uint32_t method_idx) {
    auto code = method_codes[method_idx];
    if (code == nullptr) {
        return {};
    }
    std::vector<EncodeNumber> using_numbers;
    auto p = code->insns;
    auto end_p = p + code->insns_size;
    while (p < end_p) {
        auto op = (uint8_t) *p;
        auto ptr = p;
        auto width = GetBytecodeWidth(ptr++);
        auto op_format = ins_formats[op];
        PushEncodeNumber(op_format, op, ptr, &using_numbers);
        p += width;
    }
    return using_numbers;
}

const std::vector<EncodeNumber> &DexItem::GetUsingNumbers(uint32_t method_idx) {
    if ((dex_flag.load(std::memory_order_acquire) & kUsingNumber) != 0) {
        return method_using_numbers[method_idx];
    }

    // Using-numbers remains a sparse per-method lazy cache because full warm-up cost and
    // resident memory are too high for the typical "read one method's metadata" path.
#if DEXKIT_EXPERIMENT_LAZY_DIRECTORIES
    std::call_once(lazy_number_directory_once, [this] {
        lazy_using_numbers_slots = std::make_unique<LazyUsingNumbersSlot[]>(reader.MethodIds().size());
    });
#endif
    auto &slot = lazy_using_numbers_slots[method_idx];
    auto state = slot.state.load(std::memory_order_acquire);
    if (state == static_cast<uint8_t>(LazyMethodFeatureState::Ready)) {
        return *slot.data;
    }

    uint8_t expected = static_cast<uint8_t>(LazyMethodFeatureState::Empty);
    if (slot.state.compare_exchange_strong(expected,
                                           static_cast<uint8_t>(LazyMethodFeatureState::Building),
                                           std::memory_order_acq_rel,
                                           std::memory_order_acquire)) {
        auto built_data = std::make_unique<const std::vector<EncodeNumber>>(ParseUsingNumbersFromCode(method_idx));
        auto stripe = method_idx % lazy_method_wait_mutexes->size();
        {
            std::lock_guard lock((*lazy_method_wait_mutexes)[stripe]);
            slot.data = std::move(built_data);
            slot.state.store(static_cast<uint8_t>(LazyMethodFeatureState::Ready), std::memory_order_release);
        }
        (*lazy_method_wait_cvs)[stripe].notify_all();
        return *slot.data;
    }

    auto stripe = method_idx % lazy_method_wait_mutexes->size();
    std::unique_lock lock((*lazy_method_wait_mutexes)[stripe]);
    (*lazy_method_wait_cvs)[stripe].wait(lock, [&slot] {
        return slot.state.load(std::memory_order_acquire) == static_cast<uint8_t>(LazyMethodFeatureState::Ready);
    });
    return *slot.data;
}

bool DexItem::CheckAllTypeNamesDeclared(std::vector<std::string_view> &types) {
    for (auto &type: types) { // NOLINT
        if (!this->type_ids_map.contains(NameToDescriptor(type))) {
            return false;
        }
    }
    return true;
}

}
