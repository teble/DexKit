// DexKit - An high-performance runtime parsing library for dex
// implemented in C++.
// Copyright (C) 2022-2023 LuckyPray
// https://github.com/LuckyPray/DexKit
//
// This program is free software: you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation, either
// version 3 of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see
// <https://www.gnu.org/licenses/>.
// <https://github.com/LuckyPray/DexKit/blob/master/LICENSE>.

#include "dex_item.h"
#include "benchmark_diagnostics.h"
#include "string_query_diagnostics.h"
#include "field_query_diagnostics.h"
#if DEXKIT_EXPERIMENT_SINGLE_STRING_DIRECT || DEXKIT_EXPERIMENT_SINGLE_STRING_ID || DEXKIT_EXPERIMENT_INVERTED_STRINGS
#include "single_string_index.h"
#endif
#include <type_traits>
#include "matcher_thread_cache_registry.h"
#include "utils/dex_descriptor_util.h"

#include <algorithm>
#include <mutex>

namespace dexkit {

#if DEXKIT_EXPERIMENT_RAW_INTERFACES || DEXKIT_EXPERIMENT_COMPACT_INVOKES || DEXKIT_EXPERIMENT_COMPACT_FIELDS || DEXKIT_EXPERIMENT_COMPACT_CALLERS
template<typename T, typename U, typename Targets = std::vector<T>>
#else
template<typename T, typename U>
#endif
class Hungarian {
private:
    std::vector<U> left;
#if DEXKIT_EXPERIMENT_RAW_INTERFACES || DEXKIT_EXPERIMENT_COMPACT_INVOKES || DEXKIT_EXPERIMENT_COMPACT_FIELDS || DEXKIT_EXPERIMENT_COMPACT_CALLERS
    Targets right;
#else
    std::vector<T> right;
#endif
    std::vector<std::vector<int8_t>> map;
    std::vector<int> p;
    std::vector<bool> vis;
    std::function<bool(T&, U&)> judge;
    bool fast_fail = false;
public:
#if DEXKIT_EXPERIMENT_RAW_INTERFACES || DEXKIT_EXPERIMENT_COMPACT_INVOKES || DEXKIT_EXPERIMENT_COMPACT_FIELDS || DEXKIT_EXPERIMENT_COMPACT_CALLERS
    Hungarian(const Targets &targets, const std::vector<U> &matchers, std::function<bool(T&, U&)> match) {
#else
    Hungarian(const std::vector<T> &targets, const std::vector<U> &matchers, std::function<bool(T&, U&)> match) {
#endif
        if (matchers.size() > targets.size()) {
            fast_fail = true;
            return;
        }
        this->left = matchers;
        this->right = targets;
        map.resize(left.size());
        for (int i = 0; i < left.size(); ++i) {
            map[i].resize(right.size());
        }
        p.resize(right.size(), -1);
        vis.resize(right.size());
        this->judge = match;
    }

    // NOLINTNEXTLINE
    bool dfs(int i) {
        for (int j = 0; j < right.size(); ++j) {
            if (vis[j]) continue;
            if (!map[i][j]) {
#if DEXKIT_EXPERIMENT_RAW_INTERFACES || DEXKIT_EXPERIMENT_COMPACT_INVOKES || DEXKIT_EXPERIMENT_COMPACT_FIELDS || DEXKIT_EXPERIMENT_COMPACT_CALLERS
                if constexpr (!std::is_same_v<Targets, std::vector<T>>) {
                    auto target = right[j];
                    map[i][j] = judge(target, left[i]) ? 1 : -1;
                } else
#endif
                {
                    map[i][j] = judge(right[j], left[i]) ? 1 : -1;
                }
            }
            if (map[i][j] > 0) {
                vis[j] = true;
                if (p[j] < 0 || dfs(p[j])) {
                    p[j] = i;
                    return true;
                }
            }
        }
        return false;
    }

    int solve() {
        if (fast_fail || left.empty() || right.empty()) {
            return 0;
        }
        int ans = 0;
        for (int i = 0; i < left.size(); ++i) {
            std::fill(vis.begin(), vis.end(), false);
            if (!dfs(i)) {
                return 0;
            }
            ans++;
        }
        return ans;
    }

};

// NOLINTNEXTLINE
static std::vector<uint32_t> GetAnnotationUsingStrings(const ir::Annotation *annotation) {
    if (annotation == nullptr) return {};
    std::vector<uint32_t> result;
    for (auto element: annotation->elements) {
        if (element->value->type == dex::kEncodedString) {
            result.push_back(element->value->u.string_value->orig_index);
        } else if (element->value->type == dex::kEncodedAnnotation) {
            auto sub_result = GetAnnotationUsingStrings(element->value->u.annotation_value);
            result.insert(result.end(), sub_result.begin(), sub_result.end());
        } else if (element->value->type == dex::kEncodedArray) {
            for (auto sub_value: element->value->u.array_value->values) {
                if (sub_value->type == dex::kEncodedString) {
                    result.push_back(sub_value->u.string_value->orig_index);
                } else if (sub_value->type == dex::kEncodedAnnotation) {
                    auto sub_result = GetAnnotationUsingStrings(sub_value->u.annotation_value);
                    result.insert(result.end(), sub_result.begin(), sub_result.end());
                }
            }
        }
    }
    return result;
}

void ConvertSimilarRegex(std::string_view &str, schema::StringMatchType &type) {
    if (type == schema::StringMatchType::SimilarRegex) {
        type = schema::StringMatchType::Contains;
        if (str.front() == '^') {
            type = schema::StringMatchType::StartWith;
            str = str.substr(1);
        }
        if (str.back() == '$') {
            if (type == schema::StringMatchType::StartWith) {
                type = schema::StringMatchType::Equal;
            } else {
                type = schema::StringMatchType::EndWith;
            }
            str = str.substr(0, str.size() - 1);
        }
    }
}

enum class MatcherCacheScope : uint8_t {
    AnnotationUsingStringsKeywords = 1,
    AnnotationMatchers,
    AnnotationEncodeValueMatchers,
    AnnotationElementMatchers,
    StringMatcherNormalized,
    TypeNameDescriptor,
    ClassUsingStringsKeywords,
    InterfaceMatchers,
    FieldMatchers,
    MethodMatchers,
    OpCodeMatchers,
    MethodUsingStringsKeywords,
    UsingFieldMatchers,
    UsingNumbers,
#if DEXKIT_EXPERIMENT_SINGLE_STRING_DIRECT || DEXKIT_EXPERIMENT_SINGLE_STRING_ID
    SingleUsingString,
#endif
};

namespace {

template<typename T>
static bool HasNonEmptyVector(const T *vector) {
    return vector != nullptr && vector->size() > 0;
}

template<typename T, typename MatchFunc>
static bool MatchAllOf(const flatbuffers::Vector<flatbuffers::Offset<T>> *matchers, MatchFunc &&match_func) {
    if (!HasNonEmptyVector(matchers)) {
        return true;
    }
    for (int i = 0; i < matchers->size(); ++i) {
        if (!match_func(matchers->Get(i))) {
            return false;
        }
    }
    return true;
}

template<typename T, typename MatchFunc>
static bool MatchAnyOf(const flatbuffers::Vector<flatbuffers::Offset<T>> *matchers, MatchFunc &&match_func) {
    if (!HasNonEmptyVector(matchers)) {
        return true;
    }
    for (int i = 0; i < matchers->size(); ++i) {
        if (match_func(matchers->Get(i))) {
            return true;
        }
    }
    return false;
}

template<typename T, typename MatchFunc>
static bool MatchNoneOf(const flatbuffers::Vector<flatbuffers::Offset<T>> *matchers, MatchFunc &&match_func) {
    if (!HasNonEmptyVector(matchers)) {
        return true;
    }
    for (int i = 0; i < matchers->size(); ++i) {
        if (match_func(matchers->Get(i))) {
            return false;
        }
    }
    return true;
}

static bool HasLogicalGroups(const schema::ClassMatcher *matcher) {
    return matcher != nullptr && (
            HasNonEmptyVector(matcher->all_of())
            || HasNonEmptyVector(matcher->any_of())
            || HasNonEmptyVector(matcher->none_of())
    );
}

static bool HasLogicalGroups(const schema::MethodMatcher *matcher) {
    return matcher != nullptr && (
            HasNonEmptyVector(matcher->all_of())
            || HasNonEmptyVector(matcher->any_of())
            || HasNonEmptyVector(matcher->none_of())
    );
}

static bool HasLogicalGroups(const schema::FieldMatcher *matcher) {
    return matcher != nullptr && (
            HasNonEmptyVector(matcher->all_of())
            || HasNonEmptyVector(matcher->any_of())
            || HasNonEmptyVector(matcher->none_of())
    );
}

static bool CanUseKeywordUsingStringMatcher(const schema::StringMatcher *matcher) {
    return matcher != nullptr && matcher->value() != nullptr;
}

static bool CanUseKeywordUsingStringsMatchers(
        const flatbuffers::Vector<flatbuffers::Offset<schema::StringMatcher>> *using_strings_matcher
) {
    if (using_strings_matcher == nullptr) {
        return true;
    }
    for (int i = 0; i < using_strings_matcher->size(); ++i) {
        if (!CanUseKeywordUsingStringMatcher(using_strings_matcher->Get(i))) {
            return false;
        }
    }
    return true;
}

struct MatcherThreadLocalCacheSlot {
    void *cache = nullptr;
    void (*deleter)(void *) = nullptr;
};

std::mutex &GetMatcherThreadLocalCacheRegistryMutex() {
    static std::mutex mutex;
    return mutex;
}

phmap::flat_hash_map<std::thread::id, std::vector<MatcherThreadLocalCacheSlot>> &GetMatcherThreadLocalCacheRegistry() {
    static phmap::flat_hash_map<std::thread::id, std::vector<MatcherThreadLocalCacheSlot>> registry;
    return registry;
}

constexpr size_t kPersistentUsingStringsCacheLimit = 32;

struct NormalizedUsingStringMatcher {
    std::string value;
    schema::StringMatchType match_type = schema::StringMatchType::Contains;
    bool ignore_case = false;
};

struct PersistentUsingStringsKeywordsCache {
    using AcTrie = acdat::AhoCorasickDoubleArrayTrie<std::string_view>;
    using MatchTypeMap = phmap::flat_hash_map<std::string_view, schema::StringMatchType>;
    using StringSet = std::set<std::string_view>;

    std::vector<std::string> owned_keywords;
    std::shared_ptr<AcTrie> ac_trie = std::make_shared<AcTrie>();
    std::shared_ptr<MatchTypeMap> match_type_map = std::make_shared<MatchTypeMap>();
    std::shared_ptr<StringSet> real_keywords = std::make_shared<StringSet>();
};

struct PersistentUsingStringsThreadCache {
    struct Entry {
        std::string key;
        std::shared_ptr<PersistentUsingStringsKeywordsCache> value;
    };

    template<typename Factory>
    std::shared_ptr<PersistentUsingStringsKeywordsCache> GetOrCreate(std::string key, Factory &&factory) {
        for (auto &entry: entries) {
            if (entry.key == key) {
                return entry.value;
            }
        }
        if (entries.size() >= kPersistentUsingStringsCacheLimit) {
            entries.erase(entries.begin());
        }
        entries.push_back(Entry{
                .key = std::move(key),
                .value = std::make_shared<PersistentUsingStringsKeywordsCache>(std::forward<Factory>(factory)()),
        });
        return entries.back().value;
    }

    std::vector<Entry> entries;
};

static std::vector<NormalizedUsingStringMatcher> NormalizeUsingStringsMatchers(
        const flatbuffers::Vector<flatbuffers::Offset<schema::StringMatcher>> *using_strings_matcher
) {
    std::vector<NormalizedUsingStringMatcher> normalized;
    if (using_strings_matcher == nullptr) {
        return normalized;
    }
    normalized.reserve(using_strings_matcher->size());
    for (int i = 0; i < using_strings_matcher->size(); ++i) {
        auto string_matcher = using_strings_matcher->Get(i);
        auto value = string_matcher->value()->string_view();
        auto match_type = string_matcher->match_type();
        if (match_type == schema::StringMatchType::SimilarRegex) {
            match_type = schema::StringMatchType::Contains;
            int left = 0;
            int right = static_cast<int>(value.size());
            if (value.starts_with('^')) {
                left = 1;
                match_type = schema::StringMatchType::StartWith;
            }
            if (value.ends_with('$')) {
                right = static_cast<int>(value.size()) - 1;
                if (match_type == schema::StringMatchType::StartWith) {
                    match_type = schema::StringMatchType::Equal;
                } else {
                    match_type = schema::StringMatchType::EndWith;
                }
            }
            value = value.substr(left, right - left);
        }
        normalized.push_back(NormalizedUsingStringMatcher{
                .value = std::string(value),
                .match_type = match_type,
                .ignore_case = string_matcher->ignore_case(),
        });
    }
    return normalized;
}

static std::string BuildUsingStringsCacheKey(const std::vector<NormalizedUsingStringMatcher> &normalized) {
    size_t total_size = 0;
    for (const auto &item: normalized) {
        total_size += 2 + sizeof(uint32_t) + item.value.size();
    }
    std::string key;
    key.reserve(total_size);
    for (const auto &item: normalized) {
        key.push_back(static_cast<char>(item.match_type));
        key.push_back(static_cast<char>(item.ignore_case ? 1 : 0));
        auto len = static_cast<uint32_t>(item.value.size());
        key.append(reinterpret_cast<const char *>(&len), sizeof(len));
        key.append(item.value);
    }
    return key;
}

static PersistentUsingStringsKeywordsCache BuildPersistentUsingStringsKeywordsCache(
        const std::vector<NormalizedUsingStringMatcher> &normalized
) {
    PersistentUsingStringsKeywordsCache cache;
    cache.owned_keywords.reserve(normalized.size());
    cache.match_type_map->reserve(normalized.size());

    std::vector<std::pair<std::string_view, bool>> keywords;
    keywords.reserve(normalized.size());
    for (const auto &item: normalized) {
        cache.owned_keywords.emplace_back(item.value);
        auto keyword = std::string_view(cache.owned_keywords.back());
        keywords.emplace_back(keyword, item.ignore_case);
        cache.real_keywords->insert(keyword);
        (*cache.match_type_map)[keyword] = item.match_type;
    }
    acdat::Builder<std::string_view>().Build(keywords, cache.ac_trie.get());
    return cache;
}

static std::shared_ptr<PersistentUsingStringsKeywordsCache> GetPersistentUsingStringsKeywordsCache(
        const flatbuffers::Vector<flatbuffers::Offset<schema::StringMatcher>> *using_strings_matcher
) {
    // Avoid direct non-trivial thread_local destruction on Windows DLL TLS
    // teardown. Keep the TLS slot trivially destructible and free native-owned
    // worker-thread instances through the registry before the worker exits.
    thread_local PersistentUsingStringsThreadCache *cache = nullptr;
    if (cache == nullptr) {
        cache = new PersistentUsingStringsThreadCache();
        RegisterMatcherThreadLocalCache(
                std::this_thread::get_id(),
                cache,
                [](void *ptr) {
                    if (cache == ptr) {
                        cache = nullptr;
                    }
                    delete reinterpret_cast<PersistentUsingStringsThreadCache *>(ptr);
                }
        );
    }
    auto normalized = NormalizeUsingStringsMatchers(using_strings_matcher);
    auto key = BuildUsingStringsCacheKey(normalized);
    return cache->GetOrCreate(std::move(key), [&]() {
        return BuildPersistentUsingStringsKeywordsCache(normalized);
    });
}

} // namespace

struct MatcherThreadLocalQueryCache {
    struct Entry {
        QueryCacheKey key;
        // QueryContext owns the actual cache object lifetime.
        // The per-thread matcher fast path only memoizes the raw address for the
        // current query to avoid shared_ptr refcount traffic on every cache hit.
        void *value = nullptr;
    };

    uint64_t query_id = 0;
    std::vector<Entry> entries;

    void Rebind(uint64_t current_query_id) {
        if (query_id != current_query_id) {
            entries.clear();
            query_id = current_query_id;
        }
    }

    [[nodiscard]] void *Find(const QueryCacheKey &cache_key) const {
        for (const auto &entry: entries) {
            if (!(entry.key == cache_key)) {
                continue;
            }
            return entry.value;
        }
        return nullptr;
    }

    void Put(const QueryCacheKey &cache_key, void *value) {
        for (auto &entry: entries) {
            if (entry.key == cache_key) {
                entry.value = value;
                return;
            }
        }
        entries.push_back(Entry{cache_key, value});
    }
};

static MatcherThreadLocalQueryCache &GetMatcherThreadLocalQueryCache() {
    thread_local MatcherThreadLocalQueryCache *cache = nullptr;
    if (cache == nullptr) {
        cache = new MatcherThreadLocalQueryCache();
        RegisterMatcherThreadLocalCache(
                std::this_thread::get_id(),
                cache,
                [](void *ptr) {
                    if (cache == ptr) {
                        cache = nullptr;
                    }
                    delete reinterpret_cast<MatcherThreadLocalQueryCache *>(ptr);
                }
        );
    }
    return *cache;
}

template<typename T, typename Factory>
static T *GetMatcherCache(MatcherCacheScope scope, std::uintptr_t key, Factory &&factory) {
    auto *query_context = QueryContext::Current();
    DEXKIT_CHECK(query_context != nullptr);
    auto &query_cache = GetMatcherThreadLocalQueryCache();
    query_cache.Rebind(query_context->GetQueryId());

    auto cache_key = QueryCacheKey{static_cast<uint8_t>(scope), key};
    auto cached = query_cache.Find(cache_key);
    if (cached != nullptr) {
        return reinterpret_cast<T *>(cached);
    }

    auto *ptr = query_context->GetOrCreateMatcherCache<T>(static_cast<uint8_t>(scope), key, std::forward<Factory>(factory));
    // Safe because QueryContext owns the matcher cache object until the query
    // ends, and Rebind(query_id) clears any stale per-thread entries before reuse.
    query_cache.Put(cache_key, ptr);
    return ptr;
}

static PersistentUsingStringsKeywordsCache *GetUsingStringsKeywordsCache(
        MatcherCacheScope scope,
        const flatbuffers::Vector<flatbuffers::Offset<schema::StringMatcher>> *using_strings_matcher
) {
    if (using_strings_matcher == nullptr) {
        return nullptr;
    }
    DEXKIT_CHECK(CanUseKeywordUsingStringsMatchers(using_strings_matcher));
    if (QueryContext::Current() == nullptr) {
        return GetPersistentUsingStringsKeywordsCache(using_strings_matcher).get();
    }
    auto *cache_ref = GetMatcherCache<std::shared_ptr<PersistentUsingStringsKeywordsCache>>(
            scope,
            POINT_CASE(using_strings_matcher),
            [&]() {
                return GetPersistentUsingStringsKeywordsCache(using_strings_matcher);
            }
    );
    return cache_ref->get();
}

#if DEXKIT_EXPERIMENT_INVERTED_STRINGS
bool DexItem::CanUseInvertedStrings(const StringMatcherVector *matchers) const {
    if (!matchers || matchers->size() == 0 || !CanUseKeywordUsingStringsMatchers(matchers)) return false;
    // Empty patterns have intentionally different ordinary/Batch semantics;
    // let the established matcher handle these cheap, degenerate root queries.
    for (const auto *matcher : *matchers) if (matcher->value()->size() == 0) return false;
    return true;
}

inverted_string::QueryPlan DexItem::PlanRootStringCandidates(const schema::MethodMatcher *matcher) const {
    if (!matcher) return {};
    const bool strings_only = !matcher->method_name() && !matcher->access_flags() && !matcher->declaring_class()
            && !matcher->return_type() && !matcher->parameters() && !matcher->annotations() && !matcher->op_codes()
            && !matcher->using_fields() && !matcher->using_numbers() && !matcher->invoking_methods()
            && !matcher->method_callers() && !matcher->proto_shorty() && !HasLogicalGroups(matcher);
    return PlanRootStringCandidates(matcher->using_strings(), false, strings_only);
}

inverted_string::QueryPlan DexItem::PlanRootStringCandidates(const schema::ClassMatcher *matcher) const {
    if (!matcher) return {};
    const bool strings_only = !matcher->smali_source() && !matcher->class_name() && !matcher->access_flags()
            && !matcher->super_class() && !matcher->interfaces() && !matcher->annotations()
            && !matcher->fields() && !matcher->methods() && !HasLogicalGroups(matcher);
    return PlanRootStringCandidates(matcher->using_strings(), true, strings_only);
}

inverted_string::QueryPlan DexItem::PlanRootStringCandidates(const StringMatcherVector *matchers,
        bool classes, bool strings_only) const {
    using Plan = inverted_string::QueryPlan;
    Plan plan;
    plan.reason = Plan::Reason::Ineligible;
    if (!matchers || matchers->size() == 0) return plan;
    if (!strings_only) {
        // This is a conservative admission rule, not a guess that a name,
        // flag, or relation is selective. Keep its existing filtering order
        // and parallel slices unless an already-published range is bounded.
        plan.reason = Plan::Reason::ExtraConditions;
#if !DEXKIT_EXPERIMENT_INVERTED_STRING_RANGES
        return plan;
#else
        plan.index_ready = inverted_strings_ready.load(std::memory_order_acquire);
        plan.reason = Plan::Reason::ColdIndex;
        if (!plan.index_ready) return plan;
#endif
    } else {
        plan.index_ready = inverted_strings_ready.load(std::memory_order_acquire);
    }
    plan.reason = Plan::Reason::Ineligible;
    if (!strings_only && matchers->size() != 1) return plan;
    if (!CanUseInvertedStrings(matchers)) return plan;
    const auto entities = classes ? type_names.size() : reader.MethodIds().size();
    if (matchers->size() == 1) {
        const auto *matcher = matchers->Get(0);
        const auto type = matcher->match_type();
        if (!matcher->ignore_case() && (type == schema::StringMatchType::Equal
                || type == schema::StringMatchType::StartWith)) {
            const auto range = single_string::FindIds(strings, matcher->value()->string_view(),
                    type == schema::StringMatchType::StartWith);
            if (range.valid) {
                plan.begin = range.begin;
                plan.end = range.end;
                if (plan.index_ready) plan.postings = inverted_strings.CountRange(range.begin, range.end);
                if (!strings_only && plan.postings > 1) {
                    plan.reason = Plan::Reason::PostingBound;
                    return plan;
                }
                plan.reason = strings_only ? Plan::Reason::PureStrings : Plan::Reason::SmallRange;
                if (range.begin == range.end || (plan.index_ready && plan.postings == 0)) {
                    plan.route = Plan::Route::Empty;
                    return plan;
                }
                if (inverted_string::WordCount(entities) > inverted_string::kBitmapBudget / sizeof(uint64_t)) {
                    plan.reason = Plan::Reason::BitmapBudget;
                    return plan;
                }
                plan.route = Plan::Route::Range;
                return plan;
            }
        }
    }
    if (!strings_only) return plan;
    // Raw keyword count is an upper bound on the canonical planes. Reject
    // before collapsing slices, without building an AC trie to estimate cost.
    if (!inverted_string::BitmapPlanBytes(entities, type_names.size(), matchers->size(), 1)) {
        plan.reason = Plan::Reason::BitmapBudget;
        return plan;
    }
    plan.route = Plan::Route::Keywords;
    plan.reason = Plan::Reason::PureStrings;
    return plan;
}

bool DexItem::BuildRootStringCandidates(const StringMatcherVector *matchers, bool classes,
        const inverted_string::QueryPlan &plan, inverted_string::Bits &hits) {
    using Route = inverted_string::QueryPlan::Route;
    if (plan.route == Route::Legacy || plan.route == Route::Empty) return false;
    if (plan.route == Route::Range) {
        if (!plan.index_ready && !EnsureInvertedStrings()) return false;
        hits = inverted_string::Bits(classes ? type_names.size() : reader.MethodIds().size());
        inverted_strings.VisitRange(plan.begin, plan.end, [&](uint32_t method) {
            hits.Set(classes ? reader.MethodIds()[method].class_idx : method);
        });
        return true;
    }
    auto *cache = GetUsingStringsKeywordsCache(classes ? MatcherCacheScope::ClassUsingStringsKeywords
            : MatcherCacheScope::MethodUsingStringsKeywords, matchers);
    if (cache->real_keywords->empty()) return false;
    const std::map<std::string_view, std::set<std::string_view>> groups{{"", *cache->real_keywords}};
    StringCandidateGroups candidates;
    if (!BuildStringCandidateGroups(*cache->ac_trie, groups, *cache->match_type_map, classes, candidates)) return false;
    hits = std::move(candidates.front().second);
    return true;
}
#endif

#if DEXKIT_EXPERIMENT_SINGLE_STRING_DIRECT || DEXKIT_EXPERIMENT_SINGLE_STRING_ID
namespace {
struct SingleUsingStringPlan {
    std::string_view needle;
    bool prefix;
    bool eligible;
#if DEXKIT_EXPERIMENT_SINGLE_STRING_ID
    single_string::DexRanges dex_ranges;
#endif

    SingleUsingStringPlan(std::string_view value, bool is_prefix, const DexKit *bridge)
            : needle(value), prefix(is_prefix), eligible(single_string::IsNonemptyAscii(value))
#if DEXKIT_EXPERIMENT_SINGLE_STRING_ID
            , dex_ranges(eligible ? static_cast<size_t>(bridge->GetDexNum()) : 0)
#endif
    {
        DEXKIT_STRING_COUNT(plans, 1);
        DEXKIT_STRING_COUNT(plan_bytes, sizeof(*this));
#if DEXKIT_EXPERIMENT_SINGLE_STRING_ID
        DEXKIT_STRING_COUNT(plan_bytes, dex_ranges.StorageBytes());
#else
        (void)bridge;
#endif
    }

#if DEXKIT_EXPERIMENT_SINGLE_STRING_ID
    template<typename Strings>
    const single_string::IdRange *RangeFor(uint32_t dex_id, const Strings &strings) {
        return dex_ranges.Get(dex_id, strings, needle, prefix);
    }
#endif
};

static SingleUsingStringPlan *GetSingleUsingStringPlan(
        const flatbuffers::Vector<flatbuffers::Offset<schema::StringMatcher>> *matchers,
        const DexKit *bridge) {
    if (matchers == nullptr || matchers->size() != 1) return nullptr;
    const auto *matcher = matchers->Get(0);
    if (matcher == nullptr || matcher->value() == nullptr || matcher->value()->size() == 0
            || matcher->ignore_case()) return nullptr;
    const auto type = matcher->match_type();
    bool prefix = false;
    if (type != schema::StringMatchType::Equal) {
#if DEXKIT_EXPERIMENT_SINGLE_STRING_PREFIX
        if (type != schema::StringMatchType::StartWith) return nullptr;
        prefix = true;
#else
        return nullptr;
#endif
    }
    const auto *context = QueryContext::Current();
    if (context == nullptr || (context->GetKind() != QueryKind::FindMethod
            && context->GetKind() != QueryKind::FindClass)) return nullptr;
    auto *plan = GetMatcherCache<SingleUsingStringPlan>(
            MatcherCacheScope::SingleUsingString, POINT_CASE(matchers), [&] {
                return SingleUsingStringPlan(matcher->value()->string_view(), prefix, bridge);
            });
    return plan->eligible ? plan : nullptr;
}

template<typename Strings, typename VisitReferences>
std::optional<bool> TrySingleUsingString(
        const flatbuffers::Vector<flatbuffers::Offset<schema::StringMatcher>> *matchers,
        const DexKit *bridge, uint32_t dex_id, const Strings &strings,
        VisitReferences &&visit) {
    auto *plan = GetSingleUsingStringPlan(matchers, bridge);
    if (plan == nullptr) return std::nullopt;
#if DEXKIT_EXPERIMENT_SINGLE_STRING_DIRECT
    DEXKIT_STRING_COUNT(direct_calls, 1);
#if DEXKIT_EXPERIMENT_SINGLE_STRING_PREFIX
    if (plan->prefix) {
        return visit([&](uint32_t string_id) {
            DEXKIT_STRING_COUNT(direct_refs, 1);
            return kmp::starts_with(strings[string_id], plan->needle);
        });
    }
#endif
    return visit([&](uint32_t string_id) {
        DEXKIT_STRING_COUNT(direct_refs, 1);
        return kmp::equals(strings[string_id], plan->needle);
    });
#else
    const auto *range = plan->RangeFor(dex_id, strings);
    if (range == nullptr) return std::nullopt;
    DEXKIT_STRING_COUNT(index_calls, 1);
    if (range->begin == range->end) return false;
#if DEXKIT_EXPERIMENT_SINGLE_STRING_PREFIX
    if (plan->prefix) {
        return visit([&](uint32_t string_id) {
            DEXKIT_STRING_COUNT(index_refs, 1);
            return range->begin <= string_id && string_id < range->end;
        });
    }
#endif
    return visit([&](uint32_t string_id) {
        DEXKIT_STRING_COUNT(index_refs, 1);
        return range->begin == string_id;
    });
#endif
}
}
#endif

void RegisterMatcherThreadLocalCache(
        std::thread::id thread_id,
        void *cache,
        void (*deleter)(void *)
) {
    std::lock_guard lock(GetMatcherThreadLocalCacheRegistryMutex());
    GetMatcherThreadLocalCacheRegistry()[thread_id].push_back(MatcherThreadLocalCacheSlot{
            .cache = cache,
            .deleter = deleter,
    });
}

void ReleaseCurrentThreadLocalCaches() {
    std::vector<MatcherThreadLocalCacheSlot> slots;
    {
        std::lock_guard lock(GetMatcherThreadLocalCacheRegistryMutex());
        auto &registry = GetMatcherThreadLocalCacheRegistry();
        auto it = registry.find(std::this_thread::get_id());
        if (it == registry.end()) {
            return;
        }
        slots = std::move(it->second);
        registry.erase(it);
    }
    for (const auto &slot: slots) {
        if (slot.cache != nullptr && slot.deleter != nullptr) {
            slot.deleter(slot.cache);
        }
    }
}

static bool IsStringMatchedAtomic(std::string_view str, const schema::StringMatcher *matcher) {
    if (matcher == nullptr || matcher->value() == nullptr) {
        return true;
    }
    auto match_type = matcher->match_type();
    auto match_str = matcher->value()->string_view();
    ConvertSimilarRegex(match_str, match_type);

    bool condition;
    switch (match_type) {
        case schema::StringMatchType::StartWith: condition = kmp::starts_with(str, match_str, matcher->ignore_case()); break;
        case schema::StringMatchType::EndWith: condition = kmp::ends_with(str, match_str, matcher->ignore_case()); break;
        case schema::StringMatchType::Equal: condition = kmp::equals(str, match_str, matcher->ignore_case()); break;
        case schema::StringMatchType::Contains: {
            auto index = kmp::FindIndex(str, match_str, matcher->ignore_case());
            condition = index != -1;
            break;
        }
        case schema::StringMatchType::SimilarRegex: abort();
    }
    return condition;
}

bool DexItem::IsStringMatched(std::string_view str, const schema::StringMatcher *matcher) {
    if (matcher == nullptr) {
        return true;
    }
    return IsStringMatchedAtomic(str, matcher);
}

bool DexItem::IsAccessFlagsMatched(uint32_t access_flags, const schema::AccessFlagsMatcher *matcher) {
    if (matcher == nullptr) {
        return true;
    }
    DEXKIT_CHECK(matcher->flags() != 0);
    switch (matcher->match_type()) {
        case schema::MatchType::Equal: return access_flags == matcher->flags();
        case schema::MatchType::Contains: return (access_flags & matcher->flags()) == matcher->flags();
    }
    return false;
}

std::set<std::string_view> DexItem::BuildBatchFindKeywordsMap(
        const flatbuffers::Vector<flatbuffers::Offset<schema::StringMatcher>> *using_strings_matcher,
        std::vector<std::pair<std::string_view, bool>> &keywords,
        phmap::flat_hash_map<std::string_view, schema::StringMatchType> &match_type_map
) {
    DEXKIT_CHECK(CanUseKeywordUsingStringsMatchers(using_strings_matcher));
    auto result = std::set<std::string_view>();
    for (int i = 0; i < using_strings_matcher->size(); ++i) {
        auto string_matcher = using_strings_matcher->Get(i);
        auto value = string_matcher->value()->string_view();
        auto type = string_matcher->match_type();
        auto ignore_case = string_matcher->ignore_case();
        if (type == schema::StringMatchType::SimilarRegex) {
            type = schema::StringMatchType::Contains;
            int l = 0, r = (int) value.size();
            if (value.starts_with('^')) {
                l = 1;
                type = schema::StringMatchType::StartWith;
            }
            if (value.ends_with('$')) {
                r = (int) value.size() - 1;
                if (type == schema::StringMatchType::StartWith) {
                    type = schema::StringMatchType::Equal;
                } else {
                    type = schema::StringMatchType::EndWith;
                }
            }
            value = value.substr(l, r - l);
        }
        result.insert(value);
        keywords.emplace_back(value, ignore_case);
        match_type_map[value] = type;
    }
    return result;
}

bool DexItem::IsAnnotationMatched(const ir::Annotation *annotation, const schema::AnnotationMatcher *matcher) {
    if (matcher == nullptr) {
        return true;
    }
    if (annotation == nullptr) {
        return false;
    }
    if (!IsClassMatched(annotation->type->orig_index, matcher->type())) {
        return false;
    }
    if (matcher->target_element_types() || (uint8_t) matcher->policy()) {
        DEXKIT_CHECK(class_annotations.size() == reader.TypeIds().size());
        auto m_class_annotations = this->class_annotations[annotation->type->orig_index];
        if (m_class_annotations == nullptr) {
            return false;
        }
        ir::Annotation *retention_annotation = nullptr;
        ir::Annotation *target_annotation = nullptr;
        for (auto ann: m_class_annotations->annotations) {
            if (ann->type->orig_index == this->annotation_retention_class_id) {
                retention_annotation = ann;
            } else if (ann->type->orig_index == this->annotation_target_class_id) {
                target_annotation = ann;
            }
        }
        if ((uint8_t) matcher->policy()) {
            DEXKIT_CHECK(retention_annotation->elements.size() == 1);
            auto element = retention_annotation->elements[0];
            auto field_idx = element->value->u.enum_value->orig_index;
            DEXKIT_CHECK(this->retention_map.contains(field_idx));
            if (this->retention_map[field_idx] != matcher->policy()) {
                return false;
            }
        }
        if (matcher->target_element_types()) {
            auto target_element_types = matcher->target_element_types();
            uint32_t target_flags = 0, matcher_flags = 0;

            for (auto element: target_annotation->elements) {
                auto field_idx = element->value->u.enum_value->orig_index;
                DEXKIT_CHECK(this->target_element_map.contains(field_idx));
                target_flags |= 1 << (uint8_t) this->target_element_map[field_idx];
            }

            for (int i = 0; i < target_element_types->types()->size(); ++i) {
                auto type = target_element_types->types()->Get(i);
                matcher_flags |= 1 << (uint8_t) type;
            }

            bool condition = false;
            switch (target_element_types->match_type()) {
                case schema::MatchType::Equal: condition = target_flags == matcher_flags; break;
                case schema::MatchType::Contains: condition = (target_flags & matcher_flags) == matcher_flags; break;
            }
            if (!condition) {
                return false;
            }
        }
    }
    if (!IsAnnotationElementsMatched(annotation->elements, matcher->elements())) {
        return false;
    }
    if (!IsAnnotationUsingStringsMatched(annotation, matcher)) {
        return false;
    }
    return true;
}

bool DexItem::IsAnnotationUsingStringsMatched(const ir::Annotation *annotation, const schema::AnnotationMatcher *matcher) {
    if (matcher->using_strings() == nullptr) {
        return true;
    }

    if (!CanUseKeywordUsingStringsMatchers(matcher->using_strings())) {
        auto using_string_ids = GetAnnotationUsingStrings(annotation);
        std::vector<std::string_view> using_strings;
        using_strings.reserve(using_string_ids.size());
        for (auto idx: using_string_ids) {
            using_strings.emplace_back(this->strings[idx]);
        }
        for (int i = 0; i < matcher->using_strings()->size(); ++i) {
            auto string_matcher = matcher->using_strings()->Get(i);
            bool matched = false;
            for (auto str: using_strings) {
                if (IsStringMatched(str, string_matcher)) {
                    matched = true;
                    break;
                }
            }
            if (!matched) {
                return false;
            }
        }
        return true;
    }

    auto *keywords_cache = GetUsingStringsKeywordsCache(
            MatcherCacheScope::AnnotationUsingStringsKeywords,
            matcher->using_strings()
    );
    auto &acTrie = keywords_cache->ac_trie;
    auto &match_type_map = keywords_cache->match_type_map;
    auto &real_keywords = keywords_cache->real_keywords;

    auto using_empty_string_count = 0;
    std::set<std::string_view> search_set;
    auto using_strings = GetAnnotationUsingStrings(annotation);
    for (auto idx: using_strings) {
        if (idx == this->empty_string_id) ++using_empty_string_count;
        auto str = this->strings[idx];
        auto hits = acTrie->ParseText(str);
        for (auto &hit: hits) {
            auto match_type = match_type_map->find(hit.value)->second;
            bool match;
            switch (match_type) {
                case schema::StringMatchType::Contains: match = true; break;
                case schema::StringMatchType::StartWith: match = (hit.begin == 0); break;
                case schema::StringMatchType::EndWith: match = (hit.end == str.size()); break;
                case schema::StringMatchType::Equal: match = (hit.begin == 0 && hit.end == str.size()); break;
                case schema::StringMatchType::SimilarRegex: abort();
            }
            if (match) {
                search_set.insert(hit.value);
            }
        }
    }
    if (match_type_map->contains("")) {
        DEXKIT_CHECK((*match_type_map)[""] == schema::StringMatchType::Equal);
        if (using_empty_string_count) {
            search_set.insert("");
        }
    }
    if (search_set.size() < real_keywords->size()) {
        return false;
    }
    std::vector<std::string_view> unique_vec;
    std::set_intersection(search_set.begin(), search_set.end(),
                          real_keywords->begin(), real_keywords->end(),
                          std::inserter(unique_vec, unique_vec.begin()));
    if (unique_vec.size() != real_keywords->size()) {
        return false;
    }
    return true;
}

bool DexItem::IsAnnotationsMatched(const ir::AnnotationSet *annotationSet, const schema::AnnotationsMatcher *matcher) {
    if (matcher == nullptr) {
        return true;
    }
    auto annotation_set_size = annotationSet == nullptr ? 0 : annotationSet->annotations.size();
    if (matcher->annotation_count()) {
        if (annotation_set_size < matcher->annotation_count()->min()
        || annotation_set_size > matcher->annotation_count()->max()) {
            return false;
        }
    }
    if (matcher->annotations()) {
        auto IsAnnotationMatched = [this](ir::Annotation *annotation, const schema::AnnotationMatcher *matcher) {
            return this->IsAnnotationMatched(annotation, matcher);
        };

        typedef std::vector<const schema::AnnotationMatcher *> AnnotationMatcher;
        auto ptr = GetMatcherCache<AnnotationMatcher>(MatcherCacheScope::AnnotationMatchers, POINT_CASE(matcher->annotations()),
                                                      [&]() {
            auto vec = AnnotationMatcher{};
            for (auto annotation : *matcher->annotations()) {
                vec.push_back(annotation);
            }
            return vec;
        });

        auto &annotation_matches = *ptr;
        if (annotation_matches.size() > annotation_set_size) {
            return false;
        }
        Hungarian<ir::Annotation *, const schema::AnnotationMatcher *> hungarian(annotationSet->annotations, annotation_matches, IsAnnotationMatched);
        auto count = hungarian.solve();
        if (count != annotation_matches.size()) {
            return false;
        }
        if (matcher->match_type() == schema::MatchType::Equal) {
            if (count != annotation_set_size) {
                return false;
            }
        }
    }
    return true;
}

static uint8_t AnnotationEncodeValueTypeCvt(schema::AnnotationEncodeValueMatcher value_type) {
    switch (value_type) {
        case schema::AnnotationEncodeValueMatcher::EncodeValueByte: return dex::kEncodedByte;
        case schema::AnnotationEncodeValueMatcher::EncodeValueShort: return dex::kEncodedShort;
        case schema::AnnotationEncodeValueMatcher::EncodeValueChar: return dex::kEncodedChar;
        case schema::AnnotationEncodeValueMatcher::EncodeValueInt: return dex::kEncodedInt;
        case schema::AnnotationEncodeValueMatcher::EncodeValueLong: return dex::kEncodedLong;
        case schema::AnnotationEncodeValueMatcher::EncodeValueFloat: return dex::kEncodedFloat;
        case schema::AnnotationEncodeValueMatcher::EncodeValueDouble: return dex::kEncodedDouble;
        case schema::AnnotationEncodeValueMatcher::StringMatcher: return dex::kEncodedString;
        case schema::AnnotationEncodeValueMatcher::ClassMatcher: return dex::kEncodedType;
        case schema::AnnotationEncodeValueMatcher::MethodMatcher: return dex::kEncodedMethod;
        case schema::AnnotationEncodeValueMatcher::FieldMatcher: return dex::kEncodedEnum;
        case schema::AnnotationEncodeValueMatcher::AnnotationEncodeArrayMatcher: return dex::kEncodedArray;
        case schema::AnnotationEncodeValueMatcher::AnnotationMatcher: return dex::kEncodedAnnotation;
        case schema::AnnotationEncodeValueMatcher::EncodeValueNull: return dex::kEncodedNull;
        case schema::AnnotationEncodeValueMatcher::EncodeValueBoolean: return dex::kEncodedBoolean;
        default: abort();
    }
}

template<typename T>
T NonNullCase(const void *value) {
    if (value) {
        return static_cast<T>(value);
    }
    abort();
}

bool DexItem::IsAnnotationEncodeValueMatched(const ir::EncodedValue *encodedValue, schema::AnnotationEncodeValueMatcher type, const void *value) {
    auto value_type = AnnotationEncodeValueTypeCvt(type);
    if (encodedValue->type != value_type) {
        return false;
    }
    switch (value_type) {
        case dex::kEncodedByte: return encodedValue->u.byte_value == NonNullCase<const dexkit::schema::EncodeValueByte *>(value)->value();
        case dex::kEncodedShort: return encodedValue->u.short_value == NonNullCase<const dexkit::schema::EncodeValueShort *>(value)->value();
        case dex::kEncodedChar: return encodedValue->u.char_value == NonNullCase<const dexkit::schema::EncodeValueChar *>(value)->value();
        case dex::kEncodedInt: return encodedValue->u.int_value == NonNullCase<const dexkit::schema::EncodeValueInt *>(value)->value();
        case dex::kEncodedLong: return encodedValue->u.long_value == NonNullCase<const dexkit::schema::EncodeValueLong *>(value)->value();
        case dex::kEncodedFloat: return encodedValue->u.float_value == NonNullCase<const dexkit::schema::EncodeValueFloat *>(value)->value();
        case dex::kEncodedDouble: return encodedValue->u.double_value == NonNullCase<const dexkit::schema::EncodeValueDouble *>(value)->value();
        case dex::kEncodedString: return IsStringMatched(encodedValue->u.string_value->c_str(), NonNullCase<const dexkit::schema::StringMatcher *>(value));
        case dex::kEncodedType: return IsClassMatched(encodedValue->u.type_value->orig_index, NonNullCase<const dexkit::schema::ClassMatcher *>(value));
        case dex::kEncodedMethod: return IsMethodMatched(encodedValue->u.method_value->orig_index, NonNullCase<const dexkit::schema::MethodMatcher *>(value));
        case dex::kEncodedEnum: return IsFieldMatched(encodedValue->u.enum_value->orig_index, NonNullCase<const dexkit::schema::FieldMatcher *>(value));
        case dex::kEncodedArray: return IsAnnotationEncodeArrayMatcher(encodedValue->u.array_value->values, NonNullCase<const dexkit::schema::AnnotationEncodeArrayMatcher *>(value));
        case dex::kEncodedAnnotation: return IsAnnotationMatched(encodedValue->u.annotation_value, NonNullCase<const dexkit::schema::AnnotationMatcher *>(value));
        case dex::kEncodedNull: return true;
        case dex::kEncodedBoolean: return encodedValue->u.bool_value == NonNullCase<const dexkit::schema::EncodeValueBoolean *>(value)->value();
        default: abort();
    }
}

bool DexItem::IsAnnotationEncodeArrayMatcher(const std::vector<ir::EncodedValue *> &encodedValues, const dexkit::schema::AnnotationEncodeArrayMatcher *matcher) {
    if (matcher == nullptr) {
        return true;
    }
    if (matcher->value_count()) {
        if (encodedValues.size() < matcher->value_count()->min()
        || encodedValues.size() > matcher->value_count()->max()) {
            return false;
        }
    }
    if (matcher->values()) {
        auto IsAnnotationEncodeValueMatched = [this](const ir::EncodedValue *encodedValue, const std::pair<schema::AnnotationEncodeValueMatcher, const void *> &value) {
            return this->IsAnnotationEncodeValueMatched(encodedValue, value.first, value.second);
        };

        if (matcher->values()->size() > encodedValues.size()) {
            return false;
        }

        typedef std::vector<std::pair<schema::AnnotationEncodeValueMatcher, const void *>> AnnotationEncodeValueMatcher;
        auto ptr = GetMatcherCache<AnnotationEncodeValueMatcher>(MatcherCacheScope::AnnotationEncodeValueMatchers,
                                                                 POINT_CASE(matcher->values()), [&]() {
            auto values = AnnotationEncodeValueMatcher{};
            for (auto i = 0; i < matcher->values()->size(); ++i) {
                auto type = matcher->values_type()->Get(i);
                auto value = matcher->values()->GetAs<void>(i);
                values.emplace_back(type, value);
            }
            return values;
        });

        auto &values = *ptr;
        Hungarian<ir::EncodedValue *, std::pair<schema::AnnotationEncodeValueMatcher, const void *>> hungarian(encodedValues, values, IsAnnotationEncodeValueMatched);
        int count = hungarian.solve();
        if (count != matcher->values()->size()) {
            return false;
        }
        if (matcher->match_type() == schema::MatchType::Equal) {
            if (count != encodedValues.size()) {
                return false;
            }
        }
    }
    return true;
}

bool DexItem::IsAnnotationElementMatched(const ir::AnnotationElement *annotationElement, const schema::AnnotationElementMatcher *matcher) {
    if (matcher == nullptr) {
        return true;
    }
    if (!IsStringMatched(annotationElement->name->c_str(), matcher->name())) {
        return false;
    }
    if (matcher->value()) {
        DEXKIT_CHECK(matcher->value_type() != schema::AnnotationEncodeValueMatcher::NONE);
        if (!IsAnnotationEncodeValueMatched(annotationElement->value, matcher->value_type(), matcher->value())) {
            return false;
        }
    }
    return true;
}

bool DexItem::IsAnnotationElementsMatched(const std::vector<ir::AnnotationElement *> &annotationElement, const schema::AnnotationElementsMatcher *matcher) {
    if (matcher == nullptr) {
        return true;
    }
    if (matcher->element_count()) {
        if (annotationElement.size() < matcher->element_count()->min()
        || annotationElement.size() > matcher->element_count()->max()) {
            return false;
        }
    }
    if (matcher->elements()) {
        auto IsAnnotationElementMatched = [this](const ir::AnnotationElement *annotationElement, const schema::AnnotationElementMatcher *matcher) {
            return this->IsAnnotationElementMatched(annotationElement, matcher);
        };

        typedef std::vector<const schema::AnnotationElementMatcher *> AnnotationElementMatcher;
        auto ptr = GetMatcherCache<AnnotationElementMatcher>(MatcherCacheScope::AnnotationElementMatchers,
                                                             POINT_CASE(matcher->elements()), [&]() {
            auto matchers = AnnotationElementMatcher{};
            for (auto element : *matcher->elements()) {
                matchers.push_back(element);
            }
            return matchers;
        });

        auto &matchers = *ptr;
        Hungarian<ir::AnnotationElement *, const schema::AnnotationElementMatcher *> hungarian(annotationElement, matchers, IsAnnotationElementMatched);
        auto count = hungarian.solve();
        if (count != matcher->elements()->size()) {
            return false;
        }
        if (matcher->match_type() == schema::MatchType::Equal) {
            if (count != annotationElement.size()) {
                return false;
            }
        }
    }
    return true;
}

// NOLINTNEXTLINE
bool DexItem::IsClassMatched(uint32_t type_idx, const schema::ClassMatcher *matcher) {
    if (matcher == nullptr) {
        return true;
    }
    if (!type_def_flag[type_idx]) {
        // try matched in declared dex
        auto &type_name = type_names[type_idx];
        auto declared_info = dexkit->GetClassDeclaredPair(type_name);
        if (declared_info.first) {
            return declared_info.first->IsClassMatched(declared_info.second, matcher);
        }
    }
    if (!IsTypeNameMatched(type_idx, matcher->class_name())) {
        return false;
    }
    if (!IsClassSmaliSourceMatched(type_idx, matcher->smali_source())) {
        return false;
    }
    if (!IsClassAccessFlagsMatched(type_idx, matcher->access_flags())) {
        return false;
    }
    if (!IsSuperClassMatched(type_idx, matcher->super_class())) {
        return false;
    }
    if (!IsClassUsingStringsMatched(type_idx, matcher)) {
        return false;
    }
    if (!IsClassAnnotationMatched(type_idx, matcher->annotations())) {
        return false;
    }
    if (!IsInterfacesMatched(type_idx, matcher->interfaces())) {
        return false;
    }
    if (!IsFieldsMatched(type_idx, matcher->fields())) {
        return false;
    }
    if (!IsMethodsMatched(type_idx, matcher->methods())) {
        return false;
    }
    if (!HasLogicalGroups(matcher)) {
        return true;
    }
    if (!MatchAllOf(matcher->all_of(), [&](const schema::ClassMatcher *child) {
        return this->IsClassMatched(type_idx, child);
    })) {
        return false;
    }
    if (!MatchAnyOf(matcher->any_of(), [&](const schema::ClassMatcher *child) {
        return this->IsClassMatched(type_idx, child);
    })) {
        return false;
    }
    if (!MatchNoneOf(matcher->none_of(), [&](const schema::ClassMatcher *child) {
        return this->IsClassMatched(type_idx, child);
    })) {
        return false;
    }
    return true;
}

bool DexItem::IsTypeNameMatched(uint32_t type_idx, const schema::StringMatcher *matcher) {
    if (matcher == nullptr) {
        return true;
    }
    if (matcher->value() == nullptr || matcher->value()->size() == 0) {
        return true;
    }
    auto type_array_count = this->type_name_array_count[type_idx];
    auto type_name = this->type_names[type_idx];
    auto component_type_name = type_name.substr(type_array_count);

    auto match_ptr = GetMatcherCache<std::pair<std::string_view, schema::StringMatchType>>(
            MatcherCacheScope::StringMatcherNormalized, POINT_CASE(matcher), [&]() {
                auto match_str = matcher->value()->string_view();
                auto match_type = matcher->match_type();
                ConvertSimilarRegex(match_str, match_type);
                return std::make_pair(match_str, match_type);
            });
    auto match_str = match_ptr->first;
    auto match_type = match_ptr->second;

    typedef std::pair<std::string, uint8_t> MatchPair;
    auto ptr = GetMatcherCache<MatchPair>(MatcherCacheScope::TypeNameDescriptor, POINT_CASE(matcher->value()), [&]() {
        auto array_count = 0;
        auto find_index = match_str.find_first_of('[');
        if (find_index != std::string_view::npos) {
            array_count = (uint8_t) (match_str.size() - find_index) / 2;
        }
        auto match_name_type = match_str.substr(0, match_str.size() - array_count * 2);
        bool start_flag = match_type == schema::StringMatchType::StartWith || match_type == schema::StringMatchType::Equal;
        bool end_flag = match_type == schema::StringMatchType::EndWith || match_type == schema::StringMatchType::Equal;
        auto match_name = NameToDescriptor(match_name_type, start_flag, end_flag);
        return std::make_pair(match_name, static_cast<uint8_t>(array_count));
    });

    auto &match_pair = *ptr;
    auto &match_type_name = match_pair.first;
    auto &match_array_count = match_pair.second;
    switch (match_type) {
        case schema::StringMatchType::StartWith:
            return kmp::starts_with(component_type_name, match_type_name, matcher->ignore_case())
                   && match_array_count <= type_array_count;
        case schema::StringMatchType::EndWith:
            return kmp::ends_with(component_type_name, match_type_name, matcher->ignore_case())
                   && match_array_count == type_array_count;
        case schema::StringMatchType::Equal:
            return kmp::equals(component_type_name, match_type_name, matcher->ignore_case())
                   && match_array_count == type_array_count;
        case schema::StringMatchType::Contains:
            return kmp::FindIndex(component_type_name, match_type_name, matcher->ignore_case()) != -1
                   && match_array_count <= type_array_count;
        case schema::StringMatchType::SimilarRegex:
            abort();
    }
    return false;
}

bool DexItem::IsClassAccessFlagsMatched(uint32_t type_idx, const schema::AccessFlagsMatcher *matcher) {
    if (matcher == nullptr) {
        return true;
    }
    if (!this->type_def_flag[type_idx]) {
        return false;
    }
    auto access_flags = this->class_access_flags[type_idx];
    return IsAccessFlagsMatched(access_flags, matcher);
}

bool DexItem::IsClassSmaliSourceMatched(uint32_t type_idx, const schema::StringMatcher *matcher) {
    if (matcher == nullptr) {
        return true;
    }
    if (!this->type_def_flag[type_idx]) {
        return false;
    }
#if DEXKIT_EXPERIMENT_RAW_SOURCE_FILES
    const auto &definition = reader.ClassDefs()[type_def_idx[type_idx]];
    auto smali_source = GetSourceFileByIndex(definition.source_file_idx);
#else
    auto smali_source = this->class_source_files[type_idx];
#endif
    return IsStringMatched(smali_source, matcher);
}

bool DexItem::IsClassUsingStringsMatched(uint32_t type_idx, const schema::ClassMatcher *matcher) {
    if (matcher->using_strings() == nullptr) {
        return true;
    }
    if (!this->type_def_flag[type_idx]) {
        return false;
    }
#if DEXKIT_EXPERIMENT_INVERTED_STRINGS
    if (const auto *scope = inverted_string::MatchScope::current; scope && scope->hits
            && scope->dex == this && scope->classes && scope->matchers == matcher->using_strings()
#if DEXKIT_EXPERIMENT_CANDIDATE_PIPELINE
            && (!scope->query_id || (QueryContext::Current() && QueryContext::Current()->GetQueryId() == scope->query_id))
#endif
    ) {
        return scope->hits->Has(type_idx);
    }
#endif
    DEXKIT_STRING_COUNT(class_calls, 1);
#if DEXKIT_EXPERIMENT_SINGLE_STRING_DIRECT || DEXKIT_EXPERIMENT_SINGLE_STRING_ID
    if (auto matched = TrySingleUsingString(matcher->using_strings(), dexkit, dex_id, strings,
            [&](auto &&predicate) {
                for (auto method_idx : class_method_ids[type_idx]) {
                    for (auto string_id : method_using_string_ids[method_idx]) {
                        if (predicate(string_id)) return true;
                    }
                }
                return false;
            })) return *matched;
#endif

    if (!CanUseKeywordUsingStringsMatchers(matcher->using_strings())) {
        std::vector<std::string_view> using_strings;
        for (auto method_idx: this->class_method_ids[type_idx]) {
            auto &&method_using_strings = this->method_using_string_ids[method_idx];
            using_strings.reserve(using_strings.size() + method_using_strings.size());
            for (auto idx: method_using_strings) {
                using_strings.emplace_back(this->strings[idx]);
            }
        }
        for (int i = 0; i < matcher->using_strings()->size(); ++i) {
            auto string_matcher = matcher->using_strings()->Get(i);
            bool matched = false;
            for (auto str: using_strings) {
                if (IsStringMatched(str, string_matcher)) {
                    matched = true;
                    break;
                }
            }
            if (!matched) {
                return false;
            }
        }
        return true;
    }

    auto *keywords_cache = GetUsingStringsKeywordsCache(
            MatcherCacheScope::ClassUsingStringsKeywords,
            matcher->using_strings()
    );
    DEXKIT_STRING_COUNT(keyword_calls, 1);
    auto &acTrie = keywords_cache->ac_trie;
    auto &match_type_map = keywords_cache->match_type_map;
    auto &real_keywords = keywords_cache->real_keywords;

    auto using_empty_string_count = 0;
    std::set<std::string_view> search_set;
    for (auto method_idx: this->class_method_ids[type_idx]) {
        auto &&using_strings = this->method_using_string_ids[method_idx];
        for (auto idx: using_strings) {
            if (idx == this->empty_string_id) ++using_empty_string_count;
            auto str = this->strings[idx];
            auto hits = acTrie->ParseText(str);
            DEXKIT_STRING_COUNT(ac_refs, 1);
            DEXKIT_STRING_COUNT(ac_bytes, str.size());
            DEXKIT_STRING_COUNT(hits, hits.size());
            for (auto &hit: hits) {
                auto match_type = match_type_map->find(hit.value)->second;
                bool match;
                switch (match_type) {
                    case schema::StringMatchType::Contains: match = true; break;
                    case schema::StringMatchType::StartWith: match = (hit.begin == 0); break;
                    case schema::StringMatchType::EndWith: match = (hit.end == str.size()); break;
                    case schema::StringMatchType::Equal: match = (hit.begin == 0 && hit.end == str.size()); break;
                    case schema::StringMatchType::SimilarRegex: abort();
                }
                if (match) {
                    search_set.insert(hit.value);
                }
            }
        }
    }
    if (match_type_map->contains("")) {
        DEXKIT_CHECK((*match_type_map)[""] == schema::StringMatchType::Equal);
        if (using_empty_string_count) {
            search_set.insert("");
        }
    }
    if (search_set.size() < real_keywords->size()) {
        return false;
    }
    DEXKIT_STRING_COUNT(intersections, 1);
    std::vector<std::string_view> unique_vec;
    std::set_intersection(search_set.begin(), search_set.end(),
                          real_keywords->begin(), real_keywords->end(),
                          std::inserter(unique_vec, unique_vec.begin()));
    if (unique_vec.size() != real_keywords->size()) {
        return false;
    }
    return true;
}

// NOLINTNEXTLINE
bool DexItem::IsSuperClassMatched(uint32_t type_idx, const schema::ClassMatcher *matcher) {
    if (matcher == nullptr) {
        return true;
    }
    auto super_class_idx = this->reader.ClassDefs()[this->type_def_idx[type_idx]].superclass_idx;
    return IsClassMatched(super_class_idx, matcher);
}

bool DexItem::IsInterfacesMatched(uint32_t type_idx, const schema::InterfacesMatcher *matcher) {
    if (matcher == nullptr) {
        return true;
    }
    if (!this->type_def_flag[type_idx]) {
        return false;
    }
#if DEXKIT_EXPERIMENT_RAW_INTERFACES
    const auto interfaces = GetInterfaceTypeIds(type_idx);
#else
    const auto &interfaces = this->class_interface_ids[type_idx];
#endif
    if (matcher->interface_count()) {
        if (interfaces.size() < matcher->interface_count()->min()
        || interfaces.size() > matcher->interface_count()->max()) {
            return false;
        }
    }
    if (matcher->interfaces()) {
        auto IsClassMatched = [this](uint32_t type_idx, const schema::ClassMatcher *matcher) {
            return this->IsClassMatched(type_idx, matcher);
        };

        typedef std::vector<const schema::ClassMatcher *> ClassMatcher;
        auto ptr = GetMatcherCache<ClassMatcher>(MatcherCacheScope::InterfaceMatchers, POINT_CASE(matcher->interfaces()),
                                                 [&]() {
            auto vec = ClassMatcher{};
            for (auto interface_matcher : *matcher->interfaces()) {
                vec.push_back(interface_matcher);
            }
            return vec;
        });

        auto &interface_matchers = *ptr;
#if DEXKIT_EXPERIMENT_RAW_INTERFACES
        Hungarian<uint32_t, const schema::ClassMatcher *, RawTypeIds> hungarian(interfaces, interface_matchers, IsClassMatched);
#else
        Hungarian<uint32_t, const schema::ClassMatcher *> hungarian(interfaces, interface_matchers, IsClassMatched);
#endif
        auto count = hungarian.solve();
        if (count != interface_matchers.size()) {
            return false;
        }
        if (matcher->match_type() == schema::MatchType::Equal) {
            if (count != interfaces.size()) {
                return false;
            }
        }
    }
    return true;
}

bool DexItem::IsClassAnnotationMatched(uint32_t type_idx, const schema::AnnotationsMatcher *matcher) {
    if (matcher == nullptr) {
        return true;
    }
    if (!this->type_def_flag[type_idx]) {
        return false;
    }
    // Annotation matchers are query hot paths, so unlike metadata getters they rely on
    // Analyze(...) + DexKit::EnterQueryExecution(...) to prewarm the full shared index.
    DEXKIT_CHECK(class_annotations.size() == reader.TypeIds().size());
    if (!IsAnnotationsMatched(this->class_annotations[type_idx], matcher)) {
        return false;
    }
    return true;
}

bool DexItem::IsFieldsMatched(uint32_t type_idx, const schema::FieldsMatcher *matcher) {
    if (matcher == nullptr) {
        return true;
    }
    if (!this->type_def_flag[type_idx]) {
        return false;
    }
    const auto &fields = this->class_field_ids[type_idx];
    if (matcher->field_count()) {
        if (fields.size() < matcher->field_count()->min()
        || fields.size() > matcher->field_count()->max()) {
            return false;
        }
    }
    if (matcher->fields()) {
        auto IsFieldMatched = [this](uint32_t field_idx, const schema::FieldMatcher *matcher) {
            return this->IsFieldMatched(field_idx, matcher);
        };

        typedef std::vector<const schema::FieldMatcher *> FieldMatcher;
        auto ptr = GetMatcherCache<FieldMatcher>(MatcherCacheScope::FieldMatchers, POINT_CASE(matcher->fields()), [&]() {
            auto vec = FieldMatcher{};
            for (auto field_matcher : *matcher->fields()) {
                vec.push_back(field_matcher);
            }
            return vec;
        });

        auto &field_matchers = *ptr;
        Hungarian<uint32_t, const schema::FieldMatcher *> hungarian(fields, field_matchers, IsFieldMatched);
        auto count = hungarian.solve();
        if (count != field_matchers.size()) {
            return false;
        }
        if (matcher->match_type() == schema::MatchType::Equal) {
            if (count != fields.size()) {
                return false;
            }
        }
    }
    return true;
}

bool DexItem::IsMethodsMatched(uint32_t type_idx, const schema::MethodsMatcher *matcher) {
    if (matcher == nullptr) {
        return true;
    }
    if (!this->type_def_flag[type_idx]) {
        return false;
    }
    const auto &methods = this->class_method_ids[type_idx];
    if (matcher->method_count()) {
        if (methods.size() < matcher->method_count()->min()
        || methods.size() > matcher->method_count()->max()) {
            return false;
        }
    }
    if (matcher->methods()) {
        auto IsMethodMatched = [this](uint32_t method_idx, const schema::MethodMatcher *matcher) {
            return this->IsMethodMatched(method_idx, matcher);
        };

        typedef std::vector<const schema::MethodMatcher *> MethodMatcher;
        auto ptr = GetMatcherCache<MethodMatcher>(MatcherCacheScope::MethodMatchers, POINT_CASE(matcher->methods()), [&]() {
            auto vec = MethodMatcher{};
            for (auto method_matcher : *matcher->methods()) {
                vec.push_back(method_matcher);
            }
            return vec;
        });

        auto &method_matchers = *ptr;
        Hungarian<uint32_t, const schema::MethodMatcher *> hungarian(methods, method_matchers, IsMethodMatched);
        auto count = hungarian.solve();
        if (count != method_matchers.size()) {
            return false;
        }
        if (matcher->match_type() == schema::MatchType::Equal) {
            if (count != methods.size()) {
                return false;
            }
        }
    }
    return true;
}

// NOLINTNEXTLINE
bool DexItem::IsMethodMatched(uint32_t method_idx, const schema::MethodMatcher *matcher) {
    if (matcher == nullptr) {
        return true;
    }
    auto &cross_info = this->method_cross_info[method_idx];
    if (cross_info.has_value()) {
        auto dex = dexkit->GetDexItem(cross_info->first);
        return dex->IsMethodMatched(cross_info->second, matcher);
    }
    auto &method_def = this->reader.MethodIds()[method_idx];
    auto method_name = this->strings[method_def.name_idx];
    if (!IsStringMatched(method_name, matcher->method_name())) {
        return false;
    }
    if (!IsAccessFlagsMatched(this->method_access_flags[method_idx], matcher->access_flags())) {
        return false;
    }
    if (!IsClassMatched(method_def.class_idx, matcher->declaring_class())) {
        return false;
    }
    if (!IsOpCodesMatched(method_idx, matcher->op_codes())) {
        return false;
    }
    if (!IsMethodUsingStringsMatched(method_idx, matcher)) {
        return false;
    }
    if (!IsMethodAnnotationMatched(method_idx, matcher->annotations())) {
        return false;
    }
    auto &proto_def = this->reader.ProtoIds()[method_def.proto_idx];
    if (!IsProtoShortyMatched(proto_def.shorty_idx, matcher->proto_shorty())) {
        return false;
    }
    if (!IsClassMatched(proto_def.return_type_idx, matcher->return_type())) {
        return false;
    }
    if (!IsParametersMatched(method_idx, matcher->parameters())) {
        return false;
    }
    if (!IsUsingFieldsMatched(method_idx, matcher)) {
        return false;
    }
    if (!IsInvokingMethodsMatched(method_idx, matcher->invoking_methods())) {
        return false;
    }
    if (!IsCallMethodsMatched(method_idx, matcher->method_callers())) {
        return false;
    }
    if (!IsUsingNumbersMatched(method_idx, matcher)) {
        return false;
    }
    if (!HasLogicalGroups(matcher)) {
        return true;
    }
    if (!MatchAllOf(matcher->all_of(), [&](const schema::MethodMatcher *child) {
        return this->IsMethodMatched(method_idx, child);
    })) {
        return false;
    }
    if (!MatchAnyOf(matcher->any_of(), [&](const schema::MethodMatcher *child) {
        return this->IsMethodMatched(method_idx, child);
    })) {
        return false;
    }
    if (!MatchNoneOf(matcher->none_of(), [&](const schema::MethodMatcher *child) {
        return this->IsMethodMatched(method_idx, child);
    })) {
        return false;
    }
    return true;
}

bool DexItem::IsProtoShortyMatched(uint32_t shorty_idx, const ::flatbuffers::String *matcher) {
    if (matcher == nullptr) {
        return true;
    }
    auto &shorty = this->strings[shorty_idx];
    return shorty == matcher->string_view();
}

bool DexItem::IsParametersMatched(uint32_t method_idx, const schema::ParametersMatcher *matcher) {
    if (matcher == nullptr) {
        return true;
    }
    auto method_def = this->reader.MethodIds()[method_idx];
    const auto type_list = this->proto_type_list[method_def.proto_idx];
    auto type_list_size = type_list == nullptr ? 0 : type_list->size;
    if (matcher->parameter_count()) {
        if (type_list_size < matcher->parameter_count()->min()
        || type_list_size > matcher->parameter_count()->max()) {
            return false;
        }
    }
    if (matcher->parameters()) {
        if (type_list_size != matcher->parameters()->size()) {
            return false;
        }
        const std::vector<ir::AnnotationSet *> *method_parameter_annotation = nullptr;
        for (size_t i = 0; i < type_list_size; ++i) {
            auto parameter_matcher = matcher->parameters()->Get(i);
            DEXKIT_CHECK(parameter_matcher);
            if (!IsClassMatched(type_list->list[i].type_idx, parameter_matcher->parameter_type())) {
                return false;
            }
            if (parameter_matcher->annotations()) {
                if (method_parameter_annotation == nullptr) {
                    DEXKIT_CHECK(method_parameter_annotations.size() == reader.MethodIds().size());
                    method_parameter_annotation = &this->method_parameter_annotations[method_idx];
                }
                if (method_parameter_annotation->size() <= i) {
                    return false;
                }
                if (!IsAnnotationsMatched((*method_parameter_annotation)[i], parameter_matcher->annotations())) {
                    return false;
                }
            }
        }
    }
    return true;
}

bool DexItem::IsOpCodesMatched(uint32_t method_idx, const schema::OpCodesMatcher *matcher) {
    if (matcher == nullptr) {
        return true;
    }
    auto &opt_opcodes = this->method_opcode_seq[method_idx];
    auto op_code_size = opt_opcodes.has_value() ? opt_opcodes->size() : 0;
    if (matcher->op_code_count()) {
        if (op_code_size < matcher->op_code_count()->min()
        || op_code_size > matcher->op_code_count()->max()) {
            return false;
        }
    }
    if (matcher->op_codes()) {
        if (matcher->op_codes()->size() > op_code_size) {
            return false;
        }

        typedef std::vector<std::optional<uint8_t>> OpCodeMatcher;
        auto ptr = GetMatcherCache<OpCodeMatcher>(MatcherCacheScope::OpCodeMatchers, POINT_CASE(matcher->op_codes()),
                                                  [&]() {
            auto vec = OpCodeMatcher{};
            for (auto opcode : *matcher->op_codes()) {
                if (opcode < 0) {
                    vec.emplace_back(std::nullopt);
                } else {
                    vec.emplace_back(opcode);
                }
            }
            return vec;
        });

        auto &matcher_opcodes = *ptr;
        if (matcher_opcodes.size() > op_code_size) {
            return false;
        }

        if (!matcher_opcodes.empty()) {
            auto &opcodes = opt_opcodes.value();
            bool condition = false;
            if (matcher->match_type() == schema::OpCodeMatchType::EndWith) {
                // kmp::FindIndex returns the first occurrence, which is not
                // necessarily the tail; compare the tail directly.
                condition = std::equal(matcher_opcodes.begin(), matcher_opcodes.end(), opcodes.end() - matcher_opcodes.size());
            } else {
                auto index = kmp::FindIndex(opcodes, matcher_opcodes);
                switch (matcher->match_type()) {
                    case schema::OpCodeMatchType::Equal: condition = index == 0 && matcher_opcodes.size() == op_code_size; break;
                    case schema::OpCodeMatchType::StartWith: condition = index == 0; break;
                    case schema::OpCodeMatchType::Contains: condition = index != -1; break;
                    default: break;
                }
            }
            if (!condition) {
                return false;
            }
        }

    }
    return true;
}

bool DexItem::IsMethodUsingStringsMatched(uint32_t method_idx, const schema::MethodMatcher *matcher) {
    if (matcher->using_strings() == nullptr) {
        return true;
    }
#if DEXKIT_EXPERIMENT_INVERTED_STRINGS
    if (const auto *scope = inverted_string::MatchScope::current; scope && scope->hits
            && scope->dex == this && !scope->classes && scope->matchers == matcher->using_strings()
#if DEXKIT_EXPERIMENT_CANDIDATE_PIPELINE
            && (!scope->query_id || (QueryContext::Current() && QueryContext::Current()->GetQueryId() == scope->query_id))
#endif
    ) {
        return scope->hits->Has(method_idx);
    }
#endif
    DEXKIT_STRING_COUNT(method_calls, 1);
#if DEXKIT_EXPERIMENT_SINGLE_STRING_DIRECT || DEXKIT_EXPERIMENT_SINGLE_STRING_ID
    if (auto matched = TrySingleUsingString(matcher->using_strings(), dexkit, dex_id, strings,
            [&](auto &&predicate) {
                for (auto string_id : method_using_string_ids[method_idx]) {
                    if (predicate(string_id)) return true;
                }
                return false;
            })) return *matched;
#endif

    if (!CanUseKeywordUsingStringsMatchers(matcher->using_strings())) {
        auto &&using_string_ids = this->method_using_string_ids[method_idx];
        for (int i = 0; i < matcher->using_strings()->size(); ++i) {
            auto string_matcher = matcher->using_strings()->Get(i);
            bool matched = false;
            for (auto idx: using_string_ids) {
                if (IsStringMatched(this->strings[idx], string_matcher)) {
                    matched = true;
                    break;
                }
            }
            if (!matched) {
                return false;
            }
        }
        return true;
    }

    auto *keywords_cache = GetUsingStringsKeywordsCache(
            MatcherCacheScope::MethodUsingStringsKeywords,
            matcher->using_strings()
    );
    DEXKIT_STRING_COUNT(keyword_calls, 1);
    auto &acTrie = keywords_cache->ac_trie;
    auto &match_type_map = keywords_cache->match_type_map;
    auto &real_keywords = keywords_cache->real_keywords;

    auto using_empty_string_count = 0;
    std::set<std::string_view> search_set;
    auto &&using_strings = this->method_using_string_ids[method_idx];
    for (auto idx: using_strings) {
        if (idx == this->empty_string_id) ++using_empty_string_count;
        auto str = this->strings[idx];
        auto hits = acTrie->ParseText(str);
        DEXKIT_STRING_COUNT(ac_refs, 1);
        DEXKIT_STRING_COUNT(ac_bytes, str.size());
        DEXKIT_STRING_COUNT(hits, hits.size());
        for (auto &hit: hits) {
            auto match_type = match_type_map->find(hit.value)->second;
            bool match;
            switch (match_type) {
                case schema::StringMatchType::Contains: match = true; break;
                case schema::StringMatchType::StartWith: match = (hit.begin == 0); break;
                case schema::StringMatchType::EndWith: match = (hit.end == str.size()); break;
                case schema::StringMatchType::Equal: match = (hit.begin == 0 && hit.end == str.size()); break;
                case schema::StringMatchType::SimilarRegex: abort();
            }
            if (match) {
                search_set.insert(hit.value);
            }
        }
    }
    if (match_type_map->contains("")) {
        DEXKIT_CHECK((*match_type_map)[""] == schema::StringMatchType::Equal);
        if (using_empty_string_count) {
            search_set.insert("");
        }
    }
    if (search_set.size() < real_keywords->size()) {
        return false;
    }
    DEXKIT_STRING_COUNT(intersections, 1);
    std::vector<std::string_view> unique_vec;
    std::set_intersection(search_set.begin(), search_set.end(),
                          real_keywords->begin(), real_keywords->end(),
                          std::inserter(unique_vec, unique_vec.begin()));
    if (unique_vec.size() != real_keywords->size()) {
        return false;
    }
    return true;
}

bool DexItem::IsMethodAnnotationMatched(uint32_t method_idx, const schema::AnnotationsMatcher *matcher) {
    if (matcher == nullptr) {
        return true;
    }
    DEXKIT_CHECK(method_annotations.size() == reader.MethodIds().size());
    if (!IsAnnotationsMatched(this->method_annotations[method_idx], matcher)) {
        return false;
    }
    return true;
}

bool DexItem::IsUsingFieldsMatched(uint32_t method_idx, const schema::MethodMatcher *matcher) {
    DEXKIT_FIELD_COUNT(calls, 1);
    if (matcher->using_fields() == nullptr) {
        DEXKIT_FIELD_COUNT(absent, 1);
        return true;
    }
    DEXKIT_CHECK(!method_using_field_ids.empty());
    auto IsUsingFieldMatched = [this](std::pair<uint32_t, bool> field, const schema::UsingFieldMatcher *matcher) {
        DEXKIT_FIELD_COUNT(judges, 1);
        return this->IsUsingFieldMatched(field, matcher);
    };
    const auto &using_fields = this->method_using_field_ids[method_idx];
    DEXKIT_FIELD_COUNT(row_items, using_fields.size());
    DEXKIT_FIELD_COUNT(empty, matcher->using_fields()->size() == 0);
    DEXKIT_FIELD_COUNT(single, matcher->using_fields()->size() == 1);
    DEXKIT_FIELD_COUNT(multiple, matcher->using_fields()->size() > 1);
    DEXKIT_FIELD_COUNT(single_row_items, matcher->using_fields()->size() == 1 ? using_fields.size() : 0);

#if DEXKIT_EXPERIMENT_SINGLE_USING_FIELD
    if (matcher->using_fields()->size() == 1) {
        DEXKIT_FIELD_COUNT(direct, 1);
        const auto *requirement = matcher->using_fields()->Get(0);
        for (const auto &field : using_fields) {
            if (IsUsingFieldMatched(field, requirement)) return true;
        }
        return false;
    }
#endif

    typedef std::vector<const schema::UsingFieldMatcher *> UsingFieldMatcher;
    auto ptr = GetMatcherCache<UsingFieldMatcher>(MatcherCacheScope::UsingFieldMatchers, POINT_CASE(matcher->using_fields()),
                                                  [&]() {
        DEXKIT_FIELD_COUNT(cache_builds, 1);
        auto using_vec = UsingFieldMatcher{};
        for (int i = 0; i < matcher->using_fields()->size(); ++i) {
            using_vec.push_back(matcher->using_fields()->Get(i));
        }
        return using_vec;
    });

    auto &using_field_matchers = *ptr;
    DEXKIT_FIELD_COUNT(solver_calls, 1);
    DEXKIT_FIELD_COUNT(prepared_items, using_field_matchers.size() <= using_fields.size() ? using_fields.size() : 0);
#if DEXKIT_EXPERIMENT_COMPACT_FIELDS
    Hungarian<std::pair<uint32_t, bool>, const schema::UsingFieldMatcher *,
              std::span<const std::pair<uint32_t, bool>>> hungarian(using_fields, using_field_matchers, IsUsingFieldMatched);
#else
    Hungarian<std::pair<uint32_t, bool>, const schema::UsingFieldMatcher *> hungarian(using_fields, using_field_matchers, IsUsingFieldMatched);
#endif
    auto count = hungarian.solve();
    if (count != using_field_matchers.size()) {
        return false;
    }
    return true;
}

bool DexItem::IsUsingNumbersMatched(uint32_t method_idx, const schema::MethodMatcher *matcher) {
    if (matcher->using_numbers() == nullptr) {
        return true;
    }
    const auto &using_numbers = this->GetUsingNumbers(method_idx);
    if (matcher->using_numbers()->size() > using_numbers.size()) {
        return false;
    }

    typedef std::vector<EncodeNumber> Numbers;
    auto ptr = GetMatcherCache<Numbers>(MatcherCacheScope::UsingNumbers, POINT_CASE(matcher->using_numbers()), [&]() {
        auto numbers = Numbers{};
        auto types = matcher->using_numbers_type();
        for (int i = 0; i < matcher->using_numbers()->size(); ++i) {
            auto NumberMatcher = matcher->using_numbers()->Get(i);
            auto type = types->Get(i);
            EncodeNumber number{};
            switch (type) {
                case schema::Number::EncodeValueByte: {
                    number = EncodeNumber{
                            .type = BYTE,
                            .value = {.L8 = matcher->using_numbers()->GetAs<schema::EncodeValueByte>(i)->value()}
                    };
                    break;
                }
                case schema::Number::EncodeValueShort: {
                    number = EncodeNumber{
                            .type = SHORT,
                            .value = {.L16 = matcher->using_numbers()->GetAs<schema::EncodeValueShort>(i)->value()}
                    };
                    break;
                }
                case schema::Number::EncodeValueInt: {
                    number = EncodeNumber{
                            .type = INT,
                            .value = {.L32 = {.int_value = matcher->using_numbers()->GetAs<schema::EncodeValueInt>(i)->value()}}
                    };
                    break;
                }
                case schema::Number::EncodeValueLong: {
                    number = EncodeNumber{
                            .type = LONG,
                            .value = {.L64 = {.long_value = matcher->using_numbers()->GetAs<schema::EncodeValueLong>(i)->value()}}
                    };
                    break;
                }
                case schema::Number::EncodeValueFloat: {
                    number = EncodeNumber{
                            .type = FLOAT,
                            .value = {.L32 = {.float_value = matcher->using_numbers()->GetAs<schema::EncodeValueFloat>(i)->value()}}
                    };
                    break;
                }
                case schema::Number::EncodeValueDouble: {
                    number = EncodeNumber{
                            .type = DOUBLE,
                            .value = {.L64 = {.double_value = matcher->using_numbers()->GetAs<schema::EncodeValueDouble>(i)->value()}}
                    };
                    break;
                }
                default: abort();
            }
            numbers.push_back(number);
        }
        return numbers;
    });

    auto IsNumberMatched = [](EncodeNumber number, EncodeNumber matcher) {
        if (matcher.type >= FLOAT) {
            return abs(GetDoubleValue(number) - GetDoubleValue(matcher)) < EPS;
        }
        return GetLongValue(number) == GetLongValue(matcher);
    };

    auto &numbers = *ptr;
    Hungarian<EncodeNumber, EncodeNumber> hungarian(using_numbers, numbers, IsNumberMatched);
    auto count = hungarian.solve();
    if (count != numbers.size()) {
        return false;
    }
    return true;
}

bool DexItem::IsInvokingMethodsMatched(uint32_t method_idx, const schema::MethodsMatcher *matcher) {
    if (matcher == nullptr) {
        return true;
    }
    DEXKIT_CHECK(!method_invoking_ids.empty());
    const auto &invoking_methods = this->method_invoking_ids[method_idx];
    if (matcher->method_count()) {
        if (invoking_methods.size() < matcher->method_count()->min()
        || invoking_methods.size() > matcher->method_count()->max()) {
            return false;
        }
    }

    if (matcher->methods()) {
        if (matcher->methods()->size() > invoking_methods.size()) {
            return false;
        }
        auto IsMethodMatched = [this](uint32_t method_idx, const schema::MethodMatcher *matcher) {
#if DEXKIT_BENCHMARK_DIAGNOSTICS
            RelationJudgeTrace::Observe(this->dex_id, method_idx);
#endif
            return this->IsMethodMatched(method_idx, matcher);
        };

#if DEXKIT_EXPERIMENT_SINGLE_RELATION
        // The one-row solver already stops at the first witness. Preserve that
        // predicate order while avoiding its target copies and work arrays.
        if (matcher->methods()->size() == 1) {
            const auto *required = matcher->methods()->Get(0);
            for (auto target : invoking_methods) {
                if (IsMethodMatched(target, required)) {
                    return matcher->match_type() != schema::MatchType::Equal || invoking_methods.size() == 1;
                }
            }
            return false;
        }
#endif

        typedef std::vector<const schema::MethodMatcher *> MethodMatcher;
        auto ptr = GetMatcherCache<MethodMatcher>(MatcherCacheScope::MethodMatchers, POINT_CASE(matcher->methods()), [&]() {
            auto vec = MethodMatcher{};
            for (auto method_matcher : *matcher->methods()) {
                vec.push_back(method_matcher);
            }
            return vec;
        });

        auto &method_matchers = *ptr;
#if DEXKIT_EXPERIMENT_COMPACT_INVOKES
        Hungarian<uint32_t, const schema::MethodMatcher *, std::span<const uint32_t>> hungarian(invoking_methods, method_matchers, IsMethodMatched);
#else
        Hungarian<uint32_t, const schema::MethodMatcher *> hungarian(invoking_methods, method_matchers, IsMethodMatched);
#endif
        auto count = hungarian.solve();
        if (count != method_matchers.size()) {
            return false;
        }
        if (matcher->match_type() == schema::MatchType::Equal) {
            if (count != invoking_methods.size()) {
                return false;
            }
        }
    }
    return true;
}

bool DexItem::IsCallMethodsMatched(uint32_t method_idx, const schema::MethodsMatcher *matcher) {
    if (matcher == nullptr) {
        return true;
    }
    DEXKIT_CHECK(!method_caller_ids.empty());
    const auto &ids = this->method_caller_ids[method_idx];
    if (matcher->method_count()) {
        if (ids.size() < matcher->method_count()->min() || ids.size() > matcher->method_count()->max()) {
            return false;
        }
    }
    if (matcher->methods()) {
        if (matcher->methods()->size() > ids.size()) {
            return false;
        }
        using Caller = typename std::decay_t<decltype(ids)>::value_type;
        auto IsMethodMatched = [this](Caller method_info, const schema::MethodMatcher *matcher) {
#if DEXKIT_BENCHMARK_DIAGNOSTICS
            RelationJudgeTrace::Observe(method_info.first, method_info.second);
#endif
            if (method_info.first == this->dex_id) {
                return this->IsMethodMatched(method_info.second, matcher);
            } else {
                auto dex = dexkit->GetDexItem(method_info.first);
                return dex->IsMethodMatched(method_info.second, matcher);
            }
        };

#if DEXKIT_EXPERIMENT_SINGLE_RELATION
        if (matcher->methods()->size() == 1) {
            const auto *required = matcher->methods()->Get(0);
            for (auto target : ids) {
                if (IsMethodMatched(target, required)) {
                    return matcher->match_type() != schema::MatchType::Equal || ids.size() == 1;
                }
            }
            return false;
        }
#endif

        typedef std::vector<const schema::MethodMatcher *> MethodMatcher;
        auto ptr = GetMatcherCache<MethodMatcher>(MatcherCacheScope::MethodMatchers, POINT_CASE(matcher->methods()), [&]() {
            auto vec = MethodMatcher{};
            for (auto method_matcher : *matcher->methods()) {
                vec.push_back(method_matcher);
            }
            return vec;
        });

        auto &method_matchers = *ptr;
#if DEXKIT_EXPERIMENT_COMPACT_CALLERS
        Hungarian<Caller, const schema::MethodMatcher *, std::span<const Caller>> hungarian(ids, method_matchers, IsMethodMatched);
#else
        Hungarian<Caller, const schema::MethodMatcher *> hungarian(ids, method_matchers, IsMethodMatched);
#endif
        auto count = hungarian.solve();
        if (count != method_matchers.size()) {
            return false;
        }
        if (matcher->match_type() == schema::MatchType::Equal) {
            return count == ids.size();
        }
    }
    return true;
}

bool DexItem::IsUsingFieldMatched(std::pair<uint32_t, bool> field, const schema::UsingFieldMatcher *matcher) {
    if (matcher == nullptr) {
        return true;
    }
    if (matcher->field()) {
        auto type = field.second ? schema::UsingType::Get : schema::UsingType::Put;
        if (type != matcher->using_type() && matcher->using_type() != schema::UsingType::Any) {
            return false;
        }
        if (!IsFieldMatched(field.first, matcher->field())) {
            return false;
        }
    }
    return true;
}

// NOLINTNEXTLINE
bool DexItem::IsFieldMatched(uint32_t field_idx, const schema::FieldMatcher *matcher) {
    if (matcher == nullptr) {
        return true;
    }
    auto &cross_info = this->field_cross_info[field_idx];
    if (cross_info.has_value()) {
        auto dex = dexkit->GetDexItem(cross_info->first);
        return dex->IsFieldMatched(cross_info->second, matcher);
    }
    auto &field_def = this->reader.FieldIds()[field_idx];
    auto field_name = this->strings[field_def.name_idx];
    if (!IsStringMatched(field_name, matcher->field_name())) {
        return false;
    }
    if (!IsAccessFlagsMatched(this->field_access_flags[field_idx], matcher->access_flags())) {
        return false;
    }
    if (!IsClassMatched(field_def.class_idx, matcher->declaring_class())) {
        return false;
    }
    if (!IsClassMatched(field_def.type_idx, matcher->type_class())) {
        return false;
    }
    if (!IsFieldAnnotationMatched(field_idx, matcher->annotations())) {
        return false;
    }
    if (!IsFieldGetMethodsMatched(field_idx, matcher->get_methods())) {
        return false;
    }
    if (!IsFieldPutMethodsMatched(field_idx, matcher->put_methods())) {
        return false;
    }
    if (!HasLogicalGroups(matcher)) {
        return true;
    }
    if (!MatchAllOf(matcher->all_of(), [&](const schema::FieldMatcher *child) {
        return this->IsFieldMatched(field_idx, child);
    })) {
        return false;
    }
    if (!MatchAnyOf(matcher->any_of(), [&](const schema::FieldMatcher *child) {
        return this->IsFieldMatched(field_idx, child);
    })) {
        return false;
    }
    if (!MatchNoneOf(matcher->none_of(), [&](const schema::FieldMatcher *child) {
        return this->IsFieldMatched(field_idx, child);
    })) {
        return false;
    }
    return true;
}

bool DexItem::IsFieldAnnotationMatched(uint32_t field_idx, const schema::AnnotationsMatcher *matcher) {
    if (matcher == nullptr) {
        return true;
    }
    DEXKIT_CHECK(field_annotations.size() == reader.FieldIds().size());
    if (!IsAnnotationsMatched(this->field_annotations[field_idx], matcher)) {
        return false;
    }
    return true;
}

bool DexItem::IsFieldGetMethodsMatched(uint32_t field_idx, const schema::MethodsMatcher *matcher) {
    if (matcher == nullptr) {
        return true;
    }
#if DEXKIT_BENCHMARK_DIAGNOSTICS
    benchmark_field_reverse_reads[0].fetch_add(1, std::memory_order_relaxed);
#endif
    DEXKIT_CHECK(!field_get_method_ids.empty());
    const auto &ids = this->field_get_method_ids[field_idx];
    if (matcher->method_count()) {
        if (ids.size() < matcher->method_count()->min() || ids.size() > matcher->method_count()->max()) {
            return false;
        }
    }
    if (matcher->methods()) {
        if (matcher->methods()->size() > ids.size()) {
            return false;
        }
        auto IsMethodMatched = [this](std::pair<uint16_t, uint32_t> method_idx, const schema::MethodMatcher *matcher) {
            if (method_idx.first == this->dex_id) {
                return this->IsMethodMatched(method_idx.second, matcher);
            } else {
                auto dex = dexkit->GetDexItem(method_idx.first);
                return dex->IsMethodMatched(method_idx.second, matcher);
            }
        };

        typedef std::vector<const schema::MethodMatcher *> MethodMatcher;
        auto ptr = GetMatcherCache<MethodMatcher>(MatcherCacheScope::MethodMatchers, POINT_CASE(matcher->methods()), [&]() {
            auto vec = MethodMatcher{};
            for (auto method_matcher : *matcher->methods()) {
                vec.push_back(method_matcher);
            }
            return vec;
        });

        auto &method_matchers = *ptr;
        Hungarian<std::pair<uint16_t, uint32_t>, const schema::MethodMatcher *> hungarian(ids, method_matchers, IsMethodMatched);
        auto count = hungarian.solve();
        if (count != method_matchers.size()) {
            return false;
        }
        if (matcher->match_type() == schema::MatchType::Equal) {
            return count == ids.size();
        }
    }
    return true;
}

bool DexItem::IsFieldPutMethodsMatched(uint32_t field_idx, const schema::MethodsMatcher *matcher) {
    if (matcher == nullptr) {
        return true;
    }
#if DEXKIT_BENCHMARK_DIAGNOSTICS
    benchmark_field_reverse_reads[1].fetch_add(1, std::memory_order_relaxed);
#endif
    DEXKIT_CHECK(!field_put_method_ids.empty());
    const auto &ids = this->field_put_method_ids[field_idx];
    if (matcher->method_count()) {
        if (ids.size() < matcher->method_count()->min() || ids.size() > matcher->method_count()->max()) {
            return false;
        }
    }
    if (matcher->methods()) {
        if (matcher->methods()->size() > ids.size()) {
            return false;
        }
        auto IsMethodMatched = [this](std::pair<uint16_t, uint32_t> method_idx, const schema::MethodMatcher *matcher) {
            if (method_idx.first == this->dex_id) {
                return this->IsMethodMatched(method_idx.second, matcher);
            } else {
                auto dex = dexkit->GetDexItem(method_idx.first);
                return dex->IsMethodMatched(method_idx.second, matcher);
            }
        };

        typedef std::vector<const schema::MethodMatcher *> MethodMatcher;
        auto ptr = GetMatcherCache<MethodMatcher>(MatcherCacheScope::MethodMatchers, POINT_CASE(matcher->methods()), [&]() {
            auto vec = MethodMatcher{};
            for (auto method_matcher : *matcher->methods()) {
                vec.push_back(method_matcher);
            }
            return vec;
        });

        auto &method_matchers = *ptr;
        Hungarian<std::pair<uint16_t, uint32_t>, const schema::MethodMatcher *> hungarian(ids, method_matchers, IsMethodMatched);
        auto count = hungarian.solve();
        if (count != method_matchers.size()) {
            return false;
        }
        if (matcher->match_type() == schema::MatchType::Equal) {
            return count == ids.size();
        }
    }
    return true;
}

}
