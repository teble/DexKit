"""Archive the completed fixed hybrid batch, exporting its actual source commit."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
OLD=BASE/'hybrid-descriptor-hot-hits-v1'
DENSE_BASE=BASE/'hybrid-descriptors-v1'
E=BASE/'hybrid-descriptor-direct-slots-v1'
DEST=ROOT/'tools/qaux-benchmark/evidence/hybrid-descriptor-direct-slots/v1'
BASELINE='56c680c68f44987979c96f01ccd461a546a1e5cd'
DENSE_ENGINE='bf9cee531da6a5d4f237398350eed05d7fcf96c5'
ENGINE='33b12240934d25192c5ef464d80a60019fd7dec6'
DEST.mkdir(parents=True,exist_ok=True)
files={}


def sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):
            digest.update(block)
    return digest.hexdigest()


def add(path,name):
    assert path.is_file() and name not in files,(path,name)
    files[name]=path


def tree(path,prefix):
    for file in sorted(path.rglob('*')):
        if not file.is_file(): continue
        relative=file.relative_to(path)
        if any(part in ['classes','__pycache__'] for part in relative.parts): continue
        if file.suffix in ['.apk','.dex','.class','.jar','.aar','.so','.dylib','.o','.a','.pyc']: continue
        add(file,prefix+'/'+str(relative))


def export(relative,prefix):
    path=E/'source-export'/relative
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(subprocess.check_output(['git','-C',ROOT,'show',ENGINE+':'+relative]))
    add(path,prefix+'/'+relative)


summary=json.loads((E/'summary.json').read_text())
assert summary['accepted_sweeps']==52 and summary['accepted_fresh_processes']==624
for name in ['measurements','validation']:
    tree(E/name,name)
for path in sorted(E.glob('*.py')):
    add(path,'drivers/'+path.name)
for name in ['summary.json','summary-output.txt']:
    add(E/name,name)
for directory in sorted((E/'artifacts').iterdir()):
    for file in sorted(directory.iterdir()):
        if file.is_file() and file.suffix in ['.json','.txt','.log','.patch']:
            add(file,'artifacts/'+directory.name+'/'+file.name)
for file in sorted((E/'development').iterdir()):
    if file.is_file() and file.suffix in ['.log','.json']:
        add(file,'development/'+file.name)
for label,source,original in [('before',OLD,'hybrid'),('dense',DENSE_BASE,'control')]:
    artifact=source/'artifacts'/original
    for file in sorted(artifact.iterdir()):
        if file.is_file() and file.suffix in ['.json','.txt','.log','.patch']:
            add(file,'artifacts/'+label+'/'+file.name)
    for workers in [1,4]:
        tree(source/'validation'/('verify-'+original+'-w'+str(workers)),
             'baseline-validation/'+label+'-w'+str(workers))
for relative in ['followup/fixtures/relations','followup/fixtures/field-adverse',
    'followup/fixtures/invoke-tiny','followup/fixtures/invoke-mixed','followup/fixtures/invoke-giant',
    'followup/fixtures/dense-descriptors','raw-metadata/symbol-fixture','raw-metadata/overload-fixture',
    'next-round/fixtures/field-small-v1','next-round/fixtures/field-short-v1',
    'next-round/fixtures/field-long-v1','next-round/fixtures/field-unresolved-v1',
    'compact-callers-v2/fixtures/contracts']:
    tree(BASE/relative,'inputs/'+relative)
add(BASE/'followup/formal/field-tail-oracle-best5/field-rw-expected.json','inputs/field-rw-expected.json')
add(OLD/'measurements/frozen-plan.json','inputs/previous-hot-hits-frozen-plan.json')
add(ROOT/'tools/qaux-benchmark/evidence/hybrid-descriptor-hot-hits/v1/manifest.json','inputs/previous-hot-hits-evidence-manifest.json')
add(DENSE_BASE/'measurements/frozen-plan.json','inputs/original-hybrid-frozen-plan.json')
add(ROOT/'tools/qaux-benchmark/evidence/hybrid-descriptors/v1/manifest.json','inputs/original-hybrid-evidence-manifest.json')

changed=subprocess.check_output(['git','-C',ROOT,'diff','--name-only',BASELINE,ENGINE],text=True).splitlines()
for relative in sorted(set(changed + ['Core/dexkit/dex_item.cpp','Core/dexkit/include/dex_item.h'])):
    if relative.startswith('Core/') or relative in ['dexkit/build.gradle','dexkit-android/build.gradle']:
        export(relative,'source/engine')
patch=E/'engine.patch'
patch.write_bytes(subprocess.check_output(['git','-C',ROOT,'diff',BASELINE,ENGINE,'--',
    'Core','dexkit/build.gradle','dexkit-android/build.gradle']))
add(patch,'source/engine.patch')
tracked=subprocess.check_output(['git','-C',ROOT,'ls-tree','--name-only','-r',ENGINE,'--','tools/qaux-benchmark'],text=True).splitlines()
for relative in tracked:
    path=Path(relative)
    if path.parent==Path('tools/qaux-benchmark') and path.suffix in ['.py','.cpp','.h','.java','.gradle','.json']:
        export(relative,'source/harness')
for file in sorted((ROOT/'tools/qaux-benchmark').glob('HYBRID-DESCRIPTOR-DIRECT-SLOTS*.md')):
    add(file,'source/reports/'+file.name)
tree(ROOT/'tools/qaux-benchmark/licenses','source/licenses')
identity=dict(baseline_source=BASELINE,dense_reference_source=DENSE_ENGINE,normal_engine_commit=ENGINE,diagnostic_engine_commit=ENGINE,
    native_libraries=summary['native_libraries'],frozen_plan_sha256=summary['frozen_plan_sha256'],
    note='Engine and harness files are exported from the tested 33b1224 commit. Reports describe the completed batch. '
         'Obtain QQ APK/corpus, repository baseline and platform SDK/JDK/compiler inputs separately.')
(DEST/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
integrity={name:dict(bytes=path.stat().st_size,sha256=sha(path)) for name,path in sorted(files.items())}
archive=DEST/'raw-evidence.tar.gz'
canonical,hardlinks={},0
with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tar:
    for name,path in sorted(files.items()):
        key=integrity[name]['sha256'] if path.suffix=='.bin' else None
        if key is not None and key in canonical:
            link=tarfile.TarInfo(name)
            link.type=tarfile.LNKTYPE; link.linkname=canonical[key]; link.mode=0o644
            tar.addfile(link); hardlinks+=1
        else:
            tar.add(path,arcname=name,recursive=False)
            if key is not None: canonical[key]=name
# Streaming readback hashes every regular member. A hardlink must resolve to a
# previously verified identical member; no repeated backward decompression.
verified={}
with tarfile.open(archive,'r|gz') as tar:
    for member in tar:
        assert member.name in integrity and member.name not in verified
        expected=integrity[member.name]
        if member.islnk():
            assert member.linkname in verified and verified[member.linkname]==expected
        else:
            assert member.isfile(),member.name
            stream=tar.extractfile(member)
            digest=hashlib.sha256(); size=0
            for block in iter(lambda:stream.read(1024*1024),b''):
                digest.update(block); size+=len(block)
            assert size==expected['bytes'] and digest.hexdigest()==expected['sha256'],member.name
        verified[member.name]=expected
assert verified==integrity
(DEST/'integrity.json').write_text(json.dumps(integrity,indent=2)+'\n')
for path in [E/'summary.json',E/'validation/validation-summary.json']:
    shutil.copyfile(path,DEST/path.name)
manifest=dict(archive=archive.name,archive_bytes=archive.stat().st_size,archive_sha256=sha(archive),
    files=len(files),identical_oracle_hardlinks=hardlinks,verified_readback=True,
    accepted_sweeps=52,accepted_fresh_processes=624,excluded_measurements=0,
    omitted=['All APK/DEX inputs','QQ corpus','Compiled native/JVM/Android artifacts'],
    integrity_sha256=sha(DEST/'integrity.json'))
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2),flush=True)
