"""Inspect the immutable normal executable call sites before freezing timings."""
from pathlib import Path
import hashlib,json,re,subprocess
base=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
e=base/'hybrid-descriptor-direct-slots-v1'
records=[]
for label,artifact in [('before',base/'hybrid-descriptor-hot-hits-v1/artifacts/hybrid'),('after',e/'artifacts/hybrid'),('dense',base/'hybrid-descriptors-v1/artifacts/control')]:
    path=artifact/'build/Core/dexkit_descriptor_workload'
    dis=subprocess.check_output(['otool','-tv',str(path)],text=True)
    symbols=list(re.finditer(r'^(__?ZN6dexkit7DexItem[^\n]+):$',dis,re.M))
    for kind in ['Method','Field']:
        for shape in ['lookup','index']:
            stem='Get'+kind+'BeanEj'
            matches=[m for m in symbols if stem in m.group(1) and ('basic_string_view' in m.group(1))==(shape=='lookup')]
            assert len(matches)==1,(label,kind,shape)
            m=matches[0]
            body=dis[m.start():]
            end=re.search(r'\n[^ \n\t0-9][^\n]*:\n',body[len(m.group(0)):])
            if end: body=body[:len(m.group(0))+end.start()]
            out=e/'validation'/(shape+'-'+kind.lower()+'-bean-'+label+'.s')
            out.write_text(body+'\n')
            instructions=[l for l in body.splitlines() if re.match(r'^[0-9a-f]{16}\t',l)]
            calls=[l for l in instructions if '\tbl\t' in l or '\tb\t__' in l]
            records.append(dict(label=label,kind=kind,shape=shape,executable=str(path),
                executable_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                assembly=str(out),assembly_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),
                instructions=len(instructions),calls=calls))
            if kind=='Method' and shape=='lookup':print(label,body)
(e/'validation/callsites.json').write_text(json.dumps(records,indent=2)+'\n')
