import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE = Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
E = BASE/'hybrid-descriptor-direct-slots-v1'
V = E/'validation'
JDK = '/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home'
queue = V/'census-checks.json'
records = json.loads(queue.read_text()) if queue.exists() else []


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def native(name, command):
    output = V/(name+'.log')
    previous = next((r for r in records if r['name'] == name), None)
    if previous:
        assert sha(output) == previous['log_sha256']
        return output
    command = list(map(str,command))
    with output.open('w') as log:
        subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=300)
    records.append(dict(name=name,command=command,log_sha256=sha(output)))
    queue.write_text(json.dumps(records,indent=2)+'\n')
    print('DONE '+name,flush=True)
    return output


for label in ['hybrid-trace']:
    name = 'verify-'+label+'-census-w4'
    if not any(r['name'] == name for r in records):
        cmd = ['python3',ROOT/'tools/qaux-benchmark/run.py','--dexkit-root',ROOT,
            '--corpus',BASE/'qaux-extracted','--apk',BASE/'qq-9.3.55.apk','--java-home',JDK,
            '--memory-probe',BASE/'artifacts/probe-v2/libqauxbench_probe.dylib',
            '--output',V/name,'--native-library',E/'artifacts'/label/'libdexkit.dylib',
            '--passes','11','--threads','4','--profile','all','--mode','verify']
        native(name,cmd)
        metadata = json.loads((V/name/'run-metadata.json').read_text())
        assert metadata['baseline_results_equal'] is True
    exe = E/'artifacts'/label/'build/Core'
    for fixture,mode,repeats,selected in [
        ('dense','output-sso',2,None),('dense','output-sso-prefix',16,None),
        ('dense','output-sso-scattered',16,None),('dense','output-sso-shard',16,None),
        ('symbol','output',16,None),('symbol','lookup',512,None),
        ('overload','lookup-prefix',256,None),('symbol','lookup-hot',100000,None),
        ('symbol','lookup-concurrent-w1',20000,None),('symbol','lookup-concurrent-w4',20000,None),
        ('dense','output-sso-shard',100000,1)]:
        apk = (BASE/'followup/fixtures/dense-descriptors/dense-descriptors.apk' if fixture == 'dense' else
               BASE/'raw-metadata'/('overload-fixture' if fixture == 'overload' else 'symbol-fixture')/'symbols.apk')
        name = 'census-'+label+'-'+fixture+'-'+mode+('' if selected is None else '-k'+str(selected))
        cmd = [exe/'dexkit_descriptor_workload',apk,mode,str(repeats)]
        if mode.startswith('lookup-concurrent-'):
            cmd = [exe/'dexkit_descriptor_concurrent_workload',apk,str(repeats),mode[-1]]
        if selected is not None:
            cmd += [str(selected)]
        native(name,cmd)

FIELD = 'Lcom/tencent/mobileqq/data/MessageRecord;->msg:Ljava/lang/String;'
name = 'verify-hybrid-tail-w4'
if not any(r['name'] == name for r in records):
    cmd = ['python3',ROOT/'tools/qaux-benchmark/run.py','--dexkit-root',ROOT,
        '--corpus',BASE/'qaux-extracted','--apk',BASE/'qq-9.3.55.apk','--java-home',JDK,
        '--memory-probe',BASE/'artifacts/probe-v2/libqauxbench_probe.dylib',
        '--output',V/name,'--native-library',E/'artifacts/hybrid/libdexkit.dylib',
        '--passes','11','--threads','4','--profile','all','--mode','verify',
        '--final-field-rw',FIELD,'--field-rw-expected',BASE/'followup/formal/field-tail-oracle-best5/field-rw-expected.json']
    native(name,cmd)
    metadata = json.loads((V/name/'run-metadata.json').read_text())
    assert metadata['baseline_results_equal'] is True and metadata['final_field_rw_results_equal'] is True
print('COMPLETE census '+str(len(records))+' driver commands',flush=True)
