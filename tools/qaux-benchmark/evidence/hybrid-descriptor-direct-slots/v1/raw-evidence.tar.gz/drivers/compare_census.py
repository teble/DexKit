"""Reconcile fixed requested layouts and completed-access counters across entries."""
import hashlib
import json
from pathlib import Path

BASE = Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
OLD = BASE/'hybrid-descriptor-hot-hits-v1/validation'
V = BASE/'hybrid-descriptor-direct-slots-v1/validation'
TABLE = 'BENCH_HYBRID_DESCRIPTOR_TABLE '
CACHE = 'BENCH_HYBRID_DESCRIPTOR_CACHE '
ACCESS = 'BENCH_DESCRIPTOR_ACCESS '


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path, prefix):
    return [row for line in path.read_text().splitlines() if line.startswith(prefix)
            for row in [json.loads(line[len(prefix):])] if row.get('phase') == 'pre_close']


paths = sorted(p.relative_to(V) for p in V.glob('census-hybrid-trace-*.log'))
paths += [Path('verify-hybrid-trace-census-w4/run.log')]
paths += [Path('boundary-'+str(n)+'-hybrid-trace-stderr.log') for n in [1,448,449,450]]
records = []
for relative in paths:
    before, after = OLD/relative, V/relative
    tables = [read(path,TABLE) for path in [before,after]]
    key = lambda row: (row['dex'],row['shard'],row['kind'])
    # Conversion timing and which racing read wins a lock-free hit may differ.
    # Neither affects the number of completed accesses or retained layout.
    omit = {'promotion_ns','dense_hits'}
    normalized = [sorted([{k:v for k,v in row.items() if k not in omit} for row in rows],key=key)
                  for rows in tables]
    assert normalized[0] and normalized[0] == normalized[1], str(relative)
    caches = [sorted(read(path,CACHE),key=lambda row:row['dex']) for path in [before,after]]
    assert caches[0] and caches[0] == caches[1], str(relative)
    accesses = [sorted(read(path,ACCESS),key=lambda row:row['reason']) for path in [before,after]]
    assert accesses[0] == accesses[1], str(relative)
    summary = {}
    for kind in ['method','field']:
        domain = [row for row in tables[1] if row['kind'] == kind]
        total = {name:sum(row[name] for row in domain) for name in
                 ['calls','hits','records','dense_hits','promotions','bucket_bytes','dense_bytes','block_bytes']}
        assert total['calls'] - total['hits'] == total['records']
        assert total['calls'] == sum(row[kind+'_calls'] for row in accesses[1])
        assert total['hits'] == sum(row[kind+'_hits'] for row in accesses[1])
        summary[kind] = total
    records.append(dict(case=str(relative),table_count=len(tables[1]),counts=summary,
                        before_sha256=sha(before),after_sha256=sha(after)))
(V/'census-comparison.json').write_text(json.dumps(dict(cases=records,
    omitted_pair_comparison_fields=sorted(omit),
    scope='Diagnostic requested layouts, calls, hits and records; not normal allocator physical decomposition.'),indent=2)+'\n')
print('PASS',len(records),'paired diagnostic cases,',sum(row['table_count'] for row in records),'tables; completed accesses agree with public diagnostics.')
