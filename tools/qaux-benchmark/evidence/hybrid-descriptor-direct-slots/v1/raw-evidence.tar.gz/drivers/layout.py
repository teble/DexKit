import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/Users/teble/project/android/DexKit-qaux-benchmark')
E = Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/hybrid-descriptor-direct-slots-v1')
OUT = E/'validation/layout'
OUT.mkdir(exist_ok=True)
source = OUT/'layout.cpp'
source.write_text('''#include "hybrid_descriptor_cache.h"
extern "C" {
char actual_cache[sizeof(dexkit::HybridDescriptorCache<true>)];
char actual_sparse[sizeof(dexkit::HybridDescriptorCache<false>)];
char normal_payload[sizeof(std::deque<std::string>)];
#if DEXKIT_BENCHMARK_DIAGNOSTICS
char reported_fixed[dexkit::HybridDescriptorCache<true>::FixedObjectBytes()];
char actual_payload[sizeof(std::deque<std::string, dexkit::descriptor_cache_detail::CountingAllocator<std::string>>)];
#else
char reported_fixed[sizeof(dexkit::HybridDescriptorCache<true>)];
char actual_payload[sizeof(std::deque<std::string>)];
#endif
}
''')
ndk = Path('/Users/teble/Library/Android/sdk/ndk/26.1.10909125/toolchains/llvm/prebuilt/darwin-x86_64/bin')
targets = {'desktop': ['clang++', '-mmacosx-version-min=11.0'],
           'arm64-v8a': [str(ndk/'aarch64-linux-android21-clang++')],
           'armeabi-v7a': [str(ndk/'armv7a-linux-androideabi21-clang++')],
           'x86': [str(ndk/'i686-linux-android21-clang++')],
           'x86_64': [str(ndk/'x86_64-linux-android21-clang++')]}
records = []
for abi, compiler in targets.items():
    rows = []
    for diagnostic in [0,1]:
        assembly = OUT/(abi+'-'+str(diagnostic)+'.s')
        command = compiler+['-std=c++20','-fno-exceptions','-O2','-S',str(source),'-o',str(assembly),
            '-DDEXKIT_BENCHMARK_DIAGNOSTICS='+str(diagnostic),'-I'+str(ROOT/'Core/dexkit/include'),
            '-I'+str(ROOT/'Core/third_party/parallel_hashmap')]
        subprocess.run(command, check=True)
        text = assembly.read_text()
        values = {}
        for symbol in ['actual_cache','actual_sparse','reported_fixed','normal_payload','actual_payload']:
            pattern = (r'\.zerofill\s+__DATA,__common,_'+symbol+r',(\d+),' if abi == 'desktop'
                       else r'\.size\s+'+symbol+r',\s*(\d+)')
            match = re.search(pattern, text)
            assert match, (abi,symbol)
            values[symbol] = int(match[1])
        rows.append(dict(diagnostics=bool(diagnostic), command=command, sizes=values))
    assert rows[0]['sizes']['actual_cache'] == rows[1]['sizes']['reported_fixed']
    assert all(row['sizes']['actual_cache'] == row['sizes']['actual_sparse'] for row in rows)
    assert rows[0]['sizes']['actual_payload'] == rows[1]['sizes']['normal_payload']
    records.append(dict(abi=abi, variants=rows))
    print(abi+' '+json.dumps([row['sizes'] for row in rows]), flush=True)
(OUT/'summary.json').write_text(json.dumps(records,indent=2)+'\n')
