import json
from pathlib import Path

ROOT = Path('/Users/teble/project/android/DexKit-qaux-benchmark')
E = Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/hybrid-descriptor-direct-slots-v1')
x = json.loads((E / 'summary.json').read_text())
cases = x['cases']


def pair(name, metric, interval=False):
    values = []
    for phase in ['main', 'confirm']:
        result = cases[name][phase].get(metric)
        if result is None:
            return '--'
        value = f"{result['median_change_percent']:+.2f}%"
        if interval:
            value += ' [' + ', '.join(f'{v:+.2f}' for v in result['bootstrap95_percent']) + ']'
        values.append(value)
    return ' / '.join(values)


def med(name, metric, label, phase='main'):
    return cases[name][phase][metric]['variants'][label]['median']


def confirmed(metric, regression=False):
    return [name for name, phases in cases.items()
            if name.startswith('before-to-after-') and all(metric in row for row in phases.values())
            and all((row[metric]['bootstrap95_percent'][0] > 0 if regression
                     else row[metric]['bootstrap95_percent'][1] < 0) for row in phases.values())]


wide = 'before-to-after-symbol-lookup-r512'
dense_wide = 'dense-to-after-symbol-lookup-r512'
scatter = 'before-to-after-dense-output-sso-scattered-r16'
assert confirmed('lifecycle_ms') == [wide]
assert confirmed('lifecycle_ms', True) == []
assert confirmed('repeated_api_ms') == []
assert confirmed('peak_footprint_bytes', True) == [scatter]
assert x['accepted_sweeps'] == 52 and x['accepted_fresh_processes'] == 624
qq_peaks = [metrics['peak_footprint_bytes']['median_change_percent']
            for name, phases in cases.items() if name.startswith('dense-to-after-qq-')
            for metrics in phases.values()]

lines = [
    '# Direct slot-array publication: completed results', '',
    'Retain this single change for the measured wide-lookup lifecycle benefit.',
    'It is a limited improvement within the experimental hybrid cache;',
    'HYBRID_DESCRIPTORS remains OFF by default. Wide lookup is the only one of',
    '18 before/after lifecycle comparisons whose improvement interval excludes',
    'zero in both phases. The remaining regression against old dense is still',
    'large, and sparse scattered output has a small repeated physical-peak cost.', '',
    '## Fixed comparison', '',
    f"Before: `{x['baseline_engine_commit']}` hybrid. After: `{x['engine_commit']}` hybrid.",
    f"Old dense reference: `{x['dense_engine_commit']}`, with hybrid disabled.",
    'Other Small14 options, compiler settings and public workloads are identical.',
    'The source change publishes the existing atomic slot-array address directly.',
    'DenseIndex ownership, both allocations, payload, field layout, conversion',
    'cost rule, acquire/release ordering and the preceding fast/Cold split remain.', '',
    f"Frozen plan SHA256: `{x['frozen_plan_sha256']}`.",
    'All 52 sweeps / 624 fresh processes completed: six balanced AB/BA pairs per',
    'case in a main phase and one independently seeded confirmation. Eighteen',
    'cases compare before/after and eight provide direct old-dense residuals.',
    'Every successful sample is retained, with zero exclusions; all frozen',
    'input hashes reconciled before and after measurement. No builds, correctness',
    'runs, profiling or evidence compression ran during the timed comparisons.', '',
    'Negative percentages favor after. Reported percentages are paired median',
    'changes, not ratios of absolute medians; paired bootstrap 95% intervals are',
    'exploratory per-case estimates with six pairs and no multiple-comparison',
    'adjustment. Values below are main / confirmation. Lifecycle includes create,',
    'setup, APIs, result destruction and close. One/four calling-thread cases do',
    'different total work. OS caches were not flushed. These are macOS arm64',
    'measurements, not Android runtime results. Full intervals and absolute',
    'medians are in the [summary](evidence/hybrid-descriptor-direct-slots/v1/summary.json).', '',
    '## What the measurements support', '',
    f"- Wide lookup lifecycle: {pair(wide, 'lifecycle_ms', True)}. Both phases",
    '  support a benefit for this workload, with differing effect sizes. The',
    f"  repeated API stage changes {pair(wide, 'repeated_api_ms', True)}; its",
    '  confirmation interval slightly crosses zero. Do not turn the lifecycle',
    '  result into a separately confirmed warm-stage or exact load-cycle claim.',
    f"- The direct old-dense wide residual remains {pair(dense_wide, 'lifecycle_ms')}",
    f"  for lifecycle and {pair(dense_wide, 'repeated_api_ms')} for repeated APIs.",
    '  Direct publication does not make hybrid equivalent to the original array.',
    '- Prefix lookup improves -3.40% / -3.80% and hot narrow lookup -4.94% /',
    '  -1.61% at the lifecycle point estimates, but each confirmation interval',
    '  crosses zero. Both still regress against old dense. Their direction is',
    '  promising without a confirmed general lookup benefit from this batch.',
    '- Full SSO, long output, sparse distributions, concurrent calls and immediate',
    '  close at 448/449/450 members per domain have no two-phase lifecycle result',
    '  excluding zero. No before/after lifecycle regression is established in',
    '  both phases either. These intervals do not prove equivalence or no cost.',
    '- Full SSO at two repeats still costs +9.58% / +7.57% lifecycle versus old',
    '  dense, with first APIs +14.58% / +15.06%, and higher close/peak costs.',
    '  At 16 repeats lifecycle points are +2.46% / +2.60%, but the main interval',
    '  crosses zero. Keep that uncertainty; this change does not remove initial',
    '  string construction, conversion or destruction work.',
    '- QQ and the one-member-per-domain hotspot have no confirmed before/after',
    '  lifecycle gain. They do not convert, so their time changes cannot be',
    '  attributed to the removed dense load. QQ retained its direct old-dense',
    f"  peak advantage: {min(qq_peaks):+.2f}% to {max(qq_peaks):+.2f}% across the six phase/case results.",
    '  All six peak intervals exclude zero; lifecycle benefits versus old dense',
    '  are not consistently established by both phases in this batch.',
    f"- Sparse scattered output has physical-peak changes {pair(scatter, 'peak_footprint_bytes', True)}.",
    '  Both intervals are adverse even though requested layouts and object sizes',
    '  match. Absolute peak medians differ by about 48 / 40 KiB. There is no',
    '  measured allocation attribution for this increase; retain it in the',
    '  verdict rather than declaring memory universally unchanged.', '',
    'For scale, wide before/after lifecycle medians are',
    f"{med(wide, 'lifecycle_ms', 'before'):.3f} / {med(wide, 'lifecycle_ms', 'after'):.3f} ms in the main phase and",
    f"{med(wide, 'lifecycle_ms', 'before', 'confirm'):.3f} / {med(wide, 'lifecycle_ms', 'after', 'confirm'):.3f} ms in confirmation.",
    'The separate direct old-dense/after repeated-API medians are',
    f"{med(dense_wide, 'repeated_api_ms', 'dense'):.3f} / {med(dense_wide, 'repeated_api_ms', 'after'):.3f} ms and",
    f"{med(dense_wide, 'repeated_api_ms', 'dense', 'confirm'):.3f} / {med(dense_wide, 'repeated_api_ms', 'after', 'confirm'):.3f} ms.",
    'Do not multiply percentage changes from separate batches to reconstruct',
    'either comparison. No further repeats or threshold changes were added.', '',
    '## QQ results', '',
    '| Comparison / workload | Lifecycle (95% interval), main / confirmation | Peak footprint, main / confirmation |',
    '| --- | --- | --- |',
]
for name in cases:
    if '-qq-' in name:
        lines.append(f"| {name} | {pair(name, 'lifecycle_ms', True)} | {pair(name, 'peak_footprint_bytes')} |")
lines += ['', '## Native results', '',
          'Stage/peak columns show paired median changes; full intervals and absolute',
          'values remain in JSON. A dash means the repeated stage is absent or zero.']
for edge in ['before-to-after', 'dense-to-after']:
    lines += ['', '### ' + edge, '',
              '| Workload | Lifecycle (95% interval) | First APIs | Repeated APIs | Close | Peak footprint |',
              '| --- | --- | --- | --- | --- | --- |']
    for name in cases:
        if not name.startswith(edge + '-') or '-qq-' in name:
            continue
        lines.append('| ' + name[len(edge) + 1:] + ' | ' + ' | '.join(
            pair(name, metric, metric == 'lifecycle_ms') for metric in
            ['lifecycle_ms', 'pass0_api_ms', 'repeated_api_ms', 'close_ms', 'peak_footprint_bytes']) + ' |')
lines += [
    '', '## Mechanism and unchanged storage', '',
    'Normal dylib method/field descriptor getters each change 27 -> 26 instructions',
    'and keep both acquire loads. The timed executable inlines the same probe:',
    'method text lookup changes 77 -> 76 instructions, field 67 -> 66, by removing',
    'the ordinary owner-to-slots read following the first acquire. The method',
    'lookup frame remains 160 bytes. Numeric Bean consumers also lose that load.',
    'The Cold branch, string access, candidate order and comparison remain.', '',
    'This is a more direct mechanism comparison than the preceding entry-only',
    'change, whose exported getter frame was not present per candidate in the',
    'inlined lookup loop. It still measures the whole compiled source change;',
    'scheduling, address layout and noise prevent exact cycle attribution to a',
    'single instruction. The previous post-batch profile is historical evidence,',
    'not a new profile of this source version.', '',
    'Sixteen paired diagnostic cases reconcile 4352 tables: completed calls,',
    'hits, records, conversions and requested capacities match the previous',
    'hybrid version. Race-dependent lock-free dense_hits and conversion duration',
    'are excluded only from this diagnostic equality comparison, not from timing',
    'sample acceptance. QQ has 1628 method records, zero field records and zero',
    'conversions. The 448-per-domain case remains sparse; 449 converts both',
    'method and field domains once and frees their buckets; 450 does not reconvert.', '',
    'Five ABI probes confirm unchanged normal and diagnostic cache/deque owner',
    'sizes: normal cache 6680 bytes on desktop, 5912 on Android arm64/x86_64, and',
    '2444 on Android armv7/x86. Diagnostic allocator requests and partial',
    'conversion overlap are not a decomposition of normal physical peaks.', '',
    '## Validation and review', '',
    'All 184 native driver commands, 42 normal workload smokes and four QQ full',
    'oracle runs passed before timing. Core/JAR/JVM/AAR tasks passed with 71 tests,',
    'zero skips and all four Android ABI libraries. Existing checks cover the',
    'new array publication, retained SSO/long/empty views, delayed sparse readers,',
    'concurrent first insertion and bounds. Host ASan/UBSan disables leak',
    'detection; latch hooks are diagnostic-only. Android runtime is not covered.', '',
    'The complete [Pro review](HYBRID-DESCRIPTOR-DIRECT-SLOTS-REVIEW.md) read',
    '`eed75a8 -> 33b1224` and the relevant unchanged consumers/checks. It found',
    'no confirmed ownership, boundary, publication or macro blocker. Its reporting',
    'limits are adopted; Pro did not inspect these binaries, rerun tests or',
    'independently recompute the final performance statistics.', '',
    'The [evidence manifest](evidence/hybrid-descriptor-direct-slots/v1/manifest.json)',
    'records source/artifact identities and a fully verified raw archive with',
    'ordered samples, oracles, commands, assembly and diagnostic/ABI results.',
    'APKs, DEX inputs and compiled native/JVM/Android artifacts are omitted.',
    'This completes the bounded [execution plan](HYBRID-DESCRIPTOR-DIRECT-SLOTS.md).',
    'The measured scope supports keeping direct publication within the hybrid',
    'experiment; it does not support enabling hybrid by default or claiming',
    'that the remaining dense-read and full-coverage costs are resolved.', '',
]
(ROOT / 'tools/qaux-benchmark/HYBRID-DESCRIPTOR-DIRECT-SLOTS-RESULTS.md').write_text('\n'.join(lines))
print('Wrote', len(lines), 'report lines')
