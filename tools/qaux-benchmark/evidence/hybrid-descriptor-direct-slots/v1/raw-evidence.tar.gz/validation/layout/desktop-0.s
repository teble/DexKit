	.build_version macos, 11, 0	sdk_version 26, 5
	.globl	_actual_cache                   ; @actual_cache
.zerofill __DATA,__common,_actual_cache,6680,0
	.globl	_actual_sparse                  ; @actual_sparse
.zerofill __DATA,__common,_actual_sparse,6680,0
	.globl	_normal_payload                 ; @normal_payload
.zerofill __DATA,__common,_normal_payload,48,0
	.globl	_reported_fixed                 ; @reported_fixed
.zerofill __DATA,__common,_reported_fixed,6680,0
	.globl	_actual_payload                 ; @actual_payload
.zerofill __DATA,__common,_actual_payload,48,0
.subsections_via_symbols
