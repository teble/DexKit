#include "hybrid_descriptor_cache.h"
extern "C" {
char actual_cache[sizeof(dexkit::HybridDescriptorCache<true>)];
char actual_sparse[sizeof(dexkit::HybridDescriptorCache<false>)];
char normal_payload[sizeof(std::deque<std::string>)];
#if DEXKIT_BENCHMARK_DIAGNOSTICS
char reported_fixed[dexkit::HybridDescriptorCache<true>::FixedObjectBytes()];
char actual_payload[sizeof(std::deque<std::string, dexkit::descriptor_cache_detail::CountingAllocator<std::string>>)];
#else
char reported_fixed[sizeof(dexkit::HybridDescriptorCache<true>)];
char actual_payload[sizeof(std::deque<std::string>)];
#endif
}
