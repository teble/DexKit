	.text
	.file	"layout.cpp"
	.type	actual_cache,@object            # @actual_cache
	.bss
	.globl	actual_cache
actual_cache:
	.zero	10008
	.size	actual_cache, 10008

	.type	actual_sparse,@object           # @actual_sparse
	.globl	actual_sparse
actual_sparse:
	.zero	10008
	.size	actual_sparse, 10008

	.type	normal_payload,@object          # @normal_payload
	.globl	normal_payload
normal_payload:
	.zero	24
	.size	normal_payload, 24

	.type	reported_fixed,@object          # @reported_fixed
	.globl	reported_fixed
reported_fixed:
	.zero	2444
	.size	reported_fixed, 2444

	.type	actual_payload,@object          # @actual_payload
	.globl	actual_payload
actual_payload:
	.zero	32
	.size	actual_payload, 32

	.section	".linker-options","e",@llvm_linker_options
	.ident	"Android (10552028, +pgo, +bolt, +lto, -mlgo, based on r487747d) clang version 17.0.2 (https://android.googlesource.com/toolchain/llvm-project d9f89f4d16663d5012e5c09495f3b30ece3d2362)"
	.section	".note.GNU-stack","",@progbits
