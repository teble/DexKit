"""Post-batch mechanism observations; never merge profiled times into A/B data."""
import hashlib,json,re,subprocess,time
from pathlib import Path
BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
E=BASE/'hybrid-descriptor-hot-hits-v1'
V=E/'validation'
OUT=V/'lookup-profile'
OUT.mkdir(exist_ok=False)
assert len(json.loads((E/'measurements/completed.json').read_text()))==52
fixture=BASE/'raw-metadata/symbol-fixture/symbols.apk'
records=[]
for label,artifact in [('before',BASE/'hybrid-descriptors-v1/artifacts/hybrid'),('after',E/'artifacts/hybrid'),('dense',BASE/'hybrid-descriptors-v1/artifacts/control')]:
    executable=artifact/'build/Core/dexkit_descriptor_workload'
    command=list(map(str,[executable,fixture,'lookup',100000]))
    print('START profile '+label,flush=True)
    with (OUT/(label+'-workload.log')).open('w') as log:
        process=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
        sample_command=['/usr/bin/sample',str(process.pid),'1','1','-mayDie','-file',str(OUT/(label+'-sample.txt'))]
        with (OUT/(label+'-sample-launcher.log')).open('w') as sample_log:
            sampled=subprocess.run(sample_command,stdout=sample_log,stderr=subprocess.STDOUT,timeout=30)
        status=process.wait(timeout=30)
    assert status==0,(label,status)
    report=json.loads(next(line[9:] for line in (OUT/(label+'-workload.log')).read_text().splitlines() if line.startswith('WORKLOAD ')))
    assert report['returned']==100000 and report['repeats']==100000
    records.append(dict(label=label,command=command,executable_sha256=hashlib.sha256(executable.read_bytes()).hexdigest(),
        sample_command=sample_command,sample_exit_code=sampled.returncode,workload_exit_code=status,
        note='Normal executable, sampled after formal measurements; these perturbed timings are excluded from every performance comparison.'))
    print('DONE profile '+label+' sample_exit='+str(sampled.returncode),flush=True)
# One first pass versus the existing 512-pass diagnostic run verifies that the
# repeated phase constructs no new descriptors and performs no new conversion.
command=list(map(str,[E/'artifacts/hybrid-trace/build/Core/dexkit_descriptor_workload',fixture,'lookup',1]))
one=OUT/'after-trace-one-pass.log'
with one.open('w') as log:
    subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=30)
prefix='BENCH_HYBRID_DESCRIPTOR_TABLE '
def tables(path):
    return sorted([r for line in path.read_text().splitlines() if line.startswith(prefix)
        for r in [json.loads(line[len(prefix):])] if r['phase']=='pre_close'],key=lambda r:(r['dex'],r['shard'],r['kind']))
a,b=tables(one),tables(V/'census-hybrid-trace-symbol-lookup.log')
assert a and len(a)==len(b)
for left,right in zip(a,b):
    for key in ['records','promotions','capacity','bucket_bytes','dense_bytes','payload_owner_bytes','block_bytes','directory_bytes','char_bytes']:
        assert left[key]==right[key],key
    assert right['calls']-left['calls']==right['hits']-left['hits']==right['dense_hits']-left['dense_hits']
comparison=dict(one_pass_command=command,table_count=len(a),
    records=sum(r['records'] for r in a),promotions=sum(r['promotions'] for r in a),
    additional_warm_calls=sum(y['calls']-x['calls'] for x,y in zip(a,b)),
    additional_warm_records=0,additional_warm_promotions=0,
    all_additional_calls_are_lock_free_dense_hits=True)
(OUT/'summary.json').write_text(json.dumps(dict(samples=records,diagnostic_comparison=comparison),indent=2)+'\n')
print('COMPLETE',json.dumps(comparison),flush=True)
