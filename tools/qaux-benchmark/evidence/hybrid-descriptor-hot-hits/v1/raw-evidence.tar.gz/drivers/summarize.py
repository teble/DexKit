"""Reconcile the immutable hybrid experiment without excluding successful runs."""
import hashlib
import json
from pathlib import Path
import random
import subprocess

ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
E=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/hybrid-descriptor-hot-hits-v1')
M,V=E/'measurements',E/'validation'
OLD=E.parent/'hybrid-descriptors-v1'
ARTIFACTS={'before':OLD/'artifacts/hybrid','after':E/'artifacts/hybrid','dense':OLD/'artifacts/control'}


def read(path):
    return json.loads(path.read_text())


def sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):
            digest.update(block)
    return digest.hexdigest()


frozen,completed=read(M/'frozen-plan.json'),read(M/'completed.json')
assert len(completed)==len(frozen['sweeps'])==52
assert [r['name'] for r in completed]==[r['name'] for r in frozen['sweeps']]
for path,expected in frozen['files'].items():
    assert sha(path)==expected,path
total,sweeps,cases=0,[],{}
for item in completed:
    directory=M/item['name']
    assert sha(directory/'summary.json')==item['summary_sha256']
    summary,samples=read(directory/'summary.json'),read(directory/'samples.json')
    assert len(samples)==12
    order=[i%2 for i in range(6)]
    random.Random(item['seed']).shuffle(order)
    assert summary['reversed_order']==order
    for pair in range(6):
        rows=sorted([r for r in samples if r['pair']==pair],key=lambda r:r['position'])
        assert [r['label'] for r in rows]==(list(reversed(item['labels'])) if order[pair] else item['labels'])
        if item['kind']=='qq':
            for row in rows:
                metadata=read(directory/f'pair-{pair:02d}-{row["label"]}'/'run-metadata.json')
                assert metadata['exit_code']==0 and metadata['baseline_counts_and_flow_equal'] is True
                assert metadata['repeat_results_equal'] is (True if item['passes']>1 else None)
                assert metadata['native_sha256']==frozen['native_manifests'][row['label']]['native_sha256']
                assert metadata['passes']==item['passes'] and metadata['threads']==item['threads']
        else:
            identities={(r['report']['mode'],r['report']['repeats'],r['report']['checksum'],r['report']['returned']) for r in rows}
            assert len(identities)==1
            if item['selected_count'] is not None:
                count,repeats=item['selected_count'],item['repeats']
                for row in rows:
                    report=row['report']
                    assert report['selected_count']==count and report['returned']==2*count*repeats
                    assert report['checksum']==(32*count*(count-1)+27*count)*repeats
                    if repeats==1:
                        assert report['repeated_ns']==0
    total+=len(samples)
    sweeps.append(dict(item,raw_summary=str(directory/'summary.json'),raw_samples=str(directory/'samples.json')))
    cases.setdefault(item['name'].split('-',1)[1],{})[item['phase']]=summary['metrics']
assert total==624 and len(cases)==26 and all(set(phases)=={'main','confirm'} for phases in cases.values())

commands={}
for phase in ['normal','trace','isolated','sanitize']:
    records=read(V/('checks-'+phase+'.json'))
    assert read(V/('complete-'+phase+'.json'))['checks_sha256']==sha(V/('checks-'+phase+'.json'))
    for row in records:
        path=V/(row['name']+('.bin' if row['binary'] else '.log'))
        assert sha(path)==row['output_sha256'] and row['exit_code'] in [0,-6]
    commands[phase]=len(records)
assert sum(commands.values())==184
qq=[]
for record in read(V/'qq-verification.json'):
    metadata=read(V/record['name']/'run-metadata.json')
    assert record['passed'] is True and metadata['exit_code']==0 and metadata['baseline_results_equal'] is True
    qq.append(dict(name=record['name'],passes=metadata['passes'],threads=metadata['threads'],native_sha256=metadata['native_sha256'],baseline_results_equal=True))
for record in read(V/'census-checks.json'):
    assert sha(V/(record['name']+'.log'))==record['log_sha256']
    if record['name'].startswith('verify-'):
        metadata=read(V/record['name']/'run-metadata.json')
        assert metadata['exit_code']==0 and metadata['baseline_results_equal'] is True
        if '-tail-' in record['name']:
            assert metadata['final_field_rw_results_equal'] is True
        qq.append(dict(name=record['name'],passes=metadata['passes'],threads=metadata['threads'],native_sha256=metadata['native_sha256'],
            baseline_results_equal=True,final_field_rw_results_equal=metadata.get('final_field_rw_results_equal')))
assert len(qq)==4
gradle=read(V/'gradle/validation.json')
assert gradle['total_tests']==71 and gradle['skipped']==0 and len(gradle['abis'])==4
assert all(int(row['failures'])==int(row['errors'])==int(row['skipped'])==0 for row in gradle['tests'])
smokes=read(V/'workload-smokes.json')
assert len(smokes)==42
validation=dict(engine_commit=frozen['normal_engine_commit'],native_driver_commands=commands,native_driver_total=184,
    qq=qq,census_driver_commands=13,workload_smoke_commands=len(smokes),gradle=gradle,codegen=read(V/'codegen-summary.json'),diagnostic_pair_comparison=read(V/'census-comparison.json'),
    development_driver_corrections=['The first standalone compile used an incomplete phmap include path; corrected the driver path and preserved the failed compiler log.'],
    limitations=['ASan/UBSan and concurrency execution were on the host; leak detection was disabled.',
        'Android evidence covers four ABI builds, not Android execution/performance.',
        'Latches and conversion counters are diagnostic-only; normal component checks do not execute those hooks.',
        'Diagnostic deque requests are not an exact attribution of normal physical allocations.',
        'Full frozen/independent API oracles precede the timed count/checksum checks.'])
(V/'validation-summary.json').write_text(json.dumps(validation,indent=2)+'\n')
result=dict(engine_commit=frozen['normal_engine_commit'],frozen_plan_sha256=sha(M/'frozen-plan.json'),
    accepted_sweeps=52,accepted_fresh_processes=624,excluded_measurements=0,frozen_inputs_unchanged=True,
    host=dict(cpu=subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True).strip(),
              os=subprocess.check_output(['sw_vers'],text=True).strip()),
    native_libraries={label:dict(bytes=(ARTIFACTS[label]/'libdexkit.dylib').stat().st_size,sha256=manifest['native_sha256'])
                      for label,manifest in frozen['native_manifests'].items()},
    baseline_engine_commit=frozen['baseline_engine_commit'],post_batch_mechanism=read(V/'mechanism-summary.json'),validation=validation,cases=cases,sweeps=sweeps)
(E/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
for name,phases in cases.items():
    print(name)
    for metric in ['lifecycle_ms','pass0_api_ms','repeated_api_ms','close_ms','peak_footprint_bytes']:
        if not all(metric in phases[phase] for phase in ['main','confirm']):
            continue
        values=[]
        for phase in ['main','confirm']:
            value=phases[phase][metric]
            values.append('%+.2f%% [%+.2f,%+.2f]' % (value['median_change_percent'],*value['bootstrap95_percent']))
        print(' ',metric,' / '.join(values))
print('COMPLETE 52 sweeps, 624 samples, 184 native driver commands, 4 QQ checks, 71 JVM tests, four Android ABIs')
