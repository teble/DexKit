import json
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
E=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/hybrid-descriptor-hot-hits-v1')
x=json.loads((E/'summary.json').read_text())
cases=x['cases']

def pair(name,metric,interval=False):
    values=[]
    for phase in ['main','confirm']:
        r=cases[name][phase].get(metric)
        if r is None:return '--'
        value=f"{r['median_change_percent']:+.2f}%"
        if interval:value+=' ['+', '.join(f'{v:+.2f}' for v in r['bootstrap95_percent'])+']'
        values.append(value)
    return ' / '.join(values)

def med(name,metric,label,phase='main'):
    return cases[name][phase][metric]['variants'][label]['median']

lines=['# Hybrid descriptor fast entry: completed results','',
'Do not promote this entry change as a validated general speed optimization.',
'The fixed source remains an experimental checkpoint for focused follow-up;',
'HYBRID_DESCRIPTORS remains OFF by default. None of the 18 before/after lifecycle',
'comparisons has an improvement interval excluding zero in both phases. The',
'previous conditional storage verdict remains: QQ uses less peak memory, while',
'full SSO and wide/prefix lookup still regress against the original dense cache.','',
'## Fixed comparison','',
f"Before: `{x['baseline_engine_commit']}` hybrid. After: `{x['engine_commit']}` hybrid.",
'The old dense reference uses the same baseline source with HYBRID disabled.',
'All other Small14 options and compiler settings are identical. Ownership,',
'payload, fixed object layout, conversion rule and publication order are unchanged.','',
f"Frozen plan SHA256: `{x['frozen_plan_sha256']}`.",
'All 52 planned sweeps and 624 fresh processes completed: six balanced AB/BA',
'pairs per case in a main phase and one independent confirmation. Eighteen cases',
'compare before/after; eight compare old dense/after as a direct residual reference.',
'No successful samples were excluded, and every frozen input hash reconciled.',
'No builds, correctness tests or profiling ran during the formal comparisons.',
'Profiling and extra call-site inspection below ran only after the batch ended.','',
'Percentages favor the second label when negative and are paired median changes,',
'not ratios of separately reported absolute medians. Values are main / confirmation.',
'Lifecycle includes create, setup, APIs, result destruction and close. One/four',
'calling-thread cases execute different total work and are separate comparisons.',
'OS caches were not flushed. Bootstrap 95% intervals are exploratory per-case',
'estimates without a multiple-comparison adjustment. All absolute medians and',
'intervals are in the [summary](evidence/hybrid-descriptor-hot-hits/v1/summary.json);',
'ordered individual samples and logs are in the raw evidence archive.','',
'## What the measurements support','',
'- Wide lookup does not improve: before/after lifecycle +1.85% / +1.55%, both',
'  intervals crossing zero. Repeated API changes are +1.70% / -0.86%, also',
'  inconclusive. The direct old-dense/after lifecycle residual is +66.63% /',
'  +70.95%, with repeated APIs +88.22% / +94.58%.',
'- Full SSO at 16 repeats is essentially unchanged against before (-0.32% /',
'  -0.01% lifecycle), and still +3.21% / +3.33% against old dense. At two',
'  repeats, the old-dense residual is +8.11% / +10.31%; first APIs, close and',
'  physical peak remain worse. This entry change does not remove construction',
'  or destruction work.',
'- Prefix lookup has small before/after changes (-0.38% / -0.74% lifecycle),',
'  without a two-phase lifecycle result excluding zero. It still regresses',
'  +19.07% / +18.97% against old dense.',
'- Hot narrow lookup changes -1.17% / -0.66% over the lifecycle. The main',
'  interval excludes zero, but confirmation includes a retained large outlier:',
'  pair 0 after takes 141.674 ms versus 32.500 ms before, chiefly in repeated',
'  APIs. The confirmation interval is [-1.13%, +167.84%]. The ordinary median',
'  shift alone is not a robust confirmed gain.',
'- QQ before/after lifecycle directions do not replicate consistently. Its',
'  direct peak advantage versus old dense remains -8.14% to -9.04% in this',
'  batch. QQ has zero conversions, so any entry-time change is not a gain from',
'  dense hits. No repeated cold/QQ lifecycle regression is established either.',
'- The one-member-per-domain first call improves about 19% in both phases,',
'  but the absolute difference between medians is about 1.46 microseconds.',
'  Its complete lifecycle changes -0.44% / -0.90%, with the main interval',
'  crossing zero. Preserve this small stage observation without calling it a',
'  broad speedup.',
'- Physical peak is not uniformly unchanged even though diagnostic requested',
'  layouts match. Sparse prefix and single-shard output increase about 1.2%',
'  in both phases, roughly 0.1 MiB. Those adverse observations remain in the',
'  decision; there is no measured allocation attribution that explains them.',
'- Concurrent and immediate-close results remain noisy; all their lifecycle',
'  intervals cross zero in at least one phase. No extra confirmation, tuning or',
'  outlier removal was added to force a verdict.','',
'For scale, the direct old-dense/after wide repeated-API medians are',
f"{med('dense-to-after-symbol-lookup-r512','repeated_api_ms','dense'):.3f} / {med('dense-to-after-symbol-lookup-r512','repeated_api_ms','after'):.3f} ms in the main phase and",
f"{med('dense-to-after-symbol-lookup-r512','repeated_api_ms','dense','confirm'):.3f} / {med('dense-to-after-symbol-lookup-r512','repeated_api_ms','after','confirm'):.3f} ms in confirmation.",
'Full SSO at 16 repeats has old-dense/after close medians of',
f"{med('dense-to-after-dense-output-sso-r16','close_ms','dense'):.3f} / {med('dense-to-after-dense-output-sso-r16','close_ms','after'):.3f} ms and",
f"{med('dense-to-after-dense-output-sso-r16','close_ms','dense','confirm'):.3f} / {med('dense-to-after-dense-output-sso-r16','close_ms','after','confirm'):.3f} ms, within roughly 139-150 ms complete lifecycles.",'',
'## QQ results','',
'| Comparison / workload | Lifecycle (95% interval), main / confirmation | Peak footprint, main / confirmation |',
'| --- | --- | --- |']
for name in cases:
    if '-qq-' in name:lines.append(f"| {name} | {pair(name,'lifecycle_ms',True)} | {pair(name,'peak_footprint_bytes')} |")
lines+=['','## Native results','',
'Stage and peak columns give paired median changes; full intervals and absolute',
'values are in JSON. A dash means the repeated interval is absent or zero.']
for edge in ['before-to-after','dense-to-after']:
    lines+=['','### '+edge,'',
        '| Workload | Lifecycle (95% interval) | First APIs | Repeated APIs | Close | Peak footprint |',
        '| --- | --- | --- | --- | --- | --- |']
    for name in cases:
        if not name.startswith(edge+'-') or '-qq-' in name:continue
        lines.append('| '+name[len(edge)+1:]+' | '+' | '.join(pair(name,k,k=='lifecycle_ms') for k in
            ['lifecycle_ms','pass0_api_ms','repeated_api_ms','close_ms','peak_footprint_bytes'])+' |')
lines+=['','## Mechanism checked after timing','',
'The standalone normal getters do shrink from 38 to 27 instructions and their',
'successful paths no longer create a frame. Inspecting the actual timed native',
'executables reveals the important limit: method and field text lookup inline',
'the getter. The method lookup function keeps its existing 160-byte frame;',
'its loop loses two callback-capture stores, not a per-candidate function frame.',
'The complete method lookup changes 80 -> 77 instructions and field lookup',
'72 -> 67, while their dependent dense-index reads remain. Index-based Bean',
'getters also inline the probe. A shorter exported getter is not evidence that',
'all those call sites have lost call/return or frame work.','',
'A one-pass versus 512-pass diagnostic lookup has the same 4096 cached records',
'and 32 conversions. All additional 4186623 cache calls are lock-free dense hits:',
'zero extra construction, promotion or requested payload/index capacity. This',
'isolates the descriptor cache warm path; it does not claim that the complete',
'GetMethodData wrapper avoids all hashes, locks or output allocations.','',
'One-second statistical samples of the normal before/after/old-dense executables',
'at 100000 lookup repeats place 657/838, 644/840 and 389/789 main-thread top-of-stack',
'samples in the text GetMethodBean loop, respectively. The remaining prominent',
'work includes memcmp. These samples locate a hot region, not an exact cycle',
'attribution to one load; their perturbed runtimes are excluded from all 624',
'formal samples. The call-site assembly and complete sample reports are archived.','',
'The next bounded hypothesis is to publish the slot-array pointer directly,',
'while retaining the same DenseIndex owner, allocations, byte rule, shard layout',
'and acquire/release protocol. That would remove one dependent owner-to-slots',
'load without combining a payload rewrite or threshold change. It is not',
'implemented or measured by this batch, and this observation does not establish',
'its benefit.','',
'## Validation and review','',
'All 184 native driver commands, 42 normal workload smokes and four QQ full',
'oracle runs passed. The Core/JAR/JVM/AAR Gradle tasks passed with 71 tests, zero',
'skips and four Android ABI libraries. Host ASan/UBSan disabled leak detection;',
'Android runtime performance is not covered. Sixteen diagnostic before/after',
'cases reconcile 4352 tables and completed-access counters. Requested capacities',
'are diagnostic observations, not a decomposition of normal physical peaks.','',
'The complete [Pro source review](HYBRID-DESCRIPTOR-HOT-HITS-REVIEW.md) covered',
'`e454b24 -> 56c680c` and found no confirmed correctness blocker. Its limitations',
'are adopted: dense_hits does not count all dense hits or factories avoided;',
'component helper tests verify semantics, while the actual compiled call sites',
'and public API experiments evaluate entry costs. Pro did not rerun the tests,',
'disassemble the binaries or independently recompute these final measurements.','',
'The [evidence manifest](evidence/hybrid-descriptor-hot-hits/v1/manifest.json)',
'contains hashes and a verified raw archive with inputs/commands, source exports,',
'ordered byte oracles, normal/diagnostic results, assembly and post-batch profiles.',
'APKs, DEX inputs and compiled native/JVM/Android artifacts are omitted; their',
'identities and baseline source are recorded. This report completes the bounded',
'work recorded in the frozen [execution plan](HYBRID-DESCRIPTOR-HOT-HITS.md).','']
(ROOT/'tools/qaux-benchmark/HYBRID-DESCRIPTOR-HOT-HITS-RESULTS.md').write_text('\n'.join(lines))
print('Wrote',len(lines),'report lines')
