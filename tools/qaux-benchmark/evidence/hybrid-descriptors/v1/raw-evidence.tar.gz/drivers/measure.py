"""One fixed sparse/dense rule, a main phase and one confirmation."""
import datetime
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE = Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
E = BASE/'hybrid-descriptors-v1'
OUT = E/'measurements'
JDK = Path('/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home')
ENGINE = 'bf9cee531da6a5d4f237398350eed05d7fcf96c5'
LABELS = ['control','node','sparse','hybrid']
# Three edges cover all four variants and isolate payload/index conversion.
EDGES = [('control','hybrid'), ('node','sparse'), ('sparse','hybrid')]
FIXTURES = {'dense': BASE/'followup/fixtures/dense-descriptors/dense-descriptors.apk',
            'symbol': BASE/'raw-metadata/symbol-fixture/symbols.apk',
            'overload': BASE/'raw-metadata/overload-fixture/symbols.apk'}
CASES = [('dense','output-sso',2,None), ('dense','output-sso',16,None),
         ('dense','output-sso-prefix',16,None), ('dense','output-sso-scattered',16,None),
         ('dense','output-sso-shard',16,None), ('symbol','output',16,None),
         ('symbol','lookup',512,None), ('overload','lookup-prefix',256,None),
         ('symbol','lookup-hot',100000,None), ('symbol','lookup-concurrent-w1',20000,None),
         ('symbol','lookup-concurrent-w4',20000,None),
         ('dense','output-sso-shard',1,448), ('dense','output-sso-shard',1,449),
         ('dense','output-sso-shard',1,450), ('dense','output-sso-shard',100000,1)]


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            digest.update(block)
    return digest.hexdigest()


def executable(label, mode):
    name = 'descriptor_concurrent' if mode.startswith('lookup-concurrent-') else 'descriptor'
    return E/'artifacts'/label/'build/Core'/('dexkit_'+name+'_workload')


def make_plan():
    plan = []
    for phase, seed in [('main',2026091650), ('confirm',2026091750)]:
        for fixture, mode, repeats, selected in CASES:
            for left,right in EDGES:
                seed += 1
                suffix = '' if selected is None else '-k'+str(selected)
                plan.append(dict(name=f'{phase}-{left}-to-{right}-{fixture}-{mode}-r{repeats}{suffix}',
                    phase=phase, kind='native', labels=[left,right], pairs=6, seed=seed,
                    fixture=str(FIXTURES[fixture]), fixture_name=fixture, mode=mode,
                    repeats=repeats, selected_count=selected))
        for passes,threads in [(1,4),(11,4),(1,1)]:
            for left,right in EDGES:
                seed += 1
                plan.append(dict(name=f'{phase}-{left}-to-{right}-qq-p{passes}-w{threads}',
                    phase=phase, kind='qq', labels=[left,right], pairs=6, seed=seed,
                    passes=passes, threads=threads, profile='all'))
    assert len(plan) == 108
    return plan


def command(item):
    if item['kind'] == 'native':
        cmd = [sys.executable,ROOT/'tools/qaux-benchmark/workload_sweep.py',
            '--fixture',item['fixture'],'--output',OUT/item['name'],'--mode',item['mode'],
            '--repeats',str(item['repeats']),'--pairs',str(item['pairs']),'--seed',str(item['seed'])]
        if item['selected_count'] is not None:
            cmd += ['--selected-count',str(item['selected_count'])]
        for label in item['labels']:
            cmd += ['--variant',label,E/'artifacts'/label]
    else:
        cmd = [sys.executable,ROOT/'tools/qaux-benchmark/sweep.py','--dexkit-root',ROOT,
            '--corpus',BASE/'qaux-extracted','--apk',BASE/'qq-9.3.55.apk','--java-home',JDK,
            '--memory-probe',BASE/'artifacts/probe-v2/libqauxbench_probe.dylib',
            '--output',OUT/item['name'],'--pairs',str(item['pairs']),'--seed',str(item['seed']),
            '--passes',str(item['passes']),'--threads',str(item['threads']),'--profile',item['profile']]
        for label in item['labels']:
            cmd += ['--variant',label,E/'artifacts'/label/'libdexkit.dylib',
                    E/'validation'/('verify-'+label+'-w'+str(item['threads']))]
    return list(map(str,cmd))


action = sys.argv[1]
assert action in ['smoke','freeze','run']
OUT.mkdir(exist_ok=True)
frozen_path = OUT/'frozen-plan.json'
plan = make_plan()
if action == 'smoke':
    assert not frozen_path.exists()
    seen, records = {}, []
    for fixture,mode,repeats,selected in CASES:
        key = (fixture,mode,selected)
        if key in seen:
            continue
        expected = None
        for label in LABELS:
            # Single-pass boundary cases were already independently checked;
            # here repeated cases exercise the same public adapter twice.
            repetitions = 1 if repeats == 1 else 2
            cmd = [executable(label,mode),FIXTURES[fixture],mode,str(repetitions)]
            if mode.startswith('lookup-concurrent-'):
                cmd[-2:] = [str(repetitions),mode[-1]]
            if selected is not None:
                cmd += [str(selected)]
            cmd = list(map(str,cmd))
            result = subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                                    text=True,check=True,timeout=300)
            suffix = '' if selected is None else '-k'+str(selected)
            path = E/'validation'/f'smoke-{label}-{fixture}-{mode}{suffix}.log'
            path.write_text(result.stdout)
            report = json.loads(next(line[9:] for line in result.stdout.splitlines() if line.startswith('WORKLOAD ')))
            identity = (report['mode'],report['repeats'],report['checksum'],report['returned'])
            if expected is None:
                expected = identity
            assert identity == expected
            if selected is not None:
                assert report['selected_count'] == selected
                assert report['returned'] == 2*selected*repetitions
                assert report['checksum'] == (32*selected*(selected-1)+27*selected)*repetitions
            records.append(dict(label=label,case=key,command=cmd,identity=identity,log_sha256=sha(path)))
            print('PASS smoke '+label+' '+mode+suffix,flush=True)
        seen[key] = expected
    (E/'validation/workload-smokes.json').write_text(json.dumps(records,indent=2)+'\n')
    sys.exit(0)

if action == 'freeze':
    assert not frozen_path.exists(), 'Plan already frozen.'
    paths = list(FIXTURES.values())+[Path(__file__),BASE/'qq-9.3.55.apk',JDK/'bin/java',JDK/'bin/javac',
        BASE/'artifacts/probe-v2/libqauxbench_probe.dylib',ROOT/'tools/qaux-benchmark/HYBRID-DESCRIPTORS-REVIEW.md']
    paths += [ROOT/'tools/qaux-benchmark'/name for name in
        ['workload_sweep.py','sweep.py','run.py','QueryReplay.java','descriptor_workload.cpp','descriptor_concurrent_workload.cpp']]
    paths += [E/'validation'/name for name in ['checks-normal.json','checks-trace.json',
        'checks-isolated.json','checks-sanitize.json','workload-smokes.json','gradle/validation.json',
        'qq-verification.json','layout/summary.json','census-checks.json']]
    for phase in ['normal','trace','isolated','sanitize']:
        completion = E/'validation'/('complete-'+phase+'.json')
        proof = json.loads(completion.read_text())
        assert proof['checks_sha256'] == sha(E/'validation'/('checks-'+phase+'.json'))
        paths += [completion]
    census_path = E/'census-summary.json'
    census = json.loads(census_path.read_text())
    paths += [census_path]
    paths += [Path(record['log']) for variants in census['cases'].values() for record in variants.values()]
    manifests = {}
    for label in LABELS:
        artifact = E/'artifacts'/label
        paths += [artifact/'artifact.json',artifact/'libdexkit.dylib',artifact/'workload-sources.json']
        manifest = json.loads((artifact/'artifact.json').read_text())
        manifests[label] = manifest
        assert manifest['engine_commit'] == ENGINE and manifest['diagnostics'] is False
        assert not manifest['untracked_source_sha256']
        assert (artifact/'source.patch').read_text() == '\n'
        options = manifest['cmake_options']
        for key in ['PACKED_CROSS_INFO','PACKED_FIELD_USES','COMPACT_FIELDS','POINTER_DESCRIPTORS','PAGED_DESCRIPTORS']:
            assert options['DEXKIT_EXPERIMENT_'+key] == 'OFF'
        for key,owner in [('NODE_DESCRIPTORS','node'),('SPARSE_DESCRIPTORS','sparse'),('HYBRID_DESCRIPTORS','hybrid')]:
            assert options['DEXKIT_EXPERIMENT_'+key] == ('ON' if label == owner else 'OFF')
        for workers in [1,4]:
            metadata_path = E/'validation'/('verify-'+label+'-w'+str(workers))/'run-metadata.json'
            metadata = json.loads(metadata_path.read_text())
            assert metadata['exit_code'] == 0 and metadata['baseline_results_equal'] is True
            paths += [metadata_path]+list(map(Path,metadata['jars_sha256']))
    assert len({json.dumps(m['source_trees'],sort_keys=True) for m in manifests.values()}) == 1
    for item in plan:
        if item['kind'] == 'native':
            paths += [executable(label,item['mode']) for label in item['labels']]
    frozen = dict(frozen_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        worktree_head=subprocess.check_output(['git','-C',ROOT,'rev-parse','HEAD'],text=True).strip(),
        normal_engine_commit=ENGINE,platform=platform.platform(),
        policy='108 sweeps / 1296 fresh processes, main then one independently seeded confirmation; '
               '6 balanced AB/BA pairs each. All successful samples retained, including adverse cases/outliers. '
               'One immutable byte-cost rule; no tuning between phases. Edges control->hybrid, node->sparse, '
               'sparse->hybrid separate net result, payload/flat-map change, and conversion/state-check cost. '
               'No native/Gradle build or correctness run during timing. QQ adapter compilation is serial '
               'outside measured lifecycle; OS caches are not flushed. One/four calling threads are separate '
               'A/B cases; four threads execute four times the work. Instrumented migration time is excluded '
               'from timing claims; all physical peaks come from normal processes.',
        files={str(path):sha(path) for path in sorted(set(paths))},native_manifests=manifests,
        sweeps=[dict(item,command=command(item)) for item in plan])
    frozen_path.write_text(json.dumps(frozen,indent=2)+'\n')
    print('FROZEN',sha(frozen_path),'sweeps=108 fresh_processes=1296',flush=True)
    sys.exit(0)

frozen = json.loads(frozen_path.read_text())
assert frozen['sweeps'] == [dict(item,command=command(item)) for item in plan]
for path,expected in frozen['files'].items():
    assert sha(path) == expected, 'Frozen input changed: '+path
queue = OUT/'completed.json'
completed = json.loads(queue.read_text()) if queue.exists() else []
for item in frozen['sweeps']:
    name = item['name']
    if any(row['name'] == name for row in completed):
        assert (OUT/name/'summary.json').is_file()
        continue
    print('START '+name,flush=True)
    with (OUT/(name+'-launcher.log')).open('w') as log:
        subprocess.run(item['command'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
    summary = json.loads((OUT/name/'summary.json').read_text())
    value = summary['metrics']['lifecycle_ms']
    completed.append(dict(item,summary_sha256=sha(OUT/name/'summary.json')))
    queue.write_text(json.dumps(completed,indent=2)+'\n')
    print('DONE %s lifecycle=%+.2f%% %s (%d/108)' %
        (name,value['median_change_percent'],value['bootstrap95_percent'],len(completed)),flush=True)
for path,expected in frozen['files'].items():
    assert sha(path) == expected, 'Frozen input changed after measurement: '+path
print('COMPLETE 108 sweeps / 1296 fresh process samples',flush=True)
