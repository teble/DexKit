import hashlib
import json
from pathlib import Path

BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
E=BASE/'hybrid-descriptors-v1'
V=E/'validation'


def rows(path,prefix):
    return [json.loads(line[len(prefix):]) for line in path.read_text().splitlines() if line.startswith(prefix)]


def summarize(path):
    tables=[r for r in rows(path,'BENCH_HYBRID_DESCRIPTOR_TABLE ') if r['phase']=='pre_close']
    caches=[r for r in rows(path,'BENCH_HYBRID_DESCRIPTOR_CACHE ') if r['phase']=='pre_close']
    assert caches and len(tables)==64*len(caches)
    assert len({(r['dex'],r['shard'],r['kind']) for r in tables})==len(tables)
    sums={key:sum(r[key] for r in tables) for key in [
        'slots','records','bucket_bytes','dense_bytes','payload_owner_bytes','block_bytes','directory_bytes',
        'block_live','block_allocations','directory_live','directory_allocations',
        'char_bytes','char_buffers','sso_records','calls','hits','dense_hits','growths','promotions']}
    sums['fixed_bytes']=sum(r['fixed_bytes'] for r in caches)
    # Cache instrumentation already includes each used deque owner's allocator state.
    sums['instrumentation_bytes']=sum(r['instrumentation_bytes'] for r in caches)
    sums['method_records']=sum(r['records'] for r in tables if r['kind']=='method')
    sums['field_records']=sum(r['records'] for r in tables if r['kind']=='field')
    sums['active_domains']=sum(r['records']>0 for r in tables)
    sums['block_slack_bytes']=sums['block_bytes']-sums['records']*24
    assert sums['block_slack_bytes']>=0
    sums['requested_layout_bytes']=sum(sums[key] for key in ['fixed_bytes','bucket_bytes','dense_bytes',
        'payload_owner_bytes','block_bytes','directory_bytes','char_bytes'])
    assert sums['calls']-sums['hits']==sums['records']
    categories=[r for r in rows(path,'BENCH_CENSUS ') if r['phase']=='pre_close' and r.get('category')=='descriptors']
    assert len(categories)==1
    assert categories[0]['index_bytes']+categories[0]['payload_capacity_bytes']==sums['requested_layout_bytes']
    assert categories[0]['nonempty_or_ready']==sums['records']
    promotions=[r for r in tables if r['promotions']]
    for r in tables:
        assert r['records']==r['sso_records']+r['char_buffers']
        if r['promotions']:
            assert r['promotions']==1 and r['capacity']==r['bucket_bytes']==0
            assert r['dense_bytes']<=r['promotion_hash_bytes']
            assert r['promotion_overlap_bytes']==r['promotion_payload_bytes']+r['promotion_hash_bytes']+r['dense_bytes']
        else:
            assert r['dense_bytes']==0
        if r['records']==0:
            assert all(r[k]==0 for k in ['payload_owner_bytes','block_bytes','directory_bytes','bucket_bytes','dense_bytes'])
    sums['largest_single_domain_bucket_overlap']=max(r['largest_bucket_overlap'] for r in tables)
    sums['largest_partial_single_domain_conversion_overlap']=max(r['promotion_overlap_bytes'] for r in tables)
    sums['instrumented_conversion_ns_total']=sum(r['promotion_ns'] for r in tables)
    sums['instrumented_conversion_ns_max']=max(r['promotion_ns'] for r in tables)
    return dict(log=str(path),log_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),aggregate=sums,
                promotion_events=promotions,tables=tables)


cases={}
for label in ['sparse-trace','hybrid-trace']:
    short=label.removesuffix('-trace')
    cases.setdefault('qq',{})[short]=summarize(V/('verify-'+label+'-census-w4')/'run.log')
    for path in sorted(V.glob('census-'+label+'-*.log')):
        if path.name.endswith('-stderr.log'):
            continue
        case=path.stem.removeprefix('census-'+label+'-')
        cases.setdefault(case,{})[short]=summarize(path)
    for selected in [1,448,449,450]:
        case='boundary-'+str(selected)
        cases.setdefault(case,{})[short]=summarize(V/(case+'-'+label+'-stderr.log'))
for case,variants in cases.items():
    a,b=variants['sparse']['aggregate'],variants['hybrid']['aggregate']
    for key in ['slots','records','method_records','field_records','calls','hits','payload_owner_bytes',
                'char_bytes','char_buffers','sso_records','block_bytes','directory_bytes','block_allocations','directory_allocations']:
        assert a[key]==b[key],(case,key,a[key],b[key])
    assert a['promotions']==a['dense_bytes']==a['dense_hits']==0
    if case in ['qq','dense-output-sso-shard-k1','boundary-1','boundary-448']:
        assert b['promotions']==0,case
    if case in ['boundary-449','boundary-450']:
        assert b['promotions']==2 and b['bucket_bytes']==0
        assert all(r['promotion_records']==449 for r in variants['hybrid']['promotion_events'])
    if case=='dense-output-sso':
        assert b['promotions']==64 and b['records']==120000 and b['char_bytes']==b['bucket_bytes']==0
old_path=BASE/'memory-layout-v1/census-summary.json'
old=json.loads(old_path.read_text())
reference={}
for case in ['qq','dense']:
    data=old['cases'][case]
    reference[case]={}
    for label in ['control','combined']:
        record=data[label]
        reference[case][label]=record
result=dict(cases=cases,previous_reference=dict(path=str(old_path),sha256=hashlib.sha256(old_path.read_bytes()).hexdigest(),
    source_commit='05e5a411779758a3902b72409570a28d1a17e788',cases=reference),
    notes=['Requested block/directory capacity is observed in diagnostic allocator builds; object-only instrumentation is removed from the layout total.',
           'Cache instrumentation includes per-domain owner instrumentation already; never add table detail twice.',
           'Partial conversion overlap excludes the live triggering temporary, fixed cache and allocator overhead. It is not a physical peak.',
           'Instrumented conversion time excludes lock waiting, Cold build, payload append and triggering hash growth; it is not normal timing.',
           'The previous dense/node census is explicitly reused as a layout reference; these cache implementations and fixture content are unchanged.',
           'selected-count is per method and field domain; 449 triggers two conversions, one selects two total descriptors.'])
(E/'census-summary.json').write_text(json.dumps(result,indent=2)+'\n')
for case in ['qq','dense-output-sso','dense-output-sso-shard-k1','boundary-448','boundary-449','boundary-450']:
    print(case,{label:{k:item['aggregate'][k] for k in ['requested_layout_bytes','records','promotions','bucket_bytes','dense_bytes']}
                for label,item in cases[case].items()})
