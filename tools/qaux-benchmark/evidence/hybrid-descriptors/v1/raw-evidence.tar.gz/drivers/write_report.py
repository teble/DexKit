import json
from pathlib import Path

ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
E=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/hybrid-descriptors-v1')
x=json.loads((E/'summary.json').read_text())
cases=x['cases']


def pair(name,metric,interval=False):
    values=[]
    for phase in ['main','confirm']:
        record=cases[name][phase].get(metric)
        if record is None: return '--'
        value=f"{record['median_change_percent']:+.2f}%"
        if interval: value+=' ['+', '.join(f'{v:+.2f}' for v in record['bootstrap95_percent'])+']'
        values.append(value)
    return ' / '.join(values)


def med(name,metric,label,phase='main'):
    return cases[name][phase][metric]['variants'][label]['median']


lines=['# Hybrid descriptor cache: fixed-rule results','',
'Keep the hybrid as a conditional experiment. It preserves the measured QQ memory',
'advantage and reduces high-coverage hash/lock cost relative to the new sparse-only',
'cache. Full-coverage construction/close costs and residual text-lookup regressions',
'against the original dense array prevent enabling it by default. The sparse-only',
'variant remains an attribution control; its larger flat buckets and repeated',
'lookup costs do not support general adoption over the existing node cache.','',
'## Reproduction and scope','',
f"Engine: `{x['engine_commit']}`. Plan SHA256:",f"`{x['frozen_plan_sha256']}`.",'',
'All 108 planned sweeps and 1296 fresh processes completed, with no excluded',
'successful measurements, input changes, native builds or correctness runs during',
'measurement. Each case has six balanced AB/BA pairs in a main phase and six in',
'one independently seeded confirmation. Compiler, deployment target and all other',
'Small14 options were held fixed. Packed cross identities and packed field uses',
'were OFF. Both new descriptor flags remain OFF by default.','',
'Four builds are covered by three comparisons: old dense -> hybrid is the net',
'effect; node -> sparse isolates the new payload/flat-index route; sparse -> hybrid',
'isolates conversion and its state check. Separate pairs are not a shared',
'four-way sample: do not multiply their median deltas into an inferred comparison.','',
'Negative percentages favor the second build. Values below are main / confirmation.',
'Lifecycle includes create, setup, API work, result destruction and close; it is',
'not the sum of independently rounded stage medians. Repeated APIs are the whole',
'repeated group. One/four calling-thread cases perform different total work and',
'are compared independently. File caches were not flushed. Percentile bootstrap',
'intervals are exploratory per-case estimates, without a multiple-comparison',
'adjustment. All absolute medians, intervals and raw samples are preserved in the',
'[evidence summary](evidence/hybrid-descriptors/v1/summary.json).','',
'## Decision evidence','',
'- QQ peak footprint changes are -8.78% to -9.22% across the three workloads and',
'  two phases. Close is consistently lower. Several lifecycle/API intervals cross',
'  zero, so this is principally a measured memory benefit, not a broad speed claim.',
'- Full SSO output at 16 repeats improves by 24.03% / 28.10% against sparse-only;',
'  its physical peak falls by 10.06% / 10.30%. It remains 3.92% / 3.10% slower',
'  than old dense, with 4.55% / 3.73% higher physical peak. At two repeats the',
'  lifecycle increase is 7.97% / 7.50%, and first APIs are about 14.7% / 14.5%',
'  slower. The main two-repeat lifecycle interval crosses zero; confirmation does not.',
'- Wide text lookup improves by 64.04% / 62.66% against sparse-only, but still',
'  regresses 70.13% / 65.81% against old dense. Repeated APIs regress 92.38% /',
'  85.81%. Prefix lookup remains about 18.9% / 18.6% slower over the lifecycle.',
'- New sparse-only full SSO at 16 repeats regresses 8.55% / 5.78% against node,',
'  and its peak increases 3.30% / 5.03%. Fewer per-node frees do not compensate',
'  for the larger hash and repeated lookup cost in that case.',
'- Sparse prefix/scattered output can have slower first/repeated APIs even when',
'  reduced creation/close work improves the lifecycle. Do not describe the route',
'  as regression-free for sparse workloads.',
'- One member per domain never converts. Its 100000-repeat lifecycle changes',
'  are +2.82% / +2.89% against old dense; the main interval crosses zero and the',
'  confirmation interval is positive. Concurrent shared-hotspot results are much',
'  noisier: the one-thread main regression does not replicate at the same scale,',
'  and four-thread intervals span zero. These do not establish a general win.',
'- Immediate close at 448/449/450 members per domain preserves a large peak',
'  reduction against old dense, but isolated conversion latency is not free or',
'  reliably amortized. Several first/lifecycle intervals are wide. The long-output',
'  confirmation also has a large positive outlier; it is retained in the raw data.','',
'Close percentages need absolute scale. In the 16-repeat full SSO net comparison,',
f"old dense / hybrid close medians are {med('control-to-hybrid-dense-output-sso-r16','close_ms','control'):.3f} / {med('control-to-hybrid-dense-output-sso-r16','close_ms','hybrid'):.3f} ms in the main phase,",
f"and {med('control-to-hybrid-dense-output-sso-r16','close_ms','control','confirm'):.3f} / {med('control-to-hybrid-dense-output-sso-r16','close_ms','hybrid','confirm'):.3f} ms in confirmation. The percentage increase is real in this",
'fixture but is a small part of its roughly 140-150 ms complete lifecycle.','',
'## QQ paired results','',
'Lifecycle values include their 95% paired bootstrap interval in brackets.',
'Peak values are paired median percentage changes, with full intervals in JSON.','',
'| Comparison / workload | Lifecycle main / confirmation | Peak footprint main / confirmation |',
'| --- | --- | --- |']
for name in cases:
    if '-qq-' in name:
        lines.append(f"| {name} | {pair(name,'lifecycle_ms',True)} | {pair(name,'peak_footprint_bytes')} |")
lines+=['','## Native paired results','',
'First, repeated, close and peak columns give main / confirmation median changes.',
'A dash is an unmeasured/zero repeated interval, including the one-pass boundary',
'cases. Full CIs and absolute medians accompany every available metric in JSON.']
for edge in ['control-to-hybrid','node-to-sparse','sparse-to-hybrid']:
    lines+=['',f'### {edge}','',
        '| Workload | Lifecycle (95% interval) | First APIs | Repeated APIs | Close | Peak footprint |',
        '| --- | --- | --- | --- | --- | --- |']
    for name in cases:
        if not name.startswith(edge+'-') or '-qq-' in name: continue
        title=name.removeprefix(edge+'-')
        lines.append('| '+title+' | '+' | '.join(pair(name,metric,metric=='lifecycle_ms') for metric in
            ['lifecycle_ms','pass0_api_ms','repeated_api_ms','close_ms','peak_footprint_bytes'])+' |')
lines+=['','## Requested descriptor storage','',
'These are diagnostic requested capacities after removing object-only',
'instrumentation, not a division of normal physical footprint. The old dense/node',
'layout reference is explicitly reused from `05e5a41`; those cache types and the',
'fixtures are unchanged. Old dense includes its formerly omitted fixed owners.',
'The full-coverage reference has the same 120000 strings but a different access',
'count from the current workload. Only storage is compared here.','',
'| Workload | Old dense | Node | New sparse-only | Hybrid |',
'| --- | ---: | ---: | ---: | ---: |',
'| QQ (1628 methods, zero fields) | 135348661 B | 489457 B | 3970593 B | 3970593 B |',
'| Full SSO (60000 methods + 60000 fields) | 3962112 B | 6204440 B | 7607320 B | 4111896 B |','',
'QQ uses 835 deque owners and no dense domain. Its diagnostic blocks request',
'3406800 B, plus 6680 B in block directories, 40080 B in normal-size deque owners,',
'196369 B in external characters, 46784 B in hash buckets and 273880 B in fixed',
'cache objects. This trades more sparse storage than node for the hybrid route.','',
'Full SSO converts all 64 domains. Sparse buckets fall from 4455936 B to zero;',
'dense indexes request 960512 B. Both new variants retain the same 3133440 B of',
'string blocks, 8192 B in block directories and 3072 B of normal-size deque owners.',
'Block slack is 253440 B above the 120000 24-byte strings. There are no external',
'character allocations in this SSO fixture. Hybrid is still 149784 B larger than',
'the old dense layout; normal process peaks, including allocator effects, show a',
'larger difference than that requested-byte delta.','',
'Each 1875-slot host domain promotes at 449 entries: hash requests jump from',
'8696 B to 17400 B, crossing the 15008 B dense cost. The API boundary workload',
'selects the same count in both method and field domains. It observes zero',
'conversions at 448, exactly two at 449, and no further conversion at 450.',
'Sparse bucket capacity is zero after each conversion. Each one-member domain',
'stays sparse even after 100000 repeats.','',
'The [census summary](evidence/hybrid-descriptors/v1/census-summary.json) retains',
'every domain and transition record. Partial overlap excludes the still-live',
'Cold temporary, fixed cache and allocator overhead. Instrumented conversion',
'duration excludes waiting, string construction, deque append and hash growth.',
'Neither is a normal trigger-API or whole-process measurement. See the complete',
'[source review](HYBRID-DESCRIPTORS-REVIEW.md) for all accounting limits.','',
'## Validation and next bounded increment','',
'198 native driver commands, 56 normal workload smoke runs and 11 QQ checks',
'passed their expected results. The required Core/JAR/JVM/AAR Gradle tasks',
'passed, with 71 JVM tests (zero skipped) and four Android ABI libraries. Host',
'ASan/UBSan ran with leak detection disabled. Android runtime/performance was',
'not measured. The five ABI normal/diagnostic layout probes matched. Full source',
'review covered the fixed increment and found no concrete publication/ownership',
'blocker; its reporting limits were adopted.','',
'The remaining wide-lookup regression justified reading the existing generated',
'code. The old dense getter is frameless; the hybrid getter unconditionally',
'creates a 32-byte frame and stores the construction callback captures even for',
'a dense hit. This is an observed cost, not proof that it explains the entire',
'regression. A separate follow-up will put the existing fast-hit check before',
'callback materialization, preserve the current layout/threshold/publication,',
'and compare the changed entry against these fixed artifacts. This batch is',
'complete and will not be retuned.','',
'Raw logs, ordered-byte fixture oracles, commands, manifests, source exports,',
'ABI probes and integrity hashes are in the',
'[evidence manifest](evidence/hybrid-descriptors/v1/manifest.json). APKs and',
'compiled artifacts are omitted; their identities are retained.','']
(ROOT/'tools/qaux-benchmark/HYBRID-DESCRIPTORS-RESULTS.md').write_text('\n'.join(lines))
print('Wrote',len(lines),'report lines')
