#!/usr/bin/env python3
"""Archive the completed batch comparison and post-review checker extension."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
DATA=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/next-round')
OUT=ROOT/'tools/qaux-benchmark/evidence/next-round/batch-containment'
OUT.mkdir(parents=True,exist_ok=True)
assert not any(OUT.iterdir())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
files={}
def add(path,name):
 assert path.is_file() and name not in files,(path,name)
 files[name]=path
summary=json.loads((DATA/'formal/batch-summary-v2.json').read_text())
assert summary['sweeps']==10 and summary['samples']==120
shutil.copyfile(DATA/'formal/batch-summary-v2.json',OUT/'summary.json')
shutil.copyfile(DATA/'formal/batch-trace-summary-v1.json',OUT/'trace-summary.json')
for path in sorted((DATA/'formal').iterdir()):
 if 'batch' not in path.name: continue
 for file in sorted(path.rglob('*')) if path.is_dir() else [path]:
  if file.is_file() and file.suffix not in ('.class','.aar','.dylib'):
   add(file,str(file.relative_to(DATA)))
for path in sorted((DATA/'artifacts').glob('batch-*')):
 if (path/'artifact.json').is_file():
  manifest=json.loads((path/'artifact.json').read_text())
  assert manifest['native_sha256']==sha(path/'libdexkit.dylib')
 for name in ['artifact.json','CMakeCache.txt','source.patch','build.log']:
  if (path/name).is_file(): add(path/name,str((path/name).relative_to(DATA)))
for name in ['batch-overlap-v1','batch-miss-v1','strings-correctness-v1','strings-correctness-wide-v1']:
 for file in sorted((DATA/'fixtures'/name).iterdir()):
  if file.is_file(): add(file,str(file.relative_to(DATA)))
for name in ['batch_build_queue.py','batch_trace_queue.py','batch_measure_queue.py','rebuild_batch_checkers.py','summarize_batch.py','archive_batch.py']:
 add(DATA/name,name)
for revision,directory in [('a997da6eacb879cf9c4407adfe24073f19d73d01','measurement-source'),('33c1ee0','extended-check-source')]:
 names=['batch_queries.h','batch_checks.cpp','validate_batch_checks.py','string_queries.h']
 if directory=='measurement-source': names+=['batch_workload.cpp','make_batch_fixture.py','make_string_fixture.py','make_symbol_fixture.py','validate_string_checks.py','build_native.py','run.py','sweep.py','workload_sweep.py','force_tests.gradle']
 for name in names:
  target=DATA/'archive-batch-sources'/directory/name
  target.parent.mkdir(parents=True,exist_ok=True)
  target.write_bytes(subprocess.check_output(['git','-C',str(ROOT),'show',revision+':tools/qaux-benchmark/'+name]))
  add(target,directory+'/'+name)
archive=OUT/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name,path in sorted(files.items()): tar.add(path,arcname=name,recursive=False)
manifest={'archive_sha256':sha(archive),'files':{name:sha(path) for name,path in sorted(files.items())},
 'summary_sha256':sha(OUT/'summary.json'),'trace_summary_sha256':sha(OUT/'trace-summary.json'),
 'scope':'All ten sweeps and 120 samples, native/QQ diagnostics, frozen verification, initial and extended oracles, standalone/ASan/UBSan, JVM/ABI build records, failed initial checker build logs, synthetic inputs and reproduction scripts. Measured source a997da6 and extended checker source 33c1ee0 are separately retained. Proprietary QQ APK, compiled classes, native archives/libraries/executables and AAR binaries are omitted; hashes and commands are retained.'}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive,'r:gz') as tar:
 assert set(tar.getnames())==set(files)
 for member in tar:
  assert hashlib.sha256(tar.extractfile(member).read()).hexdigest()==manifest['files'][member.name]
print(json.dumps({'files':len(files),'bytes':archive.stat().st_size,'sha256':manifest['archive_sha256'],'sweeps':summary['sweeps'],'samples':summary['samples']}))
