#!/usr/bin/env python3
import concurrent.futures
import json
from pathlib import Path
import subprocess
import sys
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
DATA=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/next-round')
JDK='/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home'
NINE=['LAZY_DIRECTORIES','COMPACT_STRINGS','NEGATIVE_STRINGS','STRUCTURAL_DESCRIPTORS','DESCRIPTOR_FAST_HITS','RAW_INTERFACES','FIELD_IDENTITY_SPLIT','COMPACT_INVOKES','SINGLE_RELATION']
phase=sys.argv[1]
assert phase in ('normal','extra')
variants=[('batch-control-v2',False,False,False,False),('batch-includes-v2',True,False,False,False)] if phase=='normal' else [
 ('batch-control-trace-v1',False,True,False,False),('batch-includes-trace-v1',True,True,False,False),
 ('batch-includes-sanitized-v1',True,False,True,False),('batch-includes-standalone-v1',True,False,False,True)]
def run(spec):
 name,candidate,trace,sanitize,standalone=spec
 command=['python3','tools/qaux-benchmark/build_native.py','--source-root',str(ROOT),'--output',str(DATA/'artifacts'/name),'--java-home',JDK,'--jobs','3']
 definitions=['DEXKIT_BENCHMARK_BATCH_WORKLOAD=ON']
 if not standalone: definitions += ['DEXKIT_EXPERIMENT_'+n+'=ON' for n in NINE]
 if candidate: definitions += ['DEXKIT_EXPERIMENT_BATCH_STRING_INCLUDES=ON']
 if trace: definitions += ['DEXKIT_BENCHMARK_BATCH_TRACE=ON']
 if sanitize:
  flags='-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer'
  definitions += ['CMAKE_C_FLAGS_RELEASE='+flags,'CMAKE_CXX_FLAGS_RELEASE='+flags,
                  'CMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined','CMAKE_SHARED_LINKER_FLAGS=-fsanitize=address,undefined']
 for definition in definitions: command += ['--define',definition]
 print('START '+name,flush=True)
 log=DATA/'formal'/(name+'-build-launcher.log')
 with log.open('w') as out: subprocess.run(command,cwd=ROOT,stdout=out,stderr=subprocess.STDOUT,check=True)
 print('DONE '+name,flush=True)
 return {'name':name,'command':command}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 records=list(pool.map(run,variants))
(DATA/'formal'/('batch-build-'+phase+'-queue.json')).write_text(json.dumps(records,indent=2)+'\n')
