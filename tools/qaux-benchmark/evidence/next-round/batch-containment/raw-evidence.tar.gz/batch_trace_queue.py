#!/usr/bin/env python3
import json
from pathlib import Path
import re
import subprocess
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
DATA=BASE/'next-round'
records=[]
for label in ['control','includes']:
 artifact=DATA/'artifacts'/('batch-'+label+'-trace-v1')
 destination=DATA/'formal'/('batch-'+label+'-trace-v1')
 destination.mkdir()
 for fixture,mode,expected in [('batch-overlap-v1','batch-method',36000),('batch-overlap-v1','batch-class',3600),('batch-miss-v1','batch-method',0)]:
  command=[str(artifact/'build/Core/dexkit_batch_workload'),str(DATA/'fixtures'/fixture/'batch.apk'),mode,'2']
  log=destination/(fixture+'-'+mode+'.log')
  with log.open('w') as out: subprocess.run(command,cwd=ROOT,stdout=out,stderr=subprocess.STDOUT,check=True)
  output=log.read_text()
  report=json.loads(re.search(r'^WORKLOAD (.+)$',output,re.M)[1])
  assert report['returned']==expected
  rows=[json.loads(line) for line in re.findall(r'^BENCH_BATCH_GROUP (.+)$',output,re.M)]
  assert len(rows)==12
  totals={key:sum(row[key] for row in rows) for key in rows[0] if key not in ('query','dex','classes')}
  records.append({'label':label,'fixture':fixture,'mode':mode,'command':command,'returned':report['returned'],'totals':totals,'rows':rows})
  print(label,fixture,mode,totals,flush=True)
 command=['python3','tools/qaux-benchmark/run.py','--dexkit-root',str(ROOT),'--corpus',str(BASE/'qaux-extracted'),'--apk',str(BASE/'qq-9.3.55.apk'),
  '--java-home','/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home','--memory-probe',str(BASE/'artifacts/probe-v2/libqauxbench_probe.dylib'),
  '--output',str(DATA/'formal'/('verify-batch-'+label+'-trace-v1')),'--native-library',str(artifact/'libdexkit.dylib'),'--passes','2','--threads','4','--profile','all','--mode','verify']
 print('START QQ trace '+label,flush=True)
 with (destination/'qq-launcher.log').open('w') as out: subprocess.run(command,cwd=ROOT,stdout=out,stderr=subprocess.STDOUT,check=True)
 records.append({'label':label,'fixture':'QQ','command':command})
 print('DONE QQ trace '+label,flush=True)
(DATA/'formal/batch-trace-records-v1.json').write_text(json.dumps(records,indent=2)+'\n')
