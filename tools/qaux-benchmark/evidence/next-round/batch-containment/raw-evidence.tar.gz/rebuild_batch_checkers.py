#!/usr/bin/env python3
"""Link extended correctness inputs against immutable, unchanged core archives."""
import concurrent.futures
import hashlib
import json
from pathlib import Path
import shlex
import shutil
import subprocess
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
DATA=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/next-round')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git','-C',str(ROOT),*args],text=True).strip()
commit=git('rev-parse','HEAD')
sources=[ROOT/'tools/qaux-benchmark'/name for name in ['batch_checks.cpp','batch_queries.h','string_queries.h']]
source_hashes={str(p.relative_to(ROOT)):sha(p) for p in sources}
def build(spec):
 label,original=spec
 native=DATA/'artifacts'/original
 output=DATA/'artifacts'/('batch-'+label+'-checks-v3')
 assert not output.exists()
 manifest=json.loads((native/'artifact.json').read_text())
 assert manifest['native_sha256']==sha(native/'libdexkit.dylib')
 paths=list(manifest['source_trees'])
 assert not git('diff','HEAD','--',*paths)
 assert not git('ls-files','--others','--exclude-standard','--',*paths)
 assert all(git('rev-parse','HEAD:'+path)==tree for path,tree in manifest['source_trees'].items())
 assert not (native/'source.patch').read_text().strip()
 settings={}
 for line in (native/'CMakeCache.txt').read_text().splitlines():
  if '=' in line and not line.startswith(('#','//')):
   key,value=line.split('=',1); settings[key.split(':')[0]]=value
 archive=native/'build/Core/libdexkit_static.a'
 archive_hash=sha(archive)
 executable=output/'build/Core/dexkit_batch_checks'
 executable.parent.mkdir(parents=True)
 command=[settings['CMAKE_CXX_COMPILER'],'-std=c++20','-arch','arm64','-pthread']
 command+=shlex.split(settings['CMAKE_CXX_FLAGS'])+shlex.split(settings['CMAKE_CXX_FLAGS_RELEASE'])
 for name,value in sorted(settings.items()):
  if name.startswith('DEXKIT_EXPERIMENT_') or name in ['DEXKIT_BENCHMARK_DIAGNOSTICS','DEXKIT_BENCHMARK_STRING_TRACE','DEXKIT_BENCHMARK_BATCH_TRACE','DEXKIT_ENABLE_INTERNAL_METRICS']:
   command+=['-D'+name+'='+{'ON':'1','OFF':'0','TRUE':'1','FALSE':'0'}.get(value.upper(),value)]
 for directory in ['dexkit/include','third_party/slicer/export','third_party/thread_helper','third_party/aho_corasick_trie','third_party/parallel_hashmap','third_party/flatbuffers/include']:
  command+=['-I',str(ROOT/'Core'/directory)]
 command += [str(sources[0]),str(archive),'-lz','-o',str(executable)]
 command += shlex.split(settings.get('CMAKE_EXE_LINKER_FLAGS',''))
 with (output/'build.log').open('w') as log: subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
 assert git('rev-parse','HEAD')==commit and sha(archive)==archive_hash
 assert all(sha(ROOT/path)==digest for path,digest in source_hashes.items())
 for name in ['libdexkit.dylib','CMakeCache.txt','source.patch']: shutil.copyfile(native/name,output/name)
 manifest['checker']={'source_commit':commit,'source_sha256':source_hashes,'core_artifact':str(native),'core_archive_sha256':archive_hash,
  'executable_sha256':sha(executable),'command':command,'scope':'Only the checker is relinked; measured native library and static core archive are unchanged.'}
 (output/'artifact.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print(label,manifest['native_sha256'],manifest['checker']['executable_sha256'],flush=True)
 return {'label':label,'artifact':str(output),'source_commit':commit}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 results=list(pool.map(build,[('control','batch-control-v2'),('includes','batch-includes-v2'),('standalone','batch-includes-standalone-v1'),('sanitized','batch-includes-sanitized-v1')]))
(DATA/'formal/batch-checker-builds-v3.json').write_text(json.dumps(results,indent=2)+'\n')
