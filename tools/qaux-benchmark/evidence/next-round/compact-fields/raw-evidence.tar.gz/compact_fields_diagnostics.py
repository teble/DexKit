#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
import re
import subprocess
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
DATA=BASE/'next-round'
records=[]
def parse(label,name,path,command):
 output=path.read_text()
 rows=[json.loads(s) for s in re.findall(r'^BENCH_CENSUS (.+)$',output,re.M)]
 rows=[r for r in rows if r.get('phase')=='pre_close' and r.get('category') in ['using_fields','field_readers','field_writers']]
 growth=[json.loads(s) for s in re.findall(r'^BENCH_FIELD_GROWTH (.+)$',output,re.M)]
 growth=[r for r in growth if r.get('phase')=='pre_close']
 work=re.findall(r'^WORKLOAD (.+)$',output,re.M)
 record=dict(label=label,name=name,command=list(map(str,command)),log_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),census=rows,growth=growth)
 if work: record['workload']=json.loads(work[0])
 assert len(rows)==3
 records.append(record)
 print(label,name,rows,flush=True)
for label in ['control','compact']:
 artifact=DATA/'artifacts'/('compact-fields-'+label+'-trace-v1')
 destination=DATA/'formal'/('compact-fields-'+label+'-diagnostics-v1'); destination.mkdir()
 for fixture,mode in [('long','using-early'),('short','using-early'),('long','using-output'),('field-adverse','field-late'),('field-adverse','field-full-first')]:
  using=mode.startswith('using-')
  executable=artifact/'build/Core'/('dexkit_field_workload' if using else 'dexkit_relation_workload')
  apk=DATA/'fixtures'/('field-'+fixture+'-v1')/'fields.apk' if using else BASE/'followup/fixtures'/fixture/'relations.apk'
  command=[executable,apk,mode,'2']; path=destination/(fixture+'-'+mode+'.log')
  with path.open('w') as out: subprocess.run(list(map(str,command)),cwd=ROOT,stdout=out,stderr=subprocess.STDOUT,check=True)
  parse(label,fixture+'-'+mode,path,command)
 name='verify-compact-fields-tail-'+label+'-trace-v1'
 command=['python3','tools/qaux-benchmark/run.py','--dexkit-root',ROOT,'--corpus',BASE/'qaux-extracted','--apk',BASE/'qq-9.3.55.apk',
  '--java-home','/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home','--memory-probe',BASE/'artifacts/probe-v2/libqauxbench_probe.dylib',
  '--output',DATA/'formal'/name,'--native-library',artifact/'libdexkit.dylib','--passes','1','--threads','4','--profile','all','--mode','verify',
  '--final-field-rw','Lcom/tencent/mobileqq/data/MessageRecord;->msg:Ljava/lang/String;',
  '--field-rw-expected',BASE/'followup/formal/field-tail-oracle-best5/field-rw-expected.json']
 print('START '+name,flush=True)
 with (destination/'qq-launcher.log').open('w') as out: subprocess.run(list(map(str,command)),cwd=ROOT,stdout=out,stderr=subprocess.STDOUT,check=True)
 metadata=json.loads((DATA/'formal'/name/'run-metadata.json').read_text())
 assert metadata['exit_code']==0 and metadata['baseline_results_equal'] and metadata['final_field_rw_results_equal']
 parse(label,'QQ-tail',DATA/'formal'/name/'run.log',command)
for name in {r['name'] for r in records}:
 a,b=[r for r in records if r['name']==name]
 if 'workload' in a:
  for key in ['mode','repeats','returned','checksum']: assert a['workload'][key]==b['workload'][key]
 # This experiment only changes forward storage; final reverse rows agree.
 assert [r for r in a['census'] if r['category']!='using_fields']==[r for r in b['census'] if r['category']!='using_fields']
(DATA/'formal/compact-fields-diagnostics-v1.json').write_text(json.dumps(records,indent=2)+'\n')
