#!/usr/bin/env python3
import hashlib
import json
import os
from pathlib import Path
import subprocess
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
DATA=BASE/'next-round'
env=os.environ.copy(); env['ASAN_OPTIONS']='detect_leaks=0'; env['UBSAN_OPTIONS']='halt_on_error=1'
for fixture,labels in [('small',['control-v1','compact-v1','control-trace-v1','compact-trace-v1','compact-standalone-v1','compact-sanitized-v1']),('long',['control-v1','compact-standalone-v1','compact-sanitized-v1']),('unresolved',['control-v1','compact-v1','compact-standalone-v1','compact-sanitized-v1'])]:
 name='compact-fields-'+fixture+'-extra-validation-v1'
 command=['python3','tools/qaux-benchmark/validate_field_checks.py','--fixture',DATA/'fixtures'/('field-'+fixture+'-v1'),'--output',DATA/'formal'/name]
 for label in labels: command+=['--variant',label,DATA/'artifacts'/('compact-fields-'+label)]
 print('START '+name,flush=True)
 with (DATA/'formal'/(name+'-launcher.log')).open('w') as out: subprocess.run(list(map(str,command)),cwd=ROOT,env=env,stdout=out,stderr=subprocess.STDOUT,check=True)
 print('DONE '+name,flush=True)
records=[]
for fixture in ['relations','field-adverse']:
 baseline=None
 for label in ['control-trace-v1','compact-trace-v1','compact-sanitized-v1']:
  name='compact-fields-'+label+'-'+fixture
  artifact=DATA/'artifacts'/('compact-fields-'+label)
  executable=artifact/'build/Core/dexkit_relation_checks'
  command=[str(executable),'--dump',str(BASE/'followup/fixtures'/fixture/'relations.apk')]
  print('START '+name,flush=True)
  with (DATA/'formal'/(name+'.bin')).open('wb') as out,(DATA/'formal'/(name+'.stderr')).open('wb') as err:
   subprocess.run(command,cwd=ROOT,env=env,stdout=out,stderr=err,timeout=300,check=True)
  result=(DATA/'formal'/(name+'.bin')).read_bytes(); assert result
  if baseline is None: baseline=result
  assert result==baseline
  records.append(dict(name=name,command=command,sha256=hashlib.sha256(result).hexdigest(),executable_sha256=hashlib.sha256(executable.read_bytes()).hexdigest(),passed=True))
  print('DONE '+name,flush=True)
(DATA/'formal/compact-fields-relations-validation-v1.json').write_text(json.dumps(records,indent=2)+'\n')
