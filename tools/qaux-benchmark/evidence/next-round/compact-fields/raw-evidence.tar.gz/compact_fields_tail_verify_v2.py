#!/usr/bin/env python3
import json
from pathlib import Path
import subprocess
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
DATA=BASE/'next-round'
JDK='/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home'
records=[]
def run(name, command):
 command=list(map(str,command)); print('START '+name,flush=True)
 with (DATA/'formal'/(name+'-launcher.log')).open('w') as output:
  subprocess.run(command,cwd=ROOT,stdout=output,stderr=subprocess.STDOUT,check=True)
 records.append({'name':name,'command':command})
 (DATA/'formal'/'compact-fields-tail-validation-queue-v2.json').write_text(json.dumps(records,indent=2)+'\n')
 print('DONE '+name,flush=True)
for label in ['control','compact']:
 name='verify-compact-fields-tail-'+label+'-v2'
 command=['python3','tools/qaux-benchmark/run.py','--dexkit-root',ROOT,'--corpus',BASE/'qaux-extracted','--apk',BASE/'qq-9.3.55.apk',
  '--java-home',JDK,'--memory-probe',BASE/'artifacts/probe-v2/libqauxbench_probe.dylib','--output',DATA/'formal'/name,
  '--native-library',DATA/'artifacts'/('compact-fields-'+label+'-v1')/'libdexkit.dylib','--passes','11','--threads','4','--profile','all','--mode','verify','--final-field-rw','Lcom/tencent/mobileqq/data/MessageRecord;->msg:Ljava/lang/String;',
  '--field-rw-expected',BASE/'followup/formal/field-tail-oracle-best5/field-rw-expected.json']
 run(name,command)
