#!/usr/bin/env python3
import json
from pathlib import Path
import sys
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
DATA=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/next-round')
sys.path.insert(0,str(ROOT/'tools/qaux-benchmark'))
from sweep import summarize
summaries={}; total=0; stages={}
for phase in ['main','confirm']:
 queue=json.loads((DATA/'formal'/('compact-fields-'+phase+'-queue.json')).read_text())
 assert len(queue)==11
 for run in queue:
  path=DATA/'formal'/run['name']
  result=json.loads((path/'summary.json').read_text())
  rows=json.loads((path/'samples.json').read_text())
  assert len(rows)==12 and result['pairs']==6
  assert {(row['pair'],row['label']) for row in rows}=={(p,label) for p in range(6) for label in ['control','compact']}
  total+=len(rows); summaries[run['name']]=result['metrics']
 for tail,passes in [(False,1),(False,11),(True,11)]:
  name='compact-fields-qq-'+('tail-' if tail else '')+phase+'-p'+str(passes)
  path=DATA/'formal'/name
  rows=json.loads((path/'samples.json').read_text())
  result=json.loads((path/'summary.json').read_text())
  measurements=[]; metrics=[]
  for row in rows:
   report=json.loads((path/('pair-%02d-%s'%(row['pair'],row['label']))/'report.json').read_text())
   measured={'pair':row['pair'],'label':row['label'],'position':row['position']}
   for stage in ['optional_has_info']:
    selected=[v for v in report['stages'] if v['stage']==stage]
    assert len(selected)==passes and {v['pass'] for v in selected}==set(range(passes))
    selected.sort(key=lambda v:v['pass'])
    measured['first_'+stage+'_ms']=selected[0]['api_ns']/1e6
    if passes>1: measured['mean_repeated_'+stage+'_ms']=sum(v['api_ns'] for v in selected[1:])/(passes-1)/1e6
   measurements.append(measured)
  metrics=[key for key in measurements[0] if key.endswith('_ms')]
  stages[name]={'notes':'Native+JNI complete query APIs as recorded by the unmodified adapter. Repeated values are each process mean over passes 2..11; then use paired median changes and exploratory bootstrap intervals.',
   'rows':measurements,'metrics':summarize(measurements,['control','compact'],6,result['seed']+333,metrics)}
assert len(summaries)==22 and total==264
output={'sweeps':len(summaries),'samples':total,'metrics':summaries,'qq_stages':stages}
(DATA/'formal/compact-fields-summary-v1.json').write_text(json.dumps(output,indent=2)+'\n')
for name,values in summaries.items():
 print(name)
 for key in ['lifecycle_ms','pass0_api_ms','repeated_api_ms','positive_ms','negative_ms','peak_footprint_bytes','final_field_rw_ms','reverse_first_ms']:
  if key in values:
   v=values[key]; print(key,round(v['median_change_percent'],2),[round(x,2) for x in v['bootstrap95_percent']])
for name,record in stages.items():
 print(name,'STAGES')
 for key,v in record['metrics'].items():
  print(key,round(v['median_change_percent'],2),[round(x,2) for x in v['bootstrap95_percent']],{k:round(z['median'],3) for k,z in v['variants'].items()})
