#!/usr/bin/env python3
"""Archive the completed deferred RW walk comparison."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
DATA=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/next-round')
OUT=ROOT/'tools/qaux-benchmark/evidence/next-round/rw-walk'
OUT.mkdir(parents=True,exist_ok=True)
assert not any(OUT.iterdir())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
files={}
def add(path,name):
 assert path.is_file() and name not in files,(path,name)
 files[name]=path
summary=json.loads((DATA/'formal/rw-walk-summary-v1.json').read_text())
assert summary['sweeps']==14 and summary['samples']==168
shutil.copyfile(DATA/'formal/rw-walk-summary-v1.json',OUT/'summary.json')
shutil.copyfile(DATA/'formal/rw-walk-diagnostics-v1.json',OUT/'diagnostics-summary.json')
for path in sorted((DATA/'formal').iterdir()):
 if 'rw-walk' not in path.name: continue
 for file in sorted(path.rglob('*')) if path.is_dir() else [path]:
  if file.is_file() and file.suffix not in ('.class','.aar','.dylib'):
   add(file,str(file.relative_to(DATA)))
for path in sorted((DATA/'artifacts').glob('rw-walk-*')):
 if (path/'artifact.json').is_file():
  manifest=json.loads((path/'artifact.json').read_text())
  assert manifest['native_sha256']==sha(path/'libdexkit.dylib')
 for name in ['artifact.json','CMakeCache.txt','source.patch','build.log']:
  if (path/name).is_file(): add(path/name,str((path/name).relative_to(DATA)))
for name in ['field-small-v1','field-short-v1','field-long-v1','field-unresolved-v1']:
 for file in sorted((DATA/'fixtures'/name).iterdir()):
  if file.is_file(): add(file,str(file.relative_to(DATA)))
for name in ['rw_walk_build_queue.py','rw_walk_validate_queue.py','rw_walk_extra_validate.py','rw_walk_gradle.py','rw_walk_tail_verify.py','rw_walk_diagnostics.py','rw_walk_relation_assertions.py','rw_walk_measure_queue.py','summarize_rw_walk.py','archive_rw_walk.py']:
 add(DATA/name,name)
for fixture in ['relations','field-adverse']:
 for file in sorted((DATA.parent/'followup/fixtures'/fixture).iterdir()):
  if file.is_file(): add(file,'relation-fixtures/'+fixture+'/'+file.name)
revision='b57b687afa84bf3315b84204a2d49e3c84ec1dc1'
for name in ['make_field_fixture.py','validate_field_checks.py','field_queries.h','field_checks.cpp','field_workload.cpp','make_symbol_fixture.py','make_relation_fixture.py','relation_checks.cpp','relation_workload.cpp','validate_string_checks.py','build_native.py','run.py','sweep.py','workload_sweep.py','force_tests.gradle']:
 target=DATA/'archive-rw-walk-sources'/name
 target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(subprocess.check_output(['git','-C',str(ROOT),'show',revision+':tools/qaux-benchmark/'+name]))
 add(target,'measurement-source/'+name)
add(DATA.parent/'followup/formal/field-tail-oracle-best5/field-rw-expected.json','field-rw-expected.json')
archive=OUT/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name,path in sorted(files.items()): tar.add(path,arcname=name,recursive=False)
manifest={'archive_sha256':sha(archive),'files':{name:sha(path) for name,path in sorted(files.items())},
 'summary_sha256':sha(OUT/'summary.json'),'diagnostics_summary_sha256':sha(OUT/'diagnostics-summary.json'),
 'scope':'All 14 sweeps and 168 samples, actual instruction-walk diagnostics, eleven-round frozen QQ verification with/without real final RW, independent ordered field/getter and seven-schedule relation checks, strengthened readiness assertions linked to unchanged Core archives after timing, standalone/ASan/UBSan, JVM/four-ABI records, four synthetic field fixtures and relation fixtures, reproduction scripts. Fixed measurement source is b57b687. Proprietary QQ APK, classes, native libraries/archives/executables and AAR binaries are omitted; identities and commands remain recorded.'}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive,'r:gz') as tar:
 assert set(tar.getnames())==set(files)
 for member in tar:
  assert hashlib.sha256(tar.extractfile(member).read()).hexdigest()==manifest['files'][member.name]
print(json.dumps({'files':len(files),'bytes':archive.stat().st_size,'sha256':manifest['archive_sha256'],'sweeps':summary['sweeps'],'samples':summary['samples']}))
