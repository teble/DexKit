#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
import re
import subprocess
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
DATA=BASE/'next-round'
records=[]
def parse(label,name,path,command):
 output=path.read_text()
 census=[json.loads(s) for s in re.findall(r'^BENCH_CENSUS (.+)$',output,re.M)]
 census=[r for r in census if r.get('phase')=='pre_close' and r.get('category') in ['using_fields','field_readers','field_writers']]
 walks=[json.loads(s) for s in re.findall(r'^BENCH_INSTRUCTION_WALK (.+)$',output,re.M)]
 work=re.findall(r'^WORKLOAD (.+)$',output,re.M)
 totals={}
 for eligible in [True,False]:
  selected=[r for r in walks if r['rw_only']==eligible]
  totals['eligible' if eligible else 'mixed']=dict(calls=len(selected),methods=sum(r['methods'] for r in selected),instructions=sum(r['instructions'] for r in selected))
  if eligible:
   if label=='skip': assert all(not r['walk'] and r['methods']==0 and r['instructions']==0 for r in selected)
   else: assert all(r['walk'] for r in selected)
  else: assert all(r['walk'] for r in selected)
 record=dict(label=label,name=name,command=list(map(str,command)),log_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),census=census,walks=walks,totals=totals)
 if work: record['workload']=json.loads(work[0])
 assert len(census)==3
 records.append(record)
 print(label,name,totals,flush=True)
for label in ['control','skip']:
 artifact=DATA/'artifacts'/('rw-walk-'+label+'-trace-v1')
 destination=DATA/'formal'/('rw-walk-'+label+'-diagnostics-v1'); destination.mkdir()
 for mode in ['field-forward','field-late','field-full-first']:
  command=[artifact/'build/Core/dexkit_relation_workload',BASE/'followup/fixtures/field-adverse/relations.apk',mode,'2']
  path=destination/(mode+'.log')
  with path.open('w') as out: subprocess.run(list(map(str,command)),cwd=ROOT,stdout=out,stderr=subprocess.STDOUT,check=True)
  parse(label,mode,path,command)
 name='verify-rw-walk-tail-'+label+'-trace-v1'
 command=['python3','tools/qaux-benchmark/run.py','--dexkit-root',ROOT,'--corpus',BASE/'qaux-extracted','--apk',BASE/'qq-9.3.55.apk',
  '--java-home','/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home','--memory-probe',BASE/'artifacts/probe-v2/libqauxbench_probe.dylib',
  '--output',DATA/'formal'/name,'--native-library',artifact/'libdexkit.dylib','--passes','1','--threads','4','--profile','all','--mode','verify',
  '--final-field-rw','Lcom/tencent/mobileqq/data/MessageRecord;->msg:Ljava/lang/String;',
  '--field-rw-expected',BASE/'followup/formal/field-tail-oracle-best5/field-rw-expected.json']
 print('START '+name,flush=True)
 with (destination/'qq-launcher.log').open('w') as out: subprocess.run(list(map(str,command)),cwd=ROOT,stdout=out,stderr=subprocess.STDOUT,check=True)
 metadata=json.loads((DATA/'formal'/name/'run-metadata.json').read_text())
 assert metadata['exit_code']==0 and metadata['baseline_results_equal'] and metadata['final_field_rw_results_equal']
 parse(label,'QQ-tail',DATA/'formal'/name/'run.log',command)
for name in {r['name'] for r in records}:
 a,b=[r for r in records if r['name']==name]
 if 'workload' in a:
  for key in ['mode','repeats','returned','checksum']: assert a['workload'][key]==b['workload'][key]
 assert a['census']==b['census']
 for eligible in [True,False]:
  key=lambda r:(r['dex'],r['flags'],r['rw_only'])
  ar=sorted((r for r in a['walks'] if r['rw_only']==eligible),key=key)
  br=sorted((r for r in b['walks'] if r['rw_only']==eligible),key=key)
  assert [key(r) for r in ar]==[key(r) for r in br]
  if not eligible: assert ar==br
 if name in ['field-late','QQ-tail']:
  assert a['totals']['eligible']['instructions']>0 and b['totals']['eligible']['instructions']==0
 if name=='field-full-first': assert a['totals']['mixed']['instructions']>0
(DATA/'formal/rw-walk-diagnostics-v1.json').write_text(json.dumps(records,indent=2)+'\n')
