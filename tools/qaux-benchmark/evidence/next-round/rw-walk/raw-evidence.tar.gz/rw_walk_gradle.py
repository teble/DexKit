#!/usr/bin/env python3
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
OUT=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/next-round/formal/gradle-rw-walk-v1')
OUT.mkdir()
env=os.environ.copy()
env['JAVA_HOME']='/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home'
env['ANDROID_HOME']=env['ANDROID_SDK_ROOT']='/Users/teble/Library/Android/sdk'
command=['bash','./gradlew',':dexkit:cmakeBuild',':dexkit:jar',':dexkit:test',':dexkit-android:assembleRelease','--max-workers=3','-I','tools/qaux-benchmark/force_tests.gradle']
properties=['LazyDirectories','CompactStrings','NegativeStrings','StructuralDescriptors','DescriptorFastHits','RawInterfaces','FieldIdentitySplit','CompactInvokes','SingleRelation','SkipRwWalk']
command+=['-Pexperiment'+p+'=ON' for p in properties]
print('START JVM and Android validation',flush=True)
with (OUT/'build.log').open('w') as log: subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
tests=[]
for source in sorted((ROOT/'dexkit/build/test-results/test').glob('TEST-*.xml')):
 shutil.copyfile(source,OUT/source.name)
 item=ET.parse(source).getroot(); tests.append(dict(item.attrib))
assert tests and all(int(t['failures'])==0 and int(t['errors'])==0 for t in tests)
aars=list((ROOT/'dexkit-android/build/outputs/aar').glob('*release.aar')); assert len(aars)==1
shutil.copyfile(aars[0],OUT/aars[0].name)
with zipfile.ZipFile(aars[0]) as archive: abis=sorted(n.split('/')[1] for n in archive.namelist() if n.startswith('jni/') and n.endswith('/libdexkit.so'))
assert abis==['arm64-v8a','armeabi-v7a','x86','x86_64']
cache_records=[]
for abi in abis+['desktop']:
 candidates=list((ROOT/('dexkit' if abi=='desktop' else 'dexkit-android')).glob('**/CMakeCache.txt'))
 candidates=[p for p in candidates if (abi=='desktop' or abi in p.parts) and 'DEXKIT_EXPERIMENT_SKIP_RW_WALK:BOOL=ON' in p.read_text()]
 assert candidates,abi
 source=max(candidates,key=lambda p:p.stat().st_mtime)
 shutil.copyfile(source,OUT/(abi+'-CMakeCache.txt'))
 cache_records.append({'abi':abi,'source':str(source),'sha256':hashlib.sha256(source.read_bytes()).hexdigest()})
record=dict(command=command,tests=tests,total_tests=sum(int(t['tests']) for t in tests),abis=abis,cmake_caches=cache_records,
 jar_sha256=hashlib.sha256((ROOT/'dexkit/build/libs/dexkit.jar').read_bytes()).hexdigest(),aar_sha256=hashlib.sha256(aars[0].read_bytes()).hexdigest())
(OUT/'validation.json').write_text(json.dumps(record,indent=2)+'\n')
print('DONE tests='+str(record['total_tests'])+' abis='+','.join(abis),flush=True)
