#!/usr/bin/env python3
import json
from pathlib import Path
import subprocess
import sys
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
DATA=BASE/'next-round'
JDK='/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home'
phase=sys.argv[1]
assert phase in ('main','confirm')
seed=2026092900 if phase=='main' else 2026093000
completed=[]
def run(name,command):
 print('START '+name,flush=True)
 with (DATA/'formal'/(name+'-launcher.log')).open('w') as output:
  subprocess.run(list(map(str,command)),cwd=ROOT,stdout=output,stderr=subprocess.STDOUT,check=True)
 result=json.loads((DATA/'formal'/name/'summary.json').read_text())
 completed.append({'name':name,'command':list(map(str,command))})
 (DATA/'formal'/('rw-walk-'+phase+'-queue.json')).write_text(json.dumps(completed,indent=2)+'\n')
 value=result['metrics']['lifecycle_ms']
 peak=result['metrics']['peak_footprint_bytes']
 print('DONE %s life %+.2f%% %s peak %+.2f%% %s'%(name,value['median_change_percent'],value['bootstrap95_percent'],peak['median_change_percent'],peak['bootstrap95_percent']),flush=True)
for tail,passes in [(False,1),(False,11),(True,1),(True,11)]:
 name='rw-walk-qq-'+('tail-' if tail else '')+phase+'-p'+str(passes)
 command=['python3','tools/qaux-benchmark/sweep.py','--dexkit-root',ROOT,'--corpus',BASE/'qaux-extracted','--apk',BASE/'qq-9.3.55.apk',
  '--java-home',JDK,'--memory-probe',BASE/'artifacts/probe-v2/libqauxbench_probe.dylib','--output',DATA/'formal'/name,
  '--pairs','6','--passes',str(passes),'--threads','4','--profile','all','--seed',str(seed)]
 if tail: command+=['--final-field-rw','Lcom/tencent/mobileqq/data/MessageRecord;->msg:Ljava/lang/String;',
  '--field-rw-expected',BASE/'followup/formal/field-tail-oracle-best5/field-rw-expected.json']
 for label in ['control','skip']:
  command += ['--variant',label,DATA/'artifacts'/('rw-walk-'+label+'-v1')/'libdexkit.dylib',
    DATA/'formal'/('verify-rw-walk-'+('tail-' if tail else '')+label+'-v1')]
 run(name,command); seed+=1
for fixture,mode,repeats in [('field-adverse',m,32) for m in ['field-forward','field-late','field-full-first']]:
 name='rw-walk-native-'+phase+'-'+fixture+'-'+mode
 apk=DATA/'fixtures'/('field-'+fixture+'-v1')/'fields.apk' if mode.startswith('using-') else BASE/'followup/fixtures'/fixture/'relations.apk'
 command=['python3','tools/qaux-benchmark/workload_sweep.py','--fixture',apk,
  '--output',DATA/'formal'/name,'--mode',mode,'--repeats',str(repeats),'--pairs','6','--seed',str(seed)]
 for label in ['control','skip']: command+=['--variant',label,DATA/'artifacts'/('rw-walk-'+label+'-v1')]
 run(name,command); seed+=1
