#!/usr/bin/env python3
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
DATA=BASE/'next-round'
OUT=DATA/'formal/rw-walk-relations-assertions-v1'
OUT.mkdir()
source=OUT/'relation_checks.cpp'
source.write_bytes((ROOT/'tools/qaux-benchmark/relation_checks.cpp').read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=os.environ.copy(); env['ASAN_OPTIONS']='detect_leaks=0'; env['UBSAN_OPTIONS']='halt_on_error=1'
records=[]
for label in ['control-trace-v1','skip-trace-v1','skip-sanitized-v1']:
 artifact=DATA/'artifacts'/('rw-walk-'+label)
 build=artifact/'build'
 target=DATA/'artifacts/rw-walk-relations-assertions-v1'/label
 target.mkdir(parents=True)
 commands=subprocess.check_output(['ninja','-t','commands','dexkit_relation_checks'],cwd=build,text=True).splitlines()
 compile=next(shlex.split(c) for c in commands if ' -c ' in c and c.endswith('/relation_checks.cpp'))
 old_object=compile[compile.index('-o')+1]
 obj=target/'relation_checks.o'
 compile=[str(obj) if a==old_object else str(obj)+'.d' if a==old_object+'.d' else str(source) if a.endswith('/tools/qaux-benchmark/relation_checks.cpp') else a for a in compile]
 link=next(shlex.split(c) for c in commands if ' -o Core/dexkit_relation_checks ' in c)
 assert link[:2]==[':','&&'] and link[-2:]==['&&',':']
 link=link[2:-2]
 assert not set(link)&{'&&',';','|'}
 executable=target/'dexkit_relation_checks'
 link=[str(obj) if a==old_object else str(executable) if a=='Core/dexkit_relation_checks' else a for a in link]
 core=build/'Core/libdexkit_static.a'; core_sha=sha(core)
 print('COMPILE '+label,flush=True)
 with (OUT/(label+'-compile.log')).open('w') as log:
  for command in [compile,link]: subprocess.run(command,cwd=build,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 runs=[]
 for fixture in ['relations','field-adverse']:
  command=[str(executable),'--dump',str(BASE/'followup/fixtures'/fixture/'relations.apk')]
  output=OUT/(label+'-'+fixture+'.bin'); errors=OUT/(label+'-'+fixture+'.stderr')
  with output.open('wb') as out, errors.open('wb') as err: subprocess.run(command,cwd=ROOT,env=env,stdout=out,stderr=err,timeout=300,check=True)
  expected=DATA/'formal'/('rw-walk-control-trace-v1-'+fixture+'.bin')
  assert output.read_bytes()==expected.read_bytes()
  walks=[json.loads(s) for s in re.findall(r'^BENCH_INSTRUCTION_WALK (.+)$',errors.read_text(),re.M)]
  joint=[r for r in walks if r['flags']==0x1400]
  assert len(joint)==3 and all(r['rw_only'] for r in joint)
  if label.startswith('skip'): assert all(not r['walk'] and r['methods']==r['instructions']==0 for r in joint)
  else: assert sum(r['instructions'] for r in joint)>0
  runs.append(dict(fixture=fixture,command=command,ordered_output_sha256=sha(output),rw_caller_walks=joint,passed=True))
  print('PASS '+label+' '+fixture,flush=True)
 assert sha(core)==core_sha
 records.append(dict(label=label,core_archive_sha256=core_sha,source_sha256=sha(source),executable_sha256=sha(executable),compile_command=compile,link_command=link,working_directory=str(build),runs=runs))
(OUT/'validation.json').write_text(json.dumps(records,indent=2)+'\n')
