#!/usr/bin/env python3
"""Archive the completed single-field comparison and refined identity oracle."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
DATA=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/next-round')
OUT=ROOT/'tools/qaux-benchmark/evidence/next-round/single-field'
OUT.mkdir(parents=True,exist_ok=True)
assert not any(OUT.iterdir())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
files={}
def add(path,name):
 assert path.is_file() and name not in files,(path,name)
 files[name]=path
summary=json.loads((DATA/'formal/single-field-summary-v1.json').read_text())
assert summary['sweeps']==18 and summary['samples']==216
shutil.copyfile(DATA/'formal/single-field-summary-v1.json',OUT/'summary.json')
shutil.copyfile(DATA/'formal/single-field-trace-records-v3.json',OUT/'trace-summary.json')
for path in sorted((DATA/'formal').iterdir()):
 if 'single-field' not in path.name: continue
 for file in sorted(path.rglob('*')) if path.is_dir() else [path]:
  if file.is_file() and file.suffix not in ('.class','.aar','.dylib'):
   add(file,str(file.relative_to(DATA)))
for path in sorted((DATA/'artifacts').glob('single-field-*')):
 if (path/'artifact.json').is_file():
  manifest=json.loads((path/'artifact.json').read_text())
  assert manifest['native_sha256']==sha(path/'libdexkit.dylib')
 for name in ['artifact.json','CMakeCache.txt','source.patch','build.log']:
  if (path/name).is_file(): add(path/name,str((path/name).relative_to(DATA)))
for name in ['field-small-v1','field-short-v1','field-long-v1','field-unresolved-v1']:
 for file in sorted((DATA/'fixtures'/name).iterdir()):
  if file.is_file(): add(file,str(file.relative_to(DATA)))
for name in ['single_field_build_queue.py','single_field_validate_queue.py','single_field_extra_validate.py','single_field_gradle.py','single_field_trace_queue.py','single_field_trace_queue_v2.py','single_field_trace_queue_v3.py','single_field_measure_queue.py','rebuild_field_workloads.py','summarize_single_field.py','archive_single_field.py']:
 add(DATA/name,name)
for fixture in ['relations','field-adverse']:
 for file in sorted((DATA.parent/'followup/fixtures'/fixture).iterdir()):
  if file.is_file(): add(file,'relation-fixtures/'+fixture+'/'+file.name)
for revision,directory in [('c707ea9','measurement-source'),('ae6a76c17dfb9e3baba437614a698121a2c9209a','refined-oracle-source')]:
 names=['make_field_fixture.py','validate_field_checks.py']
 if directory=='measurement-source': names+=['field_queries.h','field_checks.cpp','field_workload.cpp','make_symbol_fixture.py','make_relation_fixture.py','relation_checks.cpp','relation_workload.cpp','validate_string_checks.py','build_native.py','run.py','sweep.py','workload_sweep.py','force_tests.gradle']
 for name in names:
  target=DATA/'archive-single-field-sources'/directory/name
  target.parent.mkdir(parents=True,exist_ok=True)
  target.write_bytes(subprocess.check_output(['git','-C',str(ROOT),'show',revision+':tools/qaux-benchmark/'+name]))
  add(target,directory+'/'+name)
archive=OUT/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name,path in sorted(files.items()): tar.add(path,arcname=name,recursive=False)
manifest={'archive_sha256':sha(archive),'files':{name:sha(path) for name,path in sorted(files.items())},
 'summary_sha256':sha(OUT/'summary.json'),'trace_summary_sha256':sha(OUT/'trace-summary.json'),
 'scope':'All 18 sweeps and 216 samples, native/QQ field traces, eleven-round frozen verification, independent field and relation oracles, standalone/ASan/UBSan, JVM/four-ABI records, preflight corrections, four synthetic field fixtures and relation fixtures, reproduction scripts. Corrected measured workload source c707ea9 and refined identity oracle ae6a76c are separately retained. Proprietary QQ APK, classes, native libraries/archives/executables and AAR binaries are omitted; binary identities and commands remain recorded.'}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive,'r:gz') as tar:
 assert set(tar.getnames())==set(files)
 for member in tar:
  assert hashlib.sha256(tar.extractfile(member).read()).hexdigest()==manifest['files'][member.name]
print(json.dumps({'files':len(files),'bytes':archive.stat().st_size,'sha256':manifest['archive_sha256'],'sweeps':summary['sweeps'],'samples':summary['samples']}))
