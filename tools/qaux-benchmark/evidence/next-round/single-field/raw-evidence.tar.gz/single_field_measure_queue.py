#!/usr/bin/env python3
"""Finite same-source single-field comparisons, after all validation."""
import json
from pathlib import Path
import subprocess
import sys
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
DATA=BASE/'next-round'
JDK='/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home'
phase=sys.argv[1]
assert phase in ('main','confirm')
seed=2026092500 if phase=='main' else 2026092600
completed=[]
def run(name,command):
 print('START '+name,flush=True)
 with (DATA/'formal'/(name+'-launcher.log')).open('w') as output:
  subprocess.run(list(map(str,command)),cwd=ROOT,stdout=output,stderr=subprocess.STDOUT,check=True)
 result=json.loads((DATA/'formal'/name/'summary.json').read_text())
 completed.append({'name':name,'command':list(map(str,command))})
 (DATA/'formal'/('single-field-'+phase+'-queue.json')).write_text(json.dumps(completed,indent=2)+'\n')
 value=result['metrics']['lifecycle_ms']
 print('DONE %s life %+.2f%% %s'%(name,value['median_change_percent'],value['bootstrap95_percent']),flush=True)
for passes in [1,11]:
 name='single-field-qq-'+phase+'-p'+str(passes)
 command=['python3','tools/qaux-benchmark/sweep.py','--dexkit-root',ROOT,'--corpus',BASE/'qaux-extracted','--apk',BASE/'qq-9.3.55.apk',
  '--java-home',JDK,'--memory-probe',BASE/'artifacts/probe-v2/libqauxbench_probe.dylib','--output',DATA/'formal'/name,
  '--pairs','6','--passes',str(passes),'--threads','4','--profile','all','--seed',str(seed)]
 for label in ['control','direct']:
  command += ['--variant',label,DATA/'artifacts'/('single-field-'+label+'-v2')/'libdexkit.dylib',DATA/'formal'/('verify-single-field-'+label+'-v1')]
 run(name,command); seed+=1
for fixture,mode in [('long',m) for m in ['using-early','using-late','using-miss','using-sparse','using-multiple','using-class']]+[('short','using-early')]:
 name='single-field-native-'+phase+'-'+fixture+'-'+mode
 command=['python3','tools/qaux-benchmark/workload_sweep.py','--fixture',DATA/'fixtures'/('field-'+fixture+'-v1')/'fields.apk',
  '--output',DATA/'formal'/name,'--mode',mode,'--repeats','32','--pairs','6','--seed',str(seed)]
 for label in ['control','direct']: command+=['--variant',label,DATA/'artifacts'/('single-field-'+label+'-v2')]
 run(name,command); seed+=1
