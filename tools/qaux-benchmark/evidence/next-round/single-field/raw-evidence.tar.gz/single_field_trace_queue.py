#!/usr/bin/env python3
import json
from pathlib import Path
import re
import subprocess
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
DATA=BASE/'next-round'
records=[]
for label in ['control','direct']:
 artifact=DATA/'artifacts'/('single-field-'+label+'-trace-v1')
 destination=DATA/'formal'/('single-field-'+label+'-trace-v1'); destination.mkdir()
 for fixture,mode in [('long',m) for m in ['using-early','using-late','using-miss','using-sparse','using-multiple','using-class']]+[('short','using-early')]:
  command=[str(artifact/'build/Core/dexkit_field_workload'),str(DATA/'fixtures'/('field-'+fixture+'-v1')/'fields.apk'),mode,'2']
  log=destination/(fixture+'-'+mode+'.log')
  with log.open('w') as out: subprocess.run(command,cwd=ROOT,stdout=out,stderr=subprocess.STDOUT,check=True)
  output=log.read_text(); report=json.loads(re.search(r'^WORKLOAD (.+)$',output,re.M)[1])
  assert report['returned']==(0 if mode=='using-miss' else 4 if mode in ['using-sparse','using-class'] else 2400)
  rows=[json.loads(line) for line in re.findall(r'^BENCH_FIELD (.+)$',output,re.M)]; assert rows
  totals={key:sum(row[key] for row in rows) for key in rows[0] if key not in ('query','dex','kind')}
  records.append(dict(label=label,fixture=fixture,mode=mode,command=command,returned=report['returned'],totals=totals,rows=rows))
  print(label,fixture,mode,totals,flush=True)
 name='verify-single-field-'+label+'-trace-v1'
 command=['python3','tools/qaux-benchmark/run.py','--dexkit-root',str(ROOT),'--corpus',str(BASE/'qaux-extracted'),'--apk',str(BASE/'qq-9.3.55.apk'),
  '--java-home','/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home','--memory-probe',str(BASE/'artifacts/probe-v2/libqauxbench_probe.dylib'),
  '--output',str(DATA/'formal'/name),'--native-library',str(artifact/'libdexkit.dylib'),'--passes','2','--threads','4','--profile','all','--mode','verify']
 print('START QQ trace '+label,flush=True)
 with (destination/'qq-launcher.log').open('w') as out: subprocess.run(command,cwd=ROOT,stdout=out,stderr=subprocess.STDOUT,check=True)
 stages=[]; pending=[]
 for line in (DATA/'formal'/name/'run.log').read_text().splitlines():
  if line.startswith('BENCH_FIELD '): pending.append(json.loads(line[len('BENCH_FIELD '):]))
  if line.startswith('{'):
   try: report=json.loads(line)
   except json.JSONDecodeError: continue
   if 'stage' in report:
    totals={key:sum(row[key] for row in pending) for key in pending[0] if key not in ('query','dex','kind')} if pending else {}
    stages.append(dict(pass_index=report['pass'],feature=report['feature'],stage=report['stage'],totals=totals,query_ids=sorted({r['query'] for r in pending})))
    pending=[]
 assert not pending
 records.append(dict(label=label,fixture='QQ',command=command,stages=stages))
 print('DONE QQ trace '+label,flush=True)
for fixture,mode in {(r['fixture'],r['mode']) for r in records if 'mode' in r}:
 a,b=[r for r in records if r.get('fixture')==fixture and r.get('mode')==mode]
 for key in ['calls','absent','empty','single','multiple','row_items','single_row_items','judges']: assert a['totals'][key]==b['totals'][key],(fixture,mode,key)
 if mode!='using-multiple': assert b['totals']['solver_calls']==0 and b['totals']['cache_builds']==0 and b['totals']['prepared_items']==0
qq=[r for r in records if r['fixture']=='QQ']; assert len(qq)==2
assert [(s['pass_index'],s['feature'],s['stage']) for s in qq[0]['stages']]==[(s['pass_index'],s['feature'],s['stage']) for s in qq[1]['stages']]
for a,b in zip(qq[0]['stages'],qq[1]['stages']):
 for key in ['calls','absent','empty','single','multiple','row_items','single_row_items','judges']:
  assert a['totals'].get(key,0)==b['totals'].get(key,0),(a['feature'],a['stage'],key)
(DATA/'formal/single-field-trace-records-v1.json').write_text(json.dumps(records,indent=2)+'\n')
