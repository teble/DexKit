#!/usr/bin/env python3
"""Finite, sequential Equal measurements; never run alongside builds/checks."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE = Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
DATA = BASE / 'next-round'
JDK = Path('/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home')
phase = sys.argv[1]
assert phase in ('main', 'confirm')
seed = 2026091800 if phase == 'main' else 2026091900
completed = []

def run(name, command):
    print('START ' + name, flush=True)
    with (DATA / 'formal' / (name + '-launcher.log')).open('w') as output:
        subprocess.run(command, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT, check=True)
    result = json.loads((DATA / 'formal' / name / 'summary.json').read_text())
    completed.append({'name': name, 'command': list(map(str, command))})
    (DATA / 'formal' / ('eq-' + phase + '-queue.json')).write_text(json.dumps(completed, indent=2) + '\n')
    value = result['metrics']['lifecycle_ms']
    print('DONE %s life %+.2f%% %s' % (name, value['median_change_percent'], value['bootstrap95_percent']), flush=True)

def artifact(label):
    return DATA / 'artifacts' / ('strings-' + label + '-eq-v3')

for passes in (1, 11):
    for label in ('direct', 'id'):
        name = 'eq-qq-' + label + '-' + phase + '-p' + str(passes)
        command = ['python3', 'tools/qaux-benchmark/sweep.py', '--dexkit-root', ROOT,
                   '--corpus', BASE / 'qaux-extracted', '--apk', BASE / 'qq-9.3.55.apk',
                   '--java-home', JDK, '--memory-probe', BASE / 'artifacts/probe-v2/libqauxbench_probe.dylib',
                   '--output', DATA / 'formal' / name, '--pairs', '6', '--passes', str(passes),
                   '--threads', '4', '--profile', 'all', '--seed', str(seed),
                   '--variant', 'control', artifact('control') / 'libdexkit.dylib', BASE / 'followup/formal/verify-master-normal-current-combo',
                   '--variant', label, artifact(label) / 'libdexkit.dylib', DATA / 'formal' / ('verify-strings-' + label + '-eq-final')]
        run(name, command)
        seed += 1

cases = [('early', 'string-eq-long', 16), ('late', 'string-eq-long', 16),
         ('miss', 'string-eq-long', 16), ('late', 'string-sparse', 16384),
         ('late', 'string-class', 16), ('late', 'string-contains', 16),
         ('late', 'string-multiple', 16)]
for layout, mode, repeats in cases:
    for label in ('direct', 'id'):
        name = 'eq-native-' + label + '-' + phase + '-' + layout + '-' + mode
        command = ['python3', 'tools/qaux-benchmark/workload_sweep.py',
                   '--fixture', DATA / 'fixtures' / ('strings-' + layout + '-v3') / 'strings.apk',
                   '--output', DATA / 'formal' / name, '--mode', mode, '--repeats', str(repeats),
                   '--pairs', '6', '--seed', str(seed),
                   '--variant', 'control', artifact('control'), '--variant', label, artifact(label)]
        run(name, command)
        seed += 1
