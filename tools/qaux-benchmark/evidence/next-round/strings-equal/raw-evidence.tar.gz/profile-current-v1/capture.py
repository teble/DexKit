import json, subprocess, time
from pathlib import Path
p=Path(__file__).parent
r=Path("/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/followup/formal/qq-master-normal-confirm-p11/pair-00-current-combo")
m=json.loads((r/"run-metadata.json").read_text())
base=m["command"]
start=next(i for i,v in enumerate(base) if v.endswith("/bin/java"))
cmd=[v for v in base[start:] if not v.startswith(("-Dqaux.memory.probe=","-Xlog:gc:"))]
i=cmd.index("QueryReplay")
cmd[i+3]=str(p/"report.json")
cmd[i+5]="80"
with (p/"java.stdout").open("w") as out,(p/"java.stderr").open("w") as err:
    proc=subprocess.Popen(cmd,stdout=out,stderr=err)
    print(json.dumps({"java_pid":proc.pid}),flush=True)
    time.sleep(4)
    sample_cmd=["/usr/bin/sample",str(proc.pid),"8","1","-file",str(p/"sample.txt")]
    sampled=subprocess.run(sample_cmd,capture_output=True,text=True,timeout=30)
    (p/"sample.stderr").write_text(sampled.stderr)
    (p/"sample.stdout").write_text(sampled.stdout)
    print(json.dumps({"sample_exit":sampled.returncode}),flush=True)
    code=proc.wait(timeout=180)
record={"purpose":"Stack attribution only; sampled timings are not benchmark evidence.","command":cmd,"sample_command":sample_cmd,"sample_exit":sampled.returncode,"java_exit":code,"native_sha256":m["native_sha256"],"reference_metadata":str(r/"run-metadata.json")}
(p/"manifest.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record),flush=True)
raise SystemExit(code)
