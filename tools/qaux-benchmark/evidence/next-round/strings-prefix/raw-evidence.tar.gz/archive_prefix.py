#!/usr/bin/env python3
"""Archive the completed prefix phase, excluding proprietary and build binaries."""
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

ROOT = Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE = Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
DATA = BASE / 'next-round'
OUT = ROOT / 'tools/qaux-benchmark/evidence/next-round/strings-prefix'
OUT.mkdir(parents=True, exist_ok=True)
assert not any(OUT.iterdir()), 'Use an empty destination.'
files = {}
def add(path, name):
    assert path.is_file(), path
    assert name not in files, name
    files[name] = path

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

summaries = {}
sample_count = 0
for phase in ('main', 'confirm'):
    queue = json.loads((DATA / 'formal' / ('prefix-' + phase + '-queue.json')).read_text())
    assert len(queue) == 24
    for run in queue:
        path = DATA / 'formal' / run['name']
        result = json.loads((path / 'summary.json').read_text())
        samples = json.loads((path / 'samples.json').read_text())
        assert len(samples) == 12 and result['pairs'] == 6
        assert {(v['pair'], v['label']) for v in samples} == {(i, label) for i in range(6) for label in {v['label'] for v in samples}}
        sample_count += len(samples)
        summaries[run['name']] = result['metrics']
assert len(summaries) == 48 and sample_count == 576
(OUT / 'summary.json').write_text(json.dumps({'sweeps': 48, 'samples': sample_count,
    'scope': 'Separate main and confirmation batches; QQ compares PREFIX-on to matching Equal-only builds; native compares to the nine-switch AC control or DIRECT explicitly.',
    'metrics': summaries}, indent=2) + '\n')
shutil.copyfile(DATA / 'formal/strings-prefix-trace-summary-v1.json', OUT / 'trace-summary.json')

for path in sorted((DATA / 'formal').iterdir()):
    if 'prefix' not in path.name:
        continue
    paths = sorted(path.rglob('*')) if path.is_dir() else [path]
    for file in paths:
        if file.is_file() and file.suffix not in ('.class', '.aar', '.dylib'):
            add(file, str(file.relative_to(DATA)))
for path in sorted((DATA / 'artifacts').glob('*prefix*')):
    manifest = json.loads((path / 'artifact.json').read_text())
    assert manifest['native_sha256'] == sha(path / 'libdexkit.dylib')
    for name in ('artifact.json', 'CMakeCache.txt', 'source.patch', 'build.log'):
        add(path / name, str((path / name).relative_to(DATA)))
for name in ('strings-correctness-v1', 'strings-correctness-wide-v1',
             'strings-prefix-early-v1', 'strings-prefix-late-v1', 'strings-prefix-miss-v1'):
    for file in sorted((DATA / 'fixtures' / name).iterdir()):
        if file.is_file(): add(file, str(file.relative_to(DATA)))
for name in ('prefix_measure_queue.py', 'archive_prefix.py'):
    add(DATA / name, name)
for name in ('build_native.py', 'workload_sweep.py', 'sweep.py', 'run.py',
             'make_string_fixture.py', 'make_symbol_fixture.py', 'validate_string_checks.py',
             'string_queries.h', 'string_checks.cpp', 'string_workload.cpp', 'force_tests.gradle'):
    add(ROOT / 'tools/qaux-benchmark' / name, 'reproduce/' + name)
for label in ('direct', 'id'):
    path = DATA / 'artifacts' / ('strings-' + label + '-eq-v3')
    for name in ('artifact.json', 'CMakeCache.txt', 'source.patch'):
        add(path / name, str((path / name).relative_to(DATA)))
    path = DATA / 'formal' / ('verify-strings-' + label + '-eq-final')
    for name in ('report.json', 'run-metadata.json'):
        add(path / name, str((path / name).relative_to(DATA)))
archive = OUT / 'raw-evidence.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for name, path in sorted(files.items()): tar.add(path, arcname=name, recursive=False)
manifest = {'archive_sha256': sha(archive), 'files': {name: sha(path) for name, path in sorted(files.items())},
    'summary_sha256': sha(OUT / 'summary.json'), 'trace_summary_sha256': sha(OUT / 'trace-summary.json'),
    'scope': 'All 48 prefix sweeps, 576 samples, correctness and standalone/sanitizer runs, trace data, build manifests/logs, JVM XML/ABI caches, synthetic inputs and reproduction scripts. QQ APK, compiled classes, native binaries and AAR binaries are omitted; full identities remain in run and artifact manifests.'}
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
with tarfile.open(archive, 'r:gz') as tar:
    assert set(tar.getnames()) == set(files)
    for member in tar:
        assert hashlib.sha256(tar.extractfile(member).read()).hexdigest() == manifest['files'][member.name]
print(json.dumps({'files': len(files), 'bytes': archive.stat().st_size, 'sha256': manifest['archive_sha256'], 'sweeps': len(summaries), 'samples': sample_count}))
