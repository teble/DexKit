#!/usr/bin/env python3
"""Finite StartWith measurements after all builds and correctness checks."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE = Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
DATA = BASE / 'next-round'
JDK = Path('/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home')
phase = sys.argv[1]
assert phase in ('main', 'confirm')
seed = 2026092100 if phase == 'main' else 2026092200
completed = []

def run(name, command):
    print('START ' + name, flush=True)
    with (DATA / 'formal' / (name + '-launcher.log')).open('w') as output:
        subprocess.run(command, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT, check=True)
    result = json.loads((DATA / 'formal' / name / 'summary.json').read_text())
    completed.append({'name': name, 'command': list(map(str, command))})
    (DATA / 'formal' / ('prefix-' + phase + '-queue.json')).write_text(json.dumps(completed, indent=2) + '\n')
    value = result['metrics']['lifecycle_ms']
    print('DONE %s life %+.2f%% %s' % (name, value['median_change_percent'], value['bootstrap95_percent']), flush=True)

def artifact(label):
    return DATA / 'artifacts' / ('strings-' + label + '-prefix-v1')

# This replay has no explicit StartWith: isolate the cost of enabling PREFIX.
for label in ('direct', 'id'):
    name = 'prefix-qq-' + label + '-' + phase + '-p11'
    command = ['python3', 'tools/qaux-benchmark/sweep.py', '--dexkit-root', ROOT,
               '--corpus', BASE / 'qaux-extracted', '--apk', BASE / 'qq-9.3.55.apk',
               '--java-home', JDK, '--memory-probe', BASE / 'artifacts/probe-v2/libqauxbench_probe.dylib',
               '--output', DATA / 'formal' / name, '--pairs', '6', '--passes', '11',
               '--threads', '4', '--profile', 'all', '--seed', str(seed),
               '--variant', 'equal', DATA / 'artifacts' / ('strings-' + label + '-eq-v3') / 'libdexkit.dylib', DATA / 'formal' / ('verify-strings-' + label + '-eq-final'),
               '--variant', 'prefix', artifact(label) / 'libdexkit.dylib', DATA / 'formal' / ('verify-strings-' + label + '-prefix-v1')]
    run(name, command)
    seed += 1

cases = [('early', 'string-prefix-tail', 16), ('late', 'string-prefix-tail', 16),
         ('miss', 'string-prefix-tail', 16), ('late', 'string-prefix-long', 16),
         ('late', 'string-prefix-sparse', 16384), ('late', 'string-prefix-class', 16),
         ('late', 'string-prefix-multiple', 16), ('late', 'string-multiple', 16),
         ('late', 'string-contains', 16)]
for layout, mode, repeats in cases:
    for label in ('direct', 'id'):
        name = 'prefix-native-' + label + '-' + phase + '-' + layout + '-' + mode
        command = ['python3', 'tools/qaux-benchmark/workload_sweep.py',
                   '--fixture', DATA / 'fixtures' / ('strings-prefix-' + layout + '-v1') / 'strings.apk',
                   '--output', DATA / 'formal' / name, '--mode', mode, '--repeats', str(repeats),
                   '--pairs', '6', '--seed', str(seed),
                   '--variant', 'control', artifact('control'), '--variant', label, artifact(label)]
        run(name, command)
        seed += 1

# Compare the two implementations directly in the affected workloads.
for layout, mode, repeats in [('early', 'string-prefix-tail', 16), ('late', 'string-prefix-tail', 16),
                              ('late', 'string-prefix-long', 16), ('late', 'string-prefix-sparse', 16384)]:
    name = 'prefix-head-native-' + phase + '-' + layout + '-' + mode
    command = ['python3', 'tools/qaux-benchmark/workload_sweep.py',
               '--fixture', DATA / 'fixtures' / ('strings-prefix-' + layout + '-v1') / 'strings.apk',
               '--output', DATA / 'formal' / name, '--mode', mode, '--repeats', str(repeats),
               '--pairs', '6', '--seed', str(seed),
               '--variant', 'direct', artifact('direct'), '--variant', 'id', artifact('id')]
    run(name, command)
    seed += 1
