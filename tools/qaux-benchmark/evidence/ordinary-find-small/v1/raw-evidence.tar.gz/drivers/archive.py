import hashlib,json,subprocess,tarfile,io,shutil
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
E=BASE/'ordinary-find-small-v1'
DEST=ROOT/'tools/qaux-benchmark/evidence/ordinary-find-small/v1'
DEST.mkdir(parents=True)
files={}
def add(path,name):
 assert path.is_file(),path
 assert name not in files,name
 files[name]=path
def tree(path,prefix):
 for file in sorted(path.rglob('*')):
  if not file.is_file():continue
  relative=file.relative_to(path)
  if 'classes' in relative.parts or file.suffix in ('.class','.jar','.aar','.so','.dylib','.o','.a'):continue
  add(file,prefix+'/'+str(relative))
for name in ['measurements','validation','fixtures']:
 tree(E/name,name)
for file in E.glob('*.py'):add(file,'drivers/'+file.name)
add(E/'summary.json','summary.json')
for file in (E/'quick').glob('*.log'):add(file,'development/'+file.name)
for directory in sorted((E/'artifacts').iterdir()):
 for file in directory.iterdir():
  if file.is_file() and file.suffix in ('.json','.txt','.log','.patch'):
   add(file,'artifacts/'+directory.name+'/'+file.name)
for relative in ['next-round/fixtures/strings-correctness-v1','next-round/fixtures/strings-correctness-wide-v1','string-admission-v1/fixtures/admission-final','string-admission-v1/fixtures/multidex','candidate-pipeline-v1/fixtures/cross-slice','candidate-pipeline-v1/fixtures/front-skew','string-inverse-v2/fixtures/integration']:
 tree(BASE/relative,'inputs/'+relative)
add(BASE/'string-admission-v1/artifacts/small/artifact.json','inputs/old-small-artifact.json')
for file in sorted((ROOT/'tools/qaux-benchmark').iterdir()):
 if file.is_file() and file.suffix in ('.py','.cpp','.h','.java','.gradle','.md'):
  add(file,'source/tools/'+file.name)
for relative in ['Core/CMakeLists.txt','Core/dexkit/dexkit.cpp','Core/dexkit/dex_item_find.cpp','Core/dexkit/dex_item_candidates.cpp','Core/dexkit/include/candidate_pipeline.h','Core/dexkit/include/query_candidates.h','Core/dexkit/include/query_executor.h','Core/dexkit/include/query_scheduler.h','Core/dexkit/include/query_context.h','Core/dexkit/include/inverted_string_index.h','Core/dexkit/include/beans.h','dexkit/build.gradle','dexkit-android/build.gradle']:
 add(ROOT/relative,'source/engine/'+relative)
engine=json.loads((E/'summary.json').read_text())['engine_commit']
patch=subprocess.check_output(['git','-C',str(ROOT),'diff','699c01dc28845a32cc9c1051fe629ba36556a8fe',engine,'--','Core','dexkit/build.gradle','dexkit-android/build.gradle'],text=True)
(E/'engine.patch').write_text(patch);add(E/'engine.patch','source/engine.patch')
identity=dict(engine_commit=engine,base_commit='699c01dc28845a32cc9c1051fe629ba36556a8fe',source_tree=subprocess.check_output(['git','-C',str(ROOT),'rev-parse',engine+':Core'],text=True).strip(),source_note='Timed native code is fixed at the engine commit. Follow-up fixture/checker/report scripts are included verbatim. Reproduction also needs the repository at that commit, the separately obtained QQ APK/corpus, JDK and compiler/SDK.')
(DEST/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
integrity={name:dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for name,path in sorted(files.items())}
archive=DEST/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for name,path in sorted(files.items()):tar.add(path,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 assert len(tar.getmembers())==len(integrity)
 for member in tar:
  raw=tar.extractfile(member).read();expected=integrity[member.name]
  assert len(raw)==expected['bytes'] and hashlib.sha256(raw).hexdigest()==expected['sha256'],member.name
(DEST/'integrity.json').write_text(json.dumps(integrity,indent=2)+'\n')
for src,name in [(E/'summary.json','summary.json'),(E/'validation/validation-summary.json','validation-summary.json'),(E/'validation/empty-task-counts.json','empty-task-counts.json')]:shutil.copyfile(src,DEST/name)
manifest=dict(archive=archive.name,archive_bytes=archive.stat().st_size,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),files=len(files),verified_readback=True,engine_commit=engine,accepted_sweeps=40,accepted_fresh_processes=480,excluded_measurements=0,omitted=['QQ APK','compiled native/JVM/Android artifacts'],integrity_sha256=hashlib.sha256((DEST/'integrity.json').read_bytes()).hexdigest())
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
