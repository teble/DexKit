import concurrent.futures
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Users/teble/project/android/DexKit-qaux-benchmark')
DATA = Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/ordinary-find-small-v1')
JDK = '/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home'
NINE = ['LAZY_DIRECTORIES', 'COMPACT_STRINGS', 'NEGATIVE_STRINGS', 'STRUCTURAL_DESCRIPTORS',
        'DESCRIPTOR_FAST_HITS', 'RAW_INTERFACES', 'FIELD_IDENTITY_SPLIT', 'COMPACT_INVOKES', 'SINGLE_RELATION']
phase = sys.argv[1]
assert phase in ('normal', 'extra')
variants = [('control', False, False, 0, False, False), ('empty', True, False, 0, False, False),
            ('move', False, True, 0, False, False), ('both', True, True, 0, False, False)] if phase == 'normal' else [
            ('control-trace', False, False, 0, True, False), ('both-trace', True, True, 0, True, False),
            ('pipeline-trace', False, False, 1, True, False), ('slices-sanitized', True, True, 2, True, True)]

def run(spec):
    name, empty, move, mode, trace, sanitize = spec
    command = ['python3', 'tools/qaux-benchmark/build_native.py', '--source-root', str(ROOT),
               '--output', str(DATA/'artifacts'/name), '--java-home', JDK, '--jobs', '3']
    definitions = ['DEXKIT_BENCHMARK_STRING_WORKLOAD=ON', 'DEXKIT_BENCHMARK_BATCH_WORKLOAD=ON',
                   'DEXKIT_EXPERIMENT_INVERTED_STRINGS=ON', 'DEXKIT_EXPERIMENT_INVERTED_STRING_RANGES=ON']
    definitions += ['DEXKIT_EXPERIMENT_'+name+'=ON' for name in NINE]
    if mode:
        definitions += ['DEXKIT_EXPERIMENT_CANDIDATE_PIPELINE=ON']
    if mode == 2:
        definitions += ['DEXKIT_EXPERIMENT_CANDIDATE_SLICES=ON']
    if empty:
        definitions += ['DEXKIT_EXPERIMENT_SKIP_EMPTY_CANDIDATES=ON']
    if move:
        definitions += ['DEXKIT_EXPERIMENT_MOVE_FIND_RESULTS=ON']
    if trace or sanitize:
        definitions += ['DEXKIT_BENCHMARK_DIAGNOSTICS=ON']
    if sanitize:
        flags = '-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer'
        definitions += ['CMAKE_C_FLAGS_RELEASE='+flags, 'CMAKE_CXX_FLAGS_RELEASE='+flags,
                        'CMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined',
                        'CMAKE_SHARED_LINKER_FLAGS=-fsanitize=address,undefined']
    for define in definitions:
        command += ['--define', define]
    print('START '+name, flush=True)
    with (DATA/'validation'/(name+'-build-launcher.log')).open('w') as log:
        subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=True)
    print('DONE '+name, flush=True)
    return {'name': name, 'command': command}

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    records = list(pool.map(run, variants))
(DATA/'validation'/('build-'+phase+'-queue.json')).write_text(json.dumps(records, indent=2)+'\n')
