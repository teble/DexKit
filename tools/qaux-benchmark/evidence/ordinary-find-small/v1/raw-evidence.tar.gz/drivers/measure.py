"""Finite independent extraction comparisons; all measurements run serially."""
import json, subprocess, sys
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
E=BASE/'ordinary-find-small-v1'; OLD=BASE/'string-admission-v1'; PIPE=BASE/'candidate-pipeline-v1'
JDK='/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home'
phase=sys.argv[1]; assert phase in ('main','confirm')
seed=2026091610 if phase=='main' else 2026091810
fixtures={'tiny':BASE/'next-round/fixtures/strings-correctness-v1/strings.apk',
 'cross':PIPE/'fixtures/cross-slice/strings.apk', 'skew':PIPE/'fixtures/front-skew/strings.apk',
 'admission':OLD/'fixtures/admission-final/strings.apk',
 'nested':BASE/'string-inverse-v2/fixtures/broad/strings.apk'}
main={'empty':[('admission','method-empty-w4-warm'),('admission','method-equal-one-w4-warm'),
 ('admission','class-one-w4-warm'),('cross','class-multiple-w4'),('skew','method-multiple-w4')],
 'move':[('cross','class-multiple-w4'),('cross','method-multiple-w4-warm'),
 ('tiny','method-multiple-w1'),('skew','method-multiple-w4')],
 'both':[('cross','class-multiple-w4'),('admission','method-equal-one-w4-warm'),('skew','method-multiple-w4')]}
# Repeat every targeted observation, with an independent balanced order.
plan=[]
for family, native in main.items():
 for fixture, mode in native:
  plan.append(dict(name=family+'-'+phase+'-'+fixture+'-'+mode,kind='native',labels=['control',family],fixture=str(fixtures[fixture]),mode='candidate-'+mode))
 for passes in [1,11]:
  plan.append(dict(name=family+'-'+phase+'-qq-p'+str(passes),kind='qq',labels=['control',family],passes=passes))
assert len(plan)==18
(E/'measurements').mkdir(exist_ok=True)
queue=E/'measurements'/('measurement-'+phase+'-queue.json')
completed=json.loads(queue.read_text()) if queue.exists() else []
(E/'measurements'/('measurement-'+phase+'-plan.json')).write_text(json.dumps(plan,indent=2)+'\n')
for item in plan:
 seed+=1; name=item['name']
 if any(row['name']==name for row in completed): continue
 if item['kind']=='native':
  cmd=['python3','tools/qaux-benchmark/workload_sweep.py','--fixture',item['fixture'],'--output',E/'measurements'/name,'--mode',item['mode'],'--repeats','16','--pairs','6','--seed',str(seed)]
  for label in item['labels']: cmd+=['--variant',label,E/'artifacts'/label]
 else:
  cmd=['python3','tools/qaux-benchmark/sweep.py','--dexkit-root',ROOT,'--corpus',BASE/'qaux-extracted','--apk',BASE/'qq-9.3.55.apk','--java-home',JDK,'--memory-probe',BASE/'artifacts/probe-v2/libqauxbench_probe.dylib','--output',E/'measurements'/name,'--pairs','6','--passes',str(item['passes']),'--threads','4','--profile','all','--seed',str(seed)]
  for label in item['labels']:
   cmd+=['--variant',label,E/'artifacts'/label/'libdexkit.dylib',E/'validation'/('verify-'+label)]
 cmd=list(map(str,cmd)); print('START '+name,flush=True)
 with (E/'measurements'/(name+'-launcher.log')).open('w') as log: subprocess.run(cmd,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
 v=json.loads((E/'measurements'/name/'summary.json').read_text())['metrics']['lifecycle_ms']
 completed.append(dict(item,command=cmd)); queue.write_text(json.dumps(completed,indent=2)+'\n')
 print('DONE '+name+' lifecycle=%+.2f%% %s'%(v['median_change_percent'],v['bootstrap95_percent']),flush=True)
