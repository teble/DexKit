import hashlib,json
from pathlib import Path
E=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/ordinary-find-small-v1')
M=E/'measurements'; records=[]
for kind,expected in [('main',18),('confirm',18),('parameters',4)]:
 queue=json.loads((M/('measurement-'+kind+'-queue.json')).read_text()); assert len(queue)==expected
 for item in queue:
  path=M/item['name'];summary=json.loads((path/'summary.json').read_text());samples=json.loads((path/'samples.json').read_text())
  assert len(samples)==12 and summary['pairs']==6
  labels=list(summary['metrics']['lifecycle_ms']['variants'])
  assert labels==['control',item.get('label',item.get('labels',[None,None])[1])]
  for label in labels:
   rows=[r for r in samples if r['label']==label]; assert len(rows)==6 and {r['pair'] for r in rows}==set(range(6))
  records.append(dict(name=item['name'],supplementary=kind=='parameters',labels=labels,metrics=summary['metrics'],samples=len(samples),summary_sha256=hashlib.sha256((path/'summary.json').read_bytes()).hexdigest(),samples_sha256=hashlib.sha256((path/'samples.json').read_bytes()).hexdigest()))
assert len(records)==40 and len({r['name'] for r in records})==40
result=dict(engine_commit=json.loads((E/'artifacts/control/artifact.json').read_text())['engine_commit'],accepted_sweeps=len(records),accepted_fresh_processes=sum(r['samples'] for r in records),excluded_measurements=0,records=records)
(E/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
for r in records:
 life=r['metrics']['lifecycle_ms']; ci=life['bootstrap95_percent']
 print(r['name']+' %.2f [%.2f, %.2f]'%(life['median_change_percent'],*ci))
print('TOTAL',result['accepted_sweeps'],result['accepted_fresh_processes'])
