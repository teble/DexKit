"""Follow-up covering the nonempty MethodBean parameter vector absent from the original workloads."""
import json,subprocess
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
E=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/ordinary-find-small-v1')
manifest=json.loads((E/'fixtures/parameters/manifest.json').read_text())
plan=[]
for phase in ['main','confirm']:
 for label in ['move','both']:
  plan.append(dict(name=label+'-'+phase+'-parameters-method-multiple-w4-warm',phase=phase,label=label))
(E/'measurements/measurement-parameters-plan.json').write_text(json.dumps(dict(reason='The original method result fixtures use empty parameter vectors; this independent follow-up exercises four parameters including a wide primitive and a reference.',sweeps=plan),indent=2)+'\n')
records=[]
for index,item in enumerate(plan):
 name=item['name'];cmd=['python3','tools/qaux-benchmark/workload_sweep.py','--fixture',E/'fixtures/parameters/strings.apk','--output',E/'measurements'/name,'--mode','candidate-method-multiple-w4-warm','--repeats','16','--pairs','6','--seed',str(20260916200+index),'--variant','control',E/'artifacts/control','--variant',item['label'],E/'artifacts'/item['label']]
 cmd=list(map(str,cmd));print('START '+name,flush=True)
 with (E/'measurements'/(name+'-launcher.log')).open('w') as log:subprocess.run(cmd,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
 samples=json.loads((E/'measurements'/name/'samples.json').read_text())
 for sample in samples:
  assert sample['report']['returned']==manifest['expected_positive_methods']*16
  assert sample['report']['checksum']==manifest['expected_positive_checksum']*16
 d=json.loads((E/'measurements'/name/'summary.json').read_text());v=d['metrics']['lifecycle_ms']
 records.append(dict(item,command=cmd,independent_count_and_checksum=True));(E/'measurements/measurement-parameters-queue.json').write_text(json.dumps(records,indent=2)+'\n')
 print('DONE '+name+' lifecycle=%+.2f%% %s'%(v['median_change_percent'],v['bootstrap95_percent']),flush=True)
