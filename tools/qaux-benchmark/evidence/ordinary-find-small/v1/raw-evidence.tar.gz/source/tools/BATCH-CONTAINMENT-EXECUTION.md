# Batch containment experiment

Status: complete. Ten sweeps / 120 process samples, independent confirmation,
diagnostics, expanded 36-case ordered checks, standalone/sanitizer verification,
JVM tests and four-ABI Android builds are complete. See BATCH-CONTAINMENT-RESULTS
and BATCH-CONTAINMENT-REVIEW. The incremental control is the nine-switch
combination; all single-string switches are OFF in this phase.

Only the two batch group checks change: replace an intersection vector plus
size comparison with `std::includes`, keeping the same default string-view
ordering. Preserve the empty-search-set guard, normalization, duplicate keys,
AC scan, negative memo and complete result construction. The independent
`DEXKIT_EXPERIMENT_BATCH_STRING_INCLUDES` option defaults OFF.

Separate `DEXKIT_BENCHMARK_BATCH_TRACE` builds count eligible candidates,
candidates reaching the group loop, group checks and matched groups. Control
builds also count nonempty intersection vectors, final item counts and final
capacity bytes summed over those vectors. These are not allocator-call counts,
peak live bytes or CPU timing. Timed builds disable all diagnostics and metrics.

The native oracle uses independent encoded fixture rows and code-presence
parsing for 18 method/18 class batches, then checks complete ordered serialized
results across control and candidate. Cases include empty groups, mixed empty
groups, overlapping and repeated atoms, duplicate/empty keys, all literal
boundaries, SimilarRegex normalization, ASCII case folding, MUTF-8 values,
all-empty direct fallback and empty input filters. Cold, full-cache,
repeated and concurrent sequences preserve their original behavior.

Measure unchanged QQ one/eleven-round replays and high-overlap method/class
batches plus a no-hit method control. Each finite comparison uses six balanced
fresh-process pairs and an independent confirmation batch. The short-string
fixture has three DEXes, 1,500 methods per DEX, ten methods per class and four
references per method. Its 64 overlapping groups include four successful
groups and sixty partial matches, to expose temporary intersection work without
returning every group. The negative leg has no string witnesses. Keep creation,
preparation, serialization/destruction and close in the lifecycle boundary.

Run frozen QQ verification, host/JVM checks and four-ABI Android assembly,
plus focused sanitizer and standalone-macro checks. Review the source and
evidence in the authorized Pro conversation after a meaningful increment.
Do not combine this change with trie borrowing, bridge key initialization,
ordinary string ranges or any later field experiment.

The initial checker build used a nonexistent StringMatcher OR field and failed
before producing measurement artifacts. The corrected cases follow the actual
schema: StringMatcher has no logical children, and HasComposite(StringMatcher)
is always false. Missing using-string lists/values are dereferenced by existing
batch preprocessing, so they are not labeled valid batch DSL cases here. No
schema or native semantic change is made to accommodate a test fixture.

The completed source review requested two additional existing-behavior controls:
Equal and Contains of the same literal in separate groups, in both request
orders. The existing global mode map uses the last mode for that literal. These
explicit expectations preserve that behavior; the oracle is not advertised as
a general model for arbitrary mode/ignoreCase collisions. Only checker inputs
change after formal timing, and immutable measured core archives are reused.
