import hashlib,json,shutil,subprocess,tarfile
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark');BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55');E=BASE/'string-admission-v1'
REV='7d536bf4264ab5c8deeaa4a2a3f5a4831c76576d';out=ROOT/'tools/qaux-benchmark/evidence/string-admission/v1'
out.mkdir(parents=True,exist_ok=True);assert not any(out.iterdir())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
summary=json.loads((E/'formal/summary.json').read_text());assert summary['sweeps']==44 and summary['samples']==528
for name in ['summary.json','validation-summary.json','diagnostics-summary.json','source-identity.json']:shutil.copyfile(E/'formal'/name,out/name)
files={}
def add(path,name):
 assert path.is_file() and name not in files,(path,name)
 files[name]=path
for path in sorted((E/'formal').rglob('*')):
 if path.is_file() and path.suffix not in ['.class','.aar','.dylib','.so','.a','.o'] and path.name!='checks':add(path,str(path.relative_to(E)))
for artifact in sorted((E/'artifacts').iterdir()):
 manifest=json.loads((artifact/'artifact.json').read_text());assert manifest['native_sha256']==sha(artifact/'libdexkit.dylib')
 for name in ['artifact.json','CMakeCache.txt','source.patch','build.log']:
  if (artifact/name).is_file():add(artifact/name,str((artifact/name).relative_to(E)))
old=BASE/'string-inverse-v2/artifacts/string-inverse-inverse-v2'
for name in ['artifact.json','CMakeCache.txt','source.patch','build.log']:
 if (old/name).is_file():add(old/name,'old-engine-capture/'+name)
for path in sorted((old/'source-extra').rglob('*')):
 if path.is_file():add(path,'old-engine-capture/source-extra/'+str(path.relative_to(old/'source-extra')))
add(BASE/'string-inverse-v2/formal/source-identity.json','old-engine-capture/source-identity.json')
for path in sorted(E.glob('*.py')):add(path,'drivers/'+path.name)
for fixture in ['admission-final','multidex','cross-range','reordered']:
 for path in sorted((E/'fixtures'/fixture).iterdir()):
  if path.is_file():add(path,'fixtures/'+fixture+'/'+path.name)
shared={'strings-correctness-v1':BASE/'next-round/fixtures/strings-correctness-v1',
        'strings-correctness-wide-v1':BASE/'next-round/fixtures/strings-correctness-wide-v1',
        'strings-late-v3':BASE/'next-round/fixtures/strings-late-v3',
        'old-nested-broad':BASE/'string-inverse-v2/fixtures/broad',
        'old-integration':BASE/'string-inverse-v2/fixtures/integration',
        'budget':BASE/'string-inverse-v1/fixtures/budget'}
for name,directory in shared.items():
 for path in sorted(directory.iterdir()):
  if path.is_file():add(path,'shared-fixtures/'+name+'/'+path.name)
names=['build_native.py','run.py','sweep.py','workload_sweep.py','QueryReplay.java','force_tests.gradle',
       'make_symbol_fixture.py','make_string_fixture.py','make_relation_fixture.py','make_batch_fixture.py','make_string_inverse_fixture.py',
       'string_queries.h','string_checks.cpp','string_workload.cpp','batch_queries.h','batch_checks.cpp','batch_workload.cpp',
       'validate_string_checks.py','validate_batch_checks.py','inverted_string_checks.cpp','inverted_string_budget_checks.cpp','string_inverse_integration_checks.cpp',
       'make_string_admission_fixture.py','string_admission_queries.h','string_admission_workload.cpp','string_admission_checks.cpp','validate_string_admission.py']
for name in names:
 target=E/'archived-sources'/name;target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(subprocess.check_output(['git','-C',str(ROOT),'show',REV+':tools/qaux-benchmark/'+name]))
 # All timing and original validation source files still match the frozen revision.
 assert target.read_bytes()==(ROOT/'tools/qaux-benchmark'/name).read_bytes(),name
 add(target,'measurement-source/'+name)
for name in ['make_string_admission_cross_fixture.py','string_admission_cross_dex_checks.cpp']:
 add(ROOT/'tools/qaux-benchmark'/name,'extra-check-source/'+name)
add(ROOT/'tools/qaux-benchmark/baseline/expected.json','frozen-qq-expected.json')
archive=out/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name,path in sorted(files.items()):tar.add(path,arcname=name,recursive=False)
manifest=dict(version='v1',engine_commit=REV,sweeps=44,samples=528,archive_sha256=sha(archive),
 files={name:sha(path) for name,path in sorted(files.items())},
 scope='All accepted paired sweeps, raw observations, oracle and integration checks, source identities, seven current build configurations and old inverse adapter, JVM/four-ABI records, setup failures/corrections, synthetic fixtures and reproduction sources. Excludes proprietary QQ APK and native/JVM/AAR binaries. Two cross-DEX check sources were added after freezing the engine; all measured source files are unchanged.')
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive,'r:gz') as tar:
 assert set(tar.getnames())==set(files)
 for member in tar:assert hashlib.sha256(tar.extractfile(member).read()).hexdigest()==manifest['files'][member.name]
print(json.dumps(dict(files=len(files),bytes=archive.stat().st_size,sha256=manifest['archive_sha256'])),flush=True)
