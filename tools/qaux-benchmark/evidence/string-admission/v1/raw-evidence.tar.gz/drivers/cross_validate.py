import hashlib,json,shlex,subprocess
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark');E=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/string-admission-v1')
fixture=E/'fixtures/cross-range'
subprocess.run(['python3',str(ROOT/'tools/qaux-benchmark/make_string_admission_cross_fixture.py'),'--output',str(fixture)],check=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sdk=subprocess.check_output(['xcrun','--show-sdk-path'],text=True).strip();records=[];expected=None
for label in ['control','admission-trace','small-trace','small-sanitized','small-standalone']:
 artifact=E.parent/'string-inverse-v2/artifacts/string-inverse-control-trace-v2' if label=='control' else E/'artifacts'/label
 out=E/'formal'/('cross-range-'+label);out.mkdir()
 opts=json.loads((artifact/'artifact.json').read_text())['cmake_options'];source=ROOT/'tools/qaux-benchmark/string_admission_cross_dex_checks.cpp';exe=out/'checks';archive=artifact/'build/Core/libdexkit_static.a'
 cmd=[opts['CMAKE_CXX_COMPILER'],'-std=c++20','-pthread','-arch','arm64','-isysroot',sdk]+shlex.split(opts['CMAKE_CXX_FLAGS_RELEASE'])
 for k,v in opts.items():
  if k.startswith(('DEXKIT_EXPERIMENT_','DEXKIT_BENCHMARK_','DEXKIT_ENABLE_')):cmd+=['-D'+k+'='+{'ON':'1','OFF':'0'}.get(v,v)]
 for directory in ['dexkit/include','third_party/slicer/export','third_party/thread_helper','third_party/aho_corasick_trie','third_party/parallel_hashmap','third_party/flatbuffers/include']:cmd+=['-I',str(ROOT/'Core'/directory)]
 cmd+=[str(source),str(archive),'-lz','-o',str(exe)]
 print('START cross-range '+label,flush=True)
 with (out/'build.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
 with (out/'stdout.bin').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:subprocess.run([str(exe),str(fixture/'strings.apk')],stdout=stdout,stderr=stderr,check=True,timeout=120)
 data=(out/'stdout.bin').read_bytes();assert data
 if expected is None:expected=data
 assert expected==data
 records.append(dict(label=label,source_sha256=sha(source),archive_sha256=sha(archive),executable_sha256=sha(exe),fixture_sha256=sha(fixture/'strings.apk'),ordered_bytes_sha256=sha(out/'stdout.bin'),compile=cmd,queries=4,states=3,passed=True))
 print('DONE cross-range '+label,flush=True)
(E/'formal/cross-range-validation.json').write_text(json.dumps(records,indent=2)+'\n')
