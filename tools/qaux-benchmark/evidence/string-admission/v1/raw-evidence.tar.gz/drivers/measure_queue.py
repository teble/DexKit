"""Finite paired comparisons: admission, bounded ranges, and restoration references."""
import json,subprocess,sys
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark');BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55');E=BASE/'string-admission-v1'
JDK='/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home'
phase=sys.argv[1];assert phase in ['main','confirm']
seed=2026092200 if phase=='main' else 2026092300
queue=E/'formal'/('measurement-'+phase+'-queue.json');completed=json.loads(queue.read_text()) if queue.exists() else []
plan=[]
for family,labels,passes in [('step1',['old-inverse','admission'],1),('step1',['old-inverse','admission'],11),('step2',['admission','small'],11),('baseline',['control','small'],1),('baseline',['control','small'],11)]:
 plan.append(dict(name=family+'-qq-'+phase+'-p'+str(passes),kind='qq',family=family,labels=labels,passes=passes))
for mode in ['rare','wide','nested-rare','nested-wide','flags','return']:
 plan.append(dict(name='step1-'+phase+'-'+mode,kind='native',family='step1',labels=['old-inverse','admission'],fixture=str(E/'fixtures/admission-final/strings.apk'),mode='string-admission-'+mode))
for family,labels in [('step1',['old-inverse','admission']),('baseline',['control','admission'])]:
 plan.append(dict(name=family+'-'+phase+'-nested-broad',kind='native',family=family,labels=labels,fixture=str(BASE/'string-inverse-v2/fixtures/broad/strings.apk'),mode='string-nested-broad'))
plan.append(dict(name='step1-'+phase+'-pure-equal',kind='native',family='step1',labels=['old-inverse','admission'],fixture=str(BASE/'next-round/fixtures/strings-late-v3/strings.apk'),mode='string-eq-long'))
for mode in ['equal-one','prefix-one','equal-one-warm','prefix-one-warm','equal-two-warm','prefix-two-warm']:
 plan.append(dict(name='step2-'+phase+'-'+mode,kind='native',family='step2',labels=['admission','small'],fixture=str(E/'fixtures/admission-final/strings.apk'),mode='string-admission-'+mode))
plan.append(dict(name='baseline-'+phase+'-rare',kind='native',family='baseline',labels=['control','admission'],fixture=str(E/'fixtures/admission-final/strings.apk'),mode='string-admission-rare'))
plan.append(dict(name='baseline-'+phase+'-wide',kind='native',family='baseline',labels=['control','admission'],fixture=str(E/'fixtures/admission-final/strings.apk'),mode='string-admission-wide'))
assert len(plan)==22
(E/'formal'/('measurement-'+phase+'-plan.json')).write_text(json.dumps(plan,indent=2)+'\n')
for item in plan:
 name=item['name'];seed+=1
 if any(row['name']==name for row in completed):continue
 if item['kind']=='qq':
  cmd=['python3','tools/qaux-benchmark/sweep.py','--dexkit-root',ROOT,'--corpus',BASE/'qaux-extracted','--apk',BASE/'qq-9.3.55.apk','--java-home',JDK,'--memory-probe',BASE/'artifacts/probe-v2/libqauxbench_probe.dylib','--output',E/'formal'/name,'--pairs','6','--passes',str(item['passes']),'--threads','4','--profile','all','--seed',str(seed)]
  for label in item['labels']:cmd+=['--variant',label,E/'artifacts'/label/'libdexkit.dylib',E/'formal'/('verify-'+label)]
 else:
  cmd=['python3','tools/qaux-benchmark/workload_sweep.py','--fixture',item['fixture'],'--output',E/'formal'/name,'--mode',item['mode'],'--repeats','16','--pairs','6','--seed',str(seed)]
  for label in item['labels']:cmd+=['--variant',label,E/'artifacts'/label]
 cmd=list(map(str,cmd));print('START '+name,flush=True)
 with (E/'formal'/(name+'-launcher.log')).open('w') as log:subprocess.run(cmd,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
 metrics=json.loads((E/'formal'/name/'summary.json').read_text())['metrics'];v=metrics['lifecycle_ms']
 completed.append(dict(item,command=cmd));queue.write_text(json.dumps(completed,indent=2)+'\n')
 print('DONE '+name+' lifecycle=%+.2f%% %s'%(v['median_change_percent'],v['bootstrap95_percent']),flush=True)
