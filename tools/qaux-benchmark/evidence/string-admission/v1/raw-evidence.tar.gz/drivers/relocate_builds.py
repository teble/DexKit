import hashlib,json,shutil
from pathlib import Path
E=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/string-admission-v1');old=E.parent/'string-inverse-v2'
labels=['control','admission','small','admission-trace','small-trace','small-sanitized','small-standalone']
assert all((old/'artifacts'/label/'artifact.json').exists() for label in labels)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
records=[]
for label in labels:
 source=old/'artifacts'/label;dest=E/'artifacts'/label
 assert not dest.exists()
 identities={str(p.relative_to(source)):sha(p) for p in [source/'artifact.json',source/'libdexkit.dylib',source/'build/Core/libdexkit_static.a']+list((source/'build/Core').glob('dexkit_*')) if p.is_file()}
 shutil.move(source,dest)
 assert all(sha(dest/name)==h for name,h in identities.items())
 records.append(dict(source=str(source),destination=str(dest),sha256=identities))
 shutil.move(old/'formal'/(label+'-build-launcher.log'),E/'formal'/(label+'-build-launcher.log'))
for phase in ['normal','extra']:
 name='string-admission-build-'+phase+'-queue.json'
 shutil.move(old/'formal'/name,E/'formal'/name)
(E/'formal/build-location-correction.json').write_text(json.dumps({'reason':'The copied build driver initially retained the prior evidence root. Only newly created admission artifacts were relocated after completion; prior inverse artifacts and all binary bytes remain unchanged. Original configure paths remain in manifests.', 'artifacts':records},indent=2)+'\n')
print('Relocated seven completed artifacts; all hashes unchanged.',flush=True)
