import json,subprocess,sys
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark');BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55');E=BASE/'string-admission-v1'
phase=sys.argv[1];assert phase in ['normal','extra']
labels=['control','admission','small'] if phase=='normal' else ['admission-trace','small-trace','small-sanitized','small-standalone']
queue=E/'formal'/('validation-'+phase+'-queue.json')
records=json.loads(queue.read_text()) if queue.exists() else []
def run(name,cmd):
 if any(row['name']==name for row in records): return
 cmd=list(map(str,cmd));print('START '+name,flush=True)
 with (E/'formal'/(name+'.log')).open('w') as log:subprocess.run(cmd,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
 records.append(dict(name=name,command=cmd));(E/'formal'/('validation-'+phase+'-queue.json')).write_text(json.dumps(records,indent=2)+'\n')
 print('DONE '+name,flush=True)
for label in labels:
 run('layout-'+label,[E/'artifacts'/label/'build/Core/dexkit_inverted_string_checks'])
 if phase=='extra':
  for fixture in ['admission-final','multidex']:
   run('routes-'+label+'-'+fixture,[E/'artifacts'/label/'build/Core/dexkit_string_admission_checks',E/'fixtures'/fixture/'strings.apk'])
  run('inverse-integration-'+label,[E/'artifacts'/label/'build/Core/dexkit_string_inverse_integration_checks',BASE/'string-inverse-v2/fixtures/integration/strings.apk'])
for fixture in ['admission-final','multidex']:
 cmd=['python3','tools/qaux-benchmark/validate_string_admission.py','--fixture',E/'fixtures'/fixture,'--output',E/'formal'/('admission-'+fixture+'-'+phase)]
 for label in (['old-inverse'] if phase=='normal' else ['control'])+labels:
  cmd+=['--variant',label,E/'artifacts'/label/'build/Core/dexkit_string_admission_workload']
 run('admission-'+fixture+'-'+phase,cmd)
for fixture in ['strings-correctness-v1','strings-correctness-wide-v1']:
 for kind in ['string','batch']:
  name=kind+'-'+fixture+'-'+phase
  cmd=['python3','tools/qaux-benchmark/validate_'+kind+'_checks.py','--fixture',BASE/'next-round/fixtures'/fixture,'--output',E/'formal'/name]
  for label in ['old-inverse']+labels:
   artifact=BASE/'string-inverse-v2/artifacts/string-inverse-inverse-v2' if label=='old-inverse' else E/'artifacts'/label
   cmd+=['--variant',label,artifact]
  run(name,cmd)
