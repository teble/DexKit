import collections,hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark');E=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/string-admission-v1');REV='7d536bf4264ab5c8deeaa4a2a3f5a4831c76576d'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
nine=['LAZY_DIRECTORIES','COMPACT_STRINGS','NEGATIVE_STRINGS','STRUCTURAL_DESCRIPTORS','DESCRIPTOR_FAST_HITS','RAW_INTERFACES','FIELD_IDENTITY_SPLIT','COMPACT_INVOKES','SINGLE_RELATION']
artifacts=[]
for label in ['control','admission','small','admission-trace','small-trace','small-sanitized','small-standalone']:
 artifact=E/'artifacts'/label;m=json.loads((artifact/'artifact.json').read_text());assert m['engine_commit']==REV
 assert m['native_sha256']==sha(artifact/'libdexkit.dylib')
 expected=[] if label=='small-standalone' else nine[:]
 if label!='control':expected+=['INVERTED_STRINGS']
 if label.startswith('small'):expected+=['INVERTED_STRING_RANGES']
 enabled=sorted(k.removeprefix('DEXKIT_EXPERIMENT_') for k,v in m['cmake_options'].items() if k.startswith('DEXKIT_EXPERIMENT_') and v=='ON')
 assert enabled==sorted(expected),(label,enabled)
 for name,value in m['source_trees'].items():
  assert value==subprocess.check_output(['git','-C',str(ROOT),'rev-parse',REV+':'+name],text=True).strip()
 assert not subprocess.check_output(['git','-C',str(ROOT),'diff',REV,'--','Core','dexkit/src/main/cpp','schema'])
 assert (artifact/'source.patch').read_text()=='\n' and not m['untracked_source_sha256']
 artifacts.append(dict(label=label,native_sha256=m['native_sha256'],engine_commit=REV,source_trees=m['source_trees'],enabled=enabled,diagnostics=m['diagnostics']))
identities=dict(engine_commit=REV,artifacts=artifacts,control_byte_identical_to_previous_nine=artifacts[0]['native_sha256']=='1406de12c38e356b1771209f2006c73a189975e4f90c892dcf75f48c3b4fab16',
 post_review_checks={name:sha(ROOT/'tools/qaux-benchmark'/name) for name in ['make_string_admission_cross_fixture.py','string_admission_cross_dex_checks.cpp']})
(E/'formal/source-identity.json').write_text(json.dumps(identities,indent=2)+'\n')
checks=[]
for fixture in ['strings-correctness-v1','strings-correctness-wide-v1']:
 for kind in ['string','batch']:
  records=[]
  for phase in ['normal','extra']:records+=json.loads((E/'formal'/(kind+'-'+fixture+'-'+phase)/'validation.json').read_text())['records']
  assert all(r['passed'] for r in records) and len({r['ordered_results_sha256'] for r in records})==1
  checks.append(dict(kind=kind,fixture=fixture,variants=len({r['native_sha256'] for r in records}),queries_per_variant=records[0]['queries'],ordered_sha256=records[0]['ordered_results_sha256']))
for fixture in ['admission-final','multidex']:
 records=[]
 for phase in ['normal','extra']:records+=json.loads((E/'formal'/('admission-'+fixture+'-'+phase)/'validation.json').read_text())
 assert all(r['passed'] for r in records) and len({r['ordered_bytes_sha256'] for r in records})==1
 checks.append(dict(kind='admission',fixture=fixture,variants=len({r['executable_sha256'] for r in records}),queries_per_state=58,states=3,ordered_sha256=records[0]['ordered_bytes_sha256']))
gradle=json.loads((E/'formal/gradle-v1/validation.json').read_text());assert gradle['total_tests']==71
assert all(int(t.get('skipped',0))==0 and int(t['failures'])==0 and int(t['errors'])==0 for t in gradle['tests'])
for abi in gradle['abis']+['desktop']:
 text=(E/'formal/gradle-v1'/(abi+'-CMakeCache.txt')).read_text()
 enabled=sorted(re.findall(r'^DEXKIT_EXPERIMENT_(\w+):BOOL=ON$',text,re.M))
 assert enabled==sorted(nine+['INVERTED_STRINGS','INVERTED_STRING_RANGES']),(abi,enabled)
extra={}
for name in ['budget-checks','reordered-checks','cross-range-validation']:
 rows=json.loads((E/'formal'/(name+'.json')).read_text());assert rows and all(r['passed'] for r in rows);extra[name]=rows
for phase,count in [('normal',9),('extra',22)]:
 rows=json.loads((E/'formal'/('validation-'+phase+'-queue.json')).read_text());assert len(rows)==count,(phase,len(rows))
assert len(json.loads((E/'formal/qq-verification-queue.json').read_text()))==5
validation=dict(engine_commit=REV,oracles=checks,gradle=gradle,extra=extra,qq_verified=['control','admission','small','small-trace','old-inverse'],
 setup_corrections=['build-location-correction.json','integration-input-correction.json','adapter-permission-correction.json'])
(E/'formal/validation-summary.json').write_text(json.dumps(validation,indent=2)+'\n')
log=(E/'formal/verify-small-trace/run.log').read_text();parse=lambda text:dict((k,int(v)) for k,v in re.findall(r'(\w+)=(\d+)',text))
indexes=[parse(line) for line in log.splitlines() if line.startswith('BENCH_STRING_INVERSE_INDEX ')]
queries=[parse(line) for line in log.splitlines() if line.startswith('BENCH_STRING_INVERSE_QUERY ')]
plans=[parse(line) for line in log.splitlines() if line.startswith('BENCH_STRING_ADMISSION ')]
assert len(indexes)==41 and len({r['dex'] for r in indexes})==41
by_dex={r['dex']:r for r in indexes}
assert all(q['strings']==by_dex[q['dex']]['used'] for q in queries)
assert len(queries)==902 and set(collections.Counter(q['dex'] for q in queries).values())=={22}
assert sum(i['bytes'] for i in indexes)==5609448 and sum(i['used'] for i in indexes)==949982
assert sum(i['edges'] for i in indexes)==2001450
assert not any(p['reason']==7 for p in plans)
diagnostic=dict(indexes=indexes,ac_jobs=len(queries),ac_jobs_per_dex=22,retained_index_bytes=sum(i['bytes'] for i in indexes),
 referenced_string_ids=sum(i['used'] for i in indexes),edges=sum(i['edges'] for i in indexes),
 route_reason_counts={str(k):v for k,v in collections.Counter((p['route'],p['reason']) for p in plans).items()},
 ordinary_queries=len({p['query'] for p in plans}),dex_admissions=len(plans),small_range_admissions=0,
 total_string_scans=sum(q['strings'] for q in queries),max_bitmap_budget_bytes=max(q['bitmap_budget_bytes'] for q in queries),
 interpretation='QQ uses no guarded SmallRange exception; its step1 gains include changed admission and placement of pure range probes. ready=0/postings=0 in a plan means not counted, not an empty-range proof.')
(E/'formal/diagnostics-summary.json').write_text(json.dumps(diagnostic,indent=2)+'\n')
print('Validated source identities, all oracle bytes, flags, JVM/ABI and QQ diagnostic counts.',flush=True)
