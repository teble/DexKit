import json
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark');E=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/string-admission-v1')
data=json.loads((E/'formal/summary.json').read_text());out=[]
def add(text=''):out.append(text)
def metric(name,key='lifecycle_ms',stage=False):return data['qq_stages'][name]['metrics'][key] if stage else data['comparisons'][name]['metrics'][key]
def delta(v):return '%+.2f%% [%+.2f, %+.2f]'%(v['median_change_percent'],*v['bootstrap95_percent'])
def medians(v,divisor=1):return ' -> '.join('%.3f'%(s['median']/divisor) for s in v['variants'].values())
def row(label,main,confirm,key='lifecycle_ms',stage=False):
 a,b=metric(main,key,stage),metric(confirm,key,stage)
 add('| '+label+' | '+delta(a)+' | '+delta(b)+' | '+medians(b)+' |')
add('''# Conservative string admission: results

The implementation at `7d536bf4264ab5c8deeaa4a2a3f5a4831c76576d` completes the two requested changes: conservative admission for ordinary string candidates, and an independent existing-index range exception. Candidate/residual scheduling, predicate hoisting and string-vector fusion remain deferred.

The known onInitView regression is removed, and the old 4500-method nested workload returns close to the nine-option pipeline. This is a conservative policy, not a universally faster planner: it gives up substantial previous inverse gains on wide metadata conditions and on some nested shapes. Both experimental options remain default OFF.

## Rule and controls

- **Control**: the existing nine options: LAZY_DIRECTORIES, COMPACT_STRINGS, NEGATIVE_STRINGS, STRUCTURAL_DESCRIPTORS, DESCRIPTOR_FAST_HITS, RAW_INTERFACES, FIELD_IDENTITY_SPLIT, COMPACT_INVOKES, SINGLE_RELATION.
- **Old inverse**: the frozen `cc9f893` inverse artifact from the preceding experiment, added to those nine options.
- **Admission (B)**: the same nine options plus INVERTED_STRINGS, with the new admission rule. An ordinary unscoped, non-findFirst query retains whole-DEX candidates only for root usingStrings with no other present constraint. Empty logical lists keep their existing no-op semantics; other present objects are conservatively protected. Batch is unchanged.
- **Small**: B plus INVERTED_STRING_RANGES. A guarded root may use an original single nonempty case-sensitive ASCII Equal/StartWith only after an acquire observation of an already published index, with at most one distinct method/string edge in its range **per DEX**. Two matching string IDs in one method count as two edges. Cold/building indexes use Legacy without probing the pool, building, or waiting.

The decision is frozen before changing slices and carried into workers. A worker cannot upgrade Legacy when its slice covers a full DEX or another query publishes the index. Raw keyword counts and existing table sizes preflight bitmap budgets. A pure-string index-build failure after admission retains the previous single-task fallback boundary. No general allocation-failure fallback is promised.

## Measurement

There are 44 sweeps and 528 accepted fresh-process samples: six balanced randomized pairs per sweep, then an independently seeded confirmation of every comparison. macOS ARM64, four engine workers, JBR 17.0.6, frozen QQ 9.3.55/QAux queries. QQ uses all 149 string groups and ten feature chains for one or eleven passes. Native workloads use sixteen positive/absent pairs. Builds, tests and archive creation do not overlap accepted timing runs; OS file caches are not flushed. These are desktop measurements, not Android runtime measurements.

Negative percentages mean faster/smaller. Percentages are median paired relative changes, with exploratory paired bootstrap 95% intervals. Absolute figures are marginal medians, so their ratios need not equal paired percentages. An interval crossing zero is unresolved. Warm native setup includes the explicit query that builds the index and its destruction; API legs include result consumption/destruction, and lifecycle includes query destruction and close.

## Known regressions and restoration

| Metric / comparison | Main change and interval | Confirmation change and interval | Confirmation before -> after (ms) |
|---|---:|---:|---:|''')
oninit='AutoReceiveOriginalPhoto_cache_miss__nt_on_init_view_warm_per_pass_ms'
row('onInitView warm: old inverse -> B','step1-qq-main-p11','step1-qq-confirm-p11',oninit,True)
row('onInitView warm: control -> Small','baseline-qq-main-p11','baseline-qq-confirm-p11',oninit,True)
row('4500 nested lifecycle: old inverse -> B','step1-main-nested-broad','step1-confirm-nested-broad')
row('4500 nested positive APIs: old inverse -> B','step1-main-nested-broad','step1-confirm-nested-broad','positive_ms')
row('4500 nested lifecycle: control -> B','baseline-main-nested-broad','baseline-confirm-nested-broad')
row('4500 nested positive APIs: control -> B','baseline-main-nested-broad','baseline-confirm-nested-broad','positive_ms')
add('''
The former approximately 66% positive-leg regression is reduced to a small residual cost: confirmation is +2.75% against the nine-option baseline, while lifecycle is +2.52% with an interval crossing zero. This does not establish exact equality or zero overhead. The negative nested leg gives up the old inverse shortcut: old inverse -> B is 0.827 -> 423.391 ms over sixteen absent calls; control -> B is 420.873 -> 421.462 ms. Positive and negative effects must not be hidden inside the aggregate.

## Whole QQ workload

| Metric / comparison | Main change and interval | Confirmation change and interval | Confirmation before -> after (ms) |
|---|---:|---:|---:|''')
for family,label,passes in [('step1','Old inverse -> B',1),('step1','Old inverse -> B',11),('step2','B -> Small',11),('baseline','Control -> Small',1),('baseline','Control -> Small',11)]:
 row(label+', '+str(passes)+' passes',family+'-qq-main-p'+str(passes),family+'-qq-confirm-p'+str(passes))
row('Control -> Small, warm 149-group Batch per pass','baseline-qq-main-p11','baseline-qq-confirm-p11','batch_warm_per_pass_ms',True)
row('Control -> Small, warm feature chains per pass','baseline-qq-main-p11','baseline-qq-confirm-p11','chains_warm_per_pass_ms',True)
add('''
B improves the repeated workload relative to the prior inverse artifact; the one-pass B increment is unresolved. Overall control -> Small gains include the existing inverse optimization and must not be added to previous reported percentages. Diagnostics show **zero guarded SmallRange admissions in this QQ replay**: B -> Small has no established QQ latency benefit. Pure Equal/Prefix pool probes also moved from workers to the submitting thread, so the B increment is not merely the cost of an added Boolean branch.

## Cost of the conservative rule

The new fixture has 2250 unique-name methods, 2250 methods sharing one name, and five special methods. Bulk methods each reference their own long string sixteen times. This differs from the older 4500-method nested fixture, whose methods share the same long string ID.

| Old inverse -> B | Main lifecycle change and interval | Confirmation lifecycle change and interval | Confirmation before -> after (ms) |
|---|---:|---:|---:|''')
for name,label in [('rare','Rare name at root'),('wide','Broad name at root'),('nested-rare','Rare name in allOf'),('nested-wide','Broad name in allOf'),('flags','Broad static flag'),('return','Broad void return type')]:
 row(label,'step1-main-'+name,'step1-confirm-'+name)
add('''
These are repeatable losses of previous inverse gains, not evidence that a name or flag is intrinsically selective. Broad-name positive/absent API totals increase 91.993 -> 359.895 ms and 65.939 -> 261.845 ms; both legs lose. A rare name inside allOf does not move ahead of the existing composite string prefilter, so B does not give it root-name short-circuit behavior.

The added control -> B broad-name reference is -3.62% main and -3.89% [-4.86, -2.52] confirmation (639.180 -> 615.608 ms): it finds no additional regression against that original pipeline. The 3.8-5.0x lifecycle losses in the table are the opportunity cost of abandoning a previously beneficial inverse path. A more selective policy would require evidence beyond field presence; this change does not add that planner.

## Existing-index range exception

B -> Small, confirmation. API figures total sixteen calls. The warm lifecycle includes the explicit index warmup, so it is separate from the already-warm API benefit.

| Case | Lifecycle change and interval | Positive API change and interval | Absent API change and interval | Positive API before -> after (ms) |
|---|---:|---:|---:|---:|''')
for name,label in [('equal-one','Equal H=1, cold'),('prefix-one','Prefix H=1, cold'),('equal-one-warm','Equal H=1, warm'),('prefix-one-warm','Prefix H=1, warm'),('equal-two-warm','Equal H=2, warm'),('prefix-two-warm','Prefix H=2, warm')]:
 p='step2-confirm-'+name;a,b,c=[metric(p,k) for k in ['lifecycle_ms','positive_ms','negative_ms']]
 add('| '+label+' | '+delta(a)+' | '+delta(b)+' | '+delta(c)+' | '+medians(b)+' |')
add('''
Both H=1 warm improvements repeat: main lifecycle changes are -18.51% Equal and -21.19% Prefix, followed by -22.95% and -22.58% confirmation. Cold cases have no established benefit; the main cold Prefix slowdown does not resolve in confirmation. Cold repeats only warm the existing forward/matcher state and never build the inverse index in these guarded workloads.

H=2 positive queries remain Legacy. Their absent counterparts have H=0 and can use Empty, so a total improvement does not demonstrate an H=2 positive optimization. Prefix H=2 lifecycle confirmation is unresolved. A pure, unguarded long Equal workload also retains its prior performance: B versus old inverse is -0.71% main (unresolved), -0.74% confirmation.

## Memory and diagnostics

QQ control -> Small peak physical footprint increases +1.21% [+0.80, +1.59] in eleven-pass confirmation (1542.020 -> 1559.888 MiB); one-pass is +0.75% [+0.56, +0.89]. These peaks include the JVM and transient allocations. B versus old inverse, and Small versus B, have unresolved QQ peak differences. Native broad/flags/return peaks also increase relative to old inverse; their full observations remain in the summary. Warm H=1 native Small peaks decrease about 14% relative to B. There is no general memory-reduction claim.

The compact index arrays retain 5,609,448 bytes over 41 DEX files, unchanged from the prior representation: 949,982 referenced string IDs and 2,001,450 distinct method/string edges. The QQ trace records 902 AC jobs (22 per DEX), each scanning that DEX's referenced strings, versus 1353 jobs in the previous replay. It records 121 ordinary queries and 4851 per-DEX admission decisions. A diagnostic ready=0/postings=0 means not counted, not a proof of no postings.

## Validation, review and evidence

- Seven current native configurations plus the previous inverse artifact agree with the independent raw-row oracle and complete ordered bytes: 90 ordinary and 36 Batch cases on both existing small/wide fixtures; 58 admission cases in each of three states on the new single/multi-DEX fixtures. States are fresh, full cache with inverse still cold, and explicit inverse warmup.
- The index checker covers 51 layouts and 5100 intervals, including duplicate instructions, 16/32-bit payload boundaries, empty and rank-word boundaries. Range counts are checked against independent posting counts as well as method unions.
- All four diagnostic configurations check 348 method/class admission decisions, 30 explicit-empty-scope/findFirst restrictions, and 12 concurrent publication/frozen-submission cases across the two fixtures. They do not force every possible interleaving inside Build.
- Budget rejection before construction, successful later construction, reversed ClassDefs ordering, existing nested/cross-DEX and first-publication integration tests pass. ASan/UBSan and the standalone inverse/range configuration pass.
- The Pro review read the fixed `a55ba18 -> 7d536bf` increment and found no new production correctness blocker. It identified a warm Range cross-DEX coverage gap. The added checker uses the same root vector in a remote matcher at the same numeric method ID, asserts actual Range/Empty plans and real cross-DEX binding, and validates both false and true cases across five frozen artifacts. No engine change was needed.
- Gradle `:dexkit:cmakeBuild :dexkit:jar :dexkit:test :dexkit-android:assembleRelease` passed: 71 JVM tests, no skips/failures/errors, and arm64-v8a, armeabi-v7a, x86, x86_64. All five CMake caches enable exactly the nine options plus INVERTED_STRINGS and INVERTED_STRING_RANGES. Five eleven-pass QQ oracle/flow verification runs also pass.

Three harness setup corrections are preserved separately: initially building new artifacts under the previous evidence root before relocation with unchanged hashes; supplying the wrong fixture to the old TLS checker; and losing execute permission when copying an old workload. The corrected checks pass, and the executable-permission failure produced no accepted timing sample. Completed valid sweeps were retained. One additional broad-name baseline comparison per phase was added after observing the loss of previous inverse gains; its rationale is archived.

The source and timing inputs remain frozen at `7d536bf`. The two extra cross-DEX test sources were linked afterward against frozen archives; their identities are recorded separately. The nine-option control library is byte-identical to the previous control. The user's main checkout was not changed.

- [Results and all metrics](evidence/string-admission/v1/summary.json)
- [Validation](evidence/string-admission/v1/validation-summary.json), [diagnostics](evidence/string-admission/v1/diagnostics-summary.json), [source identities](evidence/string-admission/v1/source-identity.json)
- [Archive manifest](evidence/string-admission/v1/manifest.json), [execution policy](STRING-ADMISSION-EXECUTION.md)
- [Original Pro conversation](https://chatgpt.com/c/6aa81c3c-a104-83ee-b6fe-8bcdd4732ff3)

The archive contains commands, raw observations, failures/corrections, validation records, synthetic fixtures and reproduction sources. It excludes the proprietary QQ APK and native/JVM/AAR binaries; their identities remain recorded.
''')
# Derive memory units rather than retaining rounded handwritten values.
v=metric('baseline-qq-confirm-p11','peak_footprint_bytes')
text='\n'.join(out).replace('1542.020 -> 1559.888',medians(v,1024**2))
(ROOT/'tools/qaux-benchmark/STRING-ADMISSION-RESULTS.md').write_text(text)
