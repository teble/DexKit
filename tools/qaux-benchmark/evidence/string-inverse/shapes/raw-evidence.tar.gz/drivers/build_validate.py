import base64,hashlib,json,re,shlex,shutil,subprocess
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
OUT=BASE/'string-inverse-shapes-v1';SDK=subprocess.check_output(['xcrun','--show-sdk-path'],text=True).strip()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
records=[];source=ROOT/'tools/qaux-benchmark/string_shape_workload.cpp'
variants=[('control-nested','control',0),('control-flat','control',1),('inverse-nested','inverse',0),('inverse-flat','inverse',1),('inverse-root','inverse',2)]
for name,base,shape in variants:
 a=BASE/'string-inverse-v2/artifacts'/('string-inverse-'+base+'-v2');d=OUT/'artifacts'/name;d.mkdir(parents=True)
 m=json.loads((a/'artifact.json').read_text());opts=m['cmake_options']
 exe=d/'build/Core/dexkit_string_workload';exe.parent.mkdir(parents=True)
 command=[opts['CMAKE_CXX_COMPILER'],'-std=c++20','-pthread','-arch','arm64','-isysroot',SDK]+shlex.split(opts['CMAKE_CXX_FLAGS_RELEASE'])+['-DSTRING_SHAPE='+str(shape)]
 for k,v in opts.items():
  if k.startswith(('DEXKIT_EXPERIMENT_','DEXKIT_BENCHMARK_','DEXKIT_ENABLE_')):command+=['-D'+k+'='+{'ON':'1','OFF':'0'}.get(v,v)]
 for directory in ['dexkit/include','third_party/slicer/export','third_party/thread_helper','third_party/aho_corasick_trie','third_party/parallel_hashmap','third_party/flatbuffers/include']:command+=['-I',str(ROOT/'Core'/directory)]
 archive=a/'build/Core/libdexkit_static.a';command+=[str(source),str(archive),'-lz','-o',str(exe)]
 with (d/'build.log').open('w') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
 shutil.copyfile(a/'libdexkit.dylib',d/'libdexkit.dylib')
 m['workload']={'source_sha256':sha(source),'shared_workload_sha256':sha(ROOT/'tools/qaux-benchmark/string_workload.cpp'),'shape':shape,'command':command,'archive_sha256':sha(archive),'executable_sha256':sha(exe),'native_artifact':str(a)}
 (d/'artifact.json').write_text(json.dumps(m,indent=2)+'\n');print('BUILT '+name,flush=True)
for fixture in ['small','broad']:
 f=BASE/'next-round/fixtures/strings-correctness-v1' if fixture=='small' else BASE/'string-inverse-v2/fixtures/broad'
 manifest=json.loads((f/'manifest.json').read_text())
 independent=json.loads((f/'oracle-rows.json').read_text()) if fixture=='small' else None
 baseline=None;root_count=None;flat_count=None
 for name,base,shape in variants:
  expected=[]
  for absent in [False,True]:
   values=[];seen=set()
   for dex,info in enumerate(manifest['dexes']):
    for method in info['methods']:
     if not method['defined']:continue
     descriptor=method['descriptor']
     refs=[base64.b64decode(v) for v in independent[dex]['method_rows'][descriptor]] if independent else [b'LongPrefix/'+b'x'*192+b'/Needle']*16
     match=any((b'AbsentEveryPool' if absent else b'Needle') in r for r in refs)
     if shape!=2:match=match and any(b'LongPrefix/' in r for r in refs) and any(b'Needle' in r for r in refs)
     if match and descriptor not in seen:seen.add(descriptor);values.append([dex,method['id'],descriptor])
   expected.append({'absent':absent,'values':values})
  d=OUT/'validation'/fixture/name;d.mkdir(parents=True)
  exe=OUT/'artifacts'/name/'build/Core/dexkit_string_workload'
  with (d/'stdout.bin').open('wb') as out,(d/'stderr.log').open('wb') as err:subprocess.run([str(exe),'--dump',str(f/'strings.apk')],stdout=out,stderr=err,check=True)
  actual=[json.loads(line) for line in re.findall(r'^SHAPE_RESULTS (.+)$',(d/'stderr.log').read_text(),re.M)]
  assert actual==expected,(fixture,name)
  data=(d/'stdout.bin').read_bytes();assert data
  if shape!=2:
   if baseline is None:baseline=data
   assert data==baseline;flat_count=len(actual[0]['values'])
  else:
   root_count=len(actual[0]['values'])
   assert (root_count>flat_count) if fixture=='small' else (data==baseline)
  records.append({'fixture':fixture,'name':name,'positive_count':len(actual[0]['values']),'negative_count':len(actual[1]['values']),'ordered_bytes_sha256':sha(d/'stdout.bin'),'passed':True})
  print('VERIFIED '+fixture+' '+name+' positive='+str(len(actual[0]['values'])),flush=True)
(OUT/'validation.json').write_text(json.dumps(records,indent=2)+'\n')
