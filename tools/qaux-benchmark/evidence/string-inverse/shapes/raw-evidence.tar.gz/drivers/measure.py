import json,subprocess,sys
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
OUT=BASE/'string-inverse-shapes-v1';(OUT/'formal').mkdir(exist_ok=True)
phase=sys.argv[1];assert phase in ['main','confirm']
seed=2026092000 if phase=='main' else 2026092100
records=[]
for name,labels in [('control-flatten',['control-nested','control-flat']),('inverse-flatten',['inverse-nested','inverse-flat']),('inverse-remove',['inverse-nested','inverse-root'])]:
 title=phase+'-'+name
 command=['python3','tools/qaux-benchmark/workload_sweep.py','--fixture',BASE/'string-inverse-v2/fixtures/broad/strings.apk','--output',OUT/'formal'/title,'--mode','string-nested-broad','--repeats','16','--pairs','6','--seed',str(seed)]
 for label in labels:command+=['--variant',label,OUT/'artifacts'/label]
 print('START '+title,flush=True)
 with (OUT/'formal'/(title+'.log')).open('w') as log:subprocess.run(list(map(str,command)),cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
 result=json.loads((OUT/'formal'/title/'summary.json').read_text())
 v=result['metrics']['lifecycle_ms'];print('DONE '+title+' '+str(v['median_change_percent'])+' '+str(v['bootstrap95_percent']),flush=True)
 records.append({'name':title,'command':list(map(str,command))});(OUT/'formal'/(phase+'-queue.json')).write_text(json.dumps(records,indent=2)+'\n');seed+=1
