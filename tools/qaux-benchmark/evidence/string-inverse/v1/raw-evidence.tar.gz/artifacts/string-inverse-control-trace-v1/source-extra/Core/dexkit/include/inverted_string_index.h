#pragma once

#include <algorithm>
#include <bit>
#include <cstdint>
#include <limits>
#include <vector>

namespace dexkit::inverted_string {

class Bits {
public:
    Bits() = default;
    explicit Bits(size_t count) : words((count + 63) / 64) {}
    void Set(size_t id) { words[id / 64] |= uint64_t{1} << (id % 64); }
    bool Has(size_t id) const { return words[id / 64] & (uint64_t{1} << (id % 64)); }
    void Or(const Bits &other) {
        for (size_t i = 0; i < words.size(); ++i) words[i] |= other.words[i];
    }
    void And(const Bits &other) {
        for (size_t i = 0; i < words.size(); ++i) words[i] &= other.words[i];
    }
    template<class Visit> void Each(Visit &&visit) const {
        for (size_t i = 0; i < words.size(); ++i) {
            auto word = words[i];
            while (word) {
                visit(static_cast<uint32_t>(i * 64 + std::countr_zero(word)));
                word &= word - 1;
            }
        }
    }
    size_t Bytes() const { return words.capacity() * sizeof(uint64_t); }
    std::vector<uint64_t> words;
};

class RankBits : public Bits {
public:
    RankBits() = default;
    explicit RankBits(size_t count) : Bits(count), prefix(words.size() + 1) {}
    void Finish() {
        for (size_t i = 0; i < words.size(); ++i) prefix[i + 1] = prefix[i] + std::popcount(words[i]);
    }
    uint32_t Rank(size_t id) const {
        const size_t word = id / 64, bit = id % 64;
        return prefix[word] + (bit ? std::popcount(words[word] & ((uint64_t{1} << bit) - 1)) : 0);
    }
    size_t Bytes() const { return Bits::Bytes() + prefix.capacity() * sizeof(uint32_t); }
    uint32_t Count() const { return prefix.empty() ? 0 : prefix.back(); }
private:
    std::vector<uint32_t> prefix;
};

// Built from a ready immutable forward index; no code bytes are decoded here.
// Each pass visits methods in ID order, deduplicating repeated const-string
// instructions. Counts are reused as exact row cursors in the second pass.
class Index {
public:
    template<class Forward> bool Build(size_t strings, size_t methods, const Forward &forward) {
        if (strings > UINT32_MAX || methods > UINT32_MAX) return false;
        std::vector<uint32_t> counts(strings), seen(strings, UINT32_MAX);
        uint64_t edges = 0;
        uint32_t used = 0, singles = 0;
        for (uint32_t method = 0; method < methods; ++method) {
            for (auto id : forward[method]) {
                if (seen[id] == method) continue;
                seen[id] = method;
                if (++edges > UINT32_MAX) return false;
                ++counts[id];
            }
        }
        for (auto count : counts) { used += count != 0; singles += count == 1; }
        narrow = methods <= uint64_t{UINT16_MAX} + 1;
        presence = RankBits(strings);
        multiple = RankBits(used);
        offsets.resize(static_cast<size_t>(used) - singles + 1);
        if (narrow) { one16.resize(singles); many16.resize(edges - singles); }
        else { one32.resize(singles); many32.resize(edges - singles); }
        uint32_t row = 0, one = 0, multi = 0, value = 0;
        for (uint32_t id = 0; id < strings; ++id) {
            const auto count = counts[id];
            if (!count) continue;
            presence.Set(id);
            if (count == 1) counts[id] = one++;
            else {
                multiple.Set(row);
                offsets[multi++] = value;
                counts[id] = value;
                value += count;
            }
            ++row;
        }
        offsets[multi] = value;
        presence.Finish();
        multiple.Finish();
        std::fill(seen.begin(), seen.end(), UINT32_MAX);
        for (uint32_t method = 0; method < methods; ++method) {
            for (auto id : forward[method]) {
                if (seen[id] == method) continue;
                seen[id] = method;
                const auto position = counts[id]++;
                const bool many = multiple.Has(presence.Rank(id));
                if (narrow) (many ? many16 : one16)[position] = static_cast<uint16_t>(method);
                else (many ? many32 : one32)[position] = method;
            }
        }
        ready = true;
        return true;
    }
    template<class Visit> void VisitRange(size_t begin, size_t end, Visit &&visit) const {
        const auto a = presence.Rank(begin), b = presence.Rank(end);
        const auto ma = multiple.Rank(a), mb = multiple.Rank(b);
        if (narrow) {
            for (size_t i = a - ma; i < b - mb; ++i) visit(one16[i]);
            for (size_t i = offsets[ma]; i < offsets[mb]; ++i) visit(many16[i]);
        } else {
            for (size_t i = a - ma; i < b - mb; ++i) visit(one32[i]);
            for (size_t i = offsets[ma]; i < offsets[mb]; ++i) visit(many32[i]);
        }
    }
    template<class Visit> void EachString(Visit &&visit) const { presence.Each(visit); }
    bool Ready() const { return ready; }
    bool Narrow() const { return narrow; }
    uint32_t UsedStrings() const { return presence.Count(); }
    size_t Singletons() const { return one16.size() + one32.size(); }
    size_t Edges() const { return Singletons() + many16.size() + many32.size(); }
    size_t Bytes() const {
        return presence.Bytes() + multiple.Bytes() + offsets.capacity() * sizeof(uint32_t)
            + (one16.capacity() + many16.capacity()) * sizeof(uint16_t)
            + (one32.capacity() + many32.capacity()) * sizeof(uint32_t);
    }
private:
    bool ready = false, narrow = false;
    RankBits presence, multiple;
    std::vector<uint32_t> offsets;
    std::vector<uint16_t> one16, many16;
    std::vector<uint32_t> one32, many32;
};

// Only the exact root using_strings predicate is cached. Recursive matching on
// another DEX, entity kind, or matcher vector always uses the existing matcher.
struct MatchScope {
    inline static thread_local const MatchScope *current = nullptr;
    const MatchScope *previous;
    const void *dex;
    const void *matchers;
    bool classes;
    const Bits *hits;
    MatchScope(const void *owner, const void *source, bool class_query, const Bits *bits)
        : previous(current), dex(owner), matchers(source), classes(class_query), hits(bits) { current = this; }
    ~MatchScope() { current = previous; }
    MatchScope(const MatchScope &) = delete;
    MatchScope &operator=(const MatchScope &) = delete;
};

} // namespace dexkit::inverted_string
