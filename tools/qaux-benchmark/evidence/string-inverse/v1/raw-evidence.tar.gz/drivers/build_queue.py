#!/usr/bin/env python3
import concurrent.futures
import json
from pathlib import Path
import subprocess
import sys
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
DATA=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/string-inverse-v1')
JDK='/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home'
NINE=['LAZY_DIRECTORIES','COMPACT_STRINGS','NEGATIVE_STRINGS','STRUCTURAL_DESCRIPTORS','DESCRIPTOR_FAST_HITS','RAW_INTERFACES','FIELD_IDENTITY_SPLIT','COMPACT_INVOKES','SINGLE_RELATION']
phase=sys.argv[1]
assert phase in ('normal','extra')
variants=[('string-inverse-control-v1',False,False,False,False),('string-inverse-inverse-v1',True,False,False,False)] if phase=='normal' else [
 ('string-inverse-control-trace-v1',False,True,False,False),('string-inverse-inverse-trace-v1',True,True,False,False),
 ('string-inverse-inverse-sanitized-v1',True,False,True,False),('string-inverse-inverse-standalone-v1',True,False,False,True)]
def run(spec):
 name,candidate,trace,sanitize,standalone=spec
 command=['python3','tools/qaux-benchmark/build_native.py','--source-root',str(ROOT),'--output',str(DATA/'artifacts'/name),'--java-home',JDK,'--jobs','3']
 definitions=['DEXKIT_BENCHMARK_STRING_WORKLOAD=ON','DEXKIT_BENCHMARK_BATCH_WORKLOAD=ON']
 if not standalone: definitions += ['DEXKIT_EXPERIMENT_'+n+'=ON' for n in NINE]
 if candidate: definitions += ['DEXKIT_EXPERIMENT_INVERTED_STRINGS=ON']
 if trace: definitions += ['DEXKIT_BENCHMARK_DIAGNOSTICS=ON']
 if sanitize: definitions += ['DEXKIT_BENCHMARK_DIAGNOSTICS=ON']
 if sanitize:
  flags='-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer'
  definitions += ['CMAKE_C_FLAGS_RELEASE='+flags,'CMAKE_CXX_FLAGS_RELEASE='+flags,
                  'CMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined','CMAKE_SHARED_LINKER_FLAGS=-fsanitize=address,undefined']
 for definition in definitions: command += ['--define',definition]
 print('START '+name,flush=True)
 log=DATA/'formal'/(name+'-build-launcher.log')
 with log.open('w') as out: subprocess.run(command,cwd=ROOT,stdout=out,stderr=subprocess.STDOUT,check=True)
 print('DONE '+name,flush=True)
 return {'name':name,'command':command}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 records=list(pool.map(run,variants))
(DATA/'formal'/('string-inverse-build-'+phase+'-queue.json')).write_text(json.dumps(records,indent=2)+'\n')
