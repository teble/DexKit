import hashlib,json,re,shlex,struct,subprocess,zipfile,zlib
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
OUT=BASE/'string-inverse-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
SDK=subprocess.check_output(['xcrun','--show-sdk-path'],text=True).strip()
records=[]
expected=None
for label in ['control-trace-v1','inverse-trace-v1','inverse-sanitized-v1']:
 a=OUT/'artifacts'/('string-inverse-'+label)
 d=OUT/'formal'/('budget-'+label);d.mkdir()
 m=json.loads((a/'artifact.json').read_text()); opts=m['cmake_options']
 source=ROOT/'tools/qaux-benchmark/inverted_string_budget_checks.cpp'
 command=[opts['CMAKE_CXX_COMPILER'],'-std=c++20','-pthread','-arch','arm64','-isysroot',SDK]+shlex.split(opts['CMAKE_CXX_FLAGS_RELEASE'])
 for key,value in opts.items():
  if key.startswith(('DEXKIT_EXPERIMENT_','DEXKIT_BENCHMARK_','DEXKIT_ENABLE_')):
   command+=['-D'+key+'='+{'ON':'1','OFF':'0'}.get(value,value)]
 for directory in ['dexkit/include','third_party/slicer/export','third_party/thread_helper','third_party/aho_corasick_trie','third_party/parallel_hashmap','third_party/flatbuffers/include']:
  command+=['-I',str(ROOT/'Core'/directory)]
 archive=a/'build/Core/libdexkit_static.a';exe=d/'checks'
 command+=[str(source),str(archive),'-lz','-o',str(exe)]
 with (d/'build.log').open('w') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('START budget '+label,flush=True)
 with (d/'stdout.bin').open('wb') as out,(d/'stderr.log').open('wb') as err:
  subprocess.run([str(exe),str(OUT/'fixtures/budget/strings.apk')],stdout=out,stderr=err,check=True,timeout=180)
 data=(d/'stdout.bin').read_bytes();assert data
 if expected is None:expected=data
 assert data==expected
 log=(d/'stderr.log').read_text()
 for phase in [0,1]:
  section=log.split('BUDGET_BEGIN phase='+str(phase)+'\n')[1].split('BUDGET_END phase='+str(phase)+'\n')[0]
  assert 'BENCH_STRING_INVERSE' not in section
 built=re.findall(r'^BENCH_STRING_INVERSE_INDEX ',log,re.M)
 assert len(built)==(0 if label.startswith('control') else 3)
 records.append({'label':label,'source_sha256':sha(source),'archive_sha256':sha(archive),'executable_sha256':sha(exe),'compile':command,'result_sha256':sha(d/'stdout.bin'),'passed':True})
 print('DONE budget '+label,flush=True)
(OUT/'formal/budget-checks.json').write_text(json.dumps(records,indent=2)+'\n')
fixture=OUT/'fixtures/reordered';fixture.mkdir()
with zipfile.ZipFile(BASE/'next-round/fixtures/strings-correctness-v1/strings.apk') as source,zipfile.ZipFile(fixture/'strings.apk','w') as dest:
 for name in source.namelist():
  data=bytearray(source.read(name));count,offset=struct.unpack_from('<2I',data,96)
  rows=[data[offset+i*32:offset+(i+1)*32] for i in range(count)]
  data[offset:offset+count*32]=b''.join(reversed(rows))
  data[12:32]=hashlib.sha1(data[32:]).digest();struct.pack_into('<I',data,8,zlib.adler32(data[12:])&0xffffffff)
  dest.writestr(name,data)
records=[]
for kind in ['string','batch']:
 expected=None
 for label in ['control-v1','inverse-v1','inverse-sanitized-v1']:
  a=OUT/'artifacts'/('string-inverse-'+label);d=OUT/'formal'/('reordered-'+kind+'-'+label);d.mkdir()
  exe=a/('build/Core/dexkit_'+kind+'_checks')
  print('START reordered '+kind+' '+label,flush=True)
  with (d/'stdout.bin').open('wb') as out,(d/'stderr.log').open('wb') as err:
   subprocess.run([str(exe),'--dump',str(fixture/'strings.apk')],stdout=out,stderr=err,check=True,timeout=180)
  data=(d/'stdout.bin').read_bytes();assert data
  if expected is None:expected=data
  assert data==expected
  if kind=='string':
   rows=[json.loads(line) for line in re.findall(r'^STRING_RESULTS (.+)$',(d/'stderr.log').read_text(),re.M)]
   ids=[row[1] for r in rows if r['classes'] and r['variant']==1 for row in r['results'] if row[0]==0]
   assert ids==sorted(ids,reverse=True) and ids!=sorted(ids)
  records.append({'kind':kind,'label':label,'executable_sha256':sha(exe),'fixture_sha256':sha(fixture/'strings.apk'),'result_sha256':sha(d/'stdout.bin'),'passed':True})
  print('DONE reordered '+kind+' '+label,flush=True)
(OUT/'formal/reordered-checks.json').write_text(json.dumps(records,indent=2)+'\n')
