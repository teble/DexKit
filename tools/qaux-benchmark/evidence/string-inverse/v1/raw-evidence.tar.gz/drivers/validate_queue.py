import json
from pathlib import Path
import subprocess
import sys
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
OUT=BASE/'string-inverse-v1'
phase=sys.argv[1]
labels=['control-v1','inverse-v1'] if phase=='normal' else ['control-trace-v1','inverse-trace-v1','inverse-sanitized-v1','inverse-standalone-v1']
records=[]
def run(name,cmd):
 print('START '+name,flush=True)
 with (OUT/'formal'/(name+'.log')).open('w') as log: subprocess.run(list(map(str,cmd)),cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
 records.append({'name':name,'command':list(map(str,cmd))})
 (OUT/'formal'/('validation-'+phase+'-queue.json')).write_text(json.dumps(records,indent=2)+'\n')
 print('DONE '+name,flush=True)
for label in labels:
 run('layout-'+label,[OUT/'artifacts'/('string-inverse-'+label)/'build/Core/dexkit_inverted_string_checks'])
for fixture in ['strings-correctness-v1','strings-correctness-wide-v1']:
 for kind in ['string','batch']:
  name=kind+'-'+fixture+'-'+phase
  cmd=['python3','tools/qaux-benchmark/validate_'+kind+'_checks.py','--fixture',BASE/'next-round/fixtures'/fixture,'--output',OUT/'formal'/name]
  for label in labels: cmd+=['--variant',label,OUT/'artifacts'/('string-inverse-'+label)]
  run(name,cmd)
