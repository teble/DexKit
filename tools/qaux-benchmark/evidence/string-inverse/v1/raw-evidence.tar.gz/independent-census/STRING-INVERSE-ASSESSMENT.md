# String-to-method index memory assessment

The frozen QQ 9.3.55 input can support an additional immutable string-to-method
index in approximately 5.35-7.90 MiB of array storage. A simple dense directory
with 16-bit local method IDs needs 13.64 MiB. A vector object for every pool
string costs 68.05 MiB with the observed capacity growth, before allocator
bookkeeping. These are representation budgets, not measured process peaks or
query speedups. No production engine source or query routing was changed.

## Input and measured cardinalities

Input APK SHA256:
851242d139bb01ed8c787eadc30d7ec391437de550c697b5f4c65c32ec84286f.
Repository source: 9432879fd55ede21abca925142d7cd882f8ae435.

| Quantity, summed across 41 DEXes | Count |
| --- | ---: |
| String pool entries, S | 2,575,010 |
| Raw const-string/jumbo occurrences | 2,071,884 |
| Distinct (local string ID, local method ID) edges, E | 2,001,450 |
| String IDs with at least one code reference, U | 949,982 |
| String IDs referenced by exactly one method, A | 713,828 |
| String IDs referenced by multiple methods, V | 236,154 |
| Methods with string references | 552,475 |
| All method ID entries | 2,600,031 |
| Maximum method ID table size in one DEX | 65,435 |
| Maximum string ID table size in one DEX | 98,092 |
| Maximum posting-list length | 8,836 |

Only 36.89% of pool strings have code references; 75.14% of nonempty postings
are singletons. Deduplicating repeated uses within a method removes 3.40% of
raw occurrences. Counts remain local to each DEX: identical text in different
DEXes is not merged. The existing forward index still preserves access order
and duplicates; none of its memory is subtracted from this additional budget.

The census reads ClassData and string instruction operands directly and reuses
the repository's instruction-width helper. Every DEX's raw-reference count,
code-method count and width-walk iteration count agree with the completed
engine diagnostics (1,921,832 code methods / 40,384,589 steps in total).
This assessment reader accepts only the frozen input's DEX 035 format; it is
not a new general-purpose DEX validation implementation.

## Candidate layouts

All byte figures include per-DEX array rounding and sentinels. They exclude
container-object headers for the few flat arrays, allocator/page overhead,
cache publication state, existing forward arrays, APK mapping and result data.
The vector-per-string row includes all of its per-string vector headers and
observed payload capacity. MiB means 1,048,576 bytes.

| Representation | Bytes | MiB | Status / tradeoff |
| --- | ---: | ---: | --- |
| Per-string vector, uint32 method IDs | 71,358,816 | 68.05 | Observed vector capacities; many small buffers and empty headers |
| Dense CSR, uint32 offsets and method IDs | 18,306,004 | 17.46 | Straight array model |
| Dense CSR, uint32 offsets / uint16 method IDs | 14,303,104 | 13.64 | Simple dense direct lookup |
| Sorted nonempty string keys + CSR16 | 11,602,920 | 11.07 | Saves empty offsets, adds key storage and key search |
| Presence bits + rank + CSR16 | 8,286,216 | 7.90 | Materialized and all point rows verified |
| Presence/rank + singleton split + CSR16 for other rows | 5,609,448 | 5.35 | Materialized; all point rows and 615 interval unions verified |
| Presence/rank + inline singleton descriptors | 7,330,704 | 6.99 | Byte model; simpler tag access but larger than split arrays |
| Singleton split + 16-bit first value and varint gaps | 4,977,129 | 4.75 | Byte model from actual sorted IDs; adds decoding, not query-tested |

Each DEX in this APK can store its local method IDs in uint16_t without loss.
A general implementation must check the local range and use uint32_t where
necessary. The 32-bit offsets also require checked total posting counts or
byte-stream sizes. No global encoded method IDs are narrowed to 16 bits.

## Why presence bits and rank help

A presence bitmap stores one bit per string ID. A uint32 prefix count per
64-bit word lets rank(i), the number of set bits before i, use one prefix
lookup and one popcount. No hash table or stored nonempty-string keys are
needed. A present string's compact row index is rank(string_id).

For a prefix ID interval [lo, hi), its nonempty row interval is simply
[rank(lo), rank(hi)). With normal CSR the corresponding posting payload is
contiguous, so candidate generation can scan that payload directly.

For the singleton split, a second bitmap marks which compact rows contain
multiple methods. Let a = rank(lo), b = rank(hi), and ma/mb be their ranks in
that second bitmap. The union comes from two contiguous spans:

* singleton IDs in [a - ma, b - mb);
* multi-method IDs in [multi_offsets[ma], multi_offsets[mb]).

Thus singletons need a 16-bit value but no individual offset. Multi-method
rows retain ordinary CSR offsets. The exact 5.35 MiB accounting is:

| Component | Bytes |
| --- | ---: |
| String presence bits | 322,040 |
| String presence rank directory | 161,184 |
| Multiple-reference row bits | 118,920 |
| Multiple-reference row rank directory | 59,624 |
| Singleton method IDs | 1,427,656 |
| Multi-method offsets | 944,780 |
| Multi-method IDs | 2,575,244 |
| Total | 5,609,448 |

Each ID in a posting denotes an actual code reference. The pool also includes
names and descriptors, so merely finding text in the pool is insufficient.
The [DEX format](https://source.android.com/docs/core/runtime/dex-format)
documents the pool's contents and ordering, which permit the earlier binary
search but do not provide this reverse relation.

## Construction and query scratch

Build from the already-ready forward rows, visiting methods in increasing
local method ID order. A first pass counts unique method/string associations;
prefix sums then allocate the final payload exactly. A second pass fills it
in order. A last-seen method array deduplicates within a method without per-row
sets. The count array can become the write cursor after offsets are created.
Sorted visitation removes the need to sort each final posting. Publication
must occur only after both passes and all directories are complete.

Two uint32 temporary arrays per active DEX cost 8*S_d bytes. Based on this APK:

* Serial construction scratch upper bound: 784,736 bytes, or 0.75 MiB.
* Four concurrent DEX builders: at most 2,822,960 bytes, or 2.69 MiB.
* Final split index plus those scratch bounds: approximately 6.10 / 8.04 MiB
  of additional accounted arrays, excluding the overheads stated above.

These assume temporaries are allocated inside each active DEX job and released
afterward, not allocated for all 41 DEXes upfront. No staging graph or repeatedly
growing final payload is necessary. These construction budgets have not been
measured as whole-process footprint in the engine.

Candidate-method deduplication can use an ordinary temporary bitmap: at most
8,184 bytes for one DEX here, about 32 KiB for four active tasks. Keeping all
DEX candidate bitmaps simultaneously would cost 325,192 bytes. Set-bit
enumeration gives local method-ID order; final descriptor deduplication,
cross-DEX order and findFirst policy must still use the existing result rules.

## Other compression choices

Raw uint16 posting payload is 4,002,900 bytes. Encoding every sorted list as
plain delta-varints uses 4,084,936 bytes: many first IDs require three bytes,
so that simple codec is slightly larger. Keeping the first ID as uint16 and
encoding only later gaps uses 3,370,581 bytes. In the split layout that saves
about 0.60 MiB, while adding decoding and reducing simple span access. Its
speed has not been measured.

The [Roaring format](https://github.com/RoaringBitmap/RoaringFormatSpec) uses
16-bit array, bitmap and run containers. Here only one of 949,982 nonempty
lists exceeds 4,096 methods; 94.85% contain at most four methods. Giving every
short posting a separate Roaring object adds metadata that these small arrays
do not need. This is an inference from this input distribution and the format,
not a CRoaring runtime memory benchmark.

An optimistic per-row minimum of uint16 array, a local-method bitmap and run
encoding saves only 52,796 payload bytes on this input. Even a two-bit tag for
every nonempty row costs more than that. Selective compression of exceptional
large rows remains possible, but it is not the main opportunity. A full
method bitmap for every referenced string would require about 7.15 GiB.

## Recommended implementation boundary

Use presence/rank + CSR16 as the simpler performance baseline, then compare
the 5.35 MiB singleton-split layout. Prefer flat immutable arrays with exact
allocation before trying per-posting hash tables or general compressed bitmap
objects. A small scratch candidate bitmap supports union, intersection and
ordered enumeration without large temporary sets.

The new index must feed candidate enumeration, not merely be queried inside
the old full method loop. It should be built on demand and reused. If existing
filters already leave very few methods, or the prefix covers a large share of
references, retain a direct-scan route. Composite/negative conditions can only
narrow candidates using proven necessary conditions; remaining checks preserve
the original query semantics.

This evaluation establishes input cardinalities and feasible memory layouts.
It does not establish a query speedup or a construction-time break-even point.
Those require an isolated engine prototype including first construction,
repeated queries, candidate combination/output and close.

## Reproduction

The adjacent census.cpp, assess.py, census.log and assessment.json preserve the
reader, formulas, per-DEX histograms, source/input fingerprints and checks.
Compile on the measured macOS host with:

```sh
/Library/Developer/CommandLineTools/usr/bin/c++ -O3 -std=c++20 -arch arm64 \
  -isysroot /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk \
  -mmacosx-version-min=11.0 \
  -I /Users/teble/project/android/DexKit-qaux-benchmark/Core/dexkit \
  -I /Users/teble/project/android/DexKit-qaux-benchmark/Core/third_party/slicer/export \
  census.cpp -o census
python3 assess.py
```
