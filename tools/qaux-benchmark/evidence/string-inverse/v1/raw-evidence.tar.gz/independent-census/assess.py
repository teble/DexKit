#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
OUT=BASE/'string-inverse-eval-v1'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def rank_bytes(n):
 words=(n+63)//64
 return 8*words+4*(words+1)
records=[]
with zipfile.ZipFile(BASE/'qq-9.3.55.apk') as archive:
 names=[n for n in archive.namelist() if re.fullmatch(r'classes(?:[0-9]+)?\.dex',n)]
 names.sort(key=lambda n:1 if n=='classes.dex' else int(n[7:-4]))
 for n in names:
  data=archive.read(n)
  completed=subprocess.run([str(OUT/'census')],input=data,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
  record=json.loads(completed.stdout)
  record.update(name=n,dex_sha256=hashlib.sha256(data).hexdigest(),dex_bytes=len(data))
  S=record['strings']; U=record['used_strings']; E=record['unique_edges']; A=record['singleton_strings']; V=U-A; M=record['method_ids']
  assert M<=65536 and E<2**32
  bits=rank_bytes(S)
  record['layout_bytes']={
   'vector_per_string_u32_capacity':record['vector_header_bytes']*S+4*record['vector_capacity_edges'],
   'dense_csr_u32':4*(S+1)+4*E,
   'dense_csr_u16':4*(S+1)+2*E,
   'sparse_keys_csr_u16':4*U+4*(U+1)+2*E,
   'presence_rank_csr_u16':bits+4*(U+1)+2*E,
   'presence_rank_singleton_split_u16':bits+rank_bytes(U)+4*(V+1)+2*E,
   'presence_rank_inline_singleton_u16':bits+4*U+2*(E-A)+2*V,
   'presence_rank_csr_delta_varint':bits+4*(U+1)+record['delta_varint_bytes'],
   'presence_rank_singleton_split_base16_delta_varint':bits+rank_bytes(U)+4*(V+1)+record['base16_delta_varint_bytes'],
   'presence_rank_csr_adaptive_u16_bitmap_run':bits+4*(U+1)+record['adaptive_payload_bytes']+(2*U+7)//8,
   'bitmap_per_referenced_string':U*((M+63)//64)*8,
  }
  record['construction_scratch_bytes']=8*S
  record['candidate_method_bitmap_bytes']=8*((M+63)//64)
  assert record['verified_presence_csr_bytes']==record['layout_bytes']['presence_rank_csr_u16']
  assert record['verified_singleton_split_bytes']==record['layout_bytes']['presence_rank_singleton_split_u16']
  records.append(record)
  print(n,'S',S,'U',U,'E',E,'singletons',A,flush=True)
total_keys=['strings','method_ids','classes','defined_methods','code_methods','referencing_methods','instruction_steps','raw_references','jumbo_references','used_strings','unique_edges','singleton_strings','vector_capacity_edges','delta_varint_bytes','base16_delta_varint_bytes','runs','adaptive_payload_bytes','dense_winning_lists','rle_winning_lists','verified_interval_queries']
totals={k:sum(r[k] for r in records) for k in total_keys}
totals['max_method_ids']=max(r['method_ids'] for r in records)
totals['max_string_ids']=max(r['strings'] for r in records)
totals['max_posting_degree']=max(r['max_degree'] for r in records)
hist={}
for r in records:
 for n,count in r['degree_histogram'].items(): hist[n]=hist.get(n,0)+count
totals['degree_histogram']=dict(sorted(hist.items(),key=lambda p:int(p[0])))
totals['layout_bytes']={k:sum(r['layout_bytes'][k] for r in records) for k in records[0]['layout_bytes']}
totals['construction_scratch_serial_upper_bound_bytes']=max(r['construction_scratch_bytes'] for r in records)
totals['construction_scratch_four_parallel_upper_bound_bytes']=sum(sorted((r['construction_scratch_bytes'] for r in records),reverse=True)[:4])
totals['candidate_method_bitmap_max_dex_bytes']=max(r['candidate_method_bitmap_bytes'] for r in records)
totals['candidate_method_bitmap_all_dexes_bytes']=sum(r['candidate_method_bitmap_bytes'] for r in records)
# Independent extraction order/parser; verify counts against the already completed engine census.
log=BASE/'next-round/formal/verify-rw-walk-tail-control-trace-v1/run.log'
raw=log.read_text()
growth=[json.loads(m) for m in re.findall(r'^BENCH_GROWTH (.+)$',raw,re.M)]
growth=[r for r in growth if r['phase']=='pre_close']; growth.sort(key=lambda r:r['dex'])
walks=[json.loads(m) for m in re.findall(r'^BENCH_INSTRUCTION_WALK (.+)$',raw,re.M)]; walks.sort(key=lambda r:r['dex'])
assert len(records)==len(growth)==len(walks)==41
for r,g,w in zip(records,growth,walks):
 assert r['raw_references']==g['ids'],r['name']
 assert r['code_methods']==w['methods'] and r['instruction_steps']==w['instructions'],r['name']
output=dict(scope='Read-only assessment of the frozen QQ 9.3.55 DEX 035 input. Count const-string/jumbo edges, deduplicate per method, sort postings for codec byte models. Structure sizes exclude allocator/page overhead, existing forward caches, result output and other process memory. No production index or query-speed measurement is implemented.',
 apk_sha256=sha(BASE/'qq-9.3.55.apk'),source_commit=subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip(),
 census_source_sha256=sha(OUT/'census.cpp'),census_executable_sha256=sha(OUT/'census'),driver_sha256=sha(Path(__file__)),
 opcode_width_header_sha256=sha(ROOT/'Core/dexkit/utils/opcode_util.h'),cross_check_log_sha256=sha(log),engine_counts_equal=True,
 records=records,totals=totals)
(OUT/'assessment.json').write_text(json.dumps(output,indent=2)+'\n')
print('TOTAL',json.dumps({k:v for k,v in totals.items() if k not in ('degree_histogram','layout_bytes')}),flush=True)
for k,v in totals['layout_bytes'].items(): print(k,v,round(v/2**20,5),'MiB',flush=True)
