#include <algorithm>
#include <bit>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <iterator>
#include <limits>
#include <map>
#include <vector>
#include "utils/opcode_util.h"

static void Require(bool ok, const char *message) {
    if (!ok) { std::fprintf(stderr, "census: %s\n", message); std::exit(2); }
}
struct Input {
    std::vector<uint8_t> bytes;
    void Check(size_t offset, size_t length) const {
        Require(offset <= bytes.size() && length <= bytes.size() - offset, "read bounds");
    }
    uint16_t U16(size_t offset) const {
        Check(offset, 2); return uint16_t(bytes[offset]) | (uint16_t(bytes[offset + 1]) << 8);
    }
    uint32_t U32(size_t offset) const {
        Check(offset, 4); return uint32_t(U16(offset)) | (uint32_t(U16(offset + 2)) << 16);
    }
    uint32_t Uleb(size_t &offset) const {
        uint32_t value = 0;
        for (unsigned i = 0; i < 5; ++i) {
            Check(offset, 1); const auto byte = bytes[offset++];
            if (i == 4) Require((byte & 0xf0) == 0, "ULEB overflow");
            value |= uint32_t(byte & 0x7f) << (7 * i);
            if (!(byte & 0x80)) return value;
        }
        Require(false, "ULEB termination"); return 0;
    }
};
static uint64_t VarintSize(uint32_t value) {
    uint64_t n = 1; while (value >= 128) { value >>= 7; ++n; } return n;
}
struct RankBits {
    std::vector<uint64_t> words;
    std::vector<uint32_t> prefix;
    explicit RankBits(size_t size) : words((size + 63) / 64), prefix(words.size() + 1) {}
    void Set(size_t index) { words[index / 64] |= uint64_t{1} << (index % 64); }
    bool Has(size_t index) const { return words[index / 64] & (uint64_t{1} << (index % 64)); }
    void Finish() { for (size_t i = 0; i < words.size(); ++i) prefix[i + 1] = prefix[i] + std::popcount(words[i]); }
    size_t Rank(size_t index) const {
        const size_t word = index / 64, bit = index % 64;
        return prefix[word] + (bit ? std::popcount(words[word] & ((uint64_t{1} << bit) - 1)) : 0);
    }
    size_t Bytes() const { return words.capacity() * 8 + prefix.capacity() * 4; }
};
struct LayoutCheck { size_t csr_bytes, split_bytes, intervals; };
static LayoutCheck CheckLayouts(const std::vector<std::vector<uint32_t>> &rows, size_t methods,
                               size_t used, size_t edges, size_t singletons) {
    Require(methods <= 65536 && edges <= UINT32_MAX, "16-bit assessment layout bounds");
    RankBits presence(rows.size()), multiple(used);
    std::vector<uint32_t> offsets(used + 1), multi_offsets(used - singletons + 1);
    std::vector<uint16_t> values(edges), one_values(singletons), multi_values(edges - singletons);
    size_t rank = 0, value = 0, one = 0, multi = 0, multi_value = 0;
    for (size_t id = 0; id < rows.size(); ++id) {
        const auto &row = rows[id]; if (row.empty()) continue;
        presence.Set(id); offsets[rank] = value;
        for (auto method : row) values[value++] = static_cast<uint16_t>(method);
        if (row.size() == 1) one_values[one++] = static_cast<uint16_t>(row[0]);
        else {
            multiple.Set(rank); multi_offsets[multi++] = multi_value;
            for (auto method : row) multi_values[multi_value++] = static_cast<uint16_t>(method);
        }
        ++rank;
    }
    offsets[used] = value; multi_offsets[multi] = multi_value; presence.Finish(); multiple.Finish();
    Require(rank == used && value == edges && one == singletons && multi == used - singletons && multi_value == edges - singletons, "complete packed fill");
    for (size_t id = 0; id < rows.size(); ++id) {
        const auto &row = rows[id]; Require(presence.Has(id) == !row.empty(), "packed presence matches");
        if (row.empty()) continue;
        const auto r = presence.Rank(id), m = multiple.Rank(r);
        Require(offsets[r + 1] - offsets[r] == row.size(), "CSR row length");
        Require(std::equal(row.begin(), row.end(), values.begin() + offsets[r]), "CSR row values");
        Require(multiple.Has(r) == (row.size() > 1), "singleton/multiple tag");
        if (!multiple.Has(r)) Require(one_values[r - m] == row[0], "singleton value");
        else {
            Require(multi_offsets[m + 1] - multi_offsets[m] == row.size(), "split row length");
            Require(std::equal(row.begin(), row.end(), multi_values.begin() + multi_offsets[m]), "split row values");
        }
    }
    std::vector<std::pair<size_t, size_t>> intervals{{0, 0}, {0, rows.size()}, {rows.size(), rows.size()}};
    uint32_t random = 20260915;
    for (size_t i = 0; i < 12; ++i) {
        random = random * 1664525U + 1013904223U; size_t a = random % (rows.size() + 1);
        random = random * 1664525U + 1013904223U; size_t b = random % (rows.size() + 1);
        intervals.emplace_back(std::min(a, b), std::max(a, b));
    }
    for (const auto &[lo, hi] : intervals) {
        std::vector<uint64_t> expected((methods + 63) / 64), actual(expected.size());
        for (size_t id = lo; id < hi; ++id) for (auto method : rows[id]) expected[method / 64] |= uint64_t{1} << (method % 64);
        const auto a = presence.Rank(lo), b = presence.Rank(hi), ma = multiple.Rank(a), mb = multiple.Rank(b);
        for (size_t i = a - ma; i < b - mb; ++i) { const auto method = one_values[i]; actual[method / 64] |= uint64_t{1} << (method % 64); }
        for (size_t i = multi_offsets[ma]; i < multi_offsets[mb]; ++i) { const auto method = multi_values[i]; actual[method / 64] |= uint64_t{1} << (method % 64); }
        Require(actual == expected, "split interval union equals raw postings");
    }
    return {presence.Bytes() + offsets.capacity() * 4 + values.capacity() * 2,
            presence.Bytes() + multiple.Bytes() + multi_offsets.capacity() * 4 + (one_values.capacity() + multi_values.capacity()) * 2,
            intervals.size()};
}
int main() {
    Input input{{std::istreambuf_iterator<char>(std::cin), std::istreambuf_iterator<char>()}};
    input.Check(0, 112);
    Require(std::memcmp(input.bytes.data(), "dex\n035\0", 8) == 0, "assessment input must be DEX 035");
    Require(input.U32(32) == input.bytes.size() && input.U32(36) == 112, "DEX size/header");
    Require(input.U32(40) == 0x12345678, "little endian DEX");
    const uint32_t strings = input.U32(56), methods = input.U32(88);
    const uint32_t classes = input.U32(96), classes_offset = input.U32(100);
    input.Check(classes_offset, uint64_t(classes) * 32);
    std::vector<std::vector<uint32_t>> postings(strings);
    std::vector<uint32_t> seen(strings, UINT32_MAX);
    std::vector<uint8_t> defined(methods);
    uint64_t definitions = 0, code_methods = 0, referencing_methods = 0, steps = 0, raw_refs = 0, jumbo_refs = 0;
    for (uint32_t c = 0; c < classes; ++c) {
        size_t cursor = input.U32(classes_offset + uint64_t(c) * 32 + 24);
        if (!cursor) continue;
        uint32_t sizes[4]; for (auto &size : sizes) size = input.Uleb(cursor);
        for (uint64_t i = 0; i < uint64_t(sizes[0]) + sizes[1]; ++i) { input.Uleb(cursor); input.Uleb(cursor); }
        for (unsigned kind = 2; kind < 4; ++kind) {
            uint32_t method = 0;
            for (uint32_t i = 0; i < sizes[kind]; ++i) {
                const auto delta = input.Uleb(cursor);
                Require(delta <= UINT32_MAX - method, "method delta overflow"); method += delta;
                input.Uleb(cursor); const auto code = input.Uleb(cursor);
                Require(method < methods && !defined[method], "unique defined method ID"); defined[method] = 1; ++definitions;
                if (!code) continue;
                ++code_methods; input.Check(code, 16);
                const auto units = input.U32(size_t(code) + 12);
                size_t p = size_t(code) + 16; const size_t end = p + uint64_t(units) * 2;
                input.Check(p, uint64_t(units) * 2); Require((p & 1) == 0, "instruction alignment");
                bool has_string = false;
                while (p < end) {
                    const auto word = input.U16(p); const auto op = word & 0xff;
                    if (word == dex::kPackedSwitchSignature || word == dex::kSparseSwitchSignature) Require(end - p >= 4, "switch payload bounds");
                    if (word == dex::kArrayDataSignature) Require(end - p >= 8, "array payload bounds");
                    const size_t width = dexkit::GetBytecodeWidth(reinterpret_cast<const dex::u2 *>(input.bytes.data() + p));
                    Require(width > 0 && width <= (end - p) / 2, "instruction width"); ++steps;
                    if (op == 0x1a || op == 0x1b) {
                        const uint32_t string = op == 0x1a ? input.U16(p + 2) : input.U32(p + 2);
                        Require(string < strings, "string ID bounds");
                        ++raw_refs; jumbo_refs += op == 0x1b; has_string = true;
                        if (seen[string] != method) { seen[string] = method; postings[string].push_back(method); }
                    }
                    p += width * 2;
                }
                Require(p == end, "complete instruction walk"); referencing_methods += has_string;
            }
        }
    }
    uint64_t used = 0, edges = 0, capacities = 0, singleton = 0, runs_total = 0, varints = 0, first_varints = 0;
    uint64_t adaptive_payload = 0, dense_lists = 0, rle_lists = 0, max_degree = 0;
    std::map<size_t, uint64_t> histogram;
    const uint64_t bitmap_bytes = ((uint64_t(methods) + 63) / 64) * 8;
    for (auto &row : postings) {
        capacities += row.capacity(); if (row.empty()) continue;
        std::sort(row.begin(), row.end());
        Require(std::adjacent_find(row.begin(), row.end()) == row.end(), "unique method/string association");
        const uint64_t n = row.size(); ++used; edges += n; singleton += n == 1; max_degree = std::max(max_degree, n); ++histogram[n];
        first_varints += VarintSize(row.front());
        uint64_t runs = 0; uint32_t previous = 0;
        for (size_t j = 0; j < row.size(); ++j) {
            varints += VarintSize(row[j] - previous);
            if (j == 0 || row[j] != previous + 1) ++runs;
            previous = row[j];
        }
        runs_total += runs;
        const uint64_t array_bytes = n * 2, run_bytes = 2 + runs * 4;
        const auto best = std::min({array_bytes, bitmap_bytes, run_bytes}); adaptive_payload += best;
        dense_lists += bitmap_bytes < array_bytes && bitmap_bytes <= run_bytes;
        rle_lists += run_bytes < array_bytes && run_bytes < bitmap_bytes;
    }
    const auto layout = CheckLayouts(postings, methods, used, edges, singleton);
    std::cout << "{\"strings\":" << strings << ",\"method_ids\":" << methods << ",\"classes\":" << classes
        << ",\"defined_methods\":" << definitions << ",\"code_methods\":" << code_methods << ",\"referencing_methods\":" << referencing_methods
        << ",\"instruction_steps\":" << steps << ",\"raw_references\":" << raw_refs << ",\"jumbo_references\":" << jumbo_refs
        << ",\"used_strings\":" << used << ",\"unique_edges\":" << edges << ",\"singleton_strings\":" << singleton
        << ",\"max_degree\":" << max_degree << ",\"vector_capacity_edges\":" << capacities << ",\"vector_header_bytes\":" << sizeof(std::vector<uint32_t>)
        << ",\"delta_varint_bytes\":" << varints << ",\"base16_delta_varint_bytes\":" << varints - first_varints + used * 2
        << ",\"verified_presence_csr_bytes\":" << layout.csr_bytes << ",\"verified_singleton_split_bytes\":" << layout.split_bytes
        << ",\"verified_interval_queries\":" << layout.intervals << ",\"runs\":" << runs_total << ",\"adaptive_payload_bytes\":" << adaptive_payload
        << ",\"dense_winning_lists\":" << dense_lists << ",\"rle_winning_lists\":" << rle_lists << ",\"degree_histogram\":{";
    bool first = true; for (const auto &[degree, count] : histogram) { if (!first) std::cout << ','; first = false; std::cout << '"' << degree << "\":" << count; }
    std::cout << "}}\n";
}
