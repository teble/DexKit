import hashlib,json,shutil,subprocess,tarfile
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
versions=[('v1','3ccb765c5d81efa3441af8e3ade80ce5c9d57f84',24,288),('v2','cc9f893ce30ad4a31f5c5e0cf19ef338e8b15086',26,312)]
tools=['build_native.py','run.py','sweep.py','workload_sweep.py','QueryReplay.java','force_tests.gradle','make_symbol_fixture.py','make_string_fixture.py','make_batch_fixture.py','make_relation_fixture.py','string_queries.h','string_checks.cpp','string_workload.cpp','batch_queries.h','batch_checks.cpp','batch_workload.cpp','validate_string_checks.py','validate_batch_checks.py','inverted_string_checks.cpp']
for version,revision,sweeps,samples in versions:
 data=BASE/('string-inverse-'+version);out=ROOT/'tools/qaux-benchmark/evidence/string-inverse'/version
 out.mkdir(parents=True,exist_ok=True);assert not any(out.iterdir())
 summary=json.loads((data/'formal/summary.json').read_text());assert summary['sweeps']==sweeps and summary['samples']==samples
 for src,dest in [('summary.json','summary.json'),('diagnostics-summary.json','diagnostics-summary.json'),('source-identity.json','source-identity.json')]:shutil.copyfile(data/'formal'/src,out/dest)
 files={}
 def add(path,name):
  assert path.is_file() and name not in files,(path,name)
  files[name]=path
 for path in sorted((data/'formal').rglob('*')):
  if path.is_file() and path.suffix not in ('.class','.aar','.dylib','.so','.a','.o') and path.name!='checks':add(path,str(path.relative_to(data)))
 for artifact in sorted((data/'artifacts').iterdir()):
  m=json.loads((artifact/'artifact.json').read_text());assert m['native_sha256']==sha(artifact/'libdexkit.dylib')
  for name in ['artifact.json','CMakeCache.txt','source.patch','build.log']:
   if (artifact/name).is_file():add(artifact/name,str((artifact/name).relative_to(data)))
  if (artifact/'source-extra').exists():
   for path in sorted((artifact/'source-extra').rglob('*')):
    if path.is_file():add(path,str(path.relative_to(data)))
 for path in sorted(data.glob('*.py')):add(path,'drivers/'+path.name)
 for name in ['strings-correctness-v1','strings-correctness-wide-v1','strings-late-v3','strings-prefix-late-v1','batch-overlap-v1','batch-miss-v1']:
  for path in sorted((BASE/'next-round/fixtures'/name).iterdir()):
   if path.is_file():add(path,'shared-fixtures/'+name+'/'+path.name)
 for path in sorted((data/'fixtures').rglob('*')):
  if path.is_file():add(path,str(path.relative_to(data)))
 if version=='v2':
  for path in sorted((BASE/'string-inverse-v1/fixtures/budget').iterdir()):
   if path.is_file():add(path,'shared-fixtures/budget/'+path.name)
 names=tools+(['inverted_string_budget_checks.cpp','string_inverse_integration_checks.cpp','make_string_inverse_fixture.py'] if version=='v2' else [])
 for name in names:
  target=data/'archived-sources'/name;target.parent.mkdir(parents=True,exist_ok=True)
  target.write_bytes(subprocess.check_output(['git','-C',str(ROOT),'show',revision+':tools/qaux-benchmark/'+name]))
  add(target,'measurement-source/'+name)
 if version=='v2':
  add(ROOT/'tools/qaux-benchmark/string_nested_shape_checks.cpp','extra-check-source/string_nested_shape_checks.cpp')
 # The extra v1 budget checker was linked after freezing the engine, and was
 # committed with the budget revision. Keep its actual source explicitly.
 if version=='v1':
  target=data/'archived-sources/inverted_string_budget_checks.cpp'
  target.write_bytes(subprocess.check_output(['git','-C',str(ROOT),'show',versions[1][1]+':tools/qaux-benchmark/inverted_string_budget_checks.cpp']))
  add(target,'extra-check-source/inverted_string_budget_checks.cpp')
 for name in ['assessment.json','assess.py','census.cpp','census.log','STRING-INVERSE-ASSESSMENT.md']:
  path=BASE/'string-inverse-eval-v1'/name
  if path.is_file():add(path,'independent-census/'+name)
 add(ROOT/'tools/qaux-benchmark/baseline/expected.json','frozen-qq-expected.json')
 archive=out/'raw-evidence.tar.gz'
 with tarfile.open(archive,'w:gz') as tar:
  for name,path in sorted(files.items()):tar.add(path,arcname=name,recursive=False)
 manifest={'version':version,'measurement_source_commit':revision,'sweeps':sweeps,'samples':samples,'archive_sha256':sha(archive),
  'files':{name:sha(path) for name,path in sorted(files.items())},
  'scope':'Complete paired sweeps, verification, independent fixture oracles, diagnostics, source reconstruction, sanitizer/standalone and JVM/four-ABI records, synthetic fixtures and reproduction sources. Proprietary QQ APK, JVM classes, native binaries/archives/executables and AAR binaries are excluded; their identities remain recorded. v1 is the pre-review prototype; v2 is the corrected final engine.'}
 (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 with tarfile.open(archive,'r:gz') as tar:
  assert set(tar.getnames())==set(files)
  for member in tar:assert hashlib.sha256(tar.extractfile(member).read()).hexdigest()==manifest['files'][member.name]
 print(json.dumps({'version':version,'files':len(files),'bytes':archive.stat().st_size,'sha256':manifest['archive_sha256']}),flush=True)
