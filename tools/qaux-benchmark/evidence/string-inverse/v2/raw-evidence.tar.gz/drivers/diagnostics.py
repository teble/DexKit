import hashlib,json,re
from pathlib import Path
BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
assessment=BASE/'string-inverse-eval-v1/assessment.json'
a=json.loads(assessment.read_text())
for version in ['v1','v2']:
 out=BASE/('string-inverse-'+version)
 log=out/'formal'/('verify-string-inverse-inverse-trace-'+version)/'run.log'
 text=log.read_text()
 parse=lambda pattern:[{k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',line)} for line in re.findall(pattern,text,re.M)]
 indexes=parse(r'^BENCH_STRING_INVERSE_INDEX .+$');queries=parse(r'^BENCH_STRING_INVERSE_QUERY .+$')
 assert len(indexes)==41 and {r['dex'] for r in indexes}==set(range(41))
 by_dex={r['dex']:r for r in indexes}
 for dex,expected in enumerate(a['records']):
  row=by_dex[dex]
  assert row['ready']==1 and row['narrow']==1
  for key,other in [('bytes','verified_singleton_split_bytes'),('scratch_bytes','construction_scratch_bytes'),('used','used_strings'),('singletons','singleton_strings'),('edges','unique_edges')]:assert row[key]==expected[other],(dex,key)
 assert len(queries)==1353
 for dex,index in by_dex.items():
  rows=[r for r in queries if r['dex']==dex];assert len(rows)==33
  assert all(r['strings']==index['used'] and r['classes']==0 for r in rows)
  assert len({r['bytes'] for r in rows})==1
 budget_key='bitmap_bytes' if version=='v1' else 'bitmap_budget_bytes'
 report={'version':version,'index_dexes':41,'index_array_capacity_bytes':sum(r['bytes'] for r in indexes),
  'used_strings':sum(r['used'] for r in indexes),'distinct_edges':sum(r['edges'] for r in indexes),'singletons':sum(r['singletons'] for r in indexes),
  'max_per_dex_construction_scratch_bytes':max(r['scratch_bytes'] for r in indexes),
  'four_largest_dex_scratch_sum_bytes':sum(sorted(r['scratch_bytes'] for r in indexes)[-4:]),
  'ac_jobs':len(queries),'total_ac_string_visits':sum(r['strings'] for r in queries),
  'max_per_dex_bitmap_budget_bytes':max(r[budget_key] for r in queries),
  'note':'Each logged AC job scans exactly the referenced distinct string IDs of its DEX. QQ has no optimized class-query jobs. Bitmap bytes are a per-job formula, not observed capacity or process peak. Control already has negative-only memoization; raw forward-reference counts are not its actual AC call count.',
  'assessment_sha256':hashlib.sha256(assessment.read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),
  'indexes':sorted(indexes,key=lambda r:r['dex']),'queries':queries,'passed':True}
 (out/'formal/diagnostics-summary.json').write_text(json.dumps(report,indent=2)+'\n')
 print(version,{k:v for k,v in report.items() if not isinstance(v,(list,dict))})
