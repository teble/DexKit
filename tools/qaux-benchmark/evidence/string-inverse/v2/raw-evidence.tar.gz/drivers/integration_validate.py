import hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
OUT=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/string-inverse-v2')
records=[];expected=None
for label in ['control-trace-v2','inverse-trace-v2','inverse-sanitized-v2','inverse-standalone-v2']:
 d=OUT/'formal'/('integration-'+label);d.mkdir()
 a=OUT/'artifacts'/('string-inverse-'+label);exe=a/'build/Core/dexkit_string_inverse_integration_checks'
 command=[str(exe),str(OUT/'fixtures/integration/strings.apk')]
 print('START '+label,flush=True)
 with (d/'stdout.bin').open('wb') as out,(d/'stderr.log').open('wb') as err:subprocess.run(command,stdout=out,stderr=err,check=True,timeout=90)
 data=(d/'stdout.bin').read_bytes();assert data
 if expected is None:expected=data
 assert data==expected
 log=(d/'stderr.log').read_text()
 for attempt in range(4):
  section=log.split('INVERSE_FIRST_CONCURRENT_BEGIN attempt='+str(attempt)+'\n')[1].split('INVERSE_FIRST_CONCURRENT_END attempt='+str(attempt)+'\n')[0]
  ids=re.findall(r'^BENCH_STRING_INVERSE_INDEX dex=(\d+)',section,re.M)
  assert sorted(ids)==([] if label.startswith('control') else ['0','1'])
 records.append({'label':label,'command':command,'executable_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'result_sha256':hashlib.sha256(data).hexdigest(),'queries':8,'fresh_concurrent_bridges':4,'passed':True})
 print('DONE '+label,flush=True)
(OUT/'formal/integration-checks.json').write_text(json.dumps(records,indent=2)+'\n')
