import hashlib,json,re,shlex,subprocess
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
OUT=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/string-inverse-v2')
SDK=subprocess.check_output(['xcrun','--show-sdk-path'],text=True).strip()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
records=[]
for label in ['control-v2','inverse-v2','inverse-sanitized-v2','inverse-standalone-v2']:
 a=OUT/'artifacts'/('string-inverse-'+label);d=OUT/'formal'/('nested-shape-'+label);d.mkdir()
 m=json.loads((a/'artifact.json').read_text());opts=m['cmake_options'];source=ROOT/'tools/qaux-benchmark/string_nested_shape_checks.cpp'
 command=[opts['CMAKE_CXX_COMPILER'],'-std=c++20','-pthread','-arch','arm64','-isysroot',SDK]+shlex.split(opts['CMAKE_CXX_FLAGS_RELEASE'])
 for key,value in opts.items():
  if key.startswith(('DEXKIT_EXPERIMENT_','DEXKIT_BENCHMARK_','DEXKIT_ENABLE_')):command+=['-D'+key+'='+{'ON':'1','OFF':'0'}.get(value,value)]
 for directory in ['dexkit/include','third_party/slicer/export','third_party/thread_helper','third_party/aho_corasick_trie','third_party/parallel_hashmap','third_party/flatbuffers/include']:command+=['-I',str(ROOT/'Core'/directory)]
 archive=a/'build/Core/libdexkit_static.a';exe=d/'checks';command+=[str(source),str(archive),'-lz','-o',str(exe)]
 with (d/'build.log').open('w') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('START '+label,flush=True)
 with (d/'stdout.log').open('w') as out,(d/'stderr.log').open('w') as err:subprocess.run([str(exe),str(OUT/'fixtures/broad/strings.apk')],stdout=out,stderr=err,check=True,timeout=180)
 reports=[json.loads(line) for line in (d/'stdout.log').read_text().splitlines() if line.startswith('{')]
 assert reports==[{'passes':16,'positive_per_pass':4500,'negative_per_pass':0,'complete_ordered_ids_and_descriptors':True}]
 records.append({'label':label,'source_sha256':sha(source),'workload_source_sha256':sha(ROOT/'tools/qaux-benchmark/string_workload.cpp'),'archive_sha256':sha(archive),'executable_sha256':sha(exe),'compile':command,'report':reports[0],'passed':True})
 print('DONE '+label,flush=True)
manifest=json.loads((OUT/'fixtures/broad/manifest.json').read_text())
methods=manifest['dexes'][0]['methods'];assert len(methods)==4500
expected_checksum=16*sum(m['id']+len(m['descriptor']) for m in methods)
for phase in ['main','confirm']:
 path=OUT/'formal'/('string-inverse-native-'+phase+'-broad-string-nested-broad')
 rows=json.loads((path/'samples.json').read_text());assert len(rows)==12
 for row in rows:assert row['report']['returned']==72000 and row['report']['checksum']==expected_checksum
(OUT/'formal/nested-shape-checks.json').write_text(json.dumps({'records':records,'all_24_timed_samples_match_expected_aggregate':True,'expected_checksum':expected_checksum},indent=2)+'\n')
