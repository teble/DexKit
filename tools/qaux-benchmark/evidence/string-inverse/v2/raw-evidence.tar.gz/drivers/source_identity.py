import hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(ROOT),*args])
NINE={'LAZY_DIRECTORIES','COMPACT_STRINGS','NEGATIVE_STRINGS','STRUCTURAL_DESCRIPTORS','DESCRIPTOR_FAST_HITS','RAW_INTERFACES','FIELD_IDENTITY_SPLIT','COMPACT_INVOKES','SINGLE_RELATION'}
for version,target in [('v1','3ccb765c5d81efa3441af8e3ade80ce5c9d57f84'),('v2','cc9f893ce30ad4a31f5c5e0cf19ef338e8b15086')]:
 out=BASE/('string-inverse-'+version);records=[]
 for path in sorted((out/'artifacts').iterdir()):
  m=json.loads((path/'artifact.json').read_text());extras=m.get('untracked_source_sha256',{})
  assert sha(path/'libdexkit.dylib')==m['native_sha256']
  diff=git('diff',m['engine_commit'],target,'--',*m['source_trees'],*[':(exclude)'+name for name in extras]).strip()
  assert diff==(path/'source.patch').read_bytes().strip(),path
  for name,digest in extras.items():
   assert hashlib.sha256(git('show',target+':'+name)).hexdigest()==digest
   assert sha(path/'source-extra'/name)==digest
  enabled={k.removeprefix('DEXKIT_EXPERIMENT_') for k,v in m['cmake_options'].items() if k.startswith('DEXKIT_EXPERIMENT_') and v=='ON'}
  expected=set() if 'standalone' in path.name else set(NINE)
  if '-inverse-' in path.name.removeprefix('string-inverse-'):expected.add('INVERTED_STRINGS')
  # Artifact suffix begins with inverse (the prefix also contains the word).
  if path.name.removeprefix('string-inverse-').startswith('inverse'):expected.add('INVERTED_STRINGS')
  assert enabled==expected,(path,enabled,expected)
  normal=path.name in ['string-inverse-control-'+version,'string-inverse-inverse-'+version]
  if normal:
   assert not m['diagnostics']
   assert all(m['cmake_options'][key]=='OFF' for key in ['DEXKIT_ENABLE_INTERNAL_METRICS','DEXKIT_ENABLE_INTERNAL_METRICS_API','DEXKIT_BENCHMARK_DIAGNOSTICS','DEXKIT_BENCHMARK_STRING_TRACE','DEXKIT_BENCHMARK_BATCH_TRACE','DEXKIT_BENCHMARK_FIELD_TRACE'])
  records.append({'artifact':path.name,'built_base':m['engine_commit'],'reconstructed_source_commit':target,'native_sha256':m['native_sha256'],'enabled_experiments':sorted(enabled),'normal_measurement':normal,'passed':True})
 (out/'formal/source-identity.json').write_text(json.dumps(records,indent=2)+'\n')
 print(version,len(records),'source reconstructions passed')
