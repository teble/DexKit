import json,sys
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
DATA=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/string-inverse-v2')
sys.path.insert(0,str(ROOT/'tools/qaux-benchmark'))
from sweep import summarize
summaries={};stages={};total=0
for phase in ['main','confirm']:
 queue=json.loads((DATA/'formal'/('string-inverse-'+phase+'-queue.json')).read_text())
 assert len(queue)==13
 for run in queue:
  path=DATA/'formal'/run['name'];result=json.loads((path/'summary.json').read_text());rows=json.loads((path/'samples.json').read_text())
  assert len(rows)==12 and result['pairs']==6
  assert {(r['pair'],r['label']) for r in rows}=={(p,label) for p in range(6) for label in ['control','inverse']}
  summaries[run['name']]=result['metrics'];total+=len(rows)
  if not run['name'].startswith('string-inverse-qq-'):continue
  detail=[]
  for row in rows:
   report=json.loads((path/('pair-%02d-%s'%(row['pair'],row['label']))/'report.json').read_text())
   measured={'pair':row['pair'],'label':row['label'],'position':row['position']}
   for batch in [True,False]:
    for first in [True,False]:
     selected=[s for s in report['stages'] if (s['stage']=='batch_strings')==batch and (s['pass']==0)==first]
     if not selected:continue
     name=('batch' if batch else 'chain_api')+('_first_ms' if first else '_warm_per_pass_ms')
     if batch:assert all(s['group_count']==149 for s in selected)
     measured[name]=sum(s['api_ns'] for s in selected)/1e6/(1 if first else report['passes']-1)
   for s in report['stages']:
    tag=s['feature']+'__'+s['stage']+('_first_ms' if s['pass']==0 else '_warm_per_pass_ms')
    measured[tag]=measured.get(tag,0)+s['api_ns']/1e6/(1 if s['pass']==0 else report['passes']-1)
   detail.append(measured)
  metrics=[k for k in detail[0] if k.endswith('_ms')]
  stages[run['name']]={'rows':detail,'metrics':summarize(detail,['control','inverse'],6,result['seed']+411,metrics)}
assert len(summaries)==26 and total==312
output={'sweeps':26,'samples':total,'metrics':summaries,'qq_stages':stages}
(DATA/'formal/summary.json').write_text(json.dumps(output,indent=2)+'\n')
for name,values in summaries.items():
 print(name)
 for key in ['lifecycle_ms','pass0_api_ms','repeated_api_ms','positive_ms','negative_ms','peak_footprint_bytes']:
  if key in values:
   v=values[key];print(key,round(v['median_change_percent'],2),[round(x,2) for x in v['bootstrap95_percent']],{label:round(s['median'],3) for label,s in v['variants'].items()})
for name,record in stages.items():
 print(name,'STAGES')
 for key in ['batch_first_ms','batch_warm_per_pass_ms','chain_api_first_ms','chain_api_warm_per_pass_ms']:
  if key in record['metrics']:
   v=record['metrics'][key];print(key,round(v['median_change_percent'],2),[round(x,2) for x in v['bootstrap95_percent']],{label:round(s['median'],3) for label,s in v['variants'].items()})
