#!/usr/bin/env python3
import json
from pathlib import Path
import subprocess
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
DATA=BASE/'string-inverse-v2'
JDK='/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home'
records=[]
def run(name, command):
 command=list(map(str,command)); print('START '+name,flush=True)
 with (DATA/'formal'/(name+'-launcher.log')).open('w') as output:
  subprocess.run(command,cwd=ROOT,stdout=output,stderr=subprocess.STDOUT,check=True)
 records.append({'name':name,'command':command})
 (DATA/'formal'/'string-inverse-validation-queue-v1.json').write_text(json.dumps(records,indent=2)+'\n')
 print('DONE '+name,flush=True)
for label in ['control','inverse','inverse-trace']:
 name='verify-string-inverse-'+label+'-v2'
 command=['python3','tools/qaux-benchmark/run.py','--dexkit-root',ROOT,'--corpus',BASE/'qaux-extracted','--apk',BASE/'qq-9.3.55.apk',
  '--java-home',JDK,'--memory-probe',BASE/'artifacts/probe-v2/libqauxbench_probe.dylib','--output',DATA/'formal'/name,
  '--native-library',DATA/'artifacts'/('string-inverse-'+label+'-v2')/'libdexkit.dylib','--passes','11','--threads','4','--profile','all','--mode','verify']
 run(name,command)
