import hashlib,json,subprocess,sys
from pathlib import Path
from cases import BASE,E,CASES,native_command
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
V=E/'validation'
record_path=V/'census-checks.json'
records=json.loads(record_path.read_text()) if record_path.exists() else []

def run(name,command):
 path=V/(name+'.log');command=list(map(str,command))
 old=next((r for r in records if r['name']==name),None)
 if old:
  assert old['command']==command and old['sha256']==hashlib.sha256(path.read_bytes()).hexdigest()
  return path
 print('START '+name,flush=True)
 with path.open('w') as log:subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=300,check=True)
 records.append(dict(name=name,command=command,sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
 record_path.write_text(json.dumps(records,indent=2)+'\n')
 print('DONE '+name,flush=True)
 return path

def rows(path,prefix):
 return [json.loads(line[len(prefix):]) for line in path.read_text().splitlines() if line.startswith(prefix)]

def descriptor_counts(path):
 result=[];previous=None
 for line in path.read_text().splitlines():
  if line.startswith('BENCH_DESCRIPTOR_ACCESS '):previous=json.loads(line.split(' ',1)[1])
  elif line.startswith('BENCH_DESCRIPTOR '):
   value=json.loads(line.split(' ',1)[1])
   if 'reason' not in value:continue
   assert previous and previous['reason']==value['reason']
   result.append(dict(previous,**{k:v for k,v in value.items() if k!='reason'}))
   previous=None
 return result

def uncached_invariants(path):
 census=rows(path,'BENCH_CENSUS ')
 caches=[r for r in census if r.get('category')=='descriptors']
 assert caches
 for r in caches:
  for key in ['index_bytes','payload_capacity_bytes','entries','nonempty_or_ready','live_buffers']:assert r[key]==0,(key,r)
 assert not any(r.get('category')=='descriptor_publication' and r['index_bytes'] for r in census)
 assert not rows(path,'BENCH_VECTOR_DESCRIPTOR_DOMAIN ')
 counts=descriptor_counts(path);assert counts
 for r in counts:
  for kind in ['method','field']:
   assert r[kind+'_calls']==r[kind+'_builds'] and r[kind+'_hits']==0,r
 return caches,counts

if sys.argv[1]=='native':
 summary=[]
 for label in ['uncached-trace','raw-dense-trace','vector-trace']:
  for case in CASES:
   path=run('census-'+label+'-'+case['name'],native_command(label,case))
   report=rows(path,'WORKLOAD ');assert len(report)==1
   counts=descriptor_counts(path)
   final=[r for r in counts if r['phase'].endswith('workload-complete')]
   assert len(final)==3
   entry=dict(label=label,case=case['name'],report=report[0],access=final)
   if label=='uncached-trace':
    caches,_=uncached_invariants(path);entry['persistent_cache']=caches
    builds=sum(r['method_builds']+r['field_builds'] for r in final)
    extra=2 if case['mode']=='lookup-hot' else 1 if case['mode'] in ['lookup','lookup-prefix'] else 0
    assert builds==report[0]['returned']+extra,(case['name'],builds,report[0]['returned'],extra)
    if case['mode'].startswith('transition-'):
     _,kind,pattern,workers=case['mode'].split('-');n=case['repeats'];w=int(workers[1:])
     unique=60000 if pattern=='full' else 30000 if pattern=='changed' else 64
     output=next(r for r in final if r['reason']=='output')
     other='field' if kind=='method' else 'method'
     assert output[kind+'_builds']==unique*n*w and output[other+'_builds']==0
   elif label=='vector-trace':
    domains=[r for r in rows(path,'BENCH_VECTOR_DESCRIPTOR_DOMAIN ') if r['phase'].endswith('workload-complete')]
    maintenance=[r for r in rows(path,'BENCH_VECTOR_DESCRIPTOR_MAINTENANCE ') if r['phase'].endswith('workload-complete')]
    assert domains and len(maintenance)==1
    for d in domains:
     assert d['calls']-d['hits']==d['sparse_builds']+d['dense_builds']
     assert d['records']==d['sparse_records']+d['dense_builds']
     if d['dense']:
      assert d['conversions']==1 and not d['pending']
      assert all(d[k]==0 for k in ['bucket_bytes','payload_owner_bytes','block_bytes','directory_bytes','sparse_char_bytes','sparse_structural_bytes'])
    entry.update(domains=domains,maintenance=maintenance[0])
   summary.append(entry)
 (V/'census-native.json').write_text(json.dumps(summary,indent=2)+'\n')
 print('COMPLETE native census '+str(len(summary)),flush=True)
else:
 assert sys.argv[1]=='qq'
 jdk='/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home'
 plans=[('uncached-trace',False),('raw-dense-trace',False),('vector-trace',False),('uncached',True),('control',True)]
 summaries=[]
 for label,tail in plans:
  name='verify-'+label+('-tail' if tail else '-census')+'-w4'
  command=['python3',ROOT/'tools/qaux-benchmark/run.py','--dexkit-root',ROOT,'--corpus',BASE/'qaux-extracted',
    '--apk',BASE/'qq-9.3.55.apk','--java-home',jdk,'--memory-probe',BASE/'artifacts/probe-v2/libqauxbench_probe.dylib',
    '--output',V/name,'--native-library',E/'artifacts'/label/'libdexkit.dylib','--passes','11','--threads','4','--profile','all','--mode','verify']
  if tail:command+=['--final-field-rw','Lcom/tencent/mobileqq/data/MessageRecord;->msg:Ljava/lang/String;',
    '--field-rw-expected',BASE/'followup/formal/field-tail-oracle-best5/field-rw-expected.json']
  run(name,command)
  metadata=json.loads((V/name/'run-metadata.json').read_text());assert metadata['baseline_results_equal'] is True
  if tail:assert metadata['final_field_rw_results_equal'] is True
  else:
   path=V/name/'run.log'
   entry=dict(label=label,access=descriptor_counts(path),census=rows(path,'BENCH_CENSUS '))
   if label=='uncached-trace':uncached_invariants(path)
   elif label=='vector-trace':
    entry['domains']=rows(path,'BENCH_VECTOR_DESCRIPTOR_DOMAIN ')
    entry['maintenance']=rows(path,'BENCH_VECTOR_DESCRIPTOR_MAINTENANCE ')
    assert entry['domains']
   summaries.append(entry)
 (V/'census-qq.json').write_text(json.dumps(summaries,indent=2)+'\n')
 print('COMPLETE QQ census and field-tail oracles',flush=True)
