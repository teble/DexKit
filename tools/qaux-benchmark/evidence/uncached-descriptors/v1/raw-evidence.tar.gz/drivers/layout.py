import hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
E=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/uncached-descriptors-v1')
OUT=E/'validation/layout';OUT.mkdir(exist_ok=True)
source=OUT/'layout.cpp'
source.write_text('''#include "beans.h"
#include <type_traits>
#if DEXKIT_EXPERIMENT_UNCACHED_DESCRIPTORS
static_assert(std::is_same_v<dexkit::MemberDescriptor, std::string>);
#else
static_assert(std::is_same_v<dexkit::MemberDescriptor, std::string_view>);
#endif
extern "C" {
char method_bean[sizeof(dexkit::MethodBean)];
char field_bean[sizeof(dexkit::FieldBean)];
char class_bean[sizeof(dexkit::ClassBean)];
char string_object[sizeof(std::string)];
char string_view_object[sizeof(std::string_view)];
}
''')
ndk=Path('/Users/teble/Library/Android/sdk/ndk/26.1.10909125/toolchains/llvm/prebuilt/darwin-x86_64/bin')
targets={'desktop':['clang++','-mmacosx-version-min=11.0'],
 'arm64-v8a':[str(ndk/'aarch64-linux-android21-clang++')],
 'armeabi-v7a':[str(ndk/'armv7a-linux-androideabi21-clang++')],
 'x86':[str(ndk/'i686-linux-android21-clang++')],
 'x86_64':[str(ndk/'x86_64-linux-android21-clang++')]}
records=[]
for abi,compiler in targets.items():
 variants=[]
 for uncached in [0,1]:
  assembly=OUT/(abi+'-'+str(uncached)+'.s')
  command=compiler+['-std=c++20','-fno-exceptions','-O2','-S',str(source),'-o',str(assembly),
   '-DDEXKIT_EXPERIMENT_UNCACHED_DESCRIPTORS='+str(uncached),
   '-I'+str(ROOT/'Core/dexkit/include'),'-I'+str(ROOT/'Core/third_party/flatbuffers/include')]
  subprocess.run(command,check=True)
  text=assembly.read_text();sizes={}
  for symbol in ['method_bean','field_bean','class_bean','string_object','string_view_object']:
   pattern=r'\.zerofill\s+__DATA,__common,_'+symbol+r',(\d+),' if abi=='desktop' else r'\.size\s+'+symbol+r',\s*(\d+)'
   match=re.search(pattern,text);assert match,(abi,symbol);sizes[symbol]=int(match[1])
  variants.append(dict(uncached=bool(uncached),command=command,sizes=sizes,assembly_sha256=hashlib.sha256(assembly.read_bytes()).hexdigest()))
 assert variants[0]['sizes']['class_bean']==variants[1]['sizes']['class_bean']
 records.append(dict(abi=abi,variants=variants))
 print(abi+' '+json.dumps([r['sizes'] for r in variants]),flush=True)
(OUT/'summary.json').write_text(json.dumps(records,indent=2)+'\n')
