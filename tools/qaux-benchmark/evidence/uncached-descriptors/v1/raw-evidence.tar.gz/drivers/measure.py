"""Freeze and execute the bounded uncached-descriptor comparison."""
import datetime,hashlib,json,platform,subprocess,sys
from pathlib import Path
from cases import BASE,E,CASES,FIXTURES,LABELS,RAW_CASES
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
OUT=E/'measurements'
JDK=Path('/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home')
ENGINE='2be1a63f1ac9de56f6e5cd53123322388e598006'
ARTIFACTS={label:E/'artifacts'/label for label in LABELS}

def sha(path):
 value=hashlib.sha256()
 with Path(path).open('rb') as stream:
  for block in iter(lambda:stream.read(1024*1024),b''):value.update(block)
 return value.hexdigest()

def plan():
 result=[]
 for phase,seed in [('main',2026092710),('confirm',2026092810)]:
  for case in CASES:
   edges=[('control','uncached'),('vector','uncached')]
   if case['name'] in RAW_CASES:edges.append(('raw-dense','uncached'))
   for left,right in edges:
    seed+=1
    result.append(dict(name=f'{phase}-{left}-to-{right}-{case["name"]}',phase=phase,kind='native',
     labels=[left,right],pairs=6,seed=seed,case=case['name'],fixture=str(FIXTURES[case['fixture']]),
     mode=case['mode'],repeats=case['repeats']))
  for passes,workers in [(1,4),(11,4),(1,1)]:
   edges=[('control','uncached'),('vector','uncached')]
   if workers==4:edges.append(('raw-dense','uncached'))
   for left,right in edges:
    seed+=1
    result.append(dict(name=f'{phase}-{left}-to-{right}-qq-p{passes}-w{workers}',phase=phase,kind='qq',
     labels=[left,right],pairs=6,seed=seed,passes=passes,threads=workers,profile='all'))
 assert len(result)==116 and len({r['name'] for r in result})==116
 return result

def command(item):
 if item['kind']=='native':
  cmd=[sys.executable,ROOT/'tools/qaux-benchmark/workload_sweep.py','--fixture',item['fixture'],
   '--output',OUT/item['name'],'--mode',item['mode'],'--repeats',item['repeats'],'--pairs',item['pairs'],'--seed',item['seed']]
  for label in item['labels']:cmd+=['--variant',label,ARTIFACTS[label]]
 else:
  cmd=[sys.executable,ROOT/'tools/qaux-benchmark/sweep.py','--dexkit-root',ROOT,'--corpus',BASE/'qaux-extracted',
   '--apk',BASE/'qq-9.3.55.apk','--java-home',JDK,'--memory-probe',BASE/'artifacts/probe-v2/libqauxbench_probe.dylib',
   '--output',OUT/item['name'],'--pairs',item['pairs'],'--seed',item['seed'],'--passes',item['passes'],
   '--threads',item['threads'],'--profile','all']
  for label in item['labels']:
   cmd+=['--variant',label,ARTIFACTS[label]/'libdexkit.dylib',E/'validation'/('verify-'+label+'-w'+str(item['threads']))]
 return list(map(str,cmd))

def executable(label,mode):
 name='descriptor_transition' if mode.startswith('transition-') else 'descriptor_concurrent' if mode.startswith('lookup-concurrent-') else 'descriptor'
 return ARTIFACTS[label]/'build/Core'/('dexkit_'+name+'_workload')

action=sys.argv[1];assert action in ['freeze','run']
OUT.mkdir(exist_ok=True);frozen_path=OUT/'frozen-plan.json';items=plan()
if action=='freeze':
 assert not frozen_path.exists()
 assert not subprocess.check_output(['git','-C',ROOT,'status','--porcelain'],text=True).strip()
 paths=list(E.glob('*.py'))+[BASE/'qq-9.3.55.apk',JDK/'bin/java',JDK/'bin/javac',BASE/'artifacts/probe-v2/libqauxbench_probe.dylib']+list(FIXTURES.values())
 paths+=[ROOT/'tools/qaux-benchmark'/name for name in ['workload_sweep.py','sweep.py','run.py','QueryReplay.java',
  'descriptor_workload.cpp','descriptor_concurrent_workload.cpp','descriptor_transition_workload.cpp',
  'uncached_descriptor_checks.cpp','UNCACHED-DESCRIPTORS-EXECUTION.md','UNCACHED-DESCRIPTORS-REVIEW.md']]
 paths+=list((BASE/'qaux-extracted').glob('*.json'))
 paths+=[ROOT/'tools/qaux-benchmark/baseline/expected.json']
 paths+=list((E/'validation/sweep-driver-preflight').glob('*.json'))
 for phase in ['normal','trace','isolated','sanitize','default']:
  complete=E/'validation'/('complete-'+phase+'.json');proof=json.loads(complete.read_text())
  checks=E/'validation'/('checks-'+phase+'.json')
  assert proof['checks_sha256']==sha(checks)
  paths+=[complete,checks]
 for name in ['workload-smokes.json','gradle/validation.json','qq-verification.json','census-checks.json',
  'census-native.json','census-qq.json','layout/summary.json','ownership-shape/summary.json','ownership-shape/check.log','ownership-shape/uncached_descriptor_checks.cpp','docs.json','docs-install.log','docs-build.log','config-checks.json']:
  path=E/'validation'/name;assert path.is_file();paths.append(path)
 assert len(json.loads((E/'validation/workload-smokes.json').read_text()))==80
 assert len(json.loads((E/'validation/census-native.json').read_text()))==60
 gradle=json.loads((E/'validation/gradle/validation.json').read_text())
 assert gradle['total_tests']==71 and gradle['skipped']==0 and len(gradle['abis'])==4
 assert 'success VuePress build completed' in (E/'validation/docs-build.log').read_text()
 manifests={}
 selected={'control':(False,False,False),'raw-dense':(False,False,True),'vector':(True,False,False),'uncached':(False,True,True)}
 for label in LABELS:
  artifact=ARTIFACTS[label];manifest=json.loads((artifact/'artifact.json').read_text());manifests[label]=manifest
  assert manifest['engine_commit']==ENGINE and manifest['diagnostics'] is False and not manifest['untracked_source_sha256']
  assert (artifact/'source.patch').read_text()=='\n' and manifest['native_sha256']==sha(artifact/'libdexkit.dylib')
  paths+=[artifact/'artifact.json',artifact/'libdexkit.dylib',artifact/'workload-sources.json']
  options=manifest['cmake_options']
  for flag,enabled in zip(['VECTOR_DESCRIPTORS','UNCACHED_DESCRIPTORS','RAW_DESCRIPTOR_LOOKUP'],selected[label]):
   assert options['DEXKIT_EXPERIMENT_'+flag]==('ON' if enabled else 'OFF')
  for flag in ['NODE_DESCRIPTORS','SPARSE_DESCRIPTORS','POINTER_DESCRIPTORS','PAGED_DESCRIPTORS','HYBRID_DESCRIPTORS',
   'VECTOR_DESCRIPTORS_NO_PROMOTION','PACKED_CROSS_INFO','PACKED_FIELD_USES','COMPACT_FIELDS','CANDIDATE_PIPELINE','CANDIDATE_SLICES']:
   assert options['DEXKIT_EXPERIMENT_'+flag]=='OFF'
  for key in ['DEXKIT_ENABLE_INTERNAL_METRICS','DEXKIT_ENABLE_INTERNAL_METRICS_API']:assert options[key]=='OFF'
  for workers in [1,4]:
   path=E/'validation'/('verify-'+label+'-w'+str(workers))/'run-metadata.json'
   metadata=json.loads(path.read_text())
   assert metadata['exit_code']==0 and metadata['baseline_results_equal'] is True and metadata['native_sha256']==manifest['native_sha256']
   paths+=[path]+list(map(Path,metadata['jars_sha256']))
  source_hashes=json.loads((artifact/'workload-sources.json').read_text())
  for name in ['descriptor_workload.cpp','descriptor_concurrent_workload.cpp','descriptor_transition_workload.cpp']:
   assert source_hashes['tools/qaux-benchmark/'+name]==sha(ROOT/'tools/qaux-benchmark'/name)
 normalized=[{k:v for k,v in m['cmake_options'].items() if k not in ['DEXKIT_EXPERIMENT_'+flag for flag in ['VECTOR_DESCRIPTORS','UNCACHED_DESCRIPTORS','RAW_DESCRIPTOR_LOOKUP']]} for m in manifests.values()]
 assert all(options==normalized[0] for options in normalized)
 assert all(m['compiler']==manifests['control']['compiler'] for m in manifests.values())
 for item in items:
  if item['kind']=='native':paths+=[executable(label,item['mode']) for label in item['labels']]
 frozen=dict(frozen_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
  worktree_head=subprocess.check_output(['git','-C',ROOT,'rev-parse','HEAD'],text=True).strip(),
  normal_engine_commit=ENGINE,platform=platform.platform(),
  policy='116 sweeps / 1392 fresh processes: main and independent confirmation, six balanced AB/BA pairs each. '
   'All four normal artifacts use the same frozen source, Small14 and compiler. Only VECTOR, UNCACHED and RAW_LOOKUP differ. '
   'Old dense and vector are direct comparators; raw-dense separates raw input lookup from cache removal plus result ownership. '
   'All successful samples and adverse/outliers stay. No tuning, builds, correctness checks, profiling or archive during timing. '
   'OS caches are not flushed. Results include repeated construction, Bean copies/moves, serialization, result destruction and close. '
   'Uncached persistent-cache census excludes transient owning result strings; physical process peak retains those allocations. '
   'Four calling threads perform four times the work. Vector stages may mix generations. Native compatibility is conditional on the new owning-value ABI.',
  files={str(p):sha(p) for p in sorted(set(paths))},native_manifests=manifests,sweeps=[dict(i,command=command(i)) for i in items])
 frozen_path.write_text(json.dumps(frozen,indent=2)+'\n')
 print('FROZEN '+sha(frozen_path)+' 116 sweeps / 1392 processes',flush=True);sys.exit(0)
frozen=json.loads(frozen_path.read_text())
assert frozen['sweeps']==[dict(i,command=command(i)) for i in items]
for path,expected in frozen['files'].items():assert sha(path)==expected,'Frozen input changed: '+path
queue=OUT/'completed.json';completed=json.loads(queue.read_text()) if queue.exists() else []
for item in frozen['sweeps']:
 name=item['name']
 old=next((r for r in completed if r['name']==name),None)
 if old:
  assert old['summary_sha256']==sha(OUT/name/'summary.json');continue
 print('START '+name,flush=True)
 with (OUT/(name+'-launcher.log')).open('w') as log:subprocess.run(item['command'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
 summary=json.loads((OUT/name/'summary.json').read_text());metric=summary['metrics']['lifecycle_ms']
 completed.append(dict(item,summary_sha256=sha(OUT/name/'summary.json')))
 queue.write_text(json.dumps(completed,indent=2)+'\n')
 print('DONE '+name+' lifecycle=%+.2f%%'%metric['median_change_percent'],flush=True)
for path,expected in frozen['files'].items():assert sha(path)==expected,'Frozen input changed after timing: '+path
print('COMPLETE 116 sweeps / 1392 fresh processes; frozen inputs unchanged',flush=True)
