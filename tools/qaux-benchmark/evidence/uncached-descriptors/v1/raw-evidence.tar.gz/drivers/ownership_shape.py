"""Observe actual host storage in the owning checker, using immutable Core."""
import hashlib,json,shlex,subprocess
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
E=BASE/'uncached-descriptors-v1';OUT=E/'validation/ownership-shape'
OUT.mkdir(exist_ok=True)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
original=ROOT/'tools/qaux-benchmark/uncached_descriptor_checks.cpp'
source=OUT/original.name
text=original.read_text()
marker='            // Copy, move, assign and force vector relocation while the source\n'
assert text.count(marker)==1
addition=r'''            auto inline_string = [](const std::string &value) {
                const auto object = reinterpret_cast<uintptr_t>(&value);
                const auto data = reinterpret_cast<uintptr_t>(value.data());
                return data >= object && data < object + sizeof(value);
            };
            const auto shape_method = item->GetMethodBean(method_id);
            const auto shape_field = item->GetFieldBean(field_id);
            const auto shape_method_copy = shape_method;
            const auto shape_field_copy = shape_field;
            const bool method_inline = inline_string(shape_method.dex_descriptor);
            const bool field_inline = inline_string(shape_field.dex_descriptor);
            Require(method_inline == !long_strings && field_inline == !long_strings, "actual host inline/heap representation");
            std::printf("UNCACHED_HOST_SHAPE {\"long_strings\":%s,\"method_length\":%zu,\"method_capacity\":%zu,\"method_copy_capacity\":%zu,\"method_inline\":%s,\"field_length\":%zu,\"field_capacity\":%zu,\"field_copy_capacity\":%zu,\"field_inline\":%s}\n",
                long_strings ? "true" : "false", shape_method.dex_descriptor.size(),
                shape_method.dex_descriptor.capacity(), shape_method_copy.dex_descriptor.capacity(),
                method_inline ? "true" : "false", shape_field.dex_descriptor.size(),
                shape_field.dex_descriptor.capacity(), shape_field_copy.dex_descriptor.capacity(),
                field_inline ? "true" : "false");
'''
source.write_text(text.replace(marker,addition+marker))
build=E/'artifacts/uncached/build'
commands=subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-t','commands','dexkit_uncached_descriptor_checks'],text=True).splitlines()
compile=next(shlex.split(line) for line in commands if line.endswith(' -c '+str(original)))
link=shlex.split(next(line for line in commands if ' -o Core/dexkit_uncached_descriptor_checks ' in line))
assert link[:2]==[':','&&'] and link[-2:]==['&&',':'];link=link[2:-2]
old_object=compile[compile.index('-o')+1];obj=OUT/'check.o';exe=OUT/'check'
for flag,value in [('-o',obj),('-MT',obj),('-MF',OUT/'check.d'),('-c',source)]:compile[compile.index(flag)+1]=str(value)
link=[str(obj) if token==old_object else token for token in link];link[link.index('-o')+1]=str(exe)
before=sha(build/'Core/libdexkit_static.a')
with (OUT/'build.log').open('w') as log:
 for command in [compile,link]:subprocess.run(command,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
assert sha(build/'Core/libdexkit_static.a')==before
command=[exe,BASE/'followup/fixtures/dense-descriptors/dense-descriptors.apk',BASE/'raw-metadata/symbol-fixture/symbols.apk']
with (OUT/'check.log').open('w') as log:subprocess.run(list(map(str,command)),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
rows=[json.loads(line.split(' ',1)[1]) for line in (OUT/'check.log').read_text().splitlines() if line.startswith('UNCACHED_HOST_SHAPE ')]
assert len(rows)==2
record=dict(compile=compile,link=link,command=list(map(str,command)),source_sha256=sha(source),
 original_sha256=sha(original),core_sha256=before,executable_sha256=sha(exe),log_sha256=sha(OUT/'check.log'),host_shapes=rows,
 limitation='Host observations only; Android was compiled, not executed.')
(OUT/'summary.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(rows,indent=2))
