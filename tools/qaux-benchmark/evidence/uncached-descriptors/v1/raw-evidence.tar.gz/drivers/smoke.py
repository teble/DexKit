import hashlib,json,subprocess
from cases import E,CASES,LABELS,native_command
records=[]
for case in CASES:
 expected=None
 for label in LABELS:
  cmd=list(map(str,native_command(label,case,True)))
  path=E/'validation'/('smoke-'+label+'-'+case['name']+'.log')
  result=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,check=True,timeout=180)
  path.write_text(result.stdout)
  report=json.loads(next(line[9:] for line in result.stdout.splitlines() if line.startswith('WORKLOAD ')))
  identity={key:report[key] for key in ['mode','repeats','checksum','returned','kind','pattern','calling_threads'] if key in report}
  if expected is None:expected=identity
  assert identity==expected,(label,case['name'])
  if case['mode'].startswith('transition-'):
   _,kind,pattern,workers=case['mode'].split('-')
   n=report['repeats'];w=int(workers[1:]);length=14 if kind=='method' else 13
   ids=list(range(60000 if pattern=='full' else 30000 if pattern=='changed' else 64))
   if pattern=='low':ids=[i*911%60000 for i in ids]
   later=[i+30000 for i in ids] if pattern=='changed' else ids
   assert report['returned']==w*len(ids)*n
   assert report['checksum']==w*(sum(ids)+len(ids)*length+(n-1)*(sum(later)+len(later)*length))
  records.append(dict(case=case['name'],label=label,command=cmd,identity=identity,log_sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
 print('PASS four variants '+case['name'],flush=True)
(E/'validation/workload-smokes.json').write_text(json.dumps(records,indent=2)+'\n')
print('COMPLETE '+str(len(records))+' workload smokes',flush=True)
