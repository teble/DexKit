"""Render all completed comparisons; narrative conclusions are reviewed locally."""
import json
from pathlib import Path
from cases import E,CASES
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
x=json.loads((E/'summary.json').read_text());cases=x['cases']
assert x['accepted_sweeps']==116 and x['accepted_fresh_processes']==1392
def pair(name,metric,interval=False):
 values=[]
 for phase in ['main','confirm']:
  r=cases[name][phase].get(metric)
  if r is None:return '--'
  value=f"{r['median_change_percent']:+.2f}%"
  if interval:value+=' ['+', '.join(f'{v:+.2f}' for v in r['bootstrap95_percent'])+']'
  values.append(value)
 return ' / '.join(values)
def status(name,metric):
 intervals=[cases[name][p][metric]['bootstrap95_percent'] for p in ['main','confirm']]
 return 'lower in both' if all(v[1]<0 for v in intervals) else 'higher in both' if all(v[0]>0 for v in intervals) else 'not resolved in both'
def absolute(name,metric,left,divisor=1):
 return ' / '.join(f"{cases[name][p][metric]['variants'][left]['median']/divisor:.2f} -> {cases[name][p][metric]['variants']['uncached']['median']/divisor:.2f}" for p in ['main','confirm'])
lines=['# Uncached member descriptors: completed results','',
'The native persistent method/field descriptor cache can be removed while',
'preserving the tested managed result contract. The opt-in implementation uses',
'owning result strings and raw input lookup. Performance has material tradeoffs;',
'keep UNCACHED_DESCRIPTORS OFF by default and retain the original dense backend.',
'The results below distinguish removal of persistent caching from switching the',
'lookup algorithm, and retain temporary output allocations and repeated work.',
'All comparisons below use the same other optimizations. Paired values are main /',
'confirmation; negative changes favor uncached. Intervals and limits are explained',
'under the fixed comparison.','',
 '## Findings that determine the decision','',
'No tested complete-lifecycle comparison has a repeated speed benefit against',
'old dense. Against vector, repeated lifecycle benefits occur in wide lookup,',
'full method output once/twice, and changed-set field output. These are specific',
'advantages over the vector transition design, not a general speed advantage',
'over the original dense cache.','',
f"- QQ peak versus old dense changes {min(m['peak_footprint_bytes']['median_change_percent'] for n,p in cases.items() if n.startswith('control-to-uncached-qq-') for m in p.values()):.2f}% to {max(m['peak_footprint_bytes']['median_change_percent'] for n,p in cases.items() if n.startswith('control-to-uncached-qq-') for m in p.values()):.2f}% across the six observations; all peak intervals exclude zero.",
'  No QQ lifecycle comparison has repeated interval support. Against vector,',
'  both w4 peak comparisons remain unresolved; p1/w1 saves only about 0.3--0.4%.',
'  The low-output QQ case therefore gains little beyond the existing sparse',
'  vector configuration.','',
f"- Long output (4096 long methods, 16 calls) costs {pair('control-to-uncached-long-output','lifecycle_ms',True)} versus old dense.",
f"  Its peak rises {pair('control-to-uncached-long-output','peak_footprint_bytes',True)}: {absolute('control-to-uncached-long-output','peak_footprint_bytes','control',1048576)} MiB.",
f"  Against raw dense it remains {pair('raw-dense-to-uncached-long-output','lifecycle_ms',True)} slower, so changing lookup cannot explain away this counterexample.",
'  Relative to vector its peak improves about 6.7--6.9%, but lifecycle still',
'  nearly doubles. Zero persistent cache does not guarantee a lower peak.','',
f"- Full field output sixteen times costs {pair('control-to-uncached-field-full-16','lifecycle_ms',True)} versus old dense, while peak drops about 13.5--13.7%.",
f"  Against raw dense lifecycle still costs {pair('raw-dense-to-uncached-field-full-16','lifecycle_ms',True)}; repeated generation/result ownership is an independent tradeoff.",
f"- The user's two-full-field case changes {pair('control-to-uncached-field-full-2','lifecycle_ms',True)} versus old dense, and {pair('vector-to-uncached-field-full-2','lifecycle_ms',True)} versus vector.",
'  Neither timing difference has both intervals excluding zero. Its peak is',
'  clearly lower: about 13.5--13.6% versus old dense and 18.1--18.2% versus vector.',
'  Do not describe that noisy two-call timing as either proven equality or a',
'  confirmed removal of the earlier regression.','',
f"- Full method output once improves {pair('vector-to-uncached-method-full-1','lifecycle_ms')} versus vector; twice improves {pair('vector-to-uncached-method-full-2','lifecycle_ms')}. All four intervals are negative.",
'  The corresponding old-dense lifecycle differences remain unresolved in both',
'  phases; removing vector fill/transition overhead does not establish superiority',
'  to old dense.','',
f"- Wide lookup lifecycle improves {pair('vector-to-uncached-wide','lifecycle_ms')} versus vector, but its repeated stage regresses {pair('vector-to-uncached-wide','repeated_api_ms')}; all intervals exclude zero.",
f"  Versus old dense, lifecycle regresses {pair('control-to-uncached-wide','lifecycle_ms')}, while peak changes {absolute('control-to-uncached-wide','peak_footprint_bytes','control',1048576)} MiB.",
'  The lifecycle win against vector includes avoiding its initial sparse build,',
'  discard and regeneration; it is not a faster warmed lookup loop.','',
f"- Prefix lookup lifecycle regresses {pair('control-to-uncached-prefix','lifecycle_ms',True)} versus old dense.",
f"  Raw-dense/uncached changes only {pair('raw-dense-to-uncached-prefix','lifecycle_ms',True)} and both intervals include zero.",
'  Most of that overall regression belongs to choosing raw input comparison,',
'  not a measured large incremental cache-removal penalty. Likewise, most of',
'  wide/prefix peak reduction is already present in raw dense: roughly 1.9/3.1',
'  MiB before uncached reaches 1.8/3.0 MiB. Attribute those savings accordingly.',
f"- Narrow hot lookup retains a cache-removal/result-ownership penalty even with raw lookup held fixed: {pair('raw-dense-to-uncached-hot','lifecycle_ms',True)}.",
'  Other small-output, low-unique and four-caller adverse cases stay in the full',
'  matrix below. Faster first stages or close do not erase their warm/lifecycle',
'  regressions.','',
'## Fixed comparison and interpretation','',

f"All normal artifacts use `{x['engine_commit']}` with the same Small14 combination and compiler.",
'The four variants differ only in VECTOR_DESCRIPTORS, UNCACHED_DESCRIPTORS and',
'RAW_DESCRIPTOR_LOOKUP. Control is the old dense backend within this optimization',
'combination, not unmodified upstream master.','',
'| Variant | Persistent descriptor storage | Input descriptor lookup | Result descriptor |',
'| --- | --- | --- | --- |',
'| control | Old dense | Cached text | Borrowed cache view |',
'| raw-dense | Old dense | Raw component comparison | Borrowed cache view |',
'| vector | Sparse, then independent vector | Cached text | Borrowed generation view |',
'| uncached | None | Raw component comparison | Owning string |','',
'Control/uncached and vector/uncached measure the overall proposal. Raw-dense/',
'uncached isolates cache removal plus owning-result costs under the same lookup',
'algorithm. It does not isolate each string copy, allocation or construction',
'individually. Do not subtract percentages from different paired sweeps as if',
'they were an additive causal decomposition.','',
f"The frozen harness/plan snapshot is `{x['harness_commit']}`.",
f"Frozen plan SHA256: `{x['frozen_plan_sha256']}`.",
'All 116 sweeps / 1392 fresh process samples completed, with no excluded successful',
'samples. Each sweep has six balanced AB/BA pairs, with a main phase and one',
'independently seeded confirmation. Frozen inputs reconciled before and after',
'timing. No builds, correctness checks, profiling or archive compression ran',
'during measurement. A separate four-process driver preflight is validation only.','',
'Negative changes favor uncached. Values are main / confirmation paired median',
'percentage changes, not ratios of absolute medians. Bootstrap 95% intervals are',
'exploratory six-pair estimates without multiple-comparison adjustment. A result',
'is described as repeated support only when both intervals exclude zero in the',
'same direction. An interval crossing zero is not proof of equality.','',
'Lifecycle includes create, setup, API stages, result destruction and close.',
'Four calling threads perform four times the work; they are separate workloads.',
'QQ workers are query-engine workers rather than simultaneous Java callers.',
'OS caches were not flushed. These are Apple M1 / macOS host measurements, not',
'Android device performance. Full absolute medians, MADs, intervals and samples',
'are retained in the [summary](evidence/uncached-descriptors/v1/summary.json).','',
'## Decision cases','',
'| Case / comparator | Lifecycle change and 95% intervals | Lifecycle support | Peak change and 95% intervals |',
'| --- | --- | --- | --- |']
for case in ['wide','prefix','hot','long-output','method-full-1','method-full-2','field-full-1','field-full-2','field-full-16','low-id-w1','field-full-w4']:
 for left in ['control','vector','raw-dense']:
  name=left+'-to-uncached-'+case
  if name in cases:lines.append(f"| {case} / {left} | {pair(name,'lifecycle_ms',True)} | {status(name,'lifecycle_ms')} | {pair(name,'peak_footprint_bytes',True)} |")
lines+=['','## QQ workflows','',
'| Comparison | Lifecycle change and 95% intervals | Peak change and 95% intervals | Absolute peak MiB, comparator -> uncached |',
'| --- | --- | --- | --- |']
for name in cases:
 if '-qq-' not in name:continue
 left=name.split('-to-uncached-',1)[0]
 lines.append(f"| {name} | {pair(name,'lifecycle_ms',True)} | {pair(name,'peak_footprint_bytes',True)} | {absolute(name,'peak_footprint_bytes',left,1048576)} |")
lines+=['','## Complete native matrix','',
'First/repeated/close columns show paired median changes; their complete intervals',
'are in the linked summary. A single full call has no repeated stage.','']
for left in ['control','vector','raw-dense']:
 lines+=['### '+left+' to uncached','',
  '| Workload | Lifecycle and 95% intervals | First stage | Repeated stage | Close | Peak and 95% intervals |',
  '| --- | --- | --- | --- | --- | --- |']
 for case in CASES:
  name=left+'-to-uncached-'+case['name']
  if name in cases:
   lines.append(f"| {case['name']} | {pair(name,'lifecycle_ms',True)} | {pair(name,'pass0_api_ms')} | {pair(name,'repeated_api_ms')} | {pair(name,'close_ms')} | {pair(name,'peak_footprint_bytes',True)} |")
 lines+=['']
lines+=['## Physical peak in representative workloads','',
'| Case / comparator | Peak MiB, comparator -> uncached, main / confirmation | Peak support |',
'| --- | --- | --- |']
for case in ['wide','prefix','hot','long-output','method-full-1','method-full-2','method-full-16','field-full-1','field-full-2','field-full-16','method-full-w4','field-full-w4']:
 for left in ['control','vector']:
  name=left+'-to-uncached-'+case
  lines.append(f"| {case} / {left} | {absolute(name,'peak_footprint_bytes',left,1048576)} | {status(name,'peak_footprint_bytes')} |")
lines+=['','## Mechanism and accounting boundaries','',
'Uncached removes the persistent method/field descriptor owners, arrays, ready',
'bytes and descriptor publication locks. It does not use vector generation',
'maintenance or borrowing scopes. Existing query admission, raw identity',
'publication and bridge lifecycle restrictions remain in effect.','',
'Sixty native diagnostic cases retain access/build counts. Uncached',
'has zero persistent descriptor census and zero getter cache hits. Full field',
'output twice builds 120000 descriptors; sixteen passes build 960000. Long output',
'builds 65536 method descriptors. Wide input lookup builds 513 descriptors: one',
'during setup and one for each of 512 hits, while raw mismatching candidates do',
'not require descriptor construction. Counted builds are not total allocations:',
'Bean copies, FlatBuffer copies and allocator costs are not counted by Built.','',
'Find collects owning Beans before creating text-deduplication views, and does',
'not move them during deduplication. Batch and existing result assembly retain',
'their actual copying behavior; this candidate does not add unrelated move',
'optimizations. Output lifetimes and duplicate representative selection remain',
'covered by the independent result oracles.','',
'A host checker linked the unchanged normal Core observes the 14-byte method and',
'13-byte field inline, each with capacity 22. The 1778-byte method owns heap',
'capacity 2815, while its copied Bean has capacity 1783. The 30-byte field has',
'capacity 47 before copying and 31 afterward. These are concrete requested',
'capacities, not allocator size classes or process footprint. They explain why',
'equal bytes do not imply equal allocation behavior, without assigning all peak',
'changes to one cause.','',
'| ABI | MethodBean, borrowed -> owning | FieldBean, borrowed -> owning |',
'| --- | --- | --- |']
for entry in x['validation']['abi_layouts']:
 old,new=[r['sizes'] for r in entry['variants']]
 lines.append(f"| {entry['abi']} | {old['method_bean']} -> {new['method_bean']} | {old['field_bean']} -> {new['field_bean']} |")
lines+=['','Bean growth is temporary result storage, separate from the persistent-cache',
'census. Android rows are cross-compiled layout evidence only. Physical process',
'peak can include overlapping result owners, construction slack, copies, raw',
'input and allocator retention even though persistent descriptor cache is zero.','',
'## Correctness and source review','',
'- 193 native driver commands passed: normal 47, diagnostic 80, minimal 19,',
'  ASan/UBSan 24 and all-experiments-OFF 23. They preserve symbol/overload bytes,',
'  cross-DEX ordering/representatives, malformed lookups, relations, field and',
'  invocation oracles, workers and concurrent public API checks.',
'- Owning-value checks cover copy/move/assignment, vector relocation, independent',
'  source mutation, worker-returned Beans and serialized member results after',
'  bridge destruction. An additional normal-host checker observes actual inline',
'  and heap shape while repeating those ownership checks against frozen Core.',
'- All 80 normal smoke cases agreed; transition counts and ID sums also match',
'  independent calculations. Sixty native diagnostic processes reconcile caching',
'  and repeated-construction behavior separately from normal timing.',
'- Thirteen complete QQ oracle runs passed: eight normal, three diagnostic, and',
'  two final field-relation runs. Verification includes descriptors, selected',
'  results, order where relevant and unchanged empty/fallback outcomes.',
'- Required Core/JAR/JVM/Android tasks passed: 71 JVM tests, zero skipped, and an',
'  AAR containing arm64-v8a, armeabi-v7a, x86 and x86_64. Five ABI Bean layout',
'  probes and twelve CMake dependency/exclusion configurations passed.',
'- Documentation dependency install and VuePress build passed. Sanitizer leak',
'  detection was disabled; no Android device execution/performance is claimed.',
'- The complete 8m45s [source review](UNCACHED-DESCRIPTORS-REVIEW.md) read the fixed',
'  production increment and found no confirmed blocker. Review does not replace',
'  the executed verification or performance measurements.','',
'The experiment changes native C++ types/ABI: MethodBean/FieldBean descriptors',
'own strings, and a view derived from a temporary or invalidated owning value',
'can dangle. Other native raw/query views, including complete AnnotationBean and',
'Batch wrappers, retain their old lifetime requirements. Java/Kotlin result',
'schema and behavior remain unchanged.','',
'## Reproduction and retained evidence','',
'The [manifest](evidence/uncached-descriptors/v1/manifest.json) records the archive',
'hash and readback verification. The [source identity](evidence/uncached-descriptors/v1/source-identity.json)',
'separates frozen engine and harness, and the [validation summary](evidence/uncached-descriptors/v1/validation-summary.json)',
'links all checks. The archive retains raw successful samples, separate development/',
'preflight records, verification outputs, fixture manifests, copied relevant',
'source, compile/configuration records and experiment drivers. APK/DEX/corpus',
'and compiled native/JVM/Android binaries are omitted; hashes identify separately',
'obtained inputs and artifacts. No production tuning or extra timing was performed',
'after the fixed batch.','']
path=ROOT/'tools/qaux-benchmark/UNCACHED-DESCRIPTORS-RESULTS.md'
text='\n'.join(lines);assert text.isascii();path.write_text(text)
print(str(path)+' '+str(len(lines))+' lines')
