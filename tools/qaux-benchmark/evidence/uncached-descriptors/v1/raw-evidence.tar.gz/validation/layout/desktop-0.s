	.build_version macos, 11, 0	sdk_version 26, 5
	.globl	_method_bean                    ; @method_bean
.zerofill __DATA,__common,_method_bean,64,0
	.globl	_field_bean                     ; @field_bean
.zerofill __DATA,__common,_field_bean,40,0
	.globl	_class_bean                     ; @class_bean
.zerofill __DATA,__common,_class_bean,128,0
	.globl	_string_object                  ; @string_object
.zerofill __DATA,__common,_string_object,24,0
	.globl	_string_view_object             ; @string_view_object
.zerofill __DATA,__common,_string_view_object,16,0
.subsections_via_symbols
