#include "beans.h"
#include <type_traits>
#if DEXKIT_EXPERIMENT_UNCACHED_DESCRIPTORS
static_assert(std::is_same_v<dexkit::MemberDescriptor, std::string>);
#else
static_assert(std::is_same_v<dexkit::MemberDescriptor, std::string_view>);
#endif
extern "C" {
char method_bean[sizeof(dexkit::MethodBean)];
char field_bean[sizeof(dexkit::FieldBean)];
char class_bean[sizeof(dexkit::ClassBean)];
char string_object[sizeof(std::string)];
char string_view_object[sizeof(std::string_view)];
}
