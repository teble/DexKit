	.text
	.file	"layout.cpp"
	.type	method_bean,@object             # @method_bean
	.bss
	.globl	method_bean
method_bean:
	.zero	40
	.size	method_bean, 40

	.type	field_bean,@object              # @field_bean
	.globl	field_bean
field_bean:
	.zero	28
	.size	field_bean, 28

	.type	class_bean,@object              # @class_bean
	.globl	class_bean
class_bean:
	.zero	68
	.size	class_bean, 68

	.type	string_object,@object           # @string_object
	.globl	string_object
string_object:
	.zero	12
	.size	string_object, 12

	.type	string_view_object,@object      # @string_view_object
	.globl	string_view_object
string_view_object:
	.zero	8
	.size	string_view_object, 8

	.section	".linker-options","e",@llvm_linker_options
	.ident	"Android (10552028, +pgo, +bolt, +lto, -mlgo, based on r487747d) clang version 17.0.2 (https://android.googlesource.com/toolchain/llvm-project d9f89f4d16663d5012e5c09495f3b30ece3d2362)"
	.section	".note.GNU-stack","",@progbits
