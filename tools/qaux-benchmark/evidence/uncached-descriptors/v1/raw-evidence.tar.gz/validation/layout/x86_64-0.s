	.text
	.file	"layout.cpp"
	.type	method_bean,@object             # @method_bean
	.bss
	.globl	method_bean
	.p2align	4, 0x0
method_bean:
	.zero	64
	.size	method_bean, 64

	.type	field_bean,@object              # @field_bean
	.globl	field_bean
	.p2align	4, 0x0
field_bean:
	.zero	40
	.size	field_bean, 40

	.type	class_bean,@object              # @class_bean
	.globl	class_bean
	.p2align	4, 0x0
class_bean:
	.zero	128
	.size	class_bean, 128

	.type	string_object,@object           # @string_object
	.globl	string_object
	.p2align	4, 0x0
string_object:
	.zero	24
	.size	string_object, 24

	.type	string_view_object,@object      # @string_view_object
	.globl	string_view_object
	.p2align	4, 0x0
string_view_object:
	.zero	16
	.size	string_view_object, 16

	.section	".linker-options","e",@llvm_linker_options
	.ident	"Android (10552028, +pgo, +bolt, +lto, -mlgo, based on r487747d) clang version 17.0.2 (https://android.googlesource.com/toolchain/llvm-project d9f89f4d16663d5012e5c09495f3b30ece3d2362)"
	.section	".note.GNU-stack","",@progbits
