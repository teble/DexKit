# Direct master versus current uncached QQ comparison

Requested comparison: unmodified local master 1d936bd versus the existing
Small14 combination with UNCACHED_DESCRIPTORS and RAW_DESCRIPTOR_LOOKUP enabled
at engine 2be1a63. Reuse immutable Release binaries; do not change product code.

1. Verify all frozen QQ outputs with both variants for 11 passes, with and
   without the final field reader/writer operation. Confirm compiler, source,
   JAR and input identity, then freeze this plan and the driver inputs.
2. Run two independently seeded batches, each covering normal/tail and 1/11
   passes at four query workers, with six balanced fresh-process pairs per
   case. The fixed total is eight sweeps / 96 measured processes. Keep every
   successful sample; do not build, tune, run extra checks or compress archives
   during timing. Retain failures if any; do not silently replace a cohort.
3. Check raw sample arithmetic and frozen hashes, report complete lifecycle
   and process physical peak including JVM overhead, archive the evidence,
   and publish a table of direct master-to-uncached results. Explain that this
   measures cumulative changes, while cache removal alone was measured in
   UNCACHED-DESCRIPTORS-RESULTS.md. These are M1 host results, not Android
   device measurements.
