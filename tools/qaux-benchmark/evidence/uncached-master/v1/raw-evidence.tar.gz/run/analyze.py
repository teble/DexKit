"""Audit the completed paired data and create a directly reproducible report."""
import hashlib
import json
import statistics
from pathlib import Path

ROOT = Path('/Users/teble/project/android/DexKit-qaux-benchmark')
OUT = Path(__file__).resolve().parent
REPORT = ROOT / 'tools/qaux-benchmark/UNCACHED-MASTER-COMPARISON.md'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


frozen = json.loads((OUT / 'frozen-plan.json').read_text())
complete = json.loads((OUT / 'complete.json').read_text())
assert complete['samples'] == 96 and complete['sweeps'] == 8
assert complete['frozen_inputs_unchanged'] is True
assert complete['frozen_plan_sha256'] == sha(OUT / 'frozen-plan.json')
for path, expected in frozen['files'].items():
    assert sha(path) == expected, 'Frozen input changed: ' + path

rows = []
verified_count = 0
for item in frozen['sweeps']:
    folder = OUT / 'measurements' / item['name']
    summary = json.loads((folder / 'summary.json').read_text())
    samples = json.loads((folder / 'samples.json').read_text())
    assert len(samples) == 12 and summary['pairs'] == 6
    assert summary['labels'] == ['master', 'uncached']
    assert summary['reversed_order'].count(0) == summary['reversed_order'].count(1) == 3
    assert summary['passes'] == item['passes'] and summary['threads'] == 4
    assert len({(r['pair'], r['label']) for r in samples}) == 12
    audited = {}
    for sample in samples:
        metadata = json.loads((folder / ('pair-%02d-%s' % (sample['pair'], sample['label'])) / 'run-metadata.json').read_text())
        assert metadata['exit_code'] == 0 and metadata['baseline_counts_and_flow_equal'] is True
        assert metadata.get('repeat_results_equal') is not False and not metadata.get('report_error')
        assert sample['native_sha256'] == frozen['native_manifests'][sample['label']]['native_sha256']
        assert metadata['native_sha256'] == sample['native_sha256']
        verified_count += 1
    for metric, recorded in summary['metrics'].items():
        by_pair = {pair: {r['label']: r[metric] for r in samples if r['pair'] == pair} for pair in range(6)}
        deltas = [(by_pair[p]['uncached'] / by_pair[p]['master'] - 1) * 100 for p in range(6)]
        assert all(abs(a - b) < 1e-9 for a, b in zip(deltas, recorded['paired_change_percent']))
        assert abs(statistics.median(deltas) - recorded['median_change_percent']) < 1e-9
        for label in ['master', 'uncached']:
            assert statistics.median(r[metric] for r in samples if r['label'] == label) == recorded['variants'][label]['median']
        audited[metric] = recorded
    savings = []
    for pair in range(6):
        pair_rows = {r['label']: r for r in samples if r['pair'] == pair}
        savings.append((pair_rows['master']['peak_footprint_bytes'] - pair_rows['uncached']['peak_footprint_bytes']) / 2**20)
    rows.append(dict(name=item['name'], phase=item['phase'], scenario=item['scenario'],
                     passes=item['passes'], threads=4, metrics=audited,
                     paired_peak_saving_mib=statistics.median(savings),
                     summary_sha256=sha(folder / 'summary.json'), samples_sha256=sha(folder / 'samples.json')))
assert verified_count == 96
assert all(row['metrics'][metric]['bootstrap95_percent'][1] < 0
           for row in rows for metric in ['lifecycle_ms', 'peak_footprint_bytes'])

result = dict(frozen_plan_sha256=sha(OUT / 'frozen-plan.json'), samples=96, sweeps=8,
              all_raw_pair_arithmetic_verified=True, all_frozen_inputs_unchanged=True, results=rows)
(OUT / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')


def change(metric):
    lo, hi = metric['bootstrap95_percent']
    return '%+.2f%% [%+.2f, %+.2f]' % (metric['median_change_percent'], lo, hi)


def absolute(metric, scale, digits):
    before, after = [metric['variants'][label]['median'] / scale for label in ['master', 'uncached']]
    return f'{before:.{digits}f} -> {after:.{digits}f}'


text = ['# Current uncached combination versus master', '',
        'Direct paired measurements compare unmodified local master `1d936bd9efa38e00b7336ef112e73ba4048324e6`',
        'with the existing Small14 optimization combination plus `UNCACHED_DESCRIPTORS`',
        'and `RAW_DESCRIPTOR_LOOKUP`, built at `2be1a63f1ac9de56f6e5cd53123322388e598006`.',
        'This measures the cumulative optimization. Cache removal alone remains the',
        'separate comparison in [UNCACHED-DESCRIPTORS-RESULTS.md](UNCACHED-DESCRIPTORS-RESULTS.md).',
        'Earlier master-relative percentages were not combined with newer percentages.', '',
        'All values are Apple M1 / macOS host measurements using QQ 9.3.55 (41 DEX files),',
        'the pinned QAuxiliary query corpus and four query workers. The experimental',
        'uncached flag is enabled in the measured candidate; production defaults are unchanged.', '',
        '## Direct results', '',
        'The independent confirmation batch is the primary table. Times and peaks are',
        'absolute medians. Changes are medians of within-pair percentages, so they need',
        'not equal the ratio of the two absolute medians. Negative changes favor uncached.', '',
        '| Scenario | Passes | Lifecycle s, master -> uncached | Lifecycle change, 95% interval | Peak MiB, master -> uncached | Peak change, 95% interval | Paired peak saving MiB |',
        '| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for row in rows:
    if row['phase'] != 'confirm':
        continue
    m = row['metrics']
    text.append('| %s | %d | %s | %s | %s | %s | %.2f |' % (
        row['scenario'], row['passes'], absolute(m['lifecycle_ms'], 1000, 3), change(m['lifecycle_ms']),
        absolute(m['peak_footprint_bytes'], 2**20, 2), change(m['peak_footprint_bytes']), row['paired_peak_saving_mib']))
text += ['', 'Main batch:', '',
         '| Scenario | Passes | Lifecycle s, master -> uncached | Lifecycle change, 95% interval | Peak MiB, master -> uncached | Peak change, 95% interval |',
         '| --- | ---: | ---: | ---: | ---: | ---: |']
for row in rows:
    if row['phase'] != 'main':
        continue
    m = row['metrics']
    text.append('| %s | %d | %s | %s | %s | %s |' % (
        row['scenario'], row['passes'], absolute(m['lifecycle_ms'], 1000, 3), change(m['lifecycle_ms']),
        absolute(m['peak_footprint_bytes'], 2**20, 2), change(m['peak_footprint_bytes'])))

text += ['', '## Workload and interpretation', '',
         '- **normal:** the unchanged QQ queries, run once or eleven times within one',
         '  bridge lifetime. The normal workload leaves field reverse indexes unused.',
         '- **tail:** the same queries followed by fetching readers and writers of',
         '  `Lcom/tencent/mobileqq/data/MessageRecord;->msg:Ljava/lang/String;` before close.',
         '  This forces complete reverse-field construction across all 41 DEX files.',
         '  Both implementations reproduce the independent ordered oracle: 399 readers',
         '  and 313 writers. The final operation is performed once, not once per pass.',
         '- **Lifecycle:** create, the complete query sequence, the tail operation when',
         '  present, and close. Library loading is outside this timed window.',
         '- **Peak:** OS-reported process physical footprint, including the shared JVM',
         '  overhead. It is not just the descriptor cache, Java heap, or Android PSS.',
         '- Eleven passes use a single bridge and include the initial pass. They do',
         '  not mean eleven separate application startups. OS caches were not flushed.', '',
         '## Validation and fixed design', '',
         'Four complete eleven-pass verification runs (two variants, two scenarios)',
         'passed the frozen complete-result oracle before measurement. Both variants',
         'use the same JAR, schema and managed source. The existing native Release',
         'binaries use the same Apple clang 21 compiler, arm64 target, SDK, deployment',
         'target and `-O3 -DNDEBUG`. Diagnostics and internal metrics are compiled out.', '',
         'The predeclared plan contains eight sweeps / 96 fresh JVM samples. Each cell',
         'contains six balanced randomized AB/BA pairs, repeated in an independently',
         'seeded confirmation. Every successful sample is retained. No product edits,',
         'product builds, additional correctness checks, tuning or archive compression ran',
         'during timing. All frozen input hashes reconcile before and after timing,',
         'and every paired percentage and absolute median was independently checked',
         'against the raw samples. Bootstrap 95% intervals are exploratory six-pair',
         'estimates without multiple-comparison adjustment. All four lifecycle and all',
         'four peak comparisons have intervals excluding zero in both batches.', '',
         '## Source and evidence', '',
         'Native library SHA256:', '']
for label, manifest in frozen['native_manifests'].items():
    text += [f'- {label}: `{manifest["native_sha256"]}`']
text += ['', 'Enabled experimental flags in the candidate (all have `DEXKIT_EXPERIMENT_` prefix):', '']
flags = sorted(k.removeprefix('DEXKIT_EXPERIMENT_') for k, v in frozen['native_manifests']['uncached']['cmake_options'].items()
               if k.startswith('DEXKIT_EXPERIMENT_') and v == 'ON')
text += ['`' + '`, `'.join(flags) + '`.', '',
         'The pre-measurement harness commit is `' + frozen['harness_commit'] + '`.',
         'Frozen plan SHA256: `' + sha(OUT / 'frozen-plan.json') + '`.', '',
         'The evidence directory [evidence/uncached-master/v1/](evidence/uncached-master/v1/)',
         'contains the frozen plan, source identities, summaries and an archive with',
         'the driver, harness, verification reports and all timed process records.',
         'The archive excludes the QQ APK, DEX files, JARs and compiled binaries.',
         'Its member hashes and archive hash are verified after writing. Reproduction',
         'commands and exact native artifact identities are in the frozen plan.', '']
assert all(ord(c) < 128 for c in '\n'.join(text))
REPORT.write_text('\n'.join(text))
print(REPORT)
for row in rows:
    m = row['metrics']
    print(row['name'], 'seconds', absolute(m['lifecycle_ms'], 1000, 3), change(m['lifecycle_ms']),
          'MiB', absolute(m['peak_footprint_bytes'], 2**20, 2), change(m['peak_footprint_bytes']))
