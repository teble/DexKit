"""Archive the completed comparison without APKs, JARs or compiled artifacts."""
import hashlib
import json
import shutil
import tarfile
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/teble/project/android/DexKit-qaux-benchmark')
DEST = ROOT / 'tools/qaux-benchmark/evidence/uncached-master/v1'
REPORT = ROOT / 'tools/qaux-benchmark/UNCACHED-MASTER-COMPARISON.md'


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


assert not DEST.exists(), 'Do not overwrite archived evidence'
summary = json.loads((OUT / 'summary.json').read_text())
assert summary['samples'] == 96 and summary['all_raw_pair_arithmetic_verified']
frozen = json.loads((OUT / 'frozen-plan.json').read_text())
files = {}
for path in OUT.rglob('*'):
    if path.is_file() and path.suffix in ['.json', '.log', '.py', '.md']:
        files['run/' + path.relative_to(OUT).as_posix()] = path
files['UNCACHED-MASTER-COMPARISON.md'] = REPORT
for name in ['run.py', 'sweep.py', 'QueryReplay.java', 'baseline/expected.json']:
    files['harness/' + name] = ROOT / 'tools/qaux-benchmark' / name
for label, directory in [('master', OUT.parent / 'artifacts/baseline-rebuilt'),
                         ('uncached', OUT.parent / 'uncached-descriptors-v1/artifacts/uncached')]:
    for name in ['artifact.json', 'source.patch']:
        files['native/' + label + '/' + name] = directory / name
files['oracles/field-rw-expected.json'] = OUT.parent / 'followup/formal/field-tail-oracle-best5/field-rw-expected.json'
assert not any(p.suffix in ['.apk', '.dex', '.jar', '.class', '.dylib', '.o', '.a'] for p in files.values())

DEST.mkdir(parents=True)
archive = DEST / 'raw-evidence.tar.gz'
members = {name: dict(sha256=sha(path), size=path.stat().st_size) for name, path in sorted(files.items())}
with tarfile.open(archive, 'w:gz') as tar:
    for name, path in sorted(files.items()):
        tar.add(path, arcname=name, recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    assert set(tar.getnames()) == set(members)
    for item in tar.getmembers():
        with tar.extractfile(item) as stream:
            content = stream.read()
        assert hashlib.sha256(content).hexdigest() == members[item.name]['sha256']
        assert len(content) == members[item.name]['size']
manifest = dict(archive=archive.name, archive_sha256=sha(archive),
                archive_size=archive.stat().st_size, members=members)
save(DEST / 'manifest.json', manifest)
save(DEST / 'integrity.json', dict(all_members_read_back_and_verified=True,
                                 member_count=len(members), archive_sha256=manifest['archive_sha256'],
                                 archive_size=manifest['archive_size']))
for name in ['summary.json', 'frozen-plan.json', 'complete.json']:
    shutil.copyfile(OUT / name, DEST / name)
save(DEST / 'source-identity.json', dict(native_manifests=frozen['native_manifests'],
                                       harness_commit=frozen['harness_commit'],
                                       frozen_plan_sha256=sha(OUT / 'frozen-plan.json'),
                                       report_sha256=sha(REPORT)))
print(json.dumps({k: v for k, v in manifest.items() if k != 'members'}, indent=2))
print('Verified archive members:', len(members))
