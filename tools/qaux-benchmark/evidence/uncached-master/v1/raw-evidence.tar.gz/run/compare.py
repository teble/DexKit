"""Direct, bounded QQ comparison: master versus Small14 plus uncached descriptors."""
import datetime
import hashlib
import json
import platform
import subprocess
import sys
from pathlib import Path

ROOT = Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE = Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
OUT = BASE / 'master-uncached-v1'
JDK = Path('/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home')
ARTIFACTS = {
    'master': BASE / 'artifacts/baseline-rebuilt',
    'uncached': BASE / 'uncached-descriptors-v1/artifacts/uncached',
}
COMMITS = {
    'master': '1d936bd9efa38e00b7336ef112e73ba4048324e6',
    'uncached': '2be1a63f1ac9de56f6e5cd53123322388e598006',
}
FIELD = 'Lcom/tencent/mobileqq/data/MessageRecord;->msg:Ljava/lang/String;'
ORACLE = BASE / 'followup/formal/field-tail-oracle-best5/field-rw-expected.json'


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def common(scenario):
    cmd = ['--dexkit-root', ROOT, '--corpus', BASE / 'qaux-extracted',
           '--apk', BASE / 'qq-9.3.55.apk', '--java-home', JDK,
           '--profile', 'all', '--threads', 4,
           '--memory-probe', BASE / 'artifacts/probe-v2/libqauxbench_probe.dylib']
    if scenario == 'tail':
        cmd += ['--final-field-rw', FIELD, '--field-rw-expected', ORACLE]
    return list(map(str, cmd))


def verified(label, scenario):
    return OUT / 'validation' / ('verify-' + label + '-' + scenario)


def execute(name, cmd):
    print('START ' + name, flush=True)
    with (OUT / (name + '-launcher.log')).open('w') as log:
        result = subprocess.run(list(map(str, cmd)), cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    if result.returncode:
        print((OUT / (name + '-launcher.log')).read_text()[-7000:], flush=True)
        raise SystemExit(result.returncode)
    print('DONE ' + name, flush=True)


def plan():
    items = []
    for phase, seed in [('main', 2026092910), ('confirm', 2026093010)]:
        for scenario in ['normal', 'tail']:
            for passes in [1, 11]:
                seed += 1
                name = f'{phase}-{scenario}-p{passes}-w4'
                cmd = [sys.executable, ROOT / 'tools/qaux-benchmark/sweep.py', *common(scenario),
                       '--passes', passes, '--pairs', 6, '--seed', seed,
                       '--output', OUT / 'measurements' / name]
                for label, artifact in ARTIFACTS.items():
                    cmd += ['--variant', label, artifact / 'libdexkit.dylib', verified(label, scenario)]
                items.append(dict(name=name, phase=phase, scenario=scenario, passes=passes,
                                  threads=4, pairs=6, seed=seed, command=list(map(str, cmd))))
    return items


def check_files(frozen):
    for path, expected in frozen['files'].items():
        assert sha(path) == expected, 'Frozen input changed: ' + path


action = sys.argv[1]
assert action in ['verify', 'freeze', 'run']
if action == 'verify':
    (OUT / 'validation').mkdir(exist_ok=True)
    for scenario in ['normal', 'tail']:
        for label, artifact in ARTIFACTS.items():
            target = verified(label, scenario)
            assert not target.exists(), 'Do not overwrite a verification run'
            execute(target.name, [sys.executable, ROOT / 'tools/qaux-benchmark/run.py',
                    *common(scenario), '--mode', 'verify', '--passes', 11,
                    '--native-library', artifact / 'libdexkit.dylib', '--output', target])
            metadata = json.loads((target / 'run-metadata.json').read_text())
            assert metadata['exit_code'] == 0 and metadata['baseline_results_equal'] is True
    print('VERIFIED: four complete 11-pass runs', flush=True)
    sys.exit(0)

frozen_path = OUT / 'frozen-plan.json'
if action == 'freeze':
    assert not frozen_path.exists()
    assert not subprocess.check_output(['git', '-C', ROOT, 'status', '--porcelain'], text=True).strip()
    paths = [Path(__file__), OUT / 'PLAN.md', ORACLE, BASE / 'qq-9.3.55.apk',
             BASE / 'artifacts/probe-v2/libqauxbench_probe.dylib']
    paths += list((BASE / 'qaux-extracted').glob('*.json')) + [BASE / 'qaux-extracted/groups.tsv']
    paths += [ROOT / 'tools/qaux-benchmark' / name for name in
              ['run.py', 'sweep.py', 'QueryReplay.java', 'baseline/expected.json']]
    manifests = {}
    for label, artifact in ARTIFACTS.items():
        manifest = json.loads((artifact / 'artifact.json').read_text())
        assert manifest['engine_commit'] == COMMITS[label]
        assert manifest['native_sha256'] == sha(artifact / 'libdexkit.dylib')
        assert manifest['diagnostics'] is False and not manifest.get('untracked_source_sha256')
        assert (artifact / 'source.patch').read_text() == '\n'
        options = manifest['cmake_options']
        for key in ['DEXKIT_ENABLE_INTERNAL_METRICS', 'DEXKIT_ENABLE_INTERNAL_METRICS_API',
                    'DEXKIT_BENCHMARK_DIAGNOSTICS', 'DEXKIT_BENCHMARK_STRING_TRACE',
                    'DEXKIT_BENCHMARK_BATCH_TRACE', 'DEXKIT_BENCHMARK_FIELD_TRACE']:
            assert options.get(key, 'OFF') in ['OFF', '0', 'FALSE']
        for directory, expected in manifest['source_trees'].items():
            actual = subprocess.check_output(['git', '-C', ROOT, 'rev-parse',
                                              COMMITS[label] + ':' + directory], text=True).strip()
            assert actual == expected
        if label == 'uncached':
            for name in ['UNCACHED_DESCRIPTORS', 'RAW_DESCRIPTOR_LOOKUP', 'STRUCTURAL_DESCRIPTORS']:
                assert options['DEXKIT_EXPERIMENT_' + name] == 'ON'
        manifests[label] = manifest
        paths += [artifact / name for name in ['artifact.json', 'source.patch', 'libdexkit.dylib']]
        for scenario in ['normal', 'tail']:
            directory = verified(label, scenario)
            metadata = json.loads((directory / 'run-metadata.json').read_text())
            assert metadata['exit_code'] == 0 and metadata['baseline_results_equal'] is True
            assert metadata['native_sha256'] == manifest['native_sha256']
            assert metadata['passes'] == 11 and metadata['threads'] == 4
            paths += list(directory.glob('*.json'))
            paths += list(map(Path, metadata['jars_sha256'])) + list(map(Path, metadata['java_identity']))
    assert manifests['master']['compiler'] == manifests['uncached']['compiler']
    for key in ['CMAKE_BUILD_TYPE', 'CMAKE_C_COMPILER', 'CMAKE_CXX_COMPILER',
                'CMAKE_C_FLAGS_RELEASE', 'CMAKE_CXX_FLAGS_RELEASE', 'CMAKE_OSX_ARCHITECTURES',
                'CMAKE_OSX_DEPLOYMENT_TARGET', 'CMAKE_OSX_SYSROOT']:
        assert manifests['master']['cmake_options'][key] == manifests['uncached']['cmake_options'][key]
    assert not subprocess.check_output(['git', '-C', ROOT, 'diff', COMMITS['master'], COMMITS['uncached'],
                                       '--', 'dexkit/src/main/java', 'schema/fbs'], text=True)
    paths += [JDK / 'bin/javac']
    frozen = dict(frozen_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  harness_commit=subprocess.check_output(['git', '-C', ROOT, 'rev-parse', 'HEAD'], text=True).strip(),
                  platform=platform.platform(), native_manifests=manifests,
                  policy='Eight sweeps, 96 fresh JVMs; two phases, six balanced AB/BA pairs per cell. '
                  'Use all successful samples; no tuning, builds, extra tests or archive compression during timing. '
                  'Do not combine historical relative percentages. Lifecycle includes create, queries, tail where present, and close. '
                  'Physical peak includes JVM overhead; OS caches are not flushed. These are macOS host measurements.',
                  files={str(p): sha(p) for p in sorted(set(paths))}, sweeps=plan())
    save(frozen_path, frozen)
    print('FROZEN ' + sha(frozen_path) + ': eight sweeps / 96 fresh processes', flush=True)
    sys.exit(0)

frozen = json.loads(frozen_path.read_text())
assert frozen['sweeps'] == plan()
check_files(frozen)
(OUT / 'measurements').mkdir(exist_ok=True)
completed_path = OUT / 'completed.json'
assert not completed_path.exists(), 'Choose a new dataset if a batch was already started'
completed = []
for item in frozen['sweeps']:
    execute(item['name'], item['command'])
    summary_path = OUT / 'measurements' / item['name'] / 'summary.json'
    completed.append(dict(item, summary_sha256=sha(summary_path)))
    save(completed_path, completed)
    metrics = json.loads(summary_path.read_text())['metrics']
    print('RESULT ' + item['name'] + ' lifecycle=%+.2f%% peak=%+.2f%%' % (
        metrics['lifecycle_ms']['median_change_percent'],
        metrics['peak_footprint_bytes']['median_change_percent']), flush=True)
check_files(frozen)
save(OUT / 'complete.json', dict(sweeps=len(completed), samples=96, frozen_inputs_unchanged=True,
                               frozen_plan_sha256=sha(frozen_path)))
print('COMPLETE: 96 samples, frozen inputs unchanged', flush=True)
