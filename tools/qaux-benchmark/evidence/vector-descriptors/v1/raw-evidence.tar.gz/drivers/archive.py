"""Archive the completed vector batch with explicit engine and harness provenance."""
import hashlib,json,shutil,subprocess,tarfile
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
E=BASE/'vector-descriptors-v1'
DEST=ROOT/'tools/qaux-benchmark/evidence/vector-descriptors/v1'
ENGINE='4f7a82c44ab593c9db334e7623e06eede280220c'
BASELINE='3118b4ef8adb361bb7f2ca9f4cf799da582296a2'
summary=json.loads((E/'summary.json').read_text());HARNESS=summary['harness_commit']
assert summary['accepted_sweeps']==82 and summary['accepted_fresh_processes']==984
DEST.mkdir(parents=True,exist_ok=True)
assert not (DEST/'raw-evidence.tar.gz').exists()
files={}
def sha(path):
 value=hashlib.sha256()
 with Path(path).open('rb') as stream:
  for block in iter(lambda:stream.read(1024*1024),b''):value.update(block)
 return value.hexdigest()
def add(path,name):
 assert path.is_file() and name not in files,(path,name)
 files[name]=path
def tree(path,prefix):
 allowed={'.log','.json','.txt','.md','.bin','.s','.cpp','.h','.py','.gradle','.xml','.patch','.gz'}
 for file in sorted(path.rglob('*')):
  if not file.is_file():continue
  relative=file.relative_to(path)
  if any(part in ['classes','__pycache__','build','source-extra'] for part in relative.parts):continue
  if file.suffix not in allowed:continue
  add(file,prefix+'/'+str(relative))
def export(commit,relative,prefix):
 path=E/'source-export'/commit[:7]/relative;path.parent.mkdir(parents=True,exist_ok=True)
 path.write_bytes(subprocess.check_output(['git','-C',ROOT,'show',commit+':'+relative]))
 add(path,prefix+'/'+relative)
for name in ['measurements','validation']:tree(E/name,name)
for p in sorted(E.glob('*.py')):add(p,'drivers/'+p.name)
for name in ['summary.json','summary-output.txt']:add(E/name,name)
for directory in sorted((E/'artifacts').iterdir()):
 for p in sorted(directory.iterdir()):
  if p.is_file() and p.suffix in ['.json','.txt','.log','.patch']:add(p,'artifacts/'+directory.name+'/'+p.name)
# Includes the two development failures, their initial snapshots/outputs and
# the revised checks; executable/object/build directories remain excluded.
tree(E/'development','development')
for relative in ['followup/fixtures/relations','followup/fixtures/field-adverse',
 'followup/fixtures/invoke-tiny','followup/fixtures/invoke-mixed','followup/fixtures/invoke-giant',
 'followup/fixtures/dense-descriptors','raw-metadata/symbol-fixture','raw-metadata/overload-fixture',
 'next-round/fixtures/field-small-v1','next-round/fixtures/field-short-v1',
 'next-round/fixtures/field-long-v1','next-round/fixtures/field-unresolved-v1','compact-callers-v2/fixtures/contracts']:
 tree(BASE/relative,'inputs/'+relative)
add(BASE/'followup/formal/field-tail-oracle-best5/field-rw-expected.json','inputs/field-rw-expected.json')
changed=subprocess.check_output(['git','-C',ROOT,'diff','--name-only',BASELINE,ENGINE],text=True).splitlines()
for relative in sorted(set(changed+['Core/dexkit/include/hybrid_descriptor_cache.h','Core/dexkit/include/beans.h','Core/dexkit/beans.cpp'])):
 if relative.startswith('Core/') or relative in ['dexkit/build.gradle','dexkit-android/build.gradle']:export(ENGINE,relative,'source/engine')
patch=E/'engine.patch';patch.write_bytes(subprocess.check_output(['git','-C',ROOT,'diff',BASELINE,ENGINE,'--','Core','dexkit/build.gradle','dexkit-android/build.gradle']))
add(patch,'source/engine.patch')
for commit,prefix in [(ENGINE,'source/original-harness'),(HARNESS,'source/measured-harness')]:
 tracked=subprocess.check_output(['git','-C',ROOT,'ls-tree','--name-only','-r',commit,'--','tools/qaux-benchmark'],text=True).splitlines()
 for relative in tracked:
  p=Path(relative)
  if p.parent==Path('tools/qaux-benchmark') and p.suffix in ['.py','.cpp','.h','.java','.gradle','.json']:export(commit,relative,prefix)
for relative in ['README.md','README_zh.md','Core/dexkit/include/dexkit.h',
 'doc-source/src/en/guide/performance-optimization.md','doc-source/src/zh-cn/guide/performance-optimization.md']:
 export(HARNESS,relative,'source/contract-and-docs')
for p in sorted((ROOT/'tools/qaux-benchmark').glob('VECTOR-DESCRIPTORS-*.md')):add(p,'source/reports/'+p.name)
tree(ROOT/'tools/qaux-benchmark/licenses','source/licenses')
identity=dict(base_source=BASELINE,normal_engine_commit=ENGINE,diagnostic_engine_commit=ENGINE,harness_commit=HARNESS,
 native_libraries=summary['native_libraries'],frozen_plan_sha256=summary['frozen_plan_sha256'],
 note='All four normal variants and frozen Core archives were built at 4f7a82c. Revised relation and worker '
  'check executables and diagnostic first-stage snapshots link those unchanged archives. Their copied source, '
  'commands and hashes are retained, and the final normal transition source preprocesses identically to 4f7a82c. '
  'The timed Python/Java harness is exported from the frozen d078369 snapshot; external experiment drivers are '
  'separately included. Reports describe the completed batch. Obtain APK/corpus, repo and toolchain inputs separately.')
(DEST/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
integrity={name:dict(bytes=p.stat().st_size,sha256=sha(p)) for name,p in sorted(files.items())}
archive=DEST/'raw-evidence.tar.gz';canonical={};hardlinks=0
with tarfile.open(archive,'w:gz',compresslevel=6,dereference=True) as tar:
 for name,p in sorted(files.items()):
  key=integrity[name]['sha256'] if p.suffix=='.bin' else None
  if key is not None and key in canonical:
   member=tarfile.TarInfo(name);member.type=tarfile.LNKTYPE;member.linkname=canonical[key];member.mode=0o644
   tar.addfile(member);hardlinks+=1
  else:
   tar.add(p,arcname=name,recursive=False)
   if key is not None:canonical[key]=name
verified={}
with tarfile.open(archive,'r|gz') as tar:
 for member in tar:
  assert member.name in integrity and member.name not in verified
  expected=integrity[member.name]
  if member.islnk():assert member.linkname in verified and verified[member.linkname]==expected
  else:
   assert member.isfile(),member.name
   stream=tar.extractfile(member);value=hashlib.sha256();size=0
   for block in iter(lambda:stream.read(1024*1024),b''):value.update(block);size+=len(block)
   assert size==expected['bytes'] and value.hexdigest()==expected['sha256'],member.name
  verified[member.name]=expected
assert verified==integrity
(DEST/'integrity.json').write_text(json.dumps(integrity,indent=2)+'\n')
for p in [E/'summary.json',E/'validation/validation-summary.json']:shutil.copyfile(p,DEST/p.name)
manifest=dict(archive=archive.name,archive_bytes=archive.stat().st_size,archive_sha256=sha(archive),files=len(files),
 identical_oracle_hardlinks=hardlinks,verified_readback=True,accepted_sweeps=82,accepted_fresh_processes=984,
 excluded_measurements=0,omitted=['All APK/DEX inputs','QQ corpus','Compiled native/JVM/Android artifacts'],
 integrity_sha256=sha(DEST/'integrity.json'))
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2),flush=True)
