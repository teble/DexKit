from pathlib import Path
BASE=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55')
E=BASE/'vector-descriptors-v1'
FIXTURES={'dense':BASE/'followup/fixtures/dense-descriptors/dense-descriptors.apk',
          'symbol':BASE/'raw-metadata/symbol-fixture/symbols.apk',
          'overload':BASE/'raw-metadata/overload-fixture/symbols.apk'}
CASES=[]
for name,fixture,mode,repeats in [
    ('wide','symbol','lookup',512),('prefix','overload','lookup-prefix',256),
    ('hot','symbol','lookup-hot',100000),('long-output','symbol','output',16),
    ('sso-prefix','dense','output-sso-prefix',16),('sso-scattered','dense','output-sso-scattered',16),
    ('narrow-w1','symbol','lookup-concurrent-w1',20000),('narrow-w4','symbol','lookup-concurrent-w4',20000)]:
 CASES.append(dict(name=name,fixture=fixture,mode=mode,repeats=repeats))
for kind in ['method','field']:
 for repeats in [1,2,16]:
  CASES.append(dict(name=kind+'-full-'+str(repeats),fixture='dense',mode='transition-'+kind+'-full-w1',repeats=repeats))
for name,pattern,repeats,workers in [('method-changed-2','changed',2,1),('low-id-w1','low',1000,1),
    ('low-id-w4','low',1000,4),('method-full-w4','full',16,4)]:
 CASES.append(dict(name=name,fixture='dense',mode='transition-method-'+pattern+'-w'+str(workers),repeats=repeats))
DENSE_CASES={'wide','prefix','hot','long-output','method-changed-2','method-full-w4'}|{kind+'-full-'+str(n) for kind in ['method','field'] for n in [1,2,16]}
NO_PROMOTION_CASES={'wide','method-full-2','method-full-16','low-id-w4'}
LABELS=['control','hybrid','vector','vector-no-promotion']
assert len(CASES)==18 and len(DENSE_CASES)==12

def native_command(label,case,smoke=False):
 mode=case['mode'];n=1 if case['repeats']==1 else 2 if smoke else case['repeats']
 path=E/'artifacts'/label/'build/Core'
 fixture=FIXTURES[case['fixture']]
 if mode.startswith('transition-'):
  _,kind,pattern,threads=mode.split('-')
  return [path/'dexkit_descriptor_transition_workload',fixture,kind,pattern,n,threads[1:]]
 if mode.startswith('lookup-concurrent-'):
  return [path/'dexkit_descriptor_concurrent_workload',fixture,n,mode[-1]]
 return [path/'dexkit_descriptor_workload',fixture,mode,n]
