import hashlib,json,subprocess,sys
from pathlib import Path
from cases import BASE,E,CASES,native_command
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
V=E/'validation'
records_path=V/'census-checks.json'
records=json.loads(records_path.read_text()) if records_path.exists() else []
def run(name,cmd):
 path=V/(name+'.log');cmd=list(map(str,cmd))
 old=next((r for r in records if r['name']==name),None)
 if old:
  assert old['command']==cmd and old['sha256']==hashlib.sha256(path.read_bytes()).hexdigest()
  return path
 with path.open('w') as log:subprocess.run(cmd,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=300,check=True)
 records.append(dict(name=name,command=cmd,sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
 records_path.write_text(json.dumps(records,indent=2)+'\n')
 print('DONE '+name,flush=True)
 return path

def rows(path,prefix):
 return [json.loads(line[len(prefix):]) for line in path.read_text().splitlines() if line.startswith(prefix)]

if sys.argv[1]=='native':
 summary=[]
 for label in ['vector-trace','vector-no-promotion-trace']:
  for case in CASES:
   path=run('census-'+label+'-'+case['name'],native_command(label,case))
   domains=[row for row in rows(path,'BENCH_VECTOR_DESCRIPTOR_DOMAIN ') if row['phase'].endswith('workload-complete')]
   maintenance=[row for row in rows(path,'BENCH_VECTOR_DESCRIPTOR_MAINTENANCE ') if row['phase'].endswith('workload-complete')]
   assert domains and len(maintenance)==1
   for d in domains:
    assert d['calls']-d['hits']==d['sparse_builds']+d['dense_builds']
    assert d['records']==d['sparse_records']+d['dense_builds']
    assert d['conversions']<=1
    if d['dense']:
     assert d['conversions']==1 and not d['pending']
     assert all(d[k]==0 for k in ['bucket_bytes','payload_owner_bytes','block_bytes','directory_bytes','sparse_char_bytes','sparse_structural_bytes'])
     assert d['structural_at_conversion']>=d['conversion_base_bytes']
    if label=='vector-no-promotion-trace':assert not d['dense'] and not d['pending'] and d['dense_builds']==0
   if case['mode'].startswith('transition-') and case['mode'].endswith('-w1'):
    _,kind,pattern,_=case['mode'].split('-');n=case['repeats']
    d=next(d for d in domains if d['kind']==kind)
    other=next(d for d in domains if d['kind']!=kind)
    assert other['records']==0 and not other['dense']
    expected_first=60000 if pattern=='full' else 30000 if pattern=='changed' else 64
    converting=label=='vector-trace' and pattern!='low' and n>1
    assert d['conversions']==int(converting)
    if converting:
     assert d['discarded_records']==expected_first and d['sparse_builds']==expected_first
     assert d['dense_builds']==expected_first
    else:
     assert d['dense_builds']==0 and d['discarded_records']==0
     assert d['sparse_builds']==(60000 if pattern=='changed' and n>1 else expected_first)
    if n==1:assert maintenance[0]['runs']==0
   summary.append(dict(label=label,case=case['name'],domains=domains,maintenance=maintenance[0]))
 (V/'census-native.json').write_text(json.dumps(summary,indent=2)+'\n')
 print('COMPLETE native census '+str(len(summary)),flush=True)
else:
 assert sys.argv[1]=='qq'
 jdk='/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home'
 plans=[('vector-trace',False),('vector-no-promotion-trace',False),('vector',True),('vector-no-promotion',True)]
 summaries=[]
 for label,tail in plans:
  name='verify-'+label+('-tail' if tail else '-census')+'-w4'
  cmd=['python3',ROOT/'tools/qaux-benchmark/run.py','--dexkit-root',ROOT,'--corpus',BASE/'qaux-extracted',
    '--apk',BASE/'qq-9.3.55.apk','--java-home',jdk,'--memory-probe',BASE/'artifacts/probe-v2/libqauxbench_probe.dylib',
    '--output',V/name,'--native-library',E/'artifacts'/label/'libdexkit.dylib','--passes','11','--threads','4','--profile','all','--mode','verify']
  if tail:cmd+=['--final-field-rw','Lcom/tencent/mobileqq/data/MessageRecord;->msg:Ljava/lang/String;',
    '--field-rw-expected',BASE/'followup/formal/field-tail-oracle-best5/field-rw-expected.json']
  run(name,cmd)
  metadata=json.loads((V/name/'run-metadata.json').read_text())
  assert metadata['baseline_results_equal'] is True
  if tail:assert metadata['final_field_rw_results_equal'] is True
  else:
   domains=rows(V/name/'run.log','BENCH_VECTOR_DESCRIPTOR_DOMAIN ')
   assert domains
   for d in domains:assert d['calls']-d['hits']==d['sparse_builds']+d['dense_builds']
   # Keep all phases so any actual conversion is reported, not assumed absent.
   summaries.append(dict(label=label,domain_rows=domains,maintenance=rows(V/name/'run.log','BENCH_VECTOR_DESCRIPTOR_MAINTENANCE ')))
 (V/'census-qq.json').write_text(json.dumps(summaries,indent=2)+'\n')
 print('COMPLETE QQ census and field-tail oracles',flush=True)
