from pathlib import Path
import hashlib,json,re,subprocess
E=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/vector-descriptors-v1')
records=[]
for label in ['control','hybrid','vector','vector-no-promotion']:
 for target in ['libdexkit.dylib','build/Core/dexkit_descriptor_workload']:
  path=E/'artifacts'/label/target
  dis=subprocess.check_output(['otool','-tv',str(path)],text=True)
  symbols=list(re.finditer(r'^(__?ZN6dexkit7DexItem[^\n]+):$',dis,re.M))
  for kind in ['Method','Field']:
   for shape in (['getter'] if target=='libdexkit.dylib' else ['lookup','index']):
    stem='Get'+kind+('DescriptorEj' if shape=='getter' else 'BeanEj')
    matches=[m for m in symbols if stem in m.group(1) and (shape=='getter' or ('basic_string_view' in m.group(1))==(shape=='lookup'))]
    assert len(matches)==1,(label,kind,shape)
    m=matches[0];body=dis[m.start():]
    end=re.search(r'\n[^ \n\t0-9][^\n]*:\n',body[len(m.group(0)):])
    if end:body=body[:len(m.group(0))+end.start()]
    out=E/'validation'/(shape+'-'+kind.lower()+'-'+label+'.s')
    out.write_text(body+'\n')
    instructions=[line for line in body.splitlines() if re.match(r'^[0-9a-f]{16}\t',line)]
    record=dict(label=label,kind=kind,shape=shape,path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),assembly=str(out),instructions=len(instructions),acquires=[line for line in instructions if any(op in line for op in ['\tldapr','\tldar'])],calls=[line for line in instructions if '\tbl\t' in line])
    records.append(record)
    print(label,kind,shape,'instructions',len(instructions),'acquires',len(record['acquires']),flush=True)
(E/'validation/codegen.json').write_text(json.dumps(records,indent=2)+'\n')
