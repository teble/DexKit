"""A fixed independent-vector comparison with a main phase and one confirmation."""
import datetime,hashlib,json,platform,subprocess,sys
from pathlib import Path
from cases import BASE,E,CASES,DENSE_CASES,NO_PROMOTION_CASES,LABELS,FIXTURES
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
OUT=E/'measurements'
JDK=Path('/Users/teble/Library/Java/JavaVirtualMachines/jbr-17.0.6/Contents/Home')
ENGINE='4f7a82c44ab593c9db334e7623e06eede280220c'
ARTIFACTS={label:E/'artifacts'/label for label in LABELS}

def sha(path):
 value=hashlib.sha256()
 with Path(path).open('rb') as stream:
  for block in iter(lambda:stream.read(1024*1024),b''):value.update(block)
 return value.hexdigest()

def plan():
 result=[]
 for phase,seed in [('main',2026092240),('confirm',2026092340)]:
  for case in CASES:
   edges=[('hybrid','vector')]
   if case['name'] in DENSE_CASES:edges.append(('control','vector'))
   if case['name'] in NO_PROMOTION_CASES:edges.append(('vector-no-promotion','vector'))
   for left,right in edges:
    seed+=1
    result.append(dict(name=f'{phase}-{left}-to-{right}-{case["name"]}',phase=phase,kind='native',
     labels=[left,right],pairs=6,seed=seed,case=case['name'],fixture=str(FIXTURES[case['fixture']]),
     mode=case['mode'],repeats=case['repeats']))
  for passes,workers in [(1,4),(11,4),(1,1)]:
   edges=[('hybrid','vector'),('control','vector')]
   if passes==1 and workers==4:edges.append(('vector-no-promotion','vector'))
   for left,right in edges:
    seed+=1
    result.append(dict(name=f'{phase}-{left}-to-{right}-qq-p{passes}-w{workers}',phase=phase,kind='qq',
     labels=[left,right],pairs=6,seed=seed,passes=passes,threads=workers,profile='all'))
 assert len(result)==82
 return result

def command(item):
 if item['kind']=='native':
  cmd=[sys.executable,ROOT/'tools/qaux-benchmark/workload_sweep.py','--fixture',item['fixture'],
   '--output',OUT/item['name'],'--mode',item['mode'],'--repeats',item['repeats'],'--pairs',item['pairs'],'--seed',item['seed']]
  for label in item['labels']:cmd+=['--variant',label,ARTIFACTS[label]]
 else:
  cmd=[sys.executable,ROOT/'tools/qaux-benchmark/sweep.py','--dexkit-root',ROOT,'--corpus',BASE/'qaux-extracted',
   '--apk',BASE/'qq-9.3.55.apk','--java-home',JDK,'--memory-probe',BASE/'artifacts/probe-v2/libqauxbench_probe.dylib',
   '--output',OUT/item['name'],'--pairs',item['pairs'],'--seed',item['seed'],'--passes',item['passes'],
   '--threads',item['threads'],'--profile','all']
  for label in item['labels']:
   cmd+=['--variant',label,ARTIFACTS[label]/'libdexkit.dylib',E/'validation'/('verify-'+label+'-w'+str(item['threads']))]
 return list(map(str,cmd))

def executable(label,mode):
 name='descriptor_transition' if mode.startswith('transition-') else 'descriptor_concurrent' if mode.startswith('lookup-concurrent-') else 'descriptor'
 return ARTIFACTS[label]/'build/Core'/('dexkit_'+name+'_workload')

action=sys.argv[1];assert action in ['freeze','run']
OUT.mkdir(exist_ok=True);frozen_path=OUT/'frozen-plan.json';items=plan()
if action=='freeze':
 assert not frozen_path.exists()
 assert not subprocess.check_output(['git','-C',ROOT,'status','--porcelain'],text=True).strip()
 paths=[Path(__file__),E/'cases.py',E/'smoke.py',E/'census.py',E/'validate.py',E/'build.py',E/'gradle.py',E/'verify_qq.py',
  E/'review_validate.py',E/'rebuild_review_checks.py',E/'rebuild_relation_check.py',E/'codegen.py',E/'layout.py',
  BASE/'qq-9.3.55.apk',JDK/'bin/java',JDK/'bin/javac',BASE/'artifacts/probe-v2/libqauxbench_probe.dylib']+list(FIXTURES.values())
 paths += [ROOT/'tools/qaux-benchmark'/name for name in ['workload_sweep.py','sweep.py','run.py','QueryReplay.java',
  'descriptor_workload.cpp','descriptor_concurrent_workload.cpp','descriptor_transition_workload.cpp',
  'VECTOR-DESCRIPTORS-EXECUTION.md','VECTOR-DESCRIPTORS-REVIEW.md']]
 paths += [E/'validation'/name for name in ['checks-normal.json','checks-trace.json','checks-isolated.json','checks-sanitize.json',
  'workload-smokes.json','gradle/validation.json','qq-verification.json','census-checks.json','census-native.json','census-qq.json',
  'layout/summary.json','codegen.json','revised-relations/builds.json','pro-review-checks/builds.json',
  'pro-review-checks/checks.json','pro-review-checks/phases.json','pro-review-checks/normal-preprocessed-equality.json',
  'docs-install.log','docs-build-review-final.log']]
 for phase in ['normal','trace','isolated','sanitize']:
  complete=E/'validation'/('complete-'+phase+'.json');proof=json.loads(complete.read_text())
  assert proof['checks_sha256']==sha(E/'validation'/('checks-'+phase+'.json'))
  paths.append(complete)
 assert len(json.loads((E/'validation/workload-smokes.json').read_text()))==72
 assert len(json.loads((E/'validation/pro-review-checks/checks.json').read_text()))==4
 assert len(json.loads((E/'validation/pro-review-checks/phases.json').read_text()))==6
 gradle=json.loads((E/'validation/gradle/validation.json').read_text())
 assert gradle['total_tests']==71 and gradle['skipped']==0 and len(gradle['abis'])==4
 assert 'success VuePress build completed' in (E/'validation/docs-build-review-final.log').read_text()
 paths+=list((E/'validation').glob('*.s'))
 manifests={}
 selected={'control':(False,False,False),'hybrid':(True,False,False),'vector':(False,True,False),'vector-no-promotion':(False,True,True)}
 for label in LABELS:
  artifact=ARTIFACTS[label];manifest=json.loads((artifact/'artifact.json').read_text());manifests[label]=manifest
  assert manifest['engine_commit']==ENGINE and manifest['diagnostics'] is False and not manifest['untracked_source_sha256']
  assert (artifact/'source.patch').read_text()=='\n'
  assert manifest['native_sha256']==sha(artifact/'libdexkit.dylib')
  paths += [artifact/'artifact.json',artifact/'libdexkit.dylib',artifact/'workload-sources.json']
  options=manifest['cmake_options']
  for flag,enabled in zip(['HYBRID_DESCRIPTORS','VECTOR_DESCRIPTORS','VECTOR_DESCRIPTORS_NO_PROMOTION'],selected[label]):
   assert options['DEXKIT_EXPERIMENT_'+flag]==('ON' if enabled else 'OFF')
  for name in ['NODE_DESCRIPTORS','SPARSE_DESCRIPTORS','POINTER_DESCRIPTORS','PAGED_DESCRIPTORS','PACKED_CROSS_INFO','PACKED_FIELD_USES','COMPACT_FIELDS','CANDIDATE_PIPELINE','CANDIDATE_SLICES']:
   assert options['DEXKIT_EXPERIMENT_'+name]=='OFF'
  for key in ['DEXKIT_ENABLE_INTERNAL_METRICS','DEXKIT_ENABLE_INTERNAL_METRICS_API']:
   assert options[key]=='OFF'
  for workers in [1,4]:
   path=E/'validation'/('verify-'+label+'-w'+str(workers))/'run-metadata.json'
   metadata=json.loads(path.read_text())
   assert metadata['exit_code']==0 and metadata['baseline_results_equal'] is True and metadata['native_sha256']==manifest['native_sha256']
   paths += [path]+list(map(Path,metadata['jars_sha256']))
  source_hashes=json.loads((artifact/'workload-sources.json').read_text())
  for name in ['descriptor_workload.cpp','descriptor_concurrent_workload.cpp']:
   assert source_hashes['tools/qaux-benchmark/'+name]==sha(ROOT/'tools/qaux-benchmark'/name)
 normalized=[]
 for m in manifests.values():
  normalized.append({k:v for k,v in m['cmake_options'].items() if k not in ['DEXKIT_EXPERIMENT_'+name for name in ['HYBRID_DESCRIPTORS','VECTOR_DESCRIPTORS','VECTOR_DESCRIPTORS_NO_PROMOTION']]})
 assert all(options==normalized[0] for options in normalized)
 assert all(m['compiler']==manifests['control']['compiler'] for m in manifests.values())
 for item in items:
  if item['kind']=='native':paths += [executable(label,item['mode']) for label in item['labels']]
 frozen=dict(frozen_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
  worktree_head=subprocess.check_output(['git','-C',ROOT,'rev-parse','HEAD'],text=True).strip(),
  normal_engine_commit=ENGINE,platform=platform.platform(),
  policy='82 sweeps / 984 fresh processes: main and one independent confirmation, 6 balanced AB/BA pairs each. '
   'All four artifacts use the same frozen source and Small14, differing only in the three storage options. '
   'hybrid->vector is the primary replacement; control->vector directly measures old-dense residual; '
   'vector-no-promotion->vector is a bounded attribution control. All successful samples and adverse/outliers stay. '
   'No tuning, builds, validation, profiling or evidence archive during timings. OS caches are not flushed. '
   'Single-API close is w1/r1; four-call-thread stages can mix generations. Conversion, regeneration, '
   'public Bean scope checks, result destruction, wait and close remain included. Partial overlapping '
   'diagnostic wait sums are not added to latency. Additive review check binaries link frozen Core; '
   'the added first-phase snapshot preprocesses out identically in all four normal builds.',
  files={str(p):sha(p) for p in sorted(set(paths))},native_manifests=manifests,sweeps=[dict(i,command=command(i)) for i in items])
 frozen_path.write_text(json.dumps(frozen,indent=2)+'\n')
 print('FROZEN '+sha(frozen_path)+' 82 sweeps / 984 processes',flush=True);sys.exit(0)
frozen=json.loads(frozen_path.read_text())
assert frozen['sweeps']==[dict(i,command=command(i)) for i in items]
for path,expected in frozen['files'].items():assert sha(path)==expected,'Frozen input changed: '+path
queue=OUT/'completed.json';completed=json.loads(queue.read_text()) if queue.exists() else []
for item in frozen['sweeps']:
 name=item['name']
 if any(row['name']==name for row in completed):
  assert (OUT/name/'summary.json').is_file();continue
 print('START '+name,flush=True)
 with (OUT/(name+'-launcher.log')).open('w') as log:subprocess.run(item['command'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
 summary=json.loads((OUT/name/'summary.json').read_text());value=summary['metrics']['lifecycle_ms']
 completed.append(dict(item,summary_sha256=sha(OUT/name/'summary.json')));queue.write_text(json.dumps(completed,indent=2)+'\n')
 print('DONE %s lifecycle=%+.2f%% %s (%d/82)'%(name,value['median_change_percent'],value['bootstrap95_percent'],len(completed)),flush=True)
for path,expected in frozen['files'].items():assert sha(path)==expected,'Frozen input changed after measurement: '+path
print('COMPLETE 82 sweeps / 984 fresh processes',flush=True)
