"""Compile the revised lifetime test against each unchanged frozen Core archive."""
import hashlib,json,shlex,shutil,subprocess
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
E=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/vector-descriptors-v1')
OUT=E/'validation/revised-relations'
OUT.mkdir(exist_ok=True)
source=OUT/'relation_checks.cpp'
shutil.copyfile(ROOT/'tools/qaux-benchmark/relation_checks.cpp',source)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
records=[]
for label in ['vector-trace','vector-no-promotion-trace','isolated-vector','vector-sanitized']:
 build=E/'artifacts'/label/'build'
 commands=subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-t','commands','dexkit_relation_checks'],text=True).splitlines()
 compile=next(shlex.split(line) for line in commands if line.endswith(' -c '+str(ROOT/'tools/qaux-benchmark/relation_checks.cpp')))
 link=shlex.split(next(line for line in commands if ' -o Core/dexkit_relation_checks ' in line))
 assert link[:2]==[':','&&'] and link[-2:]==['&&',':']
 link=link[2:-2]
 old_object=compile[compile.index('-o')+1]
 obj=OUT/(label+'.o');exe=OUT/label
 for flag,value in [('-o',obj),('-MT',obj),('-MF',OUT/(label+'.d')),('-c',source)]:compile[compile.index(flag)+1]=str(value)
 link=[str(obj) if token==old_object else token for token in link]
 link[link.index('-o')+1]=str(exe)
 before=sha(build/'Core/libdexkit_static.a')
 for command in [compile,link]: subprocess.run(command,cwd=build,check=True)
 assert sha(build/'Core/libdexkit_static.a')==before
 records.append(dict(label=label,compile=compile,link=link,source_sha256=sha(source),executable_sha256=sha(exe),core_archive_sha256=before,source_commit=subprocess.check_output(['git','-C',ROOT,'rev-parse','HEAD'],text=True).strip()))
 print('BUILT revised checker '+label,flush=True)
(OUT/'builds.json').write_text(json.dumps(records,indent=2)+'\n')
