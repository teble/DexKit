"""Build additive review checks against frozen Core, without changing timed artifacts."""
import hashlib,json,shlex,subprocess
from pathlib import Path
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
E=Path('/Users/teble/project/android/DexKit-benchmark-data/qq-9.3.55/vector-descriptors-v1')
OUT=E/'validation/pro-review-checks';OUT.mkdir(exist_ok=True)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def commands(label,target,source_name):
 build=E/'artifacts'/label/'build'
 lines=subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-t','commands',target],text=True).splitlines()
 comp=next(shlex.split(line) for line in lines if line.endswith(' -c '+str(ROOT/'tools/qaux-benchmark'/source_name)))
 link=shlex.split(next(line for line in lines if ' -o Core/'+target+' ' in line))
 assert link[:2]==[':','&&'] and link[-2:]==['&&',':']
 return build,comp,link[2:-2]
records=[]
for label in ['vector-trace','vector-no-promotion-trace','isolated-vector','vector-sanitized']:
 for target,source_name in [('dexkit_vector_descriptor_checks','vector_descriptor_checks.cpp'),('dexkit_descriptor_transition_workload','descriptor_transition_workload.cpp')]:
  if target.endswith('_workload') and label not in ['vector-trace','vector-no-promotion-trace']:continue
  build,comp,link=commands(label,target,source_name)
  source=OUT/source_name;source.write_bytes((ROOT/'tools/qaux-benchmark'/source_name).read_bytes())
  name=label+'-'+target;obj=OUT/(name+'.o');exe=OUT/name
  old_obj=comp[comp.index('-o')+1]
  for flag,value in [('-o',obj),('-MT',obj),('-MF',OUT/(name+'.d')),('-c',source)]:comp[comp.index(flag)+1]=str(value)
  link=[str(obj) if token==old_obj else token for token in link];link[link.index('-o')+1]=str(exe)
  before=sha(build/'Core/libdexkit_static.a')
  with (OUT/(name+'-compile.log')).open('w') as log:
   for cmd in [comp,link]:subprocess.run(cmd,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
  assert before==sha(build/'Core/libdexkit_static.a')
  records.append(dict(label=label,target=target,compile=comp,link=link,source_sha256=sha(source),executable_sha256=sha(exe),core_archive_sha256=before))
  print('BUILT '+name,flush=True)
(OUT/'builds.json').write_text(json.dumps(records,indent=2)+'\n')
old_source=OUT/'transition-4f7a82c.cpp'
old_source.write_bytes(subprocess.check_output(['git','-C',ROOT,'show','4f7a82c44ab593c9db334e7623e06eede280220c:tools/qaux-benchmark/descriptor_transition_workload.cpp']))
preprocessed=[]
for label in ['control','hybrid','vector','vector-no-promotion']:
 build,comp,_=commands(label,'dexkit_descriptor_transition_workload','descriptor_transition_workload.cpp')
 args=[];skip=False
 for token in comp[:-2]:
  if skip:skip=False;continue
  if token in ['-MT','-MF','-o']:skip=True;continue
  if token=='-MD':continue
  args.append(token)
 hashes=[]
 for source in [old_source,OUT/'descriptor_transition_workload.cpp']:
  text=subprocess.check_output(args+['-E','-P',str(source)],cwd=build)
  hashes.append(hashlib.sha256(text).hexdigest())
 assert hashes[0]==hashes[1],(label,hashes)
 preprocessed.append(dict(label=label,sha256=hashes[0],command=args,old_source_sha256=sha(old_source),new_source_sha256=sha(OUT/'descriptor_transition_workload.cpp')))
(OUT/'normal-preprocessed-equality.json').write_text(json.dumps(preprocessed,indent=2)+'\n')
print('PROVED unchanged normal transition source for all four artifacts',flush=True)
