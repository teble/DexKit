import hashlib,json,os,subprocess
from cases import BASE,E,CASES,native_command
OUT=E/'validation/pro-review-checks'
records=[]
fixture=BASE/'followup/fixtures/dense-descriptors/dense-descriptors.apk'
for label in ['vector-trace','vector-no-promotion-trace','isolated-vector','vector-sanitized']:
 exe=OUT/(label+'-dexkit_vector_descriptor_checks');log=OUT/(label+'-checks.log')
 env=os.environ.copy();env['ASAN_OPTIONS']='detect_leaks=0';env['UBSAN_OPTIONS']='halt_on_error=1'
 with log.open('w') as out:subprocess.run([str(exe),str(fixture)],env=env,stdout=out,stderr=subprocess.STDOUT,timeout=180,check=True)
 assert '"passed":true' in log.read_text()
 records.append(dict(label=label,command=[str(exe),str(fixture)],sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
 print('PASS reviewed worker checks '+label,flush=True)
phases=[]
for label in ['vector-trace','vector-no-promotion-trace']:
 for name in ['method-full-w4','low-id-w4','method-changed-2']:
  case=next(case for case in CASES if case['name']==name)
  cmd=native_command(label,case);cmd[0]=OUT/(label+'-dexkit_descriptor_transition_workload');cmd=list(map(str,cmd))
  log=OUT/(label+'-'+name+'.log')
  with log.open('w') as out:subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,timeout=180,check=True)
  rows=[json.loads(line[len('BENCH_VECTOR_DESCRIPTOR_DOMAIN '):]) for line in log.read_text().splitlines() if line.startswith('BENCH_VECTOR_DESCRIPTOR_DOMAIN ')]
  first=[r for r in rows if r['phase']=='transition-first-complete']
  last=[r for r in rows if r['phase']=='transition-workload-complete']
  assert len(first)==len(last)==2
  for row in first+last:assert row['calls']-row['hits']==row['sparse_builds']+row['dense_builds']
  if name=='method-changed-2':
   f=next(r for r in first if r['kind']=='method');l=next(r for r in last if r['kind']=='method')
   assert f['records']==30000 and f['conversions']==0
   if label=='vector-trace':assert f['pending'] and l['conversions']==1 and l['discarded_records']==l['dense_builds']==30000
  phases.append(dict(label=label,case=name,command=cmd,first=first,last=last,sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
  print('PASS first-phase snapshot '+label+' '+name,flush=True)
(OUT/'checks.json').write_text(json.dumps(records,indent=2)+'\n')
(OUT/'phases.json').write_text(json.dumps(phases,indent=2)+'\n')
print('COMPLETE 4 worker checks + 6 phase checks',flush=True)
