"""Reconcile all fixed samples and verification evidence without exclusions."""
import hashlib,json,random,subprocess
from pathlib import Path
from cases import E,LABELS
ROOT=Path('/Users/teble/project/android/DexKit-qaux-benchmark')
M,V=E/'measurements',E/'validation'
def read(path):return json.loads(path.read_text())
def sha(path):
 value=hashlib.sha256()
 with Path(path).open('rb') as stream:
  for block in iter(lambda:stream.read(1024*1024),b''):value.update(block)
 return value.hexdigest()
frozen,completed=read(M/'frozen-plan.json'),read(M/'completed.json')
assert len(completed)==len(frozen['sweeps'])==82
assert [r['name'] for r in completed]==[r['name'] for r in frozen['sweeps']]
for path,expected in frozen['files'].items():assert sha(path)==expected,path
cases={};sweeps=[];total=0
for item in completed:
 directory=M/item['name'];summary,samples=read(directory/'summary.json'),read(directory/'samples.json')
 assert sha(directory/'summary.json')==item['summary_sha256'] and len(samples)==12
 order=[i%2 for i in range(6)];random.Random(item['seed']).shuffle(order)
 assert summary['reversed_order']==order
 for pair in range(6):
  rows=sorted([r for r in samples if r['pair']==pair],key=lambda r:r['position'])
  assert [r['label'] for r in rows]==(list(reversed(item['labels'])) if order[pair] else item['labels'])
  if item['kind']=='qq':
   for row in rows:
    metadata=read(directory/f'pair-{pair:02d}-{row["label"]}'/'run-metadata.json')
    assert metadata['exit_code']==0 and metadata['baseline_counts_and_flow_equal'] is True
    assert metadata['repeat_results_equal'] is (True if item['passes']>1 else None)
    assert metadata['native_sha256']==frozen['native_manifests'][row['label']]['native_sha256']
    assert metadata['passes']==item['passes'] and metadata['threads']==item['threads']
  else:
   identities={(r['report']['mode'],r['report']['repeats'],r['report']['checksum'],r['report']['returned']) for r in rows}
   assert len(identities)==1
   if item['mode'].startswith('transition-'):
    _,kind,pattern,workers=item['mode'].split('-');n=item['repeats'];w=int(workers[1:]);length=14 if kind=='method' else 13
    ids=list(range(60000 if pattern=='full' else 30000 if pattern=='changed' else 64))
    if pattern=='low':ids=[i*911%60000 for i in ids]
    later=[i+30000 for i in ids] if pattern=='changed' else ids
    for r in rows:
     q=r['report'];assert q['kind']==kind and q['pattern']==pattern and q['calling_threads']==w
     assert q['returned']==w*len(ids)*n
     assert q['checksum']==w*(sum(ids)+len(ids)*length+(n-1)*(sum(later)+len(later)*length))
     if n==1:assert q['repeated_ns']==0
 total+=len(samples)
 cases.setdefault(item['name'].split('-',1)[1],{})[item['phase']]=summary['metrics']
 sweeps.append(dict(item,raw_summary=str(directory/'summary.json'),raw_samples=str(directory/'samples.json')))
assert total==984 and len(cases)==41 and all(set(p)=={'main','confirm'} for p in cases.values())
counts={}
for phase in ['normal','trace','isolated','sanitize']:
 records=read(V/('checks-'+phase+'.json'))
 assert read(V/('complete-'+phase+'.json'))['checks_sha256']==sha(V/('checks-'+phase+'.json'))
 for r in records:
  path=V/(r['name']+('.bin' if r['binary'] else '.log'))
  assert sha(path)==r['output_sha256'] and r['exit_code'] in [0,-6]
 counts[phase]=len(records)
assert sum(counts.values())==219
qq=[]
for r in read(V/'qq-verification.json'):
 metadata=read(V/r['name']/'run-metadata.json')
 assert r['passed'] and metadata['exit_code']==0 and metadata['baseline_results_equal'] is True
 qq.append(dict(name=r['name'],passes=metadata['passes'],threads=metadata['threads'],native_sha256=metadata['native_sha256']))
for r in read(V/'census-checks.json'):
 assert sha(V/(r['name']+'.log'))==r['sha256']
 if r['name'].startswith('verify-'):
  metadata=read(V/r['name']/'run-metadata.json')
  assert metadata['exit_code']==0 and metadata['baseline_results_equal'] is True
  if '-tail-' in r['name']:assert metadata['final_field_rw_results_equal'] is True
  qq.append(dict(name=r['name'],passes=metadata['passes'],threads=metadata['threads'],native_sha256=metadata['native_sha256'],field_tail=metadata.get('final_field_rw_results_equal')))
assert len(qq)==12
review=read(V/'pro-review-checks/checks.json');phase_checks=read(V/'pro-review-checks/phases.json')
assert len(review)==4 and len(phase_checks)==6
for r in review:assert sha(V/'pro-review-checks'/(r['label']+'-checks.log'))==r['sha256']
for r in phase_checks:assert sha(V/'pro-review-checks'/(r['label']+'-'+r['case']+'.log'))==r['sha256']
gradle=read(V/'gradle/validation.json')
assert gradle['total_tests']==71 and gradle['skipped']==0 and len(gradle['abis'])==4
assert all(int(r['failures'])==int(r['errors'])==int(r['skipped'])==0 for r in gradle['tests'])
validation=dict(engine_commit=frozen['normal_engine_commit'],native_driver_commands=counts,native_driver_total=219,
 additional_worker_checks=4,additional_phase_checks=6,workload_smoke_commands=72,qq=qq,native_census_commands=36,
 gradle=gradle,codegen=read(V/'codegen.json'),abi_layouts=read(V/'layout/summary.json'),
 review_builds=read(V/'pro-review-checks/builds.json'),normal_transition_preprocessed_equality=read(V/'pro-review-checks/normal-preprocessed-equality.json'),
 revised_relation_builds=read(V/'revised-relations/builds.json'),
 limitations=['ASan/UBSan host execution disables leak detection; Android evidence is build-only.',
  'Non-owning native contexts require live sessions and completed worker/view/destructor use.',
  'Partial overlapping entrant wait sums are not complete wall time.',
  'The old dense-fixture check holds a sparse generation; separate second-API checks exercise actual dense storage.',
  'Four calling threads do four times the work and may mix generations during their first phase.',
  'A field full r1 case does not convert; its measured cost is sparse fill, API entry, output and close.',
  'Preflight/development timings are not included in the fixed 984-process batch.'])
(V/'validation-summary.json').write_text(json.dumps(validation,indent=2)+'\n')
confirmed={}
for metric in ['lifecycle_ms','pass0_api_ms','repeated_api_ms','close_ms','peak_footprint_bytes']:
 confirmed[metric]={}
 for edge in ['hybrid-to-vector','control-to-vector','vector-no-promotion-to-vector']:
  selected={name:p for name,p in cases.items() if name.startswith(edge+'-') and all(metric in m for m in p.values())}
  confirmed[metric][edge]={key:[name[len(edge)+1:] for name,p in selected.items() if all(predicate(m[metric]['bootstrap95_percent']) for m in p.values())]
   for key,predicate in [('benefit',lambda interval:interval[1]<0),('regression',lambda interval:interval[0]>0)]}
result=dict(engine_commit=frozen['normal_engine_commit'],harness_commit=frozen['worktree_head'],frozen_plan_sha256=sha(M/'frozen-plan.json'),
 accepted_sweeps=82,accepted_fresh_processes=984,excluded_measurements=0,frozen_inputs_unchanged=True,
 host=dict(cpu=subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True).strip(),os=subprocess.check_output(['sw_vers'],text=True).strip()),
 native_libraries={label:dict(bytes=(E/'artifacts'/label/'libdexkit.dylib').stat().st_size,sha256=manifest['native_sha256']) for label,manifest in frozen['native_manifests'].items()},
 validation=validation,confirmed=confirmed,cases=cases,sweeps=sweeps)
(E/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(host=result['host'],lifecycle=confirmed['lifecycle_ms'],peak=confirmed['peak_footprint_bytes']),indent=2))
for name,p in cases.items():
 print(name)
 for metric in ['lifecycle_ms','pass0_api_ms','repeated_api_ms','close_ms','peak_footprint_bytes']:
  if all(metric in p[phase] for phase in ['main','confirm']):
   print(' ',metric,' / '.join('%+.2f%% [%+.2f,%+.2f]'%(p[phase][metric]['median_change_percent'],*p[phase][metric]['bootstrap95_percent']) for phase in ['main','confirm']))
print('COMPLETE 82 sweeps / 984 samples, all frozen inputs and successful samples reconciled')
