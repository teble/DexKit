	.text
	.syntax unified
	.eabi_attribute	67, "2.09"	@ Tag_conformance
	.eabi_attribute	6, 10	@ Tag_CPU_arch
	.eabi_attribute	7, 65	@ Tag_CPU_arch_profile
	.eabi_attribute	8, 1	@ Tag_ARM_ISA_use
	.eabi_attribute	9, 2	@ Tag_THUMB_ISA_use
	.fpu	neon
	.eabi_attribute	34, 1	@ Tag_CPU_unaligned_access
	.eabi_attribute	15, 1	@ Tag_ABI_PCS_RW_data
	.eabi_attribute	16, 1	@ Tag_ABI_PCS_RO_data
	.eabi_attribute	17, 2	@ Tag_ABI_PCS_GOT_use
	.eabi_attribute	20, 2	@ Tag_ABI_FP_denormal
	.eabi_attribute	21, 0	@ Tag_ABI_FP_exceptions
	.eabi_attribute	23, 3	@ Tag_ABI_FP_number_model
	.eabi_attribute	24, 1	@ Tag_ABI_align_needed
	.eabi_attribute	25, 1	@ Tag_ABI_align_preserved
	.eabi_attribute	38, 1	@ Tag_ABI_FP_16bit_format
	.eabi_attribute	18, 4	@ Tag_ABI_PCS_wchar_t
	.eabi_attribute	26, 2	@ Tag_ABI_enum_size
	.eabi_attribute	14, 0	@ Tag_ABI_PCS_R9_use
	.file	"layout.cpp"
	.type	actual_cache,%object            @ @actual_cache
	.bss
	.globl	actual_cache
actual_cache:
	.zero	5456
	.size	actual_cache, 5456

	.type	actual_sparse,%object           @ @actual_sparse
	.globl	actual_sparse
actual_sparse:
	.zero	5456
	.size	actual_sparse, 5456

	.type	normal_payload,%object          @ @normal_payload
	.globl	normal_payload
normal_payload:
	.zero	32
	.size	normal_payload, 32

	.type	reported_fixed,%object          @ @reported_fixed
	.globl	reported_fixed
reported_fixed:
	.zero	2756
	.size	reported_fixed, 2756

	.type	actual_payload,%object          @ @actual_payload
	.globl	actual_payload
actual_payload:
	.zero	32
	.size	actual_payload, 32

	.section	".linker-options","e",%llvm_linker_options
	.ident	"Android (10552028, +pgo, +bolt, +lto, -mlgo, based on r487747d) clang version 17.0.2 (https://android.googlesource.com/toolchain/llvm-project d9f89f4d16663d5012e5c09495f3b30ece3d2362)"
	.section	".note.GNU-stack","",%progbits
