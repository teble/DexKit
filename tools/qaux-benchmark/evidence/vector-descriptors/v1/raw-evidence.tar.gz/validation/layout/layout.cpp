#include "vector_descriptor_cache.h"
extern "C" {
char actual_cache[sizeof(dexkit::VectorDescriptorCache<true>)];
char actual_sparse[sizeof(dexkit::VectorDescriptorCache<false>)];
char normal_payload[sizeof(std::deque<std::string, dexkit::vector_descriptor_detail::SparseAllocator<std::string>>)];
#if DEXKIT_BENCHMARK_DIAGNOSTICS
char reported_fixed[dexkit::VectorDescriptorCache<true>::FixedObjectBytes()];
char actual_payload[sizeof(std::deque<std::string, dexkit::vector_descriptor_detail::SparseAllocator<std::string>>)];
#else
char reported_fixed[sizeof(dexkit::VectorDescriptorCache<true>)];
char actual_payload[sizeof(std::deque<std::string, dexkit::vector_descriptor_detail::SparseAllocator<std::string>>)];
#endif
}
